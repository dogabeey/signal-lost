import{A as e,B as t,C as n,D as r,E as i,F as a,H as o,I as s,L as c,M as l,N as u,O as d,P as f,R as p,S as ee,T as m,V as h,_ as te,a as g,b as ne,c as re,d as ie,f as ae,g as oe,h as se,i as ce,j as le,k as ue,l as de,m as fe,n as pe,o as me,p as he,r as ge,s as _e,t as ve,u as ye,v as be,w as _,x as xe,y as Se,z as Ce}from"./three-jd-Tqq7K.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var v={maxPixelRatio:2,difficultyPressureMultiplier:.88,obstacleSpawnCount:2,arenaSize:26,arenaLimit:12,playerSpeed:5,playerStartHeight:.75,playerRadius:1.05,cellPickupRadius:1.15,cellCashValue:1,baseCellCashValue:1,initialCellCount:5,initialObstacleTypes:[`regular`,`chaser`,`creeper`],cellSpawnInterval:5,cellMagnetRange:4,cellMagnetBaseSpeed:.8,boosterSpawnInterval:18,speedBoosterBaseDuration:5,thornShieldBaseDuration:4,freezerBaseDuration:3,pushbackBaseRange:3.5,pushbackBaseSpeed:.7,slowAuraBaseRange:4,slowAuraBaseEffect:.25,orbitalElectronOrbitRadius:3.5,orbitalElectronBaseSpeed:2.1,orbitalElectronBaseStunDuration:.65,orbitalElectronHitRadius:.28,cellMinDistance:3,chronoCellSpawnInterval:20,chronoCellLifetime:9,chronoCellMinDistance:4,chronoCellChronoshardValue:1,obstacleMinDistance:4,obstacleColliderRadius:.86,obstacleColliderIterations:2,creeperStaticCollisionSlowDuration:.35,creeperStaticCollisionSpeedMultiplier:.45,obstacleSpawnInterval:7.85,obstacleSpawnDecreasePerCell:.07,regularObstacleLifetime:32,regularObstacleLifetimeIncreasePerCell:.14,obstacleDespawnWarningDuration:2,obstacleDespawnWarningStartFrequency:1.2,obstacleDespawnWarningEndFrequency:10,obstacleSpawnWarningDuration:2,bangerExplosionVfxDuration:.65,bangerPulseStartInterval:.9,bangerPulseEndInterval:.1,bangerPulseVfxDuration:.55,fallingBlockStartHeight:16,obstacleGroundHeight:.86,fallingBlockGroundHeight:.86,fallingBlockDuration:1.8,fallingBlockLifetime:1.9,fallingBlockMinInterval:1.8,fallingBlockBaseInterval:24,fallingRockSpawnFrequencyMultiplier:.75,fallingBlockIntervalPerCell:.1,fallingRockImpactOffset:.8,fieryRockFireDuration:5,fieryRockFireRadius:1.7,poisonTrailDuration:5.5,fieryRockFlameCount:9,fieryRockEmberCount:12,splinterPieceCount:4,splinterPieceDistance:8,splinterPieceDuration:1,shockwaveBaseRadius:4.5,shockwaveBaseInterval:8,shockwavePushDistance:4.5,shockwaveVfxDuration:.65,shieldInvulnerabilityDuration:1,playerDeathVfxDuration:.9},we={sector1:{extraArenaPadding:0,cellsRequiredToAdvance:30,cashValueMultiplier:1,availableObstacleTypes:[`regular`,`creeper`],maxActiveEnemies:10,maxActiveEnemiesIncrementPerCell:.03,obstacleSpawnCountOffset:0,obstacleSpawnCountIncreasePerCell:.035,obstacleSpawnIntervalOffset:1.8,obstacleSpawnDecreasePerCellOffset:.002,obstacleLifetimeOffset:-7,obstacleLifetimeIncreasePerCellOffset:-.03,regularSpawnWeight:.7,creeperSpawnWeight:.3,availableFallingRockTypes:[`stoneRock`],fallingRockSpawnIntervalOffset:1.5,fallingRockSpawnDecreasePerCellOffset:-.04,stoneRockSpawnWeight:1},sector2:{extraArenaPadding:1,cellsRequiredToAdvance:100,cashValueMultiplier:2,availableObstacleTypes:[`regular`,`chaser`,`creeper`],maxActiveEnemies:11,maxActiveEnemiesIncrementPerCell:.04,obstacleSpawnCountOffset:1,obstacleSpawnCountIncreasePerCell:.047,obstacleSpawnIntervalOffset:.6,obstacleSpawnDecreasePerCellOffset:.014,obstacleLifetimeOffset:-4.8,obstacleLifetimeIncreasePerCellOffset:.012,regularSpawnWeight:.6,chaserSpawnWeight:.2,creeperSpawnWeight:.2,availableFallingRockTypes:[`stoneRock`,`splinter`],fallingRockSpawnIntervalOffset:-5.8,fallingRockSpawnDecreasePerCellOffset:-.01,stoneRockSpawnWeight:.8,splinterSpawnWeight:.2},sector3:{extraArenaPadding:2,cellsRequiredToAdvance:200,cashValueMultiplier:4,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:13,maxActiveEnemiesIncrementPerCell:.05,obstacleSpawnCountOffset:2,obstacleSpawnCountIncreasePerCell:.06,obstacleSpawnIntervalOffset:-.4,obstacleSpawnDecreasePerCellOffset:.025,obstacleLifetimeOffset:-2.4,obstacleLifetimeIncreasePerCellOffset:.032,regularSpawnWeight:.6,chaserSpawnWeight:.1,creeperSpawnWeight:.1,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-11,fallingRockSpawnDecreasePerCellOffset:.015,stoneRockSpawnWeight:.6,fieryRockSpawnWeight:.2,splinterSpawnWeight:.2},sector4:{extraArenaPadding:3,cellsRequiredToAdvance:300,cashValueMultiplier:8,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:14,maxActiveEnemiesIncrementPerCell:.06,obstacleSpawnCountOffset:3,obstacleSpawnCountIncreasePerCell:.072,obstacleSpawnIntervalOffset:-.9,obstacleSpawnDecreasePerCellOffset:.03,obstacleLifetimeOffset:-.2,obstacleLifetimeIncreasePerCellOffset:.052,regularSpawnWeight:.5,chaserSpawnWeight:.16,creeperSpawnWeight:.14,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-16.2,fallingRockSpawnDecreasePerCellOffset:.065,stoneRockSpawnWeight:.4,fieryRockSpawnWeight:.35,splinterSpawnWeight:.25},sector5:{extraArenaPadding:4,cellsRequiredToAdvance:300,cashValueMultiplier:16,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`],maxActiveEnemies:16,maxActiveEnemiesIncrementPerCell:.07,obstacleSpawnCountOffset:5,obstacleSpawnCountIncreasePerCell:.085,obstacleSpawnIntervalOffset:-1.9,obstacleSpawnDecreasePerCellOffset:.042,obstacleLifetimeOffset:2,obstacleLifetimeIncreasePerCellOffset:.076,regularSpawnWeight:.42,chaserSpawnWeight:.2,creeperSpawnWeight:.15,bangerSpawnWeight:.12,shooterSpawnWeight:.11,porterSpawnWeight:.08,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-18.4,fallingRockSpawnDecreasePerCellOffset:.088,stoneRockSpawnWeight:.3,fieryRockSpawnWeight:.42,splinterSpawnWeight:.28},sector6:{extraArenaPadding:5,cellsRequiredToAdvance:300,cashValueMultiplier:32,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`],maxActiveEnemies:17,maxActiveEnemiesIncrementPerCell:.08,obstacleSpawnCountOffset:6,obstacleSpawnCountIncreasePerCell:.097,obstacleSpawnIntervalOffset:-2.8,obstacleSpawnDecreasePerCellOffset:.054,obstacleLifetimeOffset:4.2,obstacleLifetimeIncreasePerCellOffset:.1,regularSpawnWeight:.34,chaserSpawnWeight:.23,creeperSpawnWeight:.16,bangerSpawnWeight:.14,shooterSpawnWeight:.13,porterSpawnWeight:.1,magnetSpawnWeight:.09,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-20.6,fallingRockSpawnDecreasePerCellOffset:.112,stoneRockSpawnWeight:.24,fieryRockSpawnWeight:.47,splinterSpawnWeight:.29},sector7:{extraArenaPadding:6,cellsRequiredToAdvance:300,cashValueMultiplier:64,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:19,maxActiveEnemiesIncrementPerCell:.09,obstacleSpawnCountOffset:7,obstacleSpawnCountIncreasePerCell:.11,obstacleSpawnIntervalOffset:-3.7,obstacleSpawnDecreasePerCellOffset:.066,obstacleLifetimeOffset:6.6,obstacleLifetimeIncreasePerCellOffset:.124,regularSpawnWeight:.28,chaserSpawnWeight:.26,creeperSpawnWeight:.17,bangerSpawnWeight:.15,shooterSpawnWeight:.14,porterSpawnWeight:.11,magnetSpawnWeight:.11,sporeSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-22.7,fallingRockSpawnDecreasePerCellOffset:.136,stoneRockSpawnWeight:.18,fieryRockSpawnWeight:.51,splinterSpawnWeight:.31},sector8:{extraArenaPadding:7,cellsRequiredToAdvance:300,cashValueMultiplier:128,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:20,maxActiveEnemiesIncrementPerCell:.1,obstacleSpawnCountOffset:8,obstacleSpawnCountIncreasePerCell:.123,obstacleSpawnIntervalOffset:-4.6,obstacleSpawnDecreasePerCellOffset:.078,obstacleLifetimeOffset:9.2,obstacleLifetimeIncreasePerCellOffset:.148,regularSpawnWeight:.22,chaserSpawnWeight:.29,creeperSpawnWeight:.18,bangerSpawnWeight:.16,shooterSpawnWeight:.15,porterSpawnWeight:.12,magnetSpawnWeight:.13,sporeSpawnWeight:.12,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-24.5,fallingRockSpawnDecreasePerCellOffset:.16,stoneRockSpawnWeight:.14,fieryRockSpawnWeight:.54,splinterSpawnWeight:.32},sector9:{extraArenaPadding:8,cellsRequiredToAdvance:400,cashValueMultiplier:256,availableObstacleTypes:[`regular`,`chaser`,`poisonCreeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:22,maxActiveEnemiesIncrementPerCell:.11,obstacleSpawnCountOffset:9,obstacleSpawnCountIncreasePerCell:.14,obstacleSpawnIntervalOffset:-5.4,obstacleSpawnDecreasePerCellOffset:.09,obstacleLifetimeOffset:12,obstacleLifetimeIncreasePerCellOffset:.17,regularSpawnWeight:.18,chaserSpawnWeight:.3,poisonCreeperSpawnWeight:.2,bangerSpawnWeight:.17,shooterSpawnWeight:.16,porterSpawnWeight:.14,magnetSpawnWeight:.14,sporeSpawnWeight:.14,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-26,fallingRockSpawnDecreasePerCellOffset:.18,stoneRockSpawnWeight:.1,fieryRockSpawnWeight:.56,splinterSpawnWeight:.34}},y={background:`#101b25`,floor:`#1d3a46`,gridMajor:`#50e5bc`,gridMinor:`#244b59`,arenaBoundary:`#ff795f`,player:`#67d46e`,playerEmissive:`#1d7437`,playerWing:`#9af08f`,playerWingEmissive:`#2f8b42`,playerRing:`#d7ffb8`,cell:`#63f5cd`,cellEmissive:`#00b487`,chronoCell:`#b59aff`,chronoCellEmissive:`#5933c7`,slowAura:`#63f5cd`,obstacle:`#41687c`,obstacleEmissive:`#07141d`,chaser:`#c36b55`,chaserEmissive:`#70281d`,creeper:`#8d71c5`,creeperEmissive:`#38265c`,poisonCreeper:`#215c3a`,poisonCreeperEmissive:`#0b3d25`,poisonTrail:`#75df65`,banger:`#ffb347`,bangerEmissive:`#8f3100`,shooter:`#63f58a`,shooterEmissive:`#086b35`,porter:`#4ba3ff`,porterEmissive:`#124b9e`,magnet:`#050505`,magnetEmissive:`#171717`,spore:`#ff8fd0`,sporeEmissive:`#9b145f`,fallingObstacle:`#66869a`,fallingObstacleEmissive:`#152b3b`,fieryRock:`#ff6948`,fieryRockEmissive:`#b11d08`,splinter:`#d2c27e`,splinterEmissive:`#675b25`,fire:`#ff8a38`,targetShadow:`#020407`,targetRing:`#ff795f`},Te={fov:52,near:.1,far:100,angle:53,distance:15,portraitDistanceMultiplier:1.2,followStrength:.06},Ee={floorMetalness:.5,floorRoughness:.55,floorOpacity:.76,starCount:720,brightStarCount:70,starfieldRadius:70,starSize:1.55,brightStarSize:3.1},De={hemisphereSky:`#b8e8ff`,hemisphereGround:`#0a1016`,hemisphereIntensity:2.2,key:`#fff4cf`,keyIntensity:3},b={playerCoreRadius:.7,playerCoreDetail:1,playerCoreEmissiveIntensity:1.4,playerCoreMetalness:.35,playerCoreRoughness:.25,playerRingRadius:.92,playerRingTube:.07,playerRingRadialSegments:10,playerRingTubularSegments:32,cellRadius:.42,chronoCellRadius:.52,chronoCellEmissiveIntensity:2.4,obstacleRadius:.86,fallingRockDetail:1,obstacleCoreRadius:.48,obstacleSpikeRadius:.2,obstacleSpikeHeight:.68,obstacleSpikeSegments:5,cellEmissiveIntensity:1.8,cellMetalness:.08,cellRoughness:.48,obstacleMetalness:.6,obstacleRoughness:.3,fallingObstacleEmissiveIntensity:.8,fallingObstacleMetalness:.65,fallingObstacleRoughness:.25,chaserRangeIndicatorWidth:.08,chaserRangeIndicatorSegments:64,chaserRange:3.5,bangerRangeMultiplier:1.5,bangerFuseDuration:3,shooterRangeMultiplier:2,shooterProjectileRadius:.24,shooterProjectileSpeed:5.25,shooterProjectileLifetime:2.4,shooterProjectileCooldown:2,porterTeleportInterval:10,porterWarningDuration:2,porterTeleportMinDistance:3,porterTeleportMaxDistance:7,magnetPullSpeed:1.1,sporeFuseDuration:3,sporeFragmentCount:4,sporeFragmentChildCount:4,sporeFragmentDuration:1.35,sporeFragmentSpeed:4.6,sporeFragmentScale:.42,sporeFragmentChildScale:.18,poisonCreeperTrailInterval:.42,poisonCreeperTrailRadius:.9,spawnRingInnerRadius:.38,spawnRingOuterRadius:.5,spawnRingSegments:32,spawnCueGlowRadius:1.45,spawnCueBeamHeight:3.2,slowAuraRingWidth:.1,slowAuraRingSegments:64},x={playerTurnSpeed:1.4,playerCoreSpinSpeed:1.8,playerRingSpinSpeed:2.4,cellSpinSpeed:2.2,cellBobBaseHeight:.8,cellBobAmplitude:.16,cellBobSpeed:2.4,chronoCellSpinSpeed:3.6,chronoCellBobSpeed:3.2,chronoCellBobAmplitude:.24,obstacleBobBaseHeight:.72,obstacleBobAmplitude:.12,obstacleBobSpeed:1.8,fallingObstacleSpinXSpeed:3,fallingObstacleSpinZSpeed:2,targetShadowBaseScale:.38,targetShadowScaleGrowth:.9,targetShadowBaseOpacity:.32,targetShadowOpacityGrowth:.56,targetRingPulseSpeed:12,targetRingPulseAmount:.1,targetRingBaseScale:.82,targetRingScaleGrowth:.62,targetRingBaseOpacity:.95,targetRingOpacityFade:.4,chaserRangeIndicatorBaseOpacity:.24,chaserRangeIndicatorActiveOpacity:.7,chaserRangeIndicatorPulseSpeed:7,chaserRangeIndicatorPulseAmount:.1,bangerFusePulseSpeed:9,bangerFuseEmissiveBaseIntensity:.45,bangerFuseEmissivePulseAmount:.9,spawnRingBaseScale:.7,spawnRingScaleGrowth:1,spawnRingPulseSpeed:15,spawnRingPulseAmount:.12,spawnRingBaseOpacity:.9,spawnCueGlowBaseOpacity:.2,spawnCueGlowPulseAmount:.14,spawnCueBeamBaseOpacity:.26},Oe={masterVolume:.16,bangerPulseVolume:.32,fallingObstacleVolume:.82,cellCollectVolume:.26,obstacleSummonVolume:.17,buttonClickVolume:.2,spatialMaxDistance:24,spatialMinGain:.04,fallback:{bangerPulse:{startFrequency:180,endFrequency:860,duration:.055,type:`square`},fallingObstacle:{duration:v.fallingBlockDuration},cellCollect:{startFrequency:540,endFrequency:960,duration:.13,type:`triangle`},obstacleSummon:{startFrequency:130,endFrequency:310,duration:2,type:`sine`},buttonClick:{startFrequency:440,endFrequency:660,duration:.07,type:`square`}},assets:{bangerPulse:`./audio/banger-pulse.wav`,fallingObstacle:`./audio/falling-obstacle.wav`,cellCollect:`./audio/cell-collect.wav`,obstacleSummon:`./audio/obstacle-summon.wav`,buttonClick:`./audio/button-click.wav`}},ke={regular:{color:y.obstacle,emissive:y.obstacleEmissive,speed:0,range:0},chaser:{color:y.chaser,emissive:y.chaserEmissive,speed:v.playerSpeed/2,range:b.chaserRange},creeper:{color:y.creeper,emissive:y.creeperEmissive,speed:v.playerSpeed/4,range:1/0},banger:{color:y.banger,emissive:y.bangerEmissive,speed:0,range:b.chaserRange*b.bangerRangeMultiplier},shooter:{color:y.shooter,emissive:y.shooterEmissive,speed:0,range:b.chaserRange*b.shooterRangeMultiplier},porter:{color:y.porter,emissive:y.porterEmissive,speed:0,range:0},magnet:{color:y.magnet,emissive:y.magnetEmissive,speed:0,range:b.chaserRange},spore:{color:y.spore,emissive:y.sporeEmissive,speed:0,range:0},poisonCreeper:{color:y.creeper,emissive:y.creeperEmissive,speed:v.playerSpeed/4,range:1/0}},Ae={stoneRock:{name:`Stone Rock`,color:y.fallingObstacle,emissive:y.fallingObstacleEmissive,emissiveIntensity:b.fallingObstacleEmissiveIntensity},fieryRock:{name:`Fiery Rock`,color:y.fieryRock,emissive:y.fieryRockEmissive,emissiveIntensity:2.1},splinter:{name:`Splinter`,color:y.splinter,emissive:y.splinterEmissive,emissiveIntensity:1.2}},je=`language.english: "English"\r
language.turkish: "Turkish"\r
language.spanish: "Spanish"\r
settings.language: "Language"\r
settings.language_help: "Choose the language used by the game interface."\r
save_slots.heading: "SELECT SAVE SLOT"\r
save_slots.archive: "COMMAND ARCHIVE"\r
save_slots.description: "Choose a pilot archive to continue your expedition."\r
save_slots.slot: "SLOT {slot}"\r
save_slots.new_expedition: "NEW EXPEDITION"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MAX CELLS"\r
save_slots.total_cash: "TOTAL CASH"\r
save_slots.total_chronoshards: "TOTAL CHRONOSHARDS"\r
research.category.player_enhancements: "Player Enhancements"\r
research.category.economy: "Economy"\r
research.category.boosters: "Boosters"\r
research.category.weapons: "Weapons"\r
research.category.building_system: "Building System"\r
research.category.enemy_debuff: "Enemy Debuff"\r
research.lucky-find.name: "Lucky Find"\r
research.lucky-find.description: "Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1."\r
research.weapon-recharge.name: "Weapon Recharge"\r
research.weapon-recharge.description: "Weapons are now capable of recharging over time."\r
research.weapon-recharge-rate.name: "Weapon Recharge Rate"\r
research.weapon-recharge-rate.description: "Reduces weapon recharge time."\r
research.weapon-charge-capacity.name: "Weapon Charge Capacity"\r
research.weapon-charge-capacity.description: "Increases the maximum stored charges for each equipped weapon by 1."\r
research.weapon-slots.name: "Weapon Slot"\r
research.weapon-slots.description: "Adds one weapon slot to your round loadout."\r
research.player-speed-multiplier.name: "Player Speed Multiplier"\r
research.player-speed-multiplier.description: "Increases player movement speed."\r
research.unlock-slow-aura.name: "Unlock Slow Aura"\r
research.unlock-slow-aura.description: "Unlocks the Slow Aura ability, which slows down nearby enemies within the range."\r
research.unlock-orbital-electron.name: "Unlock Orbital Electron"\r
research.unlock-orbital-electron.description: "Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc."\r
research.electron-stun-duration.name: "Electron Stun Duration"\r
research.electron-stun-duration.description: "Increases how long enemies hit by the Orbital Electron are stunned."\r
research.electron-speed.name: "Electron Speed"\r
research.electron-speed.description: "Increases Orbital Electron orbit speed."\r
research.slow-aura-effect.name: "Slow Aura Effect"\r
research.slow-aura-effect.description: "Increases the effect of the Slow Aura ability."\r
research.slow-aura-range.name: "Effect Range"\r
research.slow-aura-range.description: "Increases the range of every active range-based effect."\r
research.cell-spawn-rate.name: "Cell Spawn Rate"\r
research.cell-spawn-rate.description: "Increases the spawn rate of standard cells."\r
research.cell-increment-per-cell.name: "Cell Increment Per Cell"\r
research.cell-increment-per-cell.description: "Each collected Cell increases the standard Cell spawn rate."\r
research.cash-cell-multiplier.name: "Cash/Cell Multiplier"\r
research.cash-cell-multiplier.description: "Increases the Cash earned from every standard cell."\r
research.initial-cell-count.name: "Initial Cell"\r
research.initial-cell-count.description: "Adds one Cell to the arena at the start of every run."\r
research.cell-magnet.name: "Cell Magnet"\r
research.cell-magnet.description: "Pulls nearby Cells toward you. Each level increases pull speed."\r
research.chrono-spawn-rate.name: "Chrono Spawn Rate"\r
research.chrono-spawn-rate.description: "Makes Chrono Cells appear more frequently."\r
research.chrono-lifetime-multiplier.name: "Chrono Lifetime Multiplier"\r
research.chrono-lifetime-multiplier.description: "Increases the lifetime of Chrono Cells."\r
research.unlock-shockwave.name: "Unlock Shockwave"\r
research.unlock-shockwave.description: "Periodically emits a green shockwave that pushes enemies away."\r
research.shockwave-frequency.name: "Shockwave Frequency"\r
research.shockwave-frequency.description: "Makes Shockwaves trigger more frequently."\r
research.shield.name: "Shield"\r
research.shield.description: "Grants one death save per level at the start of every run."\r
research.building-slots.name: "Building Slots"\r
research.building-slots.description: "Increases the number of buildings you can place in the arena by 1."\r
research.unlock-speed-booster.name: "Unlock Speed Boosters"\r
research.unlock-speed-booster.description: "Unlocks Speed Booster pickups that double movement speed."\r
research.speed-booster-duration.name: "Speed Booster Duration"\r
research.speed-booster-duration.description: "Increases Speed Booster duration."\r
research.thorn-shield.name: "Thorn Shield"\r
research.thorn-shield.description: "Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact."\r
research.thorn-shield-duration.name: "Thorn Shield Duration"\r
research.thorn-shield-duration.description: "Increases Thorn Shield duration."\r
research.freezer.name: "Freezer"\r
research.freezer.description: "Unlocks Freezer pickups that freeze all enemies."\r
research.freezer-duration.name: "Freezer Duration"\r
research.freezer-duration.description: "Increases Freezer duration."\r
research.pushback.name: "Pushback"\r
research.pushback.description: "Pushes nearby stationary enemies away. Each level increases push speed."\r
research.shield-invulnerability-duration.name: "Shield Afterglow"\r
research.shield-invulnerability-duration.description: "Increases invulnerability time after the Shield breaks."\r
research.shield-break-explosion.name: "Shield Break Explosion"\r
research.shield-break-explosion.description: "Destroys all enemies within range when the Shield breaks. Each level increases the range."\r
research.regular-lifetime-debuff.name: "Regular Decay"\r
research.regular-lifetime-debuff.description: "Reduces Regular enemy lifetime."\r
research.chaser-range-debuff.name: "Chaser Range Dampener"\r
research.chaser-range-debuff.description: "Reduces Chaser detection range."\r
research.creeper-speed-debuff.name: "Creeper Slowdown"\r
research.creeper-speed-debuff.description: "Reduces Creeper movement speed."\r
research.banger-range-debuff.name: "Banger Range Dampener"\r
research.banger-range-debuff.description: "Reduces Banger blast range."\r
research.banger-enemy-destruction.name: "Banger Disruption"\r
research.banger-enemy-destruction.description: "Give the banger's blast a chance to destroy affected enemies."\r
research.shooter-range-debuff.name: "Shooter Range Dampener"\r
research.shooter-range-debuff.description: "Reduces Shooter firing range."\r
research.shooter-projectile-debuff.name: "Projectile Drag"\r
research.shooter-projectile-debuff.description: "Reduces Shooter projectile speed."\r
research.porter-interval-debuff.name: "Porter Delay Field"\r
research.porter-interval-debuff.description: "Increases the interval between Porter teleports."\r
research.magnet-strength-debuff.name: "Magnet Insulation"\r
research.magnet-strength-debuff.description: "Reduces Magnet pull strength."\r
research.spore-speed-debuff.name: "Spore Drag"\r
research.spore-speed-debuff.description: "Reduces Spore movement speed."\r
research.poison-creep-clean.name: "Poison Creep Clean"\r
research.poison-creep-clean.description: "Reduces how long Poison Creeper trails remain."\r
weapon.nuke.name: "Nuke"\r
weapon.nuke.description: "Destroys a percentage of enemies in the arena."\r
weapon.megaMagnet.name: "Mega Magnet"\r
weapon.megaMagnet.description: "Pulls every Cell rapidly toward your ship."\r
weapon.atmosphereShield.name: "Atmosphere Shield"\r
weapon.atmosphereShield.description: "Destroys and blocks falling meteors for a short time."\r
weapon.phaseDash.name: "Phase Dash"\r
weapon.phaseDash.description: "Dash through enemies and erase every enemy in your path."\r
weapon.chronoFreeze.name: "Chrono Freeze"\r
weapon.chronoFreeze.description: "Freezes every enemy and their lifetime for a short time."\r
weapon.plasmaOrbital.name: "Plasma Orbital"\r
weapon.plasmaOrbital.description: "Deploys plasma orbitals that destroy enemies on contact."\r
weapon.cellOverdrive.name: "Cell Overdrive"\r
weapon.cellOverdrive.description: "Doubles Cells collected for a short time."\r
weapon.demonMode.name: "Demon Mode"\r
weapon.demonMode.description: "Move faster and destroy enemies you pass through."\r
weapon.remove_loadout: "REMOVE FROM LOADOUT"\r
weapon.add_loadout: "ADD TO LOADOUT"\r
weapon.replace_with: "REPLACE WITH {weapon}"\r
weapon.replace_selected: "REPLACE SELECTED WEAPON"\r
weapon.buy: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.empty_slot: "EMPTY SLOT"\r
weapon.not_collected: "Not collected yet"\r
weapon.max_level: "MAX LEVEL"\r
weapon.claim: "CLAIM"\r
weapon.next: "NEXT"\r
weapon.unlocked: "UNLOCKED"\r
weapon.unlocked_level: "Unlocked at Level 1."\r
weapon.level_up: "LEVEL UP · LV. {level}"\r
weapon.upgraded_level: "Upgraded to Level {level}."\r
weapon.max_level_copy: "MAX LEVEL COPY"\r
weapon.max_level_detail: "This weapon is already at maximum level."\r
weapon.copy: "COPY · LV. {level}"\r
weapon.copy_progress: "{copies}/{required} copies toward Level {level}."\r
artifact.broken-radar.name: "Broken Radar"\r
artifact.broken-radar.buff: "+10% Cell spawn rate"\r
artifact.ftl-schematics.name: "FTL Schematics"\r
artifact.ftl-schematics.buff: "+10% player movement speed"\r
artifact.supply-depot.name: "Supply Depot"\r
artifact.supply-depot.buff: "+5 initial Cells"\r
artifact.broken-extractor.name: "Broken Extractor"\r
artifact.broken-extractor.buff: "+10% cash earned from Cells"\r
artifact.construction-bot.name: "Construction Bot"\r
artifact.construction-bot.buff: "-10% Building prices"\r
artifact.alientech-gizmo.name: "Alientech Gizmo"\r
artifact.alientech-gizmo.buff: "-20% Research cost"\r
artifact.broken-hard-drive.name: "Broken Hard-Drive"\r
artifact.broken-hard-drive.buff: "+1 Weapon Slot"\r
artifact.hubble-telescope.name: "Hubble Telescope"\r
artifact.hubble-telescope.buff: "+20% player effect range"\r
artifact.dark-core.name: "Dark Core"\r
artifact.dark-core.buff: "+1% Chronoshards earned"
artifact.map-to-earth.name: "Map To Earth"\r
artifact.map-to-earth.buff: "+20% arena size in every Sector"\r
building.chronoGenerator.name: "Chrono Generator"\r
building.autocannon.name: "Autocannon"\r
building.droneBay.name: "Drone Bay"\r
building.barrierNode.name: "Barrier Node"\r
building.overclockRelay.name: "Overclock Relay"\r
building.salvageExtractor.name: "Salvage Extractor"\r
building.upgrade.range: "Range"\r
building.upgrade.effectiveness: "Effectiveness"\r
building.upgrade.frequency: "Frequency"\r
building.upgrade.period: "Period"\r
building.upgrade.count: "Count"\r
building.upgrade.duration: "Duration"\r
building.upgrade.cash: "Cash"\r
encyclopedia.category.enemies: "Enemies"\r
encyclopedia.category.meteors: "Meteors"\r
enemy.regular.name: "Regular"\r
enemy.regular.description: "A stationary asteroid enemy. Keep clear of its body while collecting Cells."\r
enemy.chaser.name: "Chaser"\r
enemy.chaser.description: "Detects the ship within its range and pursues it."\r
enemy.creeper.name: "Creeper"\r
enemy.creeper.description: "Slowly closes in from any distance and becomes faster as it survives."\r
enemy.poisonCreeper.name: "Poison Creeper"\r
enemy.poisonCreeper.description: "A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind."\r
enemy.banger.name: "Banger"\r
enemy.banger.description: "Arms itself, pulses a warning, then detonates over a wide area."\r
enemy.shooter.name: "Shooter"\r
enemy.shooter.description: "Fires projectiles at the ship when it enters firing range."\r
enemy.porter.name: "Porter"\r
enemy.porter.description: "Occasionally teleports itself to random locations."\r
enemy.magnet.name: "Magnet"\r
enemy.magnet.description: "Pulls the ship toward itself while it is within range."\r
enemy.spore.name: "Spore"\r
enemy.spore.description: "Bursts into small pieces of itself, then bursts into even smaller pieces again."\r
enemy.stoneRock.name: "Stone Rock"\r
enemy.stoneRock.description: "A standard falling meteor. Avoid its marked impact point."\r
enemy.fieryRock.name: "Fiery Rock"\r
enemy.fieryRock.description: "A burning meteor that leaves a damaging fire hazard after impact."\r
enemy.splinter.name: "Splinter"\r
enemy.splinter.description: "Shatters on impact and sends fragments outward."\r
status.fire: "Burning"\r
status.poison: "Poisoned"\r
anomaly.cell-scout.name: "Scout Rivalry"\r
anomaly.cell-scout.description: "A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you."
anomaly.tower-defense.name: "Tower Defense"
anomaly.tower-defense.description: "Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls."
anomaly.tower_health: "TOWER {current}/{maximum}"
anomaly.tower_defended: "TOWER DEFENDED"
anomaly.tower_defended_copy: "You destroyed {cells} enemies and secured the tower."
anomaly.tower_destroyed: "TOWER DESTROYED"
anomaly.tower_destroyed_copy: "The tower fell after {cells} enemies were destroyed."
anomaly.dark_core_stack: "ARTIFACT · {artifact} STACK"
anomaly.run: "ANOMALY RUN"\r
anomaly.weekly: "WEEKLY ANOMALY"\r
anomaly.start: "START ANOMALY RUN"\r
anomaly.verifying_title: "VERIFYING TIME"\r
anomaly.verifying_copy: "Checking the current Weekly Anomaly with the game server."\r
anomaly.reward: "{cells} CELLS · REWARD ✦ {reward}"\r
anomaly.reset: "(New Anomaly in {date})"\r
anomaly.reward_claimed: "This sector’s Weekly Anomaly reward has already been claimed."\r
anomaly.time_unverified_title: "TIME NOT VERIFIED"\r
anomaly.time_unverified_copy: "The current Weekly Anomaly could not be verified."\r
anomaly.time_unverified_error: "We could not verify the server time or check your internet connection. Please check your connection and try again."\r
menu.home: "HOME"\r
menu.research_lab: "RESEARCH LAB"\r
menu.weaponry: "WEAPONRY"\r
menu.buildings: "BUILDING SYSTEM"\r
menu.encyclopedia: "ENCYCLOPEDIA"\r
menu.settings: "SETTINGS"\r
menu.artifacts: "ARTIFACTS"\r
menu.exit_game: "EXIT GAME"\r
menu.start_run: "START RUN"\r
menu.continue: "CONTINUE"\r
menu.run_again: "RUN AGAIN"\r
menu.back: "BACK"\r
menu.pause: "PAUSE"\r
menu.round_paused: "ROUND PAUSED"\r
menu.reset: "RESET"\r
menu.surrender: "SURRENDER"\r
menu.return: "RETURN"\r
menu.main_menu: "MAIN MENU"\r
hud.cash: "CASH"\r
hud.chronoshards: "CHRONOSHARDS"\r
hud.cells: "CELLS"\r
hud.shields: "SHIELDS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SANDBOX SECTOR {sector}"\r
hud.anomaly_suffix: " · ANOMALY"\r
settings.preferences: "PREFERENCES"\r
settings.graphics: "GRAPHICS"\r
settings.gameplay: "GAMEPLAY"\r
settings.sound: "SOUND"\r
settings.quality: "Quality"\r
settings.quality_help: "Changes render resolution and shadows."\r
settings.low: "LOW"\r
settings.medium: "MEDIUM"\r
settings.high: "HIGH"\r
settings.shadows: "Shadows"\r
settings.shadows_help: "Show dynamic object shadows."\r
settings.hdr_emission: "HDR Emission"\r
settings.hdr_emission_help: "Controls how far bright effects bloom beyond their models."\r
settings.max_fps: "Maximum FPS"\r
settings.max_fps_help: "Limits rendering and simulation to reduce hardware load."\r
settings.unlimited: "UNLIMITED"\r
settings.auto_pause: "Auto Pause"\r
settings.auto_pause_help: "Pause the run when the game loses focus."\r
settings.high_contrast_hud: "High Contrast HUD"\r
settings.high_contrast_hud_help: "Improves HUD readability."\r
settings.master_volume: "Master Volume"\r
settings.master_volume_help: "Controls all game sound effects."\r
settings.mute_all: "Mute All"\r
settings.mute_all_help: "Instantly silence all sound effects."\r
settings.spatial_audio: "Spatial Audio"\r
settings.spatial_audio_help: "Pan sounds based on their world position."\r
settings.patch_notes: "PATCH NOTES"\r
settings.display: "DISPLAY"\r
settings.screen_mode: "Screen Mode"\r
settings.screen_mode_help: "Steam launches fullscreen by default."\r
settings.resolution: "Resolution"\r
settings.resolution_help: "Choosing a resolution switches to windowed mode."\r
settings.fullscreen: "FULLSCREEN"\r
settings.windowed: "WINDOWED"\r
milestone.ascension: "ASCENSION"\r
milestone.max_cells: "MAX CELLS"\r
milestone.cells: "{cells} CELLS"\r
milestone.next: "NEXT ASCENSION: {cells} CELLS"\r
milestone.ready: "ASCENSION REWARD READY TO CLAIM"\r
milestone.complete: "ASCENSION COMPLETE"\r
milestone.claim: "CLAIM REWARD"\r
milestone.claimed: "Claimed"\r
milestone.secured: "REWARD SECURED"\r
milestone.auto_claimed: "Claimed automatically"\r
milestone.best: "{best}/{target} best cells in Sector {sector}"\r
milestone.reward_claimed: "REWARD CLAIMED · {rewards}"\r
milestone.reward_cash: "+\${amount} cash"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshards"\r
milestone.unlock_sector: "Unlock Sector {sector}"\r
milestone.unlock_feature: "Unlock {feature}"\r
milestone.unlock_research: "Unlock: {researches}"\r
error.server_time_unconfigured: "Server time endpoint is not configured."\r
error.server_time_request: "Server time request failed with {status}."\r
error.server_time_invalid: "Server returned an invalid time."\r
message.round_saved: "Round saved. Continue when you are ready."\r
message.sandbox_closed: "Sandbox closed. No progress was saved."\r
message.run_surrendered: "Run surrendered. No progress was saved."\r
message.killed_by: "KILLED BY {cause}"\r
message.energy_secured: "You secured {count} energy {cellWord}."\r
message.cell_singular: "cell"\r
message.cell_plural: "cells"\r
message.tip: "TIP · {tip}"\r
message.anomaly_reward: "ANOMALY +✦{amount}"\r
artifact.acquired: "ARTIFACT ACQUIRED"\r
artifact.acquired_named: "ARTIFACT ACQUIRED · {artifact}"\r
artifact.locked: "ARTIFACT LOCKED"\r
artifact.unknown: "UNKNOWN ARTIFACT"\r
encyclopedia.unknown_enemy: "Unknown enemy"\r
research.slot: "SLOT {slot}"\r
research.available: "AVAILABLE"\r
research.locked: "LOCKED"\r
research.remaining: "{duration} remaining"\r
research.select_below: "Select a research below."\r
research.unlock_for: "Unlock for {cost}"\r
research.unlock_sector: "Unlock Sector {sector} research in Milestones"\r
research.max_level: "MAX LEVEL"\r
research.in_progress: "IN PROGRESS"\r
research.free_enabled: "FREE RESEARCH ENABLED"\r
research.cost: "Cost {cost}"\r
research.maxed: "MAXED"\r
research.start: "RESEARCH"\r
research.no_search_results: "No research names match your search."\r
research.started: "{research} research started in Slot {slot}."\r
research.upgraded: "{research} upgraded to Level {level}."\r
research.slot_unlocked: "Research Slot {slot} unlocked."\r
research.requires_sector_cells: "Requires {cells} Cells in Sector {sector}"\r
research.requires_banked_cells: "Requires {cells} banked cells"\r
research.requires_research: "Requires {research}"\r
research.requires_research_level: "Requires {research} Lv. {level}"\r
weapon.number: "WEAPON {current} / {total}"\r
weapon.cards: "WEAPON CARDS"\r
weapon.round_loadout: "ROUND LOADOUT"\r
weapon.buy_with_cost: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five_with_cost: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.level: "LV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copies to Lv. {level}"\r
weapon.lucky_find_double: "LUCKY FIND · 2 CARDS"\r
weapon.lucky_find_unlock: "Unlocked at Level 1 and received an extra copy."\r
weapon.lucky_find_received: "Received 2 cards. {detail}"\r
artifact.stacks: "{count} stacks"\r
artifact.stack: "{count} STACK"\r
artifact.stacks_label: "{count} STACKS"\r
artifact.dark_core_stack: "{count} DARK CORE STACK"\r
artifact.dark_core_stacks: "{count} DARK CORE STACKS"\r
artifact.to_acquire: "TO ACQUIRE"\r
artifact.permanent_buff: "PERMANENT BUFF"\r
artifact.buff_per_stack: "{buff} per stack · {count} stacks = +{percent}% Chronoshards earned"\r
artifact.requirement_score: "Reach {cells} Cells in Sector {sector}."\r
artifact.requirement_milestone: "Claim the Sector {sector} · {cells} Cells Ascension reward."\r
artifact.requirement_anomaly: "Complete each Anomaly in each Sector. Every unique Anomaly and Sector combination grants one stack."
artifact.requirement_hidden: "Hidden condition."\r
artifact.requirement_default: "Complete this artifact achievement."\r
building.choose_offer: "CHOOSE 1 OF {count} · NEXT UNLOCK ✦ {cost}"\r
building.all_unlocked: "ALL BUILDINGS UNLOCKED"\r
building.permanent_unlock: "Permanent building unlock"\r
building.unlock_cost: "UNLOCK · ✦ {cost}"\r
building.upgrade: "UPGRADE"\r
building.slot_limit: "SLOT LIMIT"\r
building.build_cost: "Build cost: \${cost}"\r
building.unlocked: "UNLOCKED"\r
building.none_unlocked: "NO BUILDINGS UNLOCKED YET"\r
building.build_mode_slots: "BUILD MODE · SLOTS {used}/{total}"\r
building.level: "LVL. {level}"\r
building.installed_defense: "INSTALLED DEFENSE"\r
building.choose_upgrade: "Choose an upgrade for this structure."\r
building.upgrade_level: "LV. {current} → {next}"\r
building.demolish_refund: "DEMOLISH · REFUND \${amount}"\r
building.demolish_confirm: "Demolish {building}? You will receive a \${refund} refund."\r
research.active_slots: "ACTIVE SLOTS"\r
research.available_research: "AVAILABLE RESEARCH"\r
research.search: "SEARCH"\r
research.search_placeholder: "Search research names"\r
research.hide_completed: "Hide Completed Researches"\r
research.hide_locked: "Hide Locked Researches"\r
artifact.permanent_achievements: "PERMANENT ACHIEVEMENTS"\r
artifact.intro: "Artifacts are permanent rewards earned by reaching achievement goals."\r
building.permanent_defenses: "PERMANENT DEFENSES"\r
building.system: "BUILDING SYSTEM"\r
building.build_mode: "BUILD MODE"\r
building.unlock_a_building: "UNLOCK A BUILDING"\r
building.unlocked_buildings: "UNLOCKED BUILDINGS"\r
building.draft: "BUILDING DRAFT"\r
weapon.active_arsenal: "ACTIVE ARSENAL"\r
menu.back: "BACK"\r
menu.done: "DONE"\r
encyclopedia.threat_database: "THREAT DATABASE"\r
accessibility.game_canvas: "Asteroid Belt game canvas"\r
accessibility.current_sector: "Current difficulty sector"\r
accessibility.pause_game: "Pause game"\r
accessibility.shield_charges: "Shield charges"\r
accessibility.game_controls: "Game controls"\r
accessibility.build_information: "Build information"\r
accessibility.build_locations: "Build locations"\r
accessibility.pause_menu: "Pause menu"\r
accessibility.debug_console: "Debug console"\r
accessibility.close_debug_console: "Close debug console"\r
accessibility.save_slots: "Save slot selection"\r
accessibility.defeating_enemy: "Defeating enemy 3D model"\r
accessibility.sector_selection: "Difficulty sector selection"\r
accessibility.previous_sector: "Select previous sector"\r
accessibility.next_sector: "Select next sector"\r
accessibility.previous_milestone_sector: "View previous milestone sector"\r
accessibility.next_milestone_sector: "View next milestone sector"\r
accessibility.enemy_model: "{enemy} model"\r
controls.move: "MOVE"\r
controls.navigate: "NAVIGATE"\r
controls.use_weapon: "USE WEAPON"\r
controls.select_weapon: "SELECT / USE WEAPON"\r
patch_notes.version_build: "VERSION {version} · BUILD {build}"\r
patch_notes.artifacts: "ARTIFACTS"\r
patch_notes.artifacts_1: "Introducing Artifact System - An achievements mechanic which rewards the player with permanent buffs and rewards when achieving certain things."\r
patch_notes.artifacts_2: "Artifacts are mostly earned by reaching 500 cells in Tier 2 and onwards."\r
patch_notes.artifacts_3: "There are 10 different artifact right now, more to come in upcoming update."\r
patch_notes.improvements: "IMPROVEMENTS"\r
patch_notes.improvements_1: "Certain UI improvements for better visibility especially in mobile devices."\r
patch_notes.improvements_2: "Small value tweaks regarding Research unlocks and Enemy strengths."\r
tip.1: "You will eventually be overwhelmed. Try unlocking new researches to push further."\r
tip.2: "Keep moving: standing still makes incoming hazards much harder to read."\r
tip.3: "The final seconds of an enemy lifetime are marked by a blink."\r
tip.4: "Research upgrades persist between runs, so a short run can still move you forward."\r
tip.5: "Use the arena edge to reduce the directions enemies can approach from."\r
tip.6: "Chronoshards are rare, valuable and short-lived. Make sure to grab them before they disappear."\r
tip.7: "Watch enemy range rings before committing to a path through the arena."\r
tip.8: "You can unlock boosters later in the game from Research Lab."\r
tip.9: "After reaching Sector IV, you can unlock the ability to build Buildings to help you in the arena."\r
tip.10: "Purple enemies are called creepers and they speed up gradually over time. They can be slowed down by static collisions with obstacles."\r
tip.11: "Red enemies are called chasers and they will actively pursue you. They can be slowed down by static collisions with obstacles."\r
tip.12: "Yellow enemies are called bangers and they explode after a few seconds."\r
tip.13: "More cells you collect, the more difficult the game becomes."\r
tip.14: "New enemies and obstacles are introduced as you progress through the game, so be prepared for new challenges."\r
cheat.title: "DEBUG CONSOLE"\r
cheat.prompt: "Enter a command."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "You need to reach Sector {sector}."\r
cheat.feature_cells: "You need to collect {cells} Cells in Sector {sector}."\r
cheat.feature_chronoshards: "You need ✦ {amount} Chronoshards."\r
cheat.feature_unavailable: "This system is not available yet."\r
cheat.research_completed: "{research} research completed."\r
status.damage: "{status} DAMAGE"\r
cheat.sandbox_started: "Sandbox Sector I started. Use sandbox [sector], sandbox simulate [cell|enemies|all], or sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "Sandbox difficulty set to Sector {sector}. Spawn simulation remains unchanged."\r
cheat.sandbox_start_first: "Start Sandbox first with: sandbox"\r
cheat.sandbox_simulate_usage: "Usage: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simulation started for Sector {sector}."\r
cheat.sandbox_spawn_usage: "Usage: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Spawned {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Usage: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"
cheat.anomaly_usage: "Usage: anomaly <anomaly_id>"
cheat.anomaly_unknown: "Unknown Anomaly: {id}. Available: {available}"
cheat.anomaly_started: "Anomaly {id} started in Sector {sector}."
cheat.cell_usage: "Usage: cell <positive amount>"
cheat.cell_requires_round: "Start a round before granting Cells."
cheat.cell_granted: "Added {amount} Cells without awarding Cash. Total: {total}."
cheat.god_usage: "Usage: god <on/off>"
cheat.god_state: "God mode {state}."
cheat.on: "ON"
cheat.off: "OFF"
cheat.artifact_usage: "Usage: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Unknown Artifact: {artifact}"\r
cheat.artifact_stack_range: "Stack must be a whole number from 1 to 10,000."\r
cheat.artifact_granted: "Granted {count} {artifact} {stackWord} ({total} total)."\r
cheat.artifact_unique: "{artifact} is a unique Artifact and is now unlocked."\r
cheat.amount_usage: "Usage: {command} [positive amount]"\r
cheat.amount_granted: "Granted {amount}."\r
cheat.free_research: "Free research enabled for this session."\r
cheat.sectors_unlocked: "All sectors and Ascension rewards unlocked.{rewards}"\r
cheat.clear_usage: "Usage: clear_save [{targets}]"\r
cheat.cleared: "Cleared {target} save data."\r
cheat.unknown_command: "Unknown command: {command}"\r
menu.patch_notes: "PATCH NOTES"\r
menu.unlock_feature: "UNLOCK {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
`,Me=`language.english: "İngilizce"\r
language.turkish: "Türkçe"\r
language.spanish: "İspanyolca"\r
settings.language: "Dil"\r
settings.language_help: "Oyun arayüzünde kullanılacak dili seçin."\r
save_slots.heading: "KAYIT YUVASI SEÇ"\r
save_slots.archive: "KOMUTA ARŞİVİ"\r
save_slots.description: "Seferinize devam etmek için bir pilot arşivi seçin."\r
save_slots.slot: "YUVA {slot}"\r
save_slots.new_expedition: "YENİ SEFER"\r
save_slots.sector: "SEKTÖR {sector}"\r
save_slots.max_cells: "AZAMİ HÜCRE"\r
save_slots.total_cash: "TOPLAM NAKİT"\r
save_slots.total_chronoshards: "TOPLAM CHRONOSHARD"\r
research.category.player_enhancements: "Oyuncu Geliştirmeleri"\r
research.category.economy: "Ekonomi"\r
research.category.boosters: "Güçlendiriciler"\r
research.category.weapons: "Silahlar"\r
research.category.building_system: "Yapı Sistemi"\r
research.category.enemy_debuff: "Düşman Zayıflatmaları"\r
research.lucky-find.name: "Şanslı Buluntu"\r
research.lucky-find.description: "Silah kartlarının Şanslı Buluntuya dönüşme ve 1 yerine 2 kart verme ihtimali vardır."\r
research.weapon-recharge.name: "Silah Yeniden Dolumu"\r
research.weapon-recharge.description: "Silahlar artık zaman içinde yeniden dolabilir."\r
research.weapon-recharge-rate.name: "Silah Dolum Hızı"\r
research.weapon-recharge-rate.description: "Silahların yeniden dolma süresini azaltır."\r
research.weapon-charge-capacity.name: "Silah Şarj Kapasitesi"\r
research.weapon-charge-capacity.description: "Kuşanılmış her silahın saklayabileceği azami şarj sayısını 1 artırır."\r
research.weapon-slots.name: "Silah Yuvası"\r
research.weapon-slots.description: "Tur donanımınıza bir silah yuvası ekler."\r
research.player-speed-multiplier.name: "Oyuncu Hız Çarpanı"\r
research.player-speed-multiplier.description: "Oyuncunun hareket hızını artırır."\r
research.unlock-slow-aura.name: "Yavaşlatma Aurasını Aç"\r
research.unlock-slow-aura.description: "Menzil içindeki yakındaki düşmanları yavaşlatan Yavaşlatma Aurası yeteneğini açar."\r
research.unlock-orbital-electron.name: "Yörünge Elektronunu Aç"\r
research.unlock-orbital-electron.description: "Etki menzilinizin çevresinde dönen ve elektrik arkının çarptığı düşmanları sersemleten bir Elektron konuşlandırır."\r
research.electron-stun-duration.name: "Elektron Sersemletme Süresi"\r
research.electron-stun-duration.description: "Yörünge Elektronunun vurduğu düşmanların sersemleme süresini artırır."\r
research.electron-speed.name: "Elektron Hızı"\r
research.electron-speed.description: "Yörünge Elektronunun yörünge hızını artırır."\r
research.slow-aura-effect.name: "Yavaşlatma Aurası Etkisi"\r
research.slow-aura-effect.description: "Yavaşlatma Aurası yeteneğinin etkisini artırır."\r
research.slow-aura-range.name: "Etki Menzili"\r
research.slow-aura-range.description: "Menzile dayalı tüm etkin etkilerin menzilini artırır."\r
research.cell-spawn-rate.name: "Hücre Belirme Hızı"\r
research.cell-spawn-rate.description: "Standart Hücrelerin belirme hızını artırır."\r
research.cell-increment-per-cell.name: "Hücre Başına Hücre Artışı"\r
research.cell-increment-per-cell.description: "Toplanan her Hücre, standart Hücrelerin belirme hızını artırır."\r
research.cash-cell-multiplier.name: "Nakit/Hücre Çarpanı"\r
research.cash-cell-multiplier.description: "Her standart Hücreden kazanılan Nakdi artırır."\r
research.initial-cell-count.name: "Başlangıç Hücresi"\r
research.initial-cell-count.description: "Her seferin başında arenaya bir Hücre ekler."\r
research.cell-magnet.name: "Hücre Mıknatısı"\r
research.cell-magnet.description: "Yakındaki Hücreleri size doğru çeker. Her seviye çekme hızını artırır."\r
research.chrono-spawn-rate.name: "Krono Belirme Hızı"\r
research.chrono-spawn-rate.description: "Krono Hücrelerinin daha sık belirmesini sağlar."\r
research.chrono-lifetime-multiplier.name: "Krono Ömür Çarpanı"\r
research.chrono-lifetime-multiplier.description: "Krono Hücrelerinin ömrünü artırır."\r
research.unlock-shockwave.name: "Şok Dalgasını Aç"\r
research.unlock-shockwave.description: "Belirli aralıklarla düşmanları uzağa iten yeşil bir şok dalgası yayar."\r
research.shockwave-frequency.name: "Şok Dalgası Sıklığı"\r
research.shockwave-frequency.description: "Şok Dalgalarının daha sık tetiklenmesini sağlar."\r
research.shield.name: "Kalkan"\r
research.shield.description: "Her seviye, her seferin başında ölümden bir kez kurtulma hakkı verir."\r
research.building-slots.name: "Yapı Yuvaları"\r
research.building-slots.description: "Arenaya yerleştirebileceğiniz yapı sayısını 1 artırır."\r
research.unlock-speed-booster.name: "Hız Güçlendiricilerini Aç"\r
research.unlock-speed-booster.description: "Hareket hızını iki katına çıkaran Hız Güçlendirici nesnelerini açar."\r
research.speed-booster-duration.name: "Hız Güçlendirici Süresi"\r
research.speed-booster-duration.description: "Hız Güçlendiricinin süresini artırır."\r
research.thorn-shield.name: "Diken Kalkan"\r
research.thorn-shield.description: "Dokunulmazlık sağlayan ve temas ettiği düşmanları yok eden Diken Kalkan nesnelerini açar."\r
research.thorn-shield-duration.name: "Diken Kalkan Süresi"\r
research.thorn-shield-duration.description: "Diken Kalkanın süresini artırır."\r
research.freezer.name: "Dondurucu"\r
research.freezer.description: "Tüm düşmanları donduran Dondurucu nesnelerini açar."\r
research.freezer-duration.name: "Dondurucu Süresi"\r
research.freezer-duration.description: "Dondurucunun süresini artırır."\r
research.pushback.name: "Geri İtme"\r
research.pushback.description: "Yakındaki hareketsiz düşmanları uzağa iter. Her seviye itme hızını artırır."\r
research.shield-invulnerability-duration.name: "Kalkan Art Etkisi"\r
research.shield-invulnerability-duration.description: "Kalkan kırıldıktan sonraki dokunulmazlık süresini artırır."\r
research.shield-break-explosion.name: "Kalkan Kırılma Patlaması"\r
research.shield-break-explosion.description: "Kalkan kırıldığında menzil içindeki tüm düşmanları yok eder. Her seviye menzili artırır."\r
research.regular-lifetime-debuff.name: "Sıradan Çürümesi"\r
research.regular-lifetime-debuff.description: "Sıradan düşmanların ömrünü azaltır."\r
research.chaser-range-debuff.name: "Takipçi Menzil Bastırıcı"\r
research.chaser-range-debuff.description: "Takipçilerin algılama menzilini azaltır."\r
research.creeper-speed-debuff.name: "Sinsici Yavaşlatma"\r
research.creeper-speed-debuff.description: "Sinsicilerin hareket hızını azaltır."\r
research.banger-range-debuff.name: "Patlayıcı Menzil Bastırıcı"\r
research.banger-range-debuff.description: "Patlayıcıların patlama menzilini azaltır."\r
research.banger-enemy-destruction.name: "Patlayıcı Bozucu"\r
research.banger-enemy-destruction.description: "Patlayıcının patlamasına, etkilenen düşmanları yok etme ihtimali verir."\r
research.shooter-range-debuff.name: "Atıcı Menzil Bastırıcı"\r
research.shooter-range-debuff.description: "Atıcıların ateş menzilini azaltır."\r
research.shooter-projectile-debuff.name: "Mermi Sürüklenmesi"\r
research.shooter-projectile-debuff.description: "Atıcıların mermi hızını azaltır."\r
research.porter-interval-debuff.name: "Işınlayıcı Gecikme Alanı"\r
research.porter-interval-debuff.description: "Işınlayıcıların ışınlanmaları arasındaki süreyi artırır."\r
research.magnet-strength-debuff.name: "Mıknatıs Yalıtımı"\r
research.magnet-strength-debuff.description: "Mıknatısların çekim gücünü azaltır."\r
research.spore-speed-debuff.name: "Spor Sürüklenmesi"\r
research.spore-speed-debuff.description: "Sporların hareket hızını azaltır."\r
research.poison-creep-clean.name: "Zehir İzi Temizliği"\r
research.poison-creep-clean.description: "Zehirli Sinsicilerin bıraktığı izlerin kalma süresini azaltır."\r
weapon.nuke.name: "Nükleer Bomba"\r
weapon.nuke.description: "Arenadaki düşmanların belirli bir yüzdesini yok eder."\r
weapon.megaMagnet.name: "Mega Mıknatıs"\r
weapon.megaMagnet.description: "Tüm Hücreleri hızla geminize doğru çeker."\r
weapon.atmosphereShield.name: "Atmosfer Kalkanı"\r
weapon.atmosphereShield.description: "Düşen meteorları kısa bir süre boyunca yok eder ve engeller."\r
weapon.phaseDash.name: "Faz Atılımı"\r
weapon.phaseDash.description: "Düşmanların içinden atılın ve yolunuzdaki her düşmanı silin."\r
weapon.chronoFreeze.name: "Krono Dondurma"\r
weapon.chronoFreeze.description: "Tüm düşmanları ve ömür sayaçlarını kısa bir süreliğine dondurur."\r
weapon.plasmaOrbital.name: "Plazma Yörüngesi"\r
weapon.plasmaOrbital.description: "Temas ettiği düşmanları yok eden plazma yörünge cisimleri konuşlandırır."\r
weapon.cellOverdrive.name: "Hücre Aşırı Yükü"\r
weapon.cellOverdrive.description: "Kısa bir süre boyunca toplanan Hücreleri iki katına çıkarır."\r
weapon.demonMode.name: "Şeytan Modu"\r
weapon.demonMode.description: "Daha hızlı hareket edin ve içinden geçtiğiniz düşmanları yok edin."\r
weapon.remove_loadout: "DONANIMDAN ÇIKAR"\r
weapon.add_loadout: "DONANIMA EKLE"\r
weapon.replace_with: "{weapon} İLE DEĞİŞTİR"\r
weapon.replace_selected: "SEÇİLİ SİLAHI DEĞİŞTİR"\r
weapon.buy: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.empty_slot: "BOŞ YUVA"\r
weapon.not_collected: "Henüz alınmadı"\r
weapon.max_level: "AZAMİ SEVİYE"\r
weapon.claim: "AL"\r
weapon.next: "SONRAKİ"\r
weapon.unlocked: "AÇILDI"\r
weapon.unlocked_level: "1. Seviyede açıldı."\r
weapon.level_up: "SEVİYE ATLA · SV. {level}"\r
weapon.upgraded_level: "{level}. Seviyeye yükseltildi."\r
weapon.max_level_copy: "AZAMİ SEVİYE KOPYASI"\r
weapon.max_level_detail: "Bu silah zaten azami seviyede."\r
weapon.copy: "KOPYA · SV. {level}"\r
weapon.copy_progress: "{level}. Seviye için {copies}/{required} kopya."\r
artifact.broken-radar.name: "Bozuk Radar"\r
artifact.broken-radar.buff: "+10% Hücre belirme hızı"\r
artifact.ftl-schematics.name: "FTL Şemaları"\r
artifact.ftl-schematics.buff: "+10% oyuncu hareket hızı"\r
artifact.supply-depot.name: "İkmal Deposu"\r
artifact.supply-depot.buff: "+5 başlangıç Hücresi"\r
artifact.broken-extractor.name: "Bozuk Çıkarıcı"\r
artifact.broken-extractor.buff: "+10% Hücrelerden kazanılan nakit"\r
artifact.construction-bot.name: "İnşaat Botu"\r
artifact.construction-bot.buff: "-10% Yapı fiyatları"\r
artifact.alientech-gizmo.name: "Uzaylı Teknolojisi Aygıtı"\r
artifact.alientech-gizmo.buff: "-20% Araştırma maliyeti"\r
artifact.broken-hard-drive.name: "Bozuk Sabit Disk"\r
artifact.broken-hard-drive.buff: "+1 Silah Yuvası"\r
artifact.hubble-telescope.name: "Hubble Teleskobu"\r
artifact.hubble-telescope.buff: "+20% oyuncu etki menzili"\r
artifact.dark-core.name: "Karanlık Çekirdek"\r
artifact.dark-core.buff: "+1% kazanılan Chronoshard"
artifact.map-to-earth.name: "Dünya'ya Giden Harita"\r
artifact.map-to-earth.buff: "+20% her Sektörde arena boyutu"\r
building.chronoGenerator.name: "Krono Jeneratörü"\r
building.autocannon.name: "Otomatik Top"\r
building.droneBay.name: "Drone Hangarı"\r
building.barrierNode.name: "Bariyer Düğümü"\r
building.overclockRelay.name: "Hız Aşırtma Rölesi"\r
building.salvageExtractor.name: "Hurda Çıkarıcı"\r
building.upgrade.range: "Menzil"\r
building.upgrade.effectiveness: "Etkinlik"\r
building.upgrade.frequency: "Sıklık"\r
building.upgrade.period: "Periyot"\r
building.upgrade.count: "Adet"\r
building.upgrade.duration: "Süre"\r
building.upgrade.cash: "Nakit"\r
encyclopedia.category.enemies: "Düşmanlar"\r
encyclopedia.category.meteors: "Meteorlar"\r
enemy.regular.name: "Normal"\r
enemy.regular.description: "Hareketsiz bir düşman. Hücreleri toplarken gövdesinden uzak durun."\r
enemy.chaser.name: "Kovalayıcı"\r
enemy.chaser.description: "Menziline giren gemiyi algılar ve peşine düşer."\r
enemy.creeper.name: "Takipçi"\r
enemy.creeper.description: "Uzaktan yavaşça yaklaşır ve hayatta kaldıkça hızlanır."\r
enemy.poisonCreeper.name: "Zehirli Takipçi"\r
enemy.poisonCreeper.description: "Arkasında zehirli izler bırakırken mor ile koyu yeşil arasında renk değiştiren bir Sinsici türüdür."\r
enemy.banger.name: "Patlayıcı"\r
enemy.banger.description: "Kendini kurar, uyarı sinyalleri verir ve ardından geniş bir alanda patlar."\r
enemy.shooter.name: "Atıcı"\r
enemy.shooter.description: "Gemi ateş menziline girdiğinde ona mermiler fırlatır."\r
enemy.porter.name: "Işınlayıcı"\r
enemy.porter.description: "Ara sıra rastgele konumlara ışınlanır."\r
enemy.magnet.name: "Mıknatıs"\r
enemy.magnet.description: "Gemi menzilindeyken onu kendine doğru çeker."\r
enemy.spore.name: "Spor"\r
enemy.spore.description: "Kendisinin küçük parçalarına ayrılır, ardından bu parçalar daha da küçük parçalara ayrılır."\r
enemy.stoneRock.name: "Taş Meteor"\r
enemy.stoneRock.description: "Standart bir düşen meteor. İşaretlenmiş çarpma noktasından uzak durun."\r
enemy.fieryRock.name: "Alevli Meteor"\r
enemy.fieryRock.description: "Çarptıktan sonra hasar veren bir ateş alanı bırakan yanan meteor."\r
enemy.splinter.name: "Parçalayıcı"\r
enemy.splinter.description: "Çarpma anında parçalanır ve parçalarını çevreye saçar."\r
status.fire: "Yanma"\r
status.poison: "Zehirlenme"\r
anomaly.cell-scout.name: "Gözcü Rekabeti"\r
anomaly.cell-scout.description: "Uzaktaki kırmızı bir yapay zekâ gemisi sizinle birlikte Hücre toplar. Topladığı Hücreler seferinize sayılmaz ve size zarar veremez."
anomaly.tower-defense.name: "Kule Savunması"
anomaly.tower-defense.description: "Merkezdeki kuleyi düşman dalgalarına karşı savun. Kule düşmeden önce 1.000 düşman yok et."
anomaly.tower_health: "KULE {current}/{maximum}"
anomaly.tower_defended: "KULE SAVUNULDU"
anomaly.tower_defended_copy: "{cells} düşman yok ettin ve kuleyi güvenceye aldın."
anomaly.tower_destroyed: "KULE YIKILDI"
anomaly.tower_destroyed_copy: "{cells} düşman yok edildikten sonra kule düştü."
anomaly.dark_core_stack: "ARTIFACT · {artifact} YIĞINI"
anomaly.run: "ANOMALİ SEFERİ"\r
anomaly.weekly: "HAFTALIK ANOMALİ"\r
anomaly.start: "ANOMALİ SEFERİNİ BAŞLAT"\r
anomaly.verifying_title: "ZAMAN DOĞRULANIYOR"\r
anomaly.verifying_copy: "Mevcut Haftalık Anomali oyun sunucusuyla kontrol ediliyor."\r
anomaly.reward: "{cells} HÜCRE · ÖDÜL ✦ {reward}"\r
anomaly.reset: "(Yeni Anomali: {date})"\r
anomaly.reward_claimed: "Bu sektörün Haftalık Anomali ödülü zaten alındı."\r
anomaly.time_unverified_title: "ZAMAN DOĞRULANAMADI"\r
anomaly.time_unverified_copy: "Mevcut Haftalık Anomali doğrulanamadı."\r
anomaly.time_unverified_error: "Sunucu zamanı doğrulanamadı veya internet bağlantınız kontrol edilemedi. Lütfen bağlantınızı kontrol edip tekrar deneyin."\r
menu.home: "ANA SAYFA"\r
menu.research_lab: "ARAŞTIRMA LABORATUVARI"\r
menu.weaponry: "SİLAHLAR"\r
menu.buildings: "YAPI SİSTEMİ"\r
menu.encyclopedia: "ANSİKLOPEDİ"\r
menu.settings: "AYARLAR"\r
menu.artifacts: "KALINTILAR"\r
menu.exit_game: "OYUNDAN ÇIK"\r
menu.start_run: "SEFERİ BAŞLAT"\r
menu.continue: "DEVAM ET"\r
menu.run_again: "TEKRAR SEFERE ÇIK"\r
menu.back: "GERİ"\r
menu.pause: "DURAKLAT"\r
menu.round_paused: "TUR DURAKLATILDI"\r
menu.reset: "SIFIRLA"\r
menu.surrender: "TESLİM OL"\r
menu.return: "DÖN"\r
menu.main_menu: "ANA MENÜ"\r
hud.cash: "NAKİT"\r
hud.chronoshards: "KRONOPARÇALARI"\r
hud.cells: "HÜCRELER"\r
hud.shields: "KALKANLAR"\r
hud.sector: "SEKTÖR {sector}"\r
hud.sandbox_sector: "SANDBOX SEKTÖR {sector}"\r
hud.anomaly_suffix: " · ANOMALİ"\r
settings.preferences: "TERCİHLER"\r
settings.graphics: "GRAFİKLER"\r
settings.gameplay: "OYNANIŞ"\r
settings.sound: "SES"\r
settings.quality: "Kalite"\r
settings.quality_help: "Görüntü işleme çözünürlüğünü ve gölgeleri değiştirir."\r
settings.low: "DÜŞÜK"\r
settings.medium: "ORTA"\r
settings.high: "YÜKSEK"\r
settings.shadows: "Gölgeler"\r
settings.shadows_help: "Dinamik nesne gölgelerini gösterir."\r
settings.hdr_emission: "HDR Işıma"\r
settings.hdr_emission_help: "Parlak efektlerin modellerinin dışına ne kadar taşacağını belirler."\r
settings.max_fps: "Maksimum FPS"\r
settings.max_fps_help: "Donanım yükünü azaltmak için görüntüleme ve simülasyonu sınırlar."\r
settings.unlimited: "SINIRSIZ"\r
settings.auto_pause: "Otomatik Duraklatma"\r
settings.auto_pause_help: "Oyun odağı kaybettiğinde seferi duraklatır."\r
settings.high_contrast_hud: "Yüksek Kontrastlı HUD"\r
settings.high_contrast_hud_help: "HUD okunabilirliğini artırır."\r
settings.master_volume: "Ana Ses Düzeyi"\r
settings.master_volume_help: "Oyundaki tüm ses efektlerini kontrol eder."\r
settings.mute_all: "Tümünü Sessize Al"\r
settings.mute_all_help: "Tüm ses efektlerini anında sessize alır."\r
settings.spatial_audio: "Uzamsal Ses"\r
settings.spatial_audio_help: "Sesleri dünya konumlarına göre sağa veya sola yönlendirir."\r
settings.patch_notes: "YAMA NOTLARI"\r
settings.display: "EKRAN"\r
settings.screen_mode: "Ekran Modu"\r
settings.screen_mode_help: "Steam oyunu varsayılan olarak tam ekranda başlatır."\r
settings.resolution: "Çözünürlük"\r
settings.resolution_help: "Bir çözünürlük seçildiğinde pencere moduna geçilir."\r
settings.fullscreen: "TAM EKRAN"\r
settings.windowed: "PENCERE"\r
milestone.ascension: "YÜKSELİŞ"\r
milestone.max_cells: "AZAMİ HÜCRE"\r
milestone.cells: "{cells} HÜCRE"\r
milestone.next: "SONRAKİ YÜKSELİŞ: {cells} HÜCRE"\r
milestone.ready: "YÜKSELİŞ ÖDÜLÜ ALINMAYA HAZIR"\r
milestone.complete: "YÜKSELİŞ TAMAMLANDI"\r
milestone.claim: "ÖDÜLÜ AL"\r
milestone.claimed: "Alındı"\r
milestone.secured: "ÖDÜL GÜVENCEDE"\r
milestone.auto_claimed: "Otomatik olarak alındı"\r
milestone.best: "Sektör {sector}: en iyi {best}/{target} Hücre"\r
milestone.reward_claimed: "ÖDÜL ALINDI · {rewards}"\r
milestone.reward_cash: "+\${amount} nakit"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshard"\r
milestone.unlock_sector: "Sektör {sector} kilidini aç"\r
milestone.unlock_feature: "{feature} kilidini aç"\r
milestone.unlock_research: "Kilidi aç: {researches}"\r
error.server_time_unconfigured: "Sunucu zamanı uç noktası yapılandırılmamış."\r
error.server_time_request: "Sunucu zamanı isteği {status} durumuyla başarısız oldu."\r
error.server_time_invalid: "Sunucu geçersiz bir zaman döndürdü."\r
message.round_saved: "Tur kaydedildi. Hazır olduğunuzda devam edin."\r
message.sandbox_closed: "Sandbox kapatıldı. İlerleme kaydedilmedi."\r
message.run_surrendered: "Seferden vazgeçildi. İlerleme kaydedilmedi."\r
message.killed_by: "ÖLÜM NEDENİ: {cause}"\r
message.energy_secured: "{count} enerji {cellWord} güvenceye aldınız."\r
message.cell_singular: "hücresi"\r
message.cell_plural: "hücresi"\r
message.tip: "İPUCU · {tip}"\r
message.anomaly_reward: "ANOMALİ +✦{amount}"\r
artifact.acquired: "KALINTI EDİNİLDİ"\r
artifact.acquired_named: "KALINTI EDİNİLDİ · {artifact}"\r
artifact.locked: "KALINTI KİLİTLİ"\r
artifact.unknown: "BİLİNMEYEN KALINTI"\r
encyclopedia.unknown_enemy: "Bilinmeyen düşman"\r
research.slot: "YUVA {slot}"\r
research.available: "MEVCUT"\r
research.locked: "KİLİTLİ"\r
research.remaining: "{duration} kaldı"\r
research.select_below: "Aşağıdan bir araştırma seçin."\r
research.unlock_for: "{cost} karşılığında aç"\r
research.unlock_sector: "Sektör {sector} araştırmalarını Yükselişlerde aç"\r
research.max_level: "AZAMİ SEVİYE"\r
research.in_progress: "DEVAM EDİYOR"\r
research.free_enabled: "ÜCRETSİZ ARAŞTIRMA ETKİN"\r
research.cost: "Maliyet {cost}"\r
research.maxed: "AZAMİ SEVİYEDE"\r
research.start: "ARAŞTIR"\r
research.no_search_results: "Aramanızla eşleşen araştırma adı yok."\r
research.started: "{research} araştırması {slot}. Yuvada başlatıldı."\r
research.upgraded: "{research}, {level}. Seviyeye yükseltildi."\r
research.slot_unlocked: "Araştırma Yuvası {slot} açıldı."\r
research.requires_sector_cells: "Sektör {sector} içinde {cells} Hücre gerektirir"\r
research.requires_banked_cells: "Biriktirilmiş {cells} Hücre gerektirir"\r
research.requires_research: "{research} gerektirir"\r
research.requires_research_level: "{research} Sv. {level} gerektirir"\r
weapon.number: "SİLAH {current} / {total}"\r
weapon.cards: "SİLAH KARTLARI"\r
weapon.round_loadout: "TUR DONANIMI"\r
weapon.buy_with_cost: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five_with_cost: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find_cards: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.level: "SV. {level}"\r
weapon.copy_progress_short: "Sv. {level} için {copies}/{required} kopya"\r
weapon.lucky_find_double: "ŞANSLI BULUNTU · 2 KART"\r
weapon.lucky_find_unlock: "1. Seviyede açıldı ve fazladan bir kopya alındı."\r
weapon.lucky_find_received: "2 kart alındı. {detail}"\r
artifact.stacks: "{count} birikim"\r
artifact.stack: "{count} BİRİKİM"\r
artifact.stacks_label: "{count} BİRİKİM"\r
artifact.dark_core_stack: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.dark_core_stacks: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.to_acquire: "EDİNİLECEK"\r
artifact.permanent_buff: "KALICI GÜÇLENDİRME"\r
artifact.buff_per_stack: "Birikim başına {buff} · {count} birikim = +%{percent} kazanılan Chronoshard"\r
artifact.requirement_score: "Sektör {sector} içinde {cells} Hücreye ulaşın."\r
artifact.requirement_milestone: "Sektör {sector} · {cells} Hücre Yükseliş ödülünü alın."\r
artifact.requirement_anomaly: "Her Anomaliyi her Sektörde tamamlayın. Her benzersiz Anomali ve Sektör birleşimi bir birikim kazandırır."
artifact.requirement_hidden: "Gizli koşul."\r
artifact.requirement_default: "Bu kalıntı başarımını tamamlayın."\r
building.choose_offer: "{count} SEÇENEKTEN 1'İNİ SEÇ · SONRAKİ KİLİT ✦ {cost}"\r
building.all_unlocked: "TÜM YAPILAR AÇILDI"\r
building.permanent_unlock: "Kalıcı yapı kilidi açma"\r
building.unlock_cost: "KİLİDİ AÇ · ✦ {cost}"\r
building.upgrade: "YÜKSELT"\r
building.slot_limit: "YUVA SINIRI"\r
building.build_cost: "İnşa maliyeti: \${cost}"\r
building.unlocked: "AÇILDI"\r
building.none_unlocked: "HENÜZ HİÇBİR YAPI AÇILMADI"\r
building.build_mode_slots: "İNŞA MODU · YUVALAR {used}/{total}"\r
building.level: "SV. {level}"\r
building.installed_defense: "KURULU SAVUNMA"\r
building.choose_upgrade: "Bu yapı için bir yükseltme seçin."\r
building.upgrade_level: "SV. {current} → {next}"\r
building.demolish_refund: "YIK · İADE \${amount}"\r
building.demolish_confirm: "{building} yıkılsın mı? \${refund} iade alacaksınız."\r
research.active_slots: "ETKİN YUVALAR"\r
research.available_research: "MEVCUT ARAŞTIRMALAR"\r
research.search: "ARA"\r
research.search_placeholder: "Araştırma adlarında ara"\r
research.hide_completed: "Tamamlanan Araştırmaları Gizle"\r
research.hide_locked: "Kilitli Araştırmaları Gizle"\r
artifact.permanent_achievements: "KALICI BAŞARIMLAR"\r
artifact.intro: "Kalıntılar, başarım hedeflerine ulaşarak kazanılan kalıcı ödüllerdir."\r
building.permanent_defenses: "KALICI SAVUNMALAR"\r
building.system: "YAPI SİSTEMİ"\r
building.build_mode: "İNŞA MODU"\r
building.unlock_a_building: "BİR YAPI AÇ"\r
building.unlocked_buildings: "AÇILAN YAPILAR"\r
building.draft: "YAPI SEÇİMİ"\r
weapon.active_arsenal: "ETKİN CEPHANELİK"\r
menu.back: "GERİ"\r
menu.done: "BİTTİ"\r
encyclopedia.threat_database: "TEHDİT VERİTABANI"\r
accessibility.game_canvas: "Asteroid Belt oyun alanı"\r
accessibility.current_sector: "Mevcut zorluk sektörü"\r
accessibility.pause_game: "Oyunu duraklat"\r
accessibility.shield_charges: "Kalkan şarjları"\r
accessibility.game_controls: "Oyun kontrolleri"\r
accessibility.build_information: "Yapı bilgileri"\r
accessibility.build_locations: "Yapı konumları"\r
accessibility.pause_menu: "Duraklatma menüsü"\r
accessibility.debug_console: "Hata ayıklama konsolu"\r
accessibility.close_debug_console: "Hata ayıklama konsolunu kapat"\r
accessibility.save_slots: "Kayıt yuvası seçimi"\r
accessibility.defeating_enemy: "Yenilmekte olan düşmanın 3B modeli"\r
accessibility.sector_selection: "Zorluk sektörü seçimi"\r
accessibility.previous_sector: "Önceki sektörü seç"\r
accessibility.next_sector: "Sonraki sektörü seç"\r
accessibility.previous_milestone_sector: "Önceki Yükseliş sektörünü görüntüle"\r
accessibility.next_milestone_sector: "Sonraki Yükseliş sektörünü görüntüle"\r
accessibility.enemy_model: "{enemy} modeli"\r
controls.move: "HAREKET"\r
controls.navigate: "GEZİN"\r
controls.use_weapon: "SİLAH KULLAN"\r
controls.select_weapon: "SİLAH SEÇ / KULLAN"\r
patch_notes.version_build: "SÜRÜM {version} · DERLEME {build}"\r
patch_notes.artifacts: "KALINTILAR"\r
patch_notes.artifacts_1: "Kalıntı Sistemi eklendi: Belirli hedefleri tamamladığınızda oyuncuyu kalıcı güçlendirmeler ve ödüllerle ödüllendiren bir başarım mekaniği."\r
patch_notes.artifacts_2: "Kalıntılar çoğunlukla 2. Kademe ve sonrasında 500 Hücreye ulaşılarak kazanılır."\r
patch_notes.artifacts_3: "Şu anda 10 farklı Kalıntı bulunuyor; gelecek güncellemelerde yenileri eklenecek."\r
patch_notes.improvements: "İYİLEŞTİRMELER"\r
patch_notes.improvements_1: "Özellikle mobil cihazlarda görünürlüğü artırmak için çeşitli arayüz iyileştirmeleri yapıldı."\r
patch_notes.improvements_2: "Araştırma kilitleri ve düşman güçleriyle ilgili küçük değer ayarlamaları yapıldı."\r
tip.1: "Eninde sonunda düşmanlar sizi bunaltacak. Daha ileri gidebilmek için yeni araştırmalar açmayı deneyin."\r
tip.2: "Hareket etmeye devam edin: Sabit durmak yaklaşan tehlikeleri okumayı çok daha zor hâle getirir."\r
tip.3: "Bir düşmanın ömrünün son saniyeleri yanıp sönmeyle belirtilir."\r
tip.4: "Araştırma yükseltmeleri seferler arasında kalıcıdır; bu yüzden kısa bir sefer bile ilerlemenizi sağlayabilir."\r
tip.5: "Düşmanların yaklaşabileceği yönleri azaltmak için arena kenarını kullanın."\r
tip.6: "Chronoshard nadir, değerli ve kısa ömürlüdür. Kaybolmadan önce topladığınızdan emin olun."\r
tip.7: "Arenada bir rota seçmeden önce düşmanların menzil halkalarını takip edin."\r
tip.8: "Oyunun ilerleyen bölümlerinde Araştırma Laboratuvarından güçlendiricilerin kilidini açabilirsiniz."\r
tip.9: "Sektör IV'e ulaştıktan sonra arenada size yardımcı olacak Yapılar inşa etme özelliğini açabilirsiniz."\r
tip.10: "Mor düşmanlara Sinsici denir ve zamanla giderek hızlanırlar. Engellere yaptıkları statik çarpışmalarla yavaşlatılabilirler."\r
tip.11: "Kırmızı düşmanlara Takipçi denir ve sizi etkin biçimde kovalarlar. Engellere yaptıkları statik çarpışmalarla yavaşlatılabilirler."\r
tip.12: "Sarı düşmanlara Patlayıcı denir ve birkaç saniye sonra patlarlar."\r
tip.13: "Ne kadar çok Hücre toplarsanız oyun o kadar zorlaşır."\r
tip.14: "Oyunda ilerledikçe yeni düşmanlar ve engeller ortaya çıkar; yeni zorluklara hazırlıklı olun."\r
cheat.title: "HATA AYIKLAMA KONSOLU"\r
cheat.prompt: "Bir komut girin."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Sektör {sector} seviyesine ulaşmanız gerekiyor."\r
cheat.feature_cells: "Sektör {sector} içinde {cells} Hücre toplamanız gerekiyor."\r
cheat.feature_chronoshards: "✦ {amount} Chronoshardna ihtiyacınız var."\r
cheat.feature_unavailable: "Bu sistem henüz kullanılamıyor."\r
cheat.research_completed: "{research} araştırması tamamlandı."\r
status.damage: "{status} HASARI"\r
cheat.sandbox_started: "Sandbox Sektör I başlatıldı. sandbox [sector], sandbox simulate [cell|enemies|all] veya sandbox spawn [enemy] [count] komutlarını kullanın."\r
cheat.sandbox_sector: "Sandbox zorluğu Sektör {sector} olarak ayarlandı. Doğma simülasyonu değiştirilmedi."\r
cheat.sandbox_start_first: "Önce şu komutla Sandbox'ı başlatın: sandbox"\r
cheat.sandbox_simulate_usage: "Kullanım: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simülasyonu Sektör {sector} için başlatıldı."\r
cheat.sandbox_spawn_usage: "Kullanım: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "{count} {enemy}{plural} oluşturuldu."\r
cheat.sandbox_usage: "Kullanım: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"
cheat.anomaly_usage: "Kullanım: anomaly <anomaly_id>"
cheat.anomaly_unknown: "Bilinmeyen Anomaly: {id}. Mevcut: {available}"
cheat.anomaly_started: "{id} Anomaly'si Sektör {sector} içinde başlatıldı."
cheat.cell_usage: "Kullanım: cell <pozitif miktar>"
cheat.cell_requires_round: "Hücre vermeden önce bir tur başlat."
cheat.cell_granted: "Nakit vermeden {amount} Hücre eklendi. Toplam: {total}."
cheat.god_usage: "Kullanım: god <on/off>"
cheat.god_state: "God mode {state}."
cheat.on: "AÇIK"
cheat.off: "KAPALI"
cheat.artifact_usage: "Kullanım: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Bilinmeyen Kalıntı: {artifact}"\r
cheat.artifact_stack_range: "Birikim 1 ile 10.000 arasında bir tam sayı olmalıdır."\r
cheat.artifact_granted: "{count} {artifact} {stackWord} verildi (toplam {total})."\r
cheat.artifact_unique: "{artifact} benzersiz bir Kalıntıdır ve artık açıldı."\r
cheat.amount_usage: "Kullanım: {command} [positive amount]"\r
cheat.amount_granted: "{amount} verildi."\r
cheat.free_research: "Bu oturum için ücretsiz araştırma etkinleştirildi."\r
cheat.sectors_unlocked: "Tüm sektörler ve Yükseliş ödülleri açıldı.{rewards}"\r
cheat.clear_usage: "Kullanım: clear_save [{targets}]"\r
cheat.cleared: "{target} kayıt verileri temizlendi."\r
cheat.unknown_command: "Bilinmeyen komut: {command}"\r
menu.patch_notes: "YAMA NOTLARI"\r
menu.unlock_feature: "{feature} KİLİDİNİ AÇ · ✦ {cost}"\r
menu.feature_sector: "{feature} · SEKTÖR {sector}"\r
`,Ne=`language.english: "Inglés"\r
language.turkish: "Turco"\r
language.spanish: "Español"\r
settings.language: "Idioma"\r
settings.language_help: "Elige el idioma utilizado por la interfaz del juego."\r
save_slots.heading: "SELECCIONAR RANURA DE GUARDADO"\r
save_slots.archive: "ARCHIVO DE MANDO"\r
save_slots.description: "Elige un archivo de piloto para continuar tu expedición."\r
save_slots.slot: "RANURA {slot}"\r
save_slots.new_expedition: "NUEVA EXPEDICIÓN"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MÁX. CÉLULAS"\r
save_slots.total_cash: "DINERO TOTAL"\r
save_slots.total_chronoshards: "CRONOFRAGMENTOS TOTALES"\r
research.category.player_enhancements: "Mejoras del jugador"\r
research.category.economy: "Economía"\r
research.category.boosters: "Potenciadores"\r
research.category.weapons: "Armas"\r
research.category.building_system: "Sistema de construcción"\r
research.category.enemy_debuff: "Debilitamiento de enemigos"\r
research.lucky-find.name: "Hallazgo afortunado"\r
research.lucky-find.description: "Las cartas de arma tienen una probabilidad de convertirse en Hallazgos afortunados y otorgar 2 cartas en lugar de 1."\r
research.weapon-recharge.name: "Recarga de armas"\r
research.weapon-recharge.description: "Las armas ahora pueden recargarse con el tiempo."\r
research.weapon-recharge-rate.name: "Velocidad de recarga de armas"\r
research.weapon-recharge-rate.description: "Reduce el tiempo de recarga de las armas."\r
research.weapon-charge-capacity.name: "Capacidad de cargas del arma"\r
research.weapon-charge-capacity.description: "Aumenta en 1 el máximo de cargas almacenadas de cada arma equipada."\r
research.weapon-slots.name: "Ranura de arma"\r
research.weapon-slots.description: "Añade una ranura de arma a tu equipamiento de partida."\r
research.player-speed-multiplier.name: "Multiplicador de velocidad del jugador"\r
research.player-speed-multiplier.description: "Aumenta la velocidad de movimiento del jugador."\r
research.unlock-slow-aura.name: "Desbloquear Aura ralentizadora"\r
research.unlock-slow-aura.description: "Desbloquea la habilidad Aura ralentizadora, que ralentiza a los enemigos cercanos dentro de su alcance."\r
research.unlock-orbital-electron.name: "Desbloquear Electrón orbital"\r
research.unlock-orbital-electron.description: "Despliega un Electrón que orbita tu alcance efectivo y aturde a los enemigos alcanzados por su arco eléctrico."\r
research.electron-stun-duration.name: "Duración del aturdimiento del Electrón"\r
research.electron-stun-duration.description: "Aumenta el tiempo que permanecen aturdidos los enemigos alcanzados por el Electrón orbital."\r
research.electron-speed.name: "Velocidad del Electrón"\r
research.electron-speed.description: "Aumenta la velocidad orbital del Electrón orbital."\r
research.slow-aura-effect.name: "Efecto del Aura ralentizadora"\r
research.slow-aura-effect.description: "Aumenta el efecto de la habilidad Aura ralentizadora."\r
research.slow-aura-range.name: "Alcance del efecto"\r
research.slow-aura-range.description: "Aumenta el alcance de todos los efectos activos basados en alcance."\r
research.cell-spawn-rate.name: "Frecuencia de aparición de Células"\r
research.cell-spawn-rate.description: "Aumenta la frecuencia de aparición de Células estándar."\r
research.cell-increment-per-cell.name: "Incremento por Célula"\r
research.cell-increment-per-cell.description: "Cada Célula recogida aumenta la frecuencia de aparición de Células estándar."\r
research.cash-cell-multiplier.name: "Multiplicador Dinero/Célula"\r
research.cash-cell-multiplier.description: "Aumenta el Dinero obtenido por cada Célula estándar."\r
research.initial-cell-count.name: "Célula inicial"\r
research.initial-cell-count.description: "Añade una Célula a la arena al comienzo de cada partida."\r
research.cell-magnet.name: "Imán de Células"\r
research.cell-magnet.description: "Atrae hacia ti las Células cercanas. Cada nivel aumenta la velocidad de atracción."\r
research.chrono-spawn-rate.name: "Frecuencia de aparición crono"\r
research.chrono-spawn-rate.description: "Hace que las Células crono aparezcan con mayor frecuencia."\r
research.chrono-lifetime-multiplier.name: "Multiplicador de duración crono"\r
research.chrono-lifetime-multiplier.description: "Aumenta la duración de las Células crono."\r
research.unlock-shockwave.name: "Desbloquear Onda de choque"\r
research.unlock-shockwave.description: "Emite periódicamente una onda de choque verde que empuja a los enemigos."\r
research.shockwave-frequency.name: "Frecuencia de Onda de choque"\r
research.shockwave-frequency.description: "Hace que las Ondas de choque se activen con mayor frecuencia."\r
research.shield.name: "Escudo"\r
research.shield.description: "Otorga una salvación de muerte por nivel al comienzo de cada partida."\r
research.building-slots.name: "Ranuras de edificios"\r
research.building-slots.description: "Aumenta en 1 la cantidad de edificios que puedes colocar en la arena."\r
research.unlock-speed-booster.name: "Desbloquear Potenciadores de velocidad"\r
research.unlock-speed-booster.description: "Desbloquea objetos de Potenciador de velocidad que duplican la velocidad de movimiento."\r
research.speed-booster-duration.name: "Duración del Potenciador de velocidad"\r
research.speed-booster-duration.description: "Aumenta la duración del Potenciador de velocidad."\r
research.thorn-shield.name: "Escudo de espinas"\r
research.thorn-shield.description: "Desbloquea objetos de Escudo de espinas que otorgan inmunidad y destruyen enemigos al contacto."\r
research.thorn-shield-duration.name: "Duración del Escudo de espinas"\r
research.thorn-shield-duration.description: "Aumenta la duración del Escudo de espinas."\r
research.freezer.name: "Congelador"\r
research.freezer.description: "Desbloquea objetos de Congelador que congelan a todos los enemigos."\r
research.freezer-duration.name: "Duración del Congelador"\r
research.freezer-duration.description: "Aumenta la duración del Congelador."\r
research.pushback.name: "Repulsión"\r
research.pushback.description: "Empuja a los enemigos estacionarios cercanos. Cada nivel aumenta la velocidad de empuje."\r
research.shield-invulnerability-duration.name: "Resplandor del escudo"\r
research.shield-invulnerability-duration.description: "Aumenta el tiempo de invulnerabilidad después de que el Escudo se rompe."\r
research.shield-break-explosion.name: "Explosión al romperse el Escudo"\r
research.shield-break-explosion.description: "Destruye a todos los enemigos dentro del alcance cuando el Escudo se rompe. Cada nivel aumenta el alcance."\r
research.regular-lifetime-debuff.name: "Deterioro de Comunes"\r
research.regular-lifetime-debuff.description: "Reduce la duración de los enemigos Comunes."\r
research.chaser-range-debuff.name: "Amortiguador de alcance del Perseguidor"\r
research.chaser-range-debuff.description: "Reduce el alcance de detección del Perseguidor."\r
research.creeper-speed-debuff.name: "Ralentización del Reptante"\r
research.creeper-speed-debuff.description: "Reduce la velocidad de movimiento del Reptante."\r
research.banger-range-debuff.name: "Amortiguador de alcance del Explosivo"\r
research.banger-range-debuff.description: "Reduce el alcance de explosión del Explosivo."\r
research.banger-enemy-destruction.name: "Disrupción del Explosivo"\r
research.banger-enemy-destruction.description: "Otorga a la explosión del Explosivo una probabilidad de destruir a los enemigos afectados."\r
research.shooter-range-debuff.name: "Amortiguador de alcance del Tirador"\r
research.shooter-range-debuff.description: "Reduce el alcance de disparo del Tirador."\r
research.shooter-projectile-debuff.name: "Resistencia de proyectiles"\r
research.shooter-projectile-debuff.description: "Reduce la velocidad de los proyectiles del Tirador."\r
research.porter-interval-debuff.name: "Campo de retraso del Teletransportador"\r
research.porter-interval-debuff.description: "Aumenta el intervalo entre los teletransportes del Teletransportador."\r
research.magnet-strength-debuff.name: "Aislamiento magnético"\r
research.magnet-strength-debuff.description: "Reduce la fuerza de atracción del Imán."\r
research.spore-speed-debuff.name: "Resistencia de la Espora"\r
research.spore-speed-debuff.description: "Reduce la velocidad de movimiento de la Espora."\r
research.poison-creep-clean.name: "Limpieza de rastro venenoso"\r
research.poison-creep-clean.description: "Reduce el tiempo que permanecen los rastros del Reptante venenoso."\r
weapon.nuke.name: "Bomba nuclear"\r
weapon.nuke.description: "Destruye un porcentaje de los enemigos de la arena."\r
weapon.megaMagnet.name: "Megaimán"\r
weapon.megaMagnet.description: "Atrae rápidamente todas las Células hacia tu nave."\r
weapon.atmosphereShield.name: "Escudo atmosférico"\r
weapon.atmosphereShield.description: "Destruye y bloquea meteoros que caen durante un breve periodo."\r
weapon.phaseDash.name: "Impulso de fase"\r
weapon.phaseDash.description: "Atraviesa a los enemigos y elimina a todos los que haya en tu trayectoria."\r
weapon.chronoFreeze.name: "Cronocongelación"\r
weapon.chronoFreeze.description: "Congela a todos los enemigos y su tiempo de vida durante un breve periodo."\r
weapon.plasmaOrbital.name: "Plasma orbital"\r
weapon.plasmaOrbital.description: "Despliega plasmas orbitales que destruyen enemigos al contacto."\r
weapon.cellOverdrive.name: "Sobrecarga de Células"\r
weapon.cellOverdrive.description: "Duplica las Células recogidas durante un breve periodo."\r
weapon.demonMode.name: "Modo demonio"\r
weapon.demonMode.description: "Muévete más rápido y destruye a los enemigos que atravieses."\r
weapon.remove_loadout: "QUITAR DEL EQUIPAMIENTO"\r
weapon.add_loadout: "AÑADIR AL EQUIPAMIENTO"\r
weapon.replace_with: "REEMPLAZAR POR {weapon}"\r
weapon.replace_selected: "REEMPLAZAR ARMA SELECCIONADA"\r
weapon.buy: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.empty_slot: "RANURA VACÍA"\r
weapon.not_collected: "Aún no obtenida"\r
weapon.max_level: "NIVEL MÁXIMO"\r
weapon.claim: "RECLAMAR"\r
weapon.next: "SIGUIENTE"\r
weapon.unlocked: "DESBLOQUEADA"\r
weapon.unlocked_level: "Desbloqueada en el nivel 1."\r
weapon.level_up: "SUBIR DE NIVEL · NV. {level}"\r
weapon.upgraded_level: "Mejorada al nivel {level}."\r
weapon.max_level_copy: "COPIA DE NIVEL MÁXIMO"\r
weapon.max_level_detail: "Esta arma ya está en el nivel máximo."\r
weapon.copy: "COPIA · NV. {level}"\r
weapon.copy_progress: "{copies}/{required} copias para alcanzar el nivel {level}."\r
artifact.broken-radar.name: "Radar averiado"\r
artifact.broken-radar.buff: "+10% a la frecuencia de aparición de Células"\r
artifact.ftl-schematics.name: "Planos FTL"\r
artifact.ftl-schematics.buff: "+10% a la velocidad de movimiento del jugador"\r
artifact.supply-depot.name: "Depósito de suministros"\r
artifact.supply-depot.buff: "+5 Células iniciales"\r
artifact.broken-extractor.name: "Extractor averiado"\r
artifact.broken-extractor.buff: "+10% al Dinero obtenido de Células"\r
artifact.construction-bot.name: "Robot constructor"\r
artifact.construction-bot.buff: "-10% al precio de los Edificios"\r
artifact.alientech-gizmo.name: "Dispositivo de tecnología alienígena"\r
artifact.alientech-gizmo.buff: "-20% al coste de Investigación"\r
artifact.broken-hard-drive.name: "Disco duro averiado"\r
artifact.broken-hard-drive.buff: "+1 Ranura de arma"\r
artifact.hubble-telescope.name: "Telescopio Hubble"\r
artifact.hubble-telescope.buff: "+20% al alcance de efectos del jugador"\r
artifact.dark-core.name: "Núcleo oscuro"\r
artifact.dark-core.buff: "+1% a los Cronofragmentos obtenidos"
artifact.map-to-earth.name: "Mapa hacia la Tierra"\r
artifact.map-to-earth.buff: "+20% al tamaño de la arena en cada Sector"\r
building.chronoGenerator.name: "Generador crono"\r
building.autocannon.name: "Cañón automático"\r
building.droneBay.name: "Hangar de drones"\r
building.barrierNode.name: "Nodo de barrera"\r
building.overclockRelay.name: "Relé de overclock"\r
building.salvageExtractor.name: "Extractor de salvamento"\r
building.upgrade.range: "Alcance"\r
building.upgrade.effectiveness: "Eficacia"\r
building.upgrade.frequency: "Frecuencia"\r
building.upgrade.period: "Periodo"\r
building.upgrade.count: "Cantidad"\r
building.upgrade.duration: "Duración"\r
building.upgrade.cash: "Dinero"\r
encyclopedia.category.enemies: "Enemigos"\r
encyclopedia.category.meteors: "Meteoros"\r
enemy.regular.name: "Común"\r
enemy.regular.description: "Un enemigo asteroide estacionario. Mantente alejado de su cuerpo mientras recoges Células."\r
enemy.chaser.name: "Perseguidor"\r
enemy.chaser.description: "Detecta la nave dentro de su alcance y la persigue."\r
enemy.creeper.name: "Reptante"\r
enemy.creeper.description: "Se acerca lentamente desde cualquier distancia y se vuelve más rápido cuanto más tiempo sobrevive."\r
enemy.poisonCreeper.name: "Reptante venenoso"\r
enemy.poisonCreeper.description: "Una variante del Reptante que alterna entre púrpura y verde oscuro mientras deja rastros venenosos."\r
enemy.banger.name: "Explosivo"\r
enemy.banger.description: "Se arma, emite pulsos de advertencia y después detona en una amplia zona."\r
enemy.shooter.name: "Tirador"\r
enemy.shooter.description: "Dispara proyectiles contra la nave cuando entra en su alcance de disparo."\r
enemy.porter.name: "Teletransportador"\r
enemy.porter.description: "Se teletransporta ocasionalmente a ubicaciones aleatorias."\r
enemy.magnet.name: "Imán"\r
enemy.magnet.description: "Atrae la nave hacia sí mientras se encuentra dentro de su alcance."\r
enemy.spore.name: "Espora"\r
enemy.spore.description: "Explota en pequeños fragmentos de sí misma y luego vuelve a dividirse en fragmentos aún más pequeños."\r
enemy.stoneRock.name: "Roca pétrea"\r
enemy.stoneRock.description: "Un meteoro estándar en caída. Evita su punto de impacto marcado."\r
enemy.fieryRock.name: "Roca ígnea"\r
enemy.fieryRock.description: "Un meteoro en llamas que deja una zona de fuego dañina tras el impacto."\r
enemy.splinter.name: "Esquirla"\r
enemy.splinter.description: "Se hace añicos al impactar y lanza fragmentos hacia el exterior."\r
status.fire: "En llamas"\r
status.poison: "Envenenado"\r
anomaly.cell-scout.name: "Rivalidad de exploradores"\r
anomaly.cell-scout.description: "Una nave de IA roja y distante recoge Células junto a ti. Sus Células no cuentan para tu partida y no puede dañarte."
anomaly.tower-defense.name: "Defensa de la torre"
anomaly.tower-defense.description: "Defiende la torre central de las oleadas enemigas. Destruye 1.000 enemigos antes de que caiga la torre."
anomaly.tower_health: "TORRE {current}/{maximum}"
anomaly.tower_defended: "TORRE DEFENDIDA"
anomaly.tower_defended_copy: "Destruiste {cells} enemigos y aseguraste la torre."
anomaly.tower_destroyed: "TORRE DESTRUIDA"
anomaly.tower_destroyed_copy: "La torre cayó después de destruir {cells} enemigos."
anomaly.dark_core_stack: "ARTEFACTO · CARGA DE {artifact}"
anomaly.run: "PARTIDA DE ANOMALÍA"\r
anomaly.weekly: "ANOMALÍA SEMANAL"\r
anomaly.start: "INICIAR PARTIDA DE ANOMALÍA"\r
anomaly.verifying_title: "VERIFICANDO HORA"\r
anomaly.verifying_copy: "Comprobando la Anomalía semanal actual con el servidor del juego."\r
anomaly.reward: "{cells} CÉLULAS · RECOMPENSA ✦ {reward}"\r
anomaly.reset: "(Nueva Anomalía en {date})"\r
anomaly.reward_claimed: "La recompensa de la Anomalía semanal de este sector ya ha sido reclamada."\r
anomaly.time_unverified_title: "HORA NO VERIFICADA"\r
anomaly.time_unverified_copy: "No se pudo verificar la Anomalía semanal actual."\r
anomaly.time_unverified_error: "No pudimos verificar la hora del servidor ni comprobar tu conexión a Internet. Revisa tu conexión e inténtalo de nuevo."\r
menu.home: "INICIO"\r
menu.research_lab: "LABORATORIO DE INVESTIGACIÓN"\r
menu.weaponry: "ARMAMENTO"\r
menu.buildings: "SISTEMA DE CONSTRUCCIÓN"\r
menu.encyclopedia: "ENCICLOPEDIA"\r
menu.settings: "AJUSTES"\r
menu.artifacts: "ARTEFACTOS"\r
menu.exit_game: "SALIR DEL JUEGO"\r
menu.start_run: "INICIAR PARTIDA"\r
menu.continue: "CONTINUAR"\r
menu.run_again: "JUGAR DE NUEVO"\r
menu.back: "ATRÁS"\r
menu.pause: "PAUSA"\r
menu.round_paused: "PARTIDA EN PAUSA"\r
menu.reset: "REINICIAR"\r
menu.surrender: "RENDIRSE"\r
menu.return: "VOLVER"\r
menu.main_menu: "MENÚ PRINCIPAL"\r
hud.cash: "DINERO"\r
hud.chronoshards: "CRONOFRAGMENTOS"\r
hud.cells: "CÉLULAS"\r
hud.shields: "ESCUDOS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SECTOR DE PRUEBAS {sector}"\r
hud.anomaly_suffix: " · ANOMALÍA"\r
settings.preferences: "PREFERENCIAS"\r
settings.graphics: "GRÁFICOS"\r
settings.gameplay: "JUGABILIDAD"\r
settings.sound: "SONIDO"\r
settings.quality: "Calidad"\r
settings.quality_help: "Cambia la resolución de renderizado y las sombras."\r
settings.low: "BAJA"\r
settings.medium: "MEDIA"\r
settings.high: "ALTA"\r
settings.shadows: "Sombras"\r
settings.shadows_help: "Muestra sombras dinámicas de los objetos."\r
settings.hdr_emission: "Emisión HDR"\r
settings.hdr_emission_help: "Controla cuánto se extienden los efectos brillantes más allá de sus modelos."\r
settings.max_fps: "FPS máximos"\r
settings.max_fps_help: "Limita el renderizado y la simulación para reducir la carga de hardware."\r
settings.unlimited: "SIN LÍMITE"\r
settings.auto_pause: "Pausa automática"\r
settings.auto_pause_help: "Pausa la partida cuando el juego pierde el foco."\r
settings.high_contrast_hud: "HUD de alto contraste"\r
settings.high_contrast_hud_help: "Mejora la legibilidad del HUD."\r
settings.master_volume: "Volumen general"\r
settings.master_volume_help: "Controla todos los efectos de sonido del juego."\r
settings.mute_all: "Silenciar todo"\r
settings.mute_all_help: "Silencia instantáneamente todos los efectos de sonido."\r
settings.spatial_audio: "Audio espacial"\r
settings.spatial_audio_help: "Distribuye los sonidos según su posición en el mundo."\r
settings.patch_notes: "NOTAS DEL PARCHE"\r
settings.display: "PANTALLA"\r
settings.screen_mode: "Modo de pantalla"\r
settings.screen_mode_help: "Steam inicia el juego en pantalla completa de forma predeterminada."\r
settings.resolution: "Resolución"\r
settings.resolution_help: "Al elegir una resolución se cambia al modo ventana."\r
settings.fullscreen: "PANTALLA COMPLETA"\r
settings.windowed: "VENTANA"\r
milestone.ascension: "ASCENSIÓN"\r
milestone.max_cells: "MÁX. CÉLULAS"\r
milestone.cells: "{cells} CÉLULAS"\r
milestone.next: "SIGUIENTE ASCENSIÓN: {cells} CÉLULAS"\r
milestone.ready: "RECOMPENSA DE ASCENSIÓN LISTA PARA RECLAMAR"\r
milestone.complete: "ASCENSIÓN COMPLETADA"\r
milestone.claim: "RECLAMAR RECOMPENSA"\r
milestone.claimed: "Reclamada"\r
milestone.secured: "RECOMPENSA ASEGURADA"\r
milestone.auto_claimed: "Reclamada automáticamente"\r
milestone.best: "Mejor marca: {best}/{target} Células en el Sector {sector}"\r
milestone.reward_claimed: "RECOMPENSA RECLAMADA · {rewards}"\r
milestone.reward_cash: "+\${amount} de Dinero"\r
milestone.reward_chronoshards: "+✦ {amount} Cronofragmentos"\r
milestone.unlock_sector: "Desbloquear Sector {sector}"\r
milestone.unlock_feature: "Desbloquear {feature}"\r
milestone.unlock_research: "Desbloquear: {researches}"\r
error.server_time_unconfigured: "El endpoint de hora del servidor no está configurado."\r
error.server_time_request: "La solicitud de hora del servidor falló con {status}."\r
error.server_time_invalid: "El servidor devolvió una hora no válida."\r
message.round_saved: "Partida guardada. Continúa cuando quieras."\r
message.sandbox_closed: "Se cerró el modo de pruebas. No se guardó ningún progreso."\r
message.run_surrendered: "Te rendiste en la partida. No se guardó ningún progreso."\r
message.killed_by: "ELIMINADO POR {cause}"\r
message.energy_secured: "Has asegurado {count} {cellWord} de energía."\r
message.cell_singular: "célula"\r
message.cell_plural: "células"\r
message.tip: "CONSEJO · {tip}"\r
message.anomaly_reward: "ANOMALÍA +✦{amount}"\r
artifact.acquired: "ARTEFACTO OBTENIDO"\r
artifact.acquired_named: "ARTEFACTO OBTENIDO · {artifact}"\r
artifact.locked: "ARTEFACTO BLOQUEADO"\r
artifact.unknown: "ARTEFACTO DESCONOCIDO"\r
encyclopedia.unknown_enemy: "Enemigo desconocido"\r
research.slot: "RANURA {slot}"\r
research.available: "DISPONIBLE"\r
research.locked: "BLOQUEADA"\r
research.remaining: "Quedan {duration}"\r
research.select_below: "Selecciona una investigación abajo."\r
research.unlock_for: "Desbloquear por {cost}"\r
research.unlock_sector: "Desbloquea la investigación del Sector {sector} en Hitos"\r
research.max_level: "NIVEL MÁXIMO"\r
research.in_progress: "EN PROGRESO"\r
research.free_enabled: "INVESTIGACIÓN GRATUITA ACTIVADA"\r
research.cost: "Coste {cost}"\r
research.maxed: "AL MÁXIMO"\r
research.start: "INVESTIGAR"\r
research.no_search_results: "Ningún nombre de investigación coincide con tu búsqueda."\r
research.started: "La investigación {research} ha comenzado en la Ranura {slot}."\r
research.upgraded: "{research} mejorada al nivel {level}."\r
research.slot_unlocked: "Ranura de investigación {slot} desbloqueada."\r
research.requires_sector_cells: "Requiere {cells} Células en el Sector {sector}"\r
research.requires_banked_cells: "Requiere {cells} células almacenadas"\r
research.requires_research: "Requiere {research}"\r
research.requires_research_level: "Requiere {research} Nv. {level}"\r
weapon.number: "ARMA {current} / {total}"\r
weapon.cards: "CARTAS DE ARMA"\r
weapon.round_loadout: "EQUIPAMIENTO DE PARTIDA"\r
weapon.buy_with_cost: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five_with_cost: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.level: "NV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copias para Nv. {level}"\r
weapon.lucky_find_double: "HALLAZGO AFORTUNADO · 2 CARTAS"\r
weapon.lucky_find_unlock: "Desbloqueada en el nivel 1 y recibiste una copia adicional."\r
weapon.lucky_find_received: "Recibiste 2 cartas. {detail}"\r
artifact.stacks: "{count} acumulaciones"\r
artifact.stack: "{count} ACUMULACIÓN"\r
artifact.stacks_label: "{count} ACUMULACIONES"\r
artifact.dark_core_stack: "{count} ACUMULACIÓN DE NÚCLEO OSCURO"\r
artifact.dark_core_stacks: "{count} ACUMULACIONES DE NÚCLEO OSCURO"\r
artifact.to_acquire: "POR OBTENER"\r
artifact.permanent_buff: "BONIFICACIÓN PERMANENTE"\r
artifact.buff_per_stack: "{buff} por acumulación · {count} acumulaciones = +{percent}% de Cronofragmentos obtenidos"\r
artifact.requirement_score: "Alcanza {cells} Células en el Sector {sector}."\r
artifact.requirement_milestone: "Reclama la recompensa de Ascensión de {cells} Células del Sector {sector}."\r
artifact.requirement_anomaly: "Completa cada Anomalía en cada Sector. Cada combinación única de Anomalía y Sector otorga una acumulación."
artifact.requirement_hidden: "Condición oculta."\r
artifact.requirement_default: "Completa este logro de artefacto."\r
building.choose_offer: "ELIGE 1 DE {count} · SIGUIENTE DESBLOQUEO ✦ {cost}"\r
building.all_unlocked: "TODOS LOS EDIFICIOS DESBLOQUEADOS"\r
building.permanent_unlock: "Desbloqueo permanente de edificio"\r
building.unlock_cost: "DESBLOQUEAR · ✦ {cost}"\r
building.upgrade: "MEJORAR"\r
building.slot_limit: "LÍMITE DE RANURAS"\r
building.build_cost: "Coste de construcción: \${cost}"\r
building.unlocked: "DESBLOQUEADO"\r
building.none_unlocked: "AÚN NO HAY EDIFICIOS DESBLOQUEADOS"\r
building.build_mode_slots: "MODO CONSTRUCCIÓN · RANURAS {used}/{total}"\r
building.level: "NV. {level}"\r
building.installed_defense: "DEFENSA INSTALADA"\r
building.choose_upgrade: "Elige una mejora para esta estructura."\r
building.upgrade_level: "NV. {current} → {next}"\r
building.demolish_refund: "DEMOLER · REEMBOLSO \${amount}"\r
building.demolish_confirm: "¿Demoler {building}? Recibirás un reembolso de \${refund}."\r
research.active_slots: "RANURAS ACTIVAS"\r
research.available_research: "INVESTIGACIONES DISPONIBLES"\r
research.search: "BUSCAR"\r
research.search_placeholder: "Buscar nombres de investigaciones"\r
research.hide_completed: "Ocultar investigaciones completadas"\r
research.hide_locked: "Ocultar investigaciones bloqueadas"\r
artifact.permanent_achievements: "LOGROS PERMANENTES"\r
artifact.intro: "Los Artefactos son recompensas permanentes obtenidas al alcanzar objetivos de logros."\r
building.permanent_defenses: "DEFENSAS PERMANENTES"\r
building.system: "SISTEMA DE CONSTRUCCIÓN"\r
building.build_mode: "MODO CONSTRUCCIÓN"\r
building.unlock_a_building: "DESBLOQUEAR UN EDIFICIO"\r
building.unlocked_buildings: "EDIFICIOS DESBLOQUEADOS"\r
building.draft: "SELECCIÓN DE EDIFICIO"\r
weapon.active_arsenal: "ARSENAL ACTIVO"\r
menu.back: "ATRÁS"\r
menu.done: "HECHO"\r
encyclopedia.threat_database: "BASE DE DATOS DE AMENAZAS"\r
accessibility.game_canvas: "Lienzo del juego Asteroid Belt"\r
accessibility.current_sector: "Sector de dificultad actual"\r
accessibility.pause_game: "Pausar juego"\r
accessibility.shield_charges: "Cargas de escudo"\r
accessibility.game_controls: "Controles del juego"\r
accessibility.build_information: "Información de construcción"\r
accessibility.build_locations: "Ubicaciones de construcción"\r
accessibility.pause_menu: "Menú de pausa"\r
accessibility.debug_console: "Consola de depuración"\r
accessibility.close_debug_console: "Cerrar consola de depuración"\r
accessibility.save_slots: "Selección de ranura de guardado"\r
accessibility.defeating_enemy: "Modelo 3D de enemigo derrotado"\r
accessibility.sector_selection: "Selección de sector de dificultad"\r
accessibility.previous_sector: "Seleccionar sector anterior"\r
accessibility.next_sector: "Seleccionar sector siguiente"\r
accessibility.previous_milestone_sector: "Ver sector de hito anterior"\r
accessibility.next_milestone_sector: "Ver sector de hito siguiente"\r
accessibility.enemy_model: "Modelo de {enemy}"\r
controls.move: "MOVERSE"\r
controls.navigate: "NAVEGAR"\r
controls.use_weapon: "USAR ARMA"\r
controls.select_weapon: "SELECCIONAR / USAR ARMA"\r
patch_notes.version_build: "VERSIÓN {version} · COMPILACIÓN {build}"\r
patch_notes.artifacts: "ARTEFACTOS"\r
patch_notes.artifacts_1: "Presentamos el Sistema de Artefactos: una mecánica de logros que recompensa al jugador con bonificaciones y recompensas permanentes al cumplir ciertos objetivos."\r
patch_notes.artifacts_2: "Los Artefactos se obtienen principalmente al alcanzar 500 Células en el Nivel 2 y superiores."\r
patch_notes.artifacts_3: "Actualmente hay 10 Artefactos distintos; se añadirán más en próximas actualizaciones."\r
patch_notes.improvements: "MEJORAS"\r
patch_notes.improvements_1: "Diversas mejoras de la interfaz para aumentar la visibilidad, especialmente en dispositivos móviles."\r
patch_notes.improvements_2: "Pequeños ajustes de valores relacionados con los desbloqueos de Investigación y la fuerza de los Enemigos."\r
tip.1: "Con el tiempo acabarás siendo superado. Intenta desbloquear nuevas investigaciones para llegar más lejos."\r
tip.2: "Sigue moviéndote: quedarte quieto hace que sea mucho más difícil anticipar los peligros entrantes."\r
tip.3: "Los últimos segundos de vida de un enemigo se indican con un parpadeo."\r
tip.4: "Las mejoras de Investigación se conservan entre partidas, así que incluso una partida corta puede hacerte avanzar."\r
tip.5: "Usa el borde de la arena para reducir las direcciones desde las que pueden acercarse los enemigos."\r
tip.6: "Los Cronofragmentos son raros, valiosos y duran poco. Asegúrate de recogerlos antes de que desaparezcan."\r
tip.7: "Observa los anillos de alcance de los enemigos antes de decidir una ruta por la arena."\r
tip.8: "Más adelante en el juego puedes desbloquear potenciadores desde el Laboratorio de Investigación."\r
tip.9: "Tras alcanzar el Sector IV, puedes desbloquear la capacidad de construir Edificios que te ayuden en la arena."\r
tip.10: "Los enemigos púrpura se llaman Reptantes y aumentan gradualmente su velocidad con el tiempo. Las colisiones estáticas con obstáculos pueden ralentizarlos."\r
tip.11: "Los enemigos rojos se llaman Perseguidores y te perseguirán activamente. Las colisiones estáticas con obstáculos pueden ralentizarlos."\r
tip.12: "Los enemigos amarillos se llaman Explosivos y explotan después de unos segundos."\r
tip.13: "Cuantas más Células recoges, más difícil se vuelve el juego."\r
tip.14: "A medida que avanzas por el juego aparecen nuevos enemigos y obstáculos, así que prepárate para nuevos desafíos."\r
cheat.title: "CONSOLA DE DEPURACIÓN"\r
cheat.prompt: "Introduce un comando."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Debes alcanzar el Sector {sector}."\r
cheat.feature_cells: "Debes recoger {cells} Células en el Sector {sector}."\r
cheat.feature_chronoshards: "Necesitas ✦ {amount} Cronofragmentos."\r
cheat.feature_unavailable: "Este sistema aún no está disponible."\r
cheat.research_completed: "Investigación {research} completada."\r
status.damage: "DAÑO DE {status}"\r
cheat.sandbox_started: "Sector de pruebas I iniciado. Usa sandbox [sector], sandbox simulate [cell|enemies|all] o sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "La dificultad del modo de pruebas se ha establecido en el Sector {sector}. La simulación de aparición no ha cambiado."\r
cheat.sandbox_start_first: "Primero inicia el modo de pruebas con: sandbox"\r
cheat.sandbox_simulate_usage: "Uso: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Simulación de {type} del modo de pruebas iniciada para el Sector {sector}."\r
cheat.sandbox_spawn_usage: "Uso: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Se generaron {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Uso: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"
cheat.anomaly_usage: "Uso: anomaly <anomaly_id>"
cheat.anomaly_unknown: "Anomalía desconocida: {id}. Disponibles: {available}"
cheat.anomaly_started: "Anomalía {id} iniciada en el Sector {sector}."
cheat.cell_usage: "Uso: cell <cantidad positiva>"
cheat.cell_requires_round: "Inicia una partida antes de añadir Células."
cheat.cell_granted: "Se añadieron {amount} Células sin otorgar dinero. Total: {total}."
cheat.god_usage: "Uso: god <on/off>"
cheat.god_state: "Modo dios {state}."
cheat.on: "ACTIVADO"
cheat.off: "DESACTIVADO"
cheat.artifact_usage: "Uso: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Artefacto desconocido: {artifact}"\r
cheat.artifact_stack_range: "La acumulación debe ser un número entero entre 1 y 10.000."\r
cheat.artifact_granted: "Se otorgaron {count} {artifact} {stackWord} ({total} en total)."\r
cheat.artifact_unique: "{artifact} es un Artefacto único y ahora está desbloqueado."\r
cheat.amount_usage: "Uso: {command} [positive amount]"\r
cheat.amount_granted: "Se otorgaron {amount}."\r
cheat.free_research: "Investigación gratuita activada para esta sesión."\r
cheat.sectors_unlocked: "Todos los sectores y recompensas de Ascensión desbloqueados.{rewards}"\r
cheat.clear_usage: "Uso: clear_save [{targets}]"\r
cheat.cleared: "Se borraron los datos de guardado de {target}."\r
cheat.unknown_command: "Comando desconocido: {command}"\r
menu.patch_notes: "NOTAS DEL PARCHE"\r
menu.unlock_feature: "DESBLOQUEAR {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
`;function Pe(e){return Object.fromEntries(e.split(/\r?\n/).map(e=>e.match(/^([\w.-]+):\s*"(.*)"\s*$/)).filter(Boolean).map(([,e,t])=>[e,t.replaceAll(`\\"`,`"`)]))}var Fe=Object.freeze({en:Pe(je),tr:Pe(Me),es:Pe(Ne)});function Ie(){return(typeof navigator>`u`?[]:navigator.languages?.length?navigator.languages:[navigator.language]).map(e=>e?.split(`-`)[0].toLowerCase()).find(e=>Fe[e])??`en`}function Le(){try{let e=Math.max(1,Number.parseInt(localStorage.getItem(`asteroid-belt-active-save-slot`)??`1`,10)||1),t=JSON.parse(localStorage.getItem(`asteroid-belt-slot-${e}-settings`)??localStorage.getItem(`asteroid-belt-settings`)??`null`);return Fe[t?.language]?t.language:Ie()}catch{return Ie()}}var Re=Le();function ze(e){Re=Fe[e]?e:`en`}function Be(){return Object.keys(Fe)}function S(e,t={},n=e){return(Fe[Re]?.[e]??Fe.en[e]??n).replace(/\{(\w+)\}/g,(e,n)=>String(t[n]??`{${n}}`))}var Ve={durationsEnabled:!1,categoryOrder:[`Player Enhancements`,`Economy`,`Boosters`],featureUnlocks:{researchLab:{minSector:1,chronoshardCost:0,requiredMilestone:`sector-1-10`},buildingSystem:{minSector:4,chronoshardCost:50},weaponry:{minSector:2,chronoshardCost:25}},maxSlots:3,slotUnlocks:[{slot:2,cost:{currency:`chronoshards`,amount:50},requirements:{minSector:2}},{slot:3,cost:{currency:`chronoshards`,amount:200},requirements:{minSector:3}},{slot:4,cost:{currency:`chronoshards`,amount:500},requirements:{minSector:4}},{slot:5,cost:{currency:`chronoshards`,amount:1500},requirements:{minSector:4}}],researches:[{id:`lucky-find`,category:`Weapons`,name:`Lucky Find`,description:`Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1.`,maxLevel:10,effect:{stat:`luckyFindChance`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:5e3,multiplier:1.3,jerk:1.001},duration:{baseMs:15e4,multiplier:1.16}},{id:`weapon-recharge`,category:`Weapons`,name:`Weapon Recharge`,description:`Weapons are now capable of recharging over time.`,maxLevel:1,cost:{currency:`cash`,base:6e3,multiplier:1,jerk:1},duration:{baseMs:18e4,multiplier:1}},{id:`weapon-recharge-rate`,category:`Weapons`,name:`Weapon Recharge Rate`,description:`Reduces weapon recharge time.`,maxLevel:10,effect:{stat:`weaponRechargeReductionSeconds`,perLevel:30,format:`flat`},cost:{currency:`cash`,base:3e3,multiplier:1.28,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18},requirements:{researchId:`weapon-recharge`}},{id:`weapon-charge-capacity`,category:`Weapons`,name:`Weapon Charge Capacity`,description:`Increases the maximum stored charges for each equipped weapon by 1.`,maxLevel:4,effect:{stat:`weaponChargeCapacity`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:7500,multiplier:1.42,jerk:1.002},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchId:`weapon-recharge`}},{id:`weapon-slots`,category:`Weapons`,name:`Weapon Slot`,description:`Adds one weapon slot to your round loadout.`,maxLevel:4,effect:{stat:`weaponSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:8e3,multiplier:1.8,jerk:1.01},duration:{baseMs:18e4,multiplier:1.25}},{id:`player-speed-multiplier`,category:`Player Enhancements`,name:`Player Speed Multiplier`,description:`Increases player movement speed.`,maxLevel:50,effect:{stat:`playerSpeedMultiplier`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:75,multiplier:1.14,jerk:1.0003},duration:{baseMs:9e4,multiplier:1.3}},{id:`unlock-slow-aura`,category:`Player Enhancements`,name:`Unlock Slow Aura`,description:`Unlocks the Slow Aura ability, which slows down nearby enemies within the range.`,maxLevel:1,cost:{currency:`cash`,base:600,multiplier:1,jerk:1},duration:{baseMs:9e4,multiplier:1}},{id:`unlock-orbital-electron`,category:`Player Enhancements`,name:`Unlock Orbital Electron`,description:`Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc.`,maxLevel:1,cost:{currency:`cash`,base:2e3,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`electron-stun-duration`,category:`Player Enhancements`,name:`Electron Stun Duration`,description:`Increases how long enemies hit by the Orbital Electron are stunned.`,maxLevel:20,effect:{stat:`electronStunDuration`,perLevel:.2,format:`flat`},cost:{currency:`cash`,base:2e3,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.18},requirements:{researchId:`unlock-orbital-electron`}},{id:`electron-speed`,category:`Player Enhancements`,name:`Electron Speed`,description:`Increases Orbital Electron orbit speed.`,maxLevel:20,effect:{stat:`electronSpeed`,perLevel:.35,format:`flat`},cost:{currency:`cash`,base:1500,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.16},requirements:{researchId:`unlock-orbital-electron`}},{id:`slow-aura-effect`,category:`Player Enhancements`,name:`Slow Aura Effect`,description:`Increases the effect of the Slow Aura ability.`,maxLevel:50,effect:{stat:`slowAuraEffect`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.14,jerk:1.0003},duration:{baseMs:12e7,multiplier:1.35},requirements:{researchId:`unlock-slow-aura`}},{id:`slow-aura-range`,category:`Player Enhancements`,name:`Effect Range`,description:`Increases the range of every active range-based effect.`,maxLevel:99,effect:{stat:`effectRange`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.09,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35},requirements:{anyResearch:[`unlock-slow-aura`,`cell-magnet`,`pushback`]}},{id:`cell-spawn-rate`,category:`Economy`,name:`Cell Spawn Rate`,description:`Increases the spawn rate of standard cells.`,maxLevel:99,effect:{stat:`cellSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.1,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`cell-increment-per-cell`,category:`Economy`,name:`Cell Increment Per Cell`,description:`Each collected Cell increases the standard Cell spawn rate.`,maxLevel:10,effect:{stat:`cellSpawnRatePerCell`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.35,jerk:1.003},duration:{baseMs:9e4,multiplier:1.2}},{id:`cash-cell-multiplier`,category:`Economy`,name:`Cash/Cell Multiplier`,description:`Increases the Cash earned from every standard cell.`,maxLevel:99,effect:{stat:`cashMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:60,multiplier:1.1,jerk:1.00015},duration:{baseMs:6e4,multiplier:1.25}},{id:`initial-cell-count`,category:`Economy`,name:`Initial Cell`,description:`Adds one Cell to the arena at the start of every run.`,maxLevel:99,effect:{stat:`initialCellCount`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:15,multiplier:1.08,jerk:1.00005},duration:{baseMs:3e4,multiplier:1.08}},{id:`cell-magnet`,category:`Economy`,name:`Cell Magnet`,description:`Pulls nearby Cells toward you. Each level increases pull speed.`,maxLevel:20,effect:{stat:`cellMagnetSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:500,multiplier:1.2,jerk:1.001},duration:{baseMs:9e4,multiplier:1.16}},{id:`chrono-spawn-rate`,category:`Economy`,name:`Chrono Spawn Rate`,description:`Makes Chrono Cells appear more frequently.`,maxLevel:99,effect:{stat:`chronoSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:400,multiplier:1.11,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`chrono-lifetime-multiplier`,category:`Economy`,name:`Chrono Lifetime Multiplier`,description:`Increases the lifetime of Chrono Cells.`,maxLevel:30,effect:{stat:`chronoLifetimeMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.14,jerk:1.0005},duration:{baseMs:12e7,multiplier:1.35}},{id:`unlock-shockwave`,category:`Player Enhancements`,name:`Unlock Shockwave`,description:`Periodically emits a green shockwave that pushes enemies away.`,maxLevel:1,cost:{currency:`cash`,base:900,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`shockwave-frequency`,category:`Player Enhancements`,name:`Shockwave Frequency`,description:`Makes Shockwaves trigger more frequently.`,maxLevel:20,effect:{stat:`shockwaveFrequency`,perLevel:.1,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.2},requirements:{researchId:`unlock-shockwave`}},{id:`shield`,category:`Player Enhancements`,name:`Shield`,description:`Grants one death save per level at the start of every run.`,maxLevel:10,effect:{stat:`shieldCharges`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:4e3,multiplier:1.38,jerk:1.002},duration:{baseMs:18e4,multiplier:1.25}},{id:`building-slots`,category:`Building System`,name:`Building Slots`,description:`Increases the number of buildings you can place in the arena by 1.`,maxLevel:7,effect:{stat:`buildingSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:5e3,multiplier:1.45,jerk:1.002},duration:{baseMs:12e4,multiplier:1.2}},...[[`unlock-speed-booster`,`Unlock Speed Boosters`,`Unlocks Speed Booster pickups that double movement speed.`,1,null],[`speed-booster-duration`,`Speed Booster Duration`,`Increases Speed Booster duration.`,20,`speedBoosterDuration`,`unlock-speed-booster`],[`thorn-shield`,`Thorn Shield`,`Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact.`,1,null],[`thorn-shield-duration`,`Thorn Shield Duration`,`Increases Thorn Shield duration.`,20,`thornShieldDuration`,`thorn-shield`],[`freezer`,`Freezer`,`Unlocks Freezer pickups that freeze all enemies.`,1,null],[`freezer-duration`,`Freezer Duration`,`Increases Freezer duration.`,20,`freezerDuration`,`freezer`]].map(([e,t,n,r,i,a])=>({id:e,category:`Boosters`,name:t,description:n,maxLevel:r,...i?{effect:{stat:i,perLevel:.25,format:`flat`}}:{},cost:{currency:`cash`,base:r===1?2500:1500,multiplier:r===1?1:1.18,jerk:r===1?1:1.001},duration:{baseMs:12e4,multiplier:1.18},...a?{requirements:{researchId:a}}:{}})),{id:`pushback`,category:`Player Enhancements`,name:`Pushback`,description:`Pushes nearby stationary enemies away. Each level increases push speed.`,maxLevel:20,effect:{stat:`pushbackSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:1e4,multiplier:1.18,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18}},{id:`shield-invulnerability-duration`,category:`Player Enhancements`,name:`Shield Afterglow`,description:`Increases invulnerability time after the Shield breaks.`,maxLevel:20,effect:{stat:`shieldInvulnerabilityDuration`,perLevel:.05,format:`flat`},cost:{currency:`cash`,base:12e3,multiplier:1.18,jerk:1.001},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchLevels:{shield:1}}},{id:`shield-break-explosion`,category:`Player Enhancements`,name:`Shield Break Explosion`,description:`Destroys all enemies within range when the Shield breaks. Each level increases the range.`,maxLevel:20,effect:{stat:`shieldBreakExplosionRadius`,perLevel:.3,format:`flat`},cost:{currency:`cash`,base:2e4,multiplier:1.18,jerk:1.001},duration:{baseMs:21e4,multiplier:1.22},requirements:{researchLevels:{shield:1}}},...[[`regular-lifetime-debuff`,`Regular Decay`,`Reduces Regular enemy lifetime.`,`regularLifetimeDebuff`],[`chaser-range-debuff`,`Chaser Range Dampener`,`Reduces Chaser detection range.`,`chaserRangeDebuff`],[`creeper-speed-debuff`,`Creeper Slowdown`,`Reduces Creeper movement speed.`,`creeperSpeedDebuff`],[`banger-range-debuff`,`Banger Range Dampener`,`Reduces Banger blast range.`,`bangerRangeDebuff`],[`banger-enemy-destruction`,`Banger Disruption`,`Give the banger's blast a chance to destroy affected enemies.`,`bangerEnemyDestroyChance`],[`shooter-range-debuff`,`Shooter Range Dampener`,`Reduces Shooter firing range.`,`shooterRangeDebuff`],[`shooter-projectile-debuff`,`Projectile Drag`,`Reduces Shooter projectile speed.`,`shooterProjectileSpeedDebuff`],[`porter-interval-debuff`,`Porter Delay Field`,`Increases the interval between Porter teleports.`,`porterIntervalBonus`],[`magnet-strength-debuff`,`Magnet Insulation`,`Reduces Magnet pull strength.`,`magnetStrengthDebuff`],[`spore-speed-debuff`,`Spore Drag`,`Reduces Spore movement speed.`,`sporeSpeedDebuff`],[`poison-creep-clean`,`Poison Creep Clean`,`Reduces how long Poison Creeper trails remain.`,`poisonTrailDurationReduction`]].map(([e,t,n,r])=>({id:e,category:`Enemy Debuff`,name:t,description:n,maxLevel:20,effect:{stat:r,perLevel:r===`porterIntervalBonus`||r===`poisonTrailDurationReduction`?.05:.025,format:`percent`},...r===`poisonTrailDurationReduction`?{maxLevel:15}:{},cost:{currency:`cash`,base:6e3,multiplier:1.18,jerk:1.001},duration:{baseMs:24e4,multiplier:1.22}}))]},He=e=>`research.category.${e.toLowerCase().replaceAll(` `,`_`)}`,C={...Ve,categoryOrder:Ve.categoryOrder.map(e=>S(He(e),{},e)),researches:Ve.researches.map(e=>({...e,category:S(He(e.category),{},e.category),name:S(`research.${e.id}.name`,{},e.name),description:S(`research.${e.id}.description`,{},e.description)}))},Ue={enabled:!0,hotkey:`"`,title:S(`cheat.title`),commands:{cash:`cash`,chrono:`chrono`,freeResearch:`free_research`,unlockSectors:`unlock_sectors`,gainArtifact:`gain_artifact`,clearSave:`clear_save`,sandbox:`sandbox`,anomaly:`anomaly`,cell:`cell`,god:`god`},clearSaveTargets:[`currency`,`game_progress`,`milestones`,`research`,`buildings`,`weapons`,`artifacts`,`all`]},We={version:`0.9.9`,number:`1135`,date:`September 17, 2026`,label:`EARLY ACCESS`},Ge={unlockSector:2,weeklyAnchorDate:`2026-09-02`,rewardCellTarget:250,rewardBaseChronoshards:10,rewardChronoshardStepPerSector:2,challenges:[{id:`cell-scout`,name:`Scout Rivalry`,description:`A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you.`,type:`cell-scout`,rewardCellTarget:250},{id:`tower-defense`,name:`Tower Defense`,description:`Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls.`,type:`tower-defense`,rewardCellTarget:1e3,towerHitpoints:100,towerContactDamage:1,towerProjectileDamage:1,towerRadius:1.15,difficultyMultiplier:1,enemyTypes:[`regular`,`chaser`,`creeper`,`shooter`],enemySpawnWeights:{regular:.4,chaser:.25,creeper:.2,shooter:.15},enemyMovementSpeeds:{chaser:2.4,creeper:1.25,shooter:1.1}}]},Ke={...Ge,challenges:Ge.challenges.map(e=>({...e,name:S(`anomaly.${e.id}.name`,{},e.name),description:S(`anomaly.${e.id}.description`,{},e.description)}))},qe={endpoint:``},Je={endpoint:``,publicEndpoint:`https://utctime.app/api/now`},Ye=`asteroid-belt-analytics-session-id`;function Xe(){try{let e=sessionStorage.getItem(Ye);if(e)return e;let t=crypto.randomUUID();return sessionStorage.setItem(Ye,t),t}catch{return crypto.randomUUID()}}function Ze({sector:e,buildVersion:t,platform:n}){qe.endpoint&&fetch(qe.endpoint,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({event:`sector_started`,sessionId:Xe(),properties:{sector:e,buildVersion:t,platform:n}}),keepalive:!0}).catch(()=>{})}var Qe={placementRadius:10,minimumSpacing:2.2,spawnClearance:2.5,types:{chronoGenerator:{name:`Chrono Generator`,baseCost:180,costMultiplier:1.35,color:`#63f5cd`,effect:{range:4,slow:.22},upgrades:{range:{base:180,step:.2},effectiveness:{base:240,step:.02}}},autocannon:{name:`Autocannon`,baseCost:350,costMultiplier:1.45,color:`#ff795f`,effect:{range:5,interval:2.6},upgrades:{range:{base:360,step:.2},frequency:{base:440,step:-.06}}},droneBay:{name:`Drone Bay`,baseCost:460,costMultiplier:1.48,color:`#79caff`,effect:{period:14,count:1,droneSpeed:5},upgrades:{period:{base:540,step:-.65},count:{base:880,step:1}}},barrierNode:{name:`Barrier Node`,baseCost:520,costMultiplier:1.5,color:`#76eaff`,effect:{range:4.3,period:12,duration:4.5},upgrades:{range:{base:560,step:.28},period:{base:640,step:-.55},duration:{base:700,step:.45}}},overclockRelay:{name:`Overclock Relay`,baseCost:580,costMultiplier:1.52,color:`#ffcf76`,effect:{range:5.2,effectiveness:.14},upgrades:{range:{base:620,step:.3},effectiveness:{base:760,step:.04}}},salvageExtractor:{name:`Salvage Extractor`,baseCost:640,costMultiplier:1.55,color:`#8dff9c`,effect:{range:4.8,period:18,count:1,cash:2},upgrades:{period:{base:720,step:-.7},cash:{base:820,step:1.5},count:{base:980,step:1}}}}},$e={...Qe,types:Object.fromEntries(Object.entries(Qe.types).map(([e,t])=>[e,{...t,name:S(`building.${e}.name`,{},t.name),upgrades:Object.fromEntries(Object.entries(t.upgrades).map(([e,t])=>[e,{...t,name:S(`building.upgrade.${e}`,{},e)}]))}]))};function et({THREE:e,COLORS:t,ENTITIES:n,GAME:r,opacity:i=1}){let a=new e.Group,o=new e.Mesh(new e.ConeGeometry(.58,1.45,6),new e.MeshStandardMaterial({color:t.player,emissive:`#000000`,emissiveIntensity:0,metalness:.2,roughness:.55}));o.rotation.x=Math.PI/2,o.position.y=.18,o.castShadow=!0,a.add(o);let s=new e.MeshStandardMaterial({color:t.playerWing??`#f6b05c`,emissive:`#000000`,emissiveIntensity:0,metalness:.18,roughness:.58});for(let t of[-1,1]){let n=new e.Mesh(new e.BoxGeometry(.82,.08,.58),s);n.position.set(t*.52,.12,-.08),n.rotation.z=t*-.16,n.castShadow=!0,a.add(n)}let c=new e.Mesh(new e.SphereGeometry(.29,12,8),new e.MeshStandardMaterial({color:`#76ddff`,emissive:`#000000`,emissiveIntensity:0,metalness:.25,roughness:.48}));c.scale.set(.82,.62,1.15),c.position.set(0,.38,.18),a.add(c);let l=new e.Mesh(new e.TorusGeometry(.3,n.playerRingTube*.72,n.playerRingRadialSegments,n.playerRingTubularSegments),new e.MeshBasicMaterial({color:t.playerRing,transparent:!0,opacity:.88}));l.position.set(0,.17,-.67),a.add(l);let u=new e.Group,d=new e.Mesh(new e.ConeGeometry(.27,.82,8),new e.MeshBasicMaterial({color:`#ff5c32`,transparent:!0,opacity:.74,depthWrite:!1})),f=new e.Mesh(new e.ConeGeometry(.14,.57,8),new e.MeshBasicMaterial({color:`#ffe781`,transparent:!0,opacity:.94,depthWrite:!1}));for(let e of[d,f])e.rotation.x=-Math.PI/2;f.position.z=-.08,u.add(d,f),u.position.set(0,.17,-.93),a.add(u);let p=new e.Mesh(new e.RingGeometry(1-n.slowAuraRingWidth,1,n.slowAuraRingSegments),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.35,side:e.DoubleSide,depthWrite:!1}));p.rotation.x=-Math.PI/2,p.position.y=-r.playerStartHeight+.04,p.visible=!1,a.add(p);let ee=new e.Mesh(new e.SphereGeometry(r.playerRadius*1.15,20,14),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.18,wireframe:!0,depthWrite:!1}));return ee.visible=!1,a.add(ee),i<1&&a.traverse(e=>{e.material&&(e.material.transparent=!0,e.material.opacity*=i,e.material.depthWrite=!1)}),a.position.y=r.playerStartHeight,{player:a,playerCore:o,slowAuraRing:p,shieldBubble:ee,updateVisuals(e,t,n){l.rotation.z+=e*n;let r=.9+Math.sin(t*20)*.12+Math.sin(t*33)*.06;u.scale.set(1,1,r),d.material.opacity=.62+Math.sin(t*17)*.12,f.material.opacity=.8+Math.sin(t*23)*.14}}}function tt({THREE:e,building:t,config:n,range:r}){let i=new e.Group,a=new e.MeshStandardMaterial({color:`#33465a`,emissive:n.color,emissiveIntensity:.24,metalness:.92,roughness:.14}),o={autocannon:`#ffd36f`,droneBay:`#79caff`,barrierNode:`#76eaff`,overclockRelay:`#ffcf76`,salvageExtractor:`#8dff9c`}[t.type]??`#a6a2ff`,s=new e.MeshStandardMaterial({color:o,emissive:o,emissiveIntensity:1.25,metalness:.78,roughness:.12}),c=new e.Mesh(new e.CylinderGeometry(.53,.64,.26,8),a);if(c.position.y=.13,i.add(c),t.type===`chronoGenerator`){let t=new e.Mesh(new e.IcosahedronGeometry(.32,1),s);t.position.y=.67;let n=new e.Mesh(new e.TorusGeometry(.46,.035,8,24),s);n.position.y=.68,n.rotation.x=Math.PI/2;let r=n.clone();r.rotation.set(Math.PI/3,0,Math.PI/5),i.add(t,n,r)}if(t.type===`autocannon`){let t=new e.Mesh(new e.BoxGeometry(.48,.26,.48),s);t.position.y=.42,i.add(t);for(let t of[-.14,.14]){let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.78,8),s);n.rotation.x=Math.PI/2,n.position.set(t,.51,.38),i.add(n)}}if(t.type===`droneBay`){let t=new e.Mesh(new e.BoxGeometry(.96,.42,.78),a);t.position.y=.47;let n=new e.Mesh(new e.BoxGeometry(.56,.22,.04),s);n.position.set(0,.5,.41),i.add(t,n);for(let t of[-.26,.26]){let n=new e.Mesh(new e.SphereGeometry(.09,8,6),s);n.position.set(t,.82,.08),i.add(n)}}if(t.type===`barrierNode`){let t=new e.Mesh(new e.OctahedronGeometry(.34,0),s);t.position.y=.72,i.add(t);for(let t=0;t<3;t+=1){let n=new e.Mesh(new e.ConeGeometry(.13,.8,6),s),r=t*Math.PI*2/3;n.position.set(Math.cos(r)*.42,.46,Math.sin(r)*.42),i.add(n)}let n=new e.Mesh(new e.SphereGeometry(.72,16,10,0,Math.PI*2,0,Math.PI/2),new e.MeshBasicMaterial({color:`#8ceaff`,transparent:!0,opacity:.15,depthWrite:!1}));n.position.y=.1,i.add(n)}if(t.type===`overclockRelay`){let t=new e.Mesh(new e.TorusGeometry(.34,.06,8,24),s);t.position.y=.62,t.rotation.x=Math.PI/2;let n=new e.Mesh(new e.CylinderGeometry(.035,.05,.72,8),s);n.position.y=.8;let r=new e.Mesh(new e.SphereGeometry(.1,10,8),s);r.position.y=1.18,i.add(t,n,r)}if(t.type===`salvageExtractor`){let t=new e.Mesh(new e.CylinderGeometry(.3,.42,.66,8),s);t.position.y=.55;let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.82,8),a);n.position.set(.36,.82,0),n.rotation.z=-Math.PI/3;let r=new e.Mesh(new e.ConeGeometry(.17,.34,5),s);r.position.set(.72,.55,0),r.rotation.z=-Math.PI/2,i.add(t,n,r)}let l=Number.isFinite(n.effect.range),u=new e.Mesh(new e.RingGeometry(.985,1.005,48),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.28,side:e.DoubleSide,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.y=.03,u.scale.setScalar(l?r:0),u.visible=l,i.add(u);let d=null;if(t.type===`barrierNode`){d=new e.Group;let t=new e.Mesh(new e.CylinderGeometry(1,1,1.6,40,1,!0),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.16,side:e.DoubleSide,depthWrite:!1}));t.position.y=.8;let r=new e.Mesh(new e.TorusGeometry(1,.035,6,40),new e.MeshBasicMaterial({color:`#d5ffff`,transparent:!0,opacity:.85,depthWrite:!1}));r.position.y=1.58,r.rotation.x=Math.PI/2,d.add(t,r),d.visible=!1,i.add(d)}return i.position.set(t.x,0,t.z),{group:i,effectRing:u,barrierField:d}}function nt(e){let t=new e.Group,n=new e.MeshStandardMaterial({color:`#314c63`,emissive:`#79caff`,emissiveIntensity:.8,metalness:.9,roughness:.18}),r=new e.MeshBasicMaterial({color:`#baf8ff`,transparent:!0,opacity:.95,depthWrite:!1}),i=new e.Mesh(new e.SphereGeometry(.14,10,7),n);i.scale.set(1.25,.55,1.5),t.add(i);let a=[];for(let[i,o]of[[-.22,-.2],[.22,-.2],[-.22,.2],[.22,.2]]){let s=new e.Mesh(new e.BoxGeometry(.13,.035,.13),n);s.position.set(i,0,o);let c=new e.Mesh(new e.CylinderGeometry(.12,.12,.018,12),r);c.position.set(i,.045,o),t.add(s,c),a.push(c)}let o=new e.Mesh(new e.SphereGeometry(.055,8,6),r);return o.position.set(0,.015,.2),t.add(o),t.userData.rotors=a,t}function rt({THREE:e,ENTITIES:t}){let n=new e.IcosahedronGeometry(t.obstacleCoreRadius,1),r=new e.ConeGeometry(t.obstacleSpikeRadius,t.obstacleSpikeHeight,t.obstacleSpikeSegments),i=new e.ConeGeometry(t.obstacleSpikeRadius*.72,t.obstacleSpikeHeight*.7,t.obstacleSpikeSegments),a=new e.ConeGeometry(t.obstacleSpikeRadius*.27,t.obstacleSpikeHeight*.22,t.obstacleSpikeSegments),o=new e.ConeGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeHeight*.27,t.obstacleSpikeSegments),s=new e.CylinderGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeRadius,t.obstacleSpikeHeight*.82,t.obstacleSpikeSegments),c=new e.CircleGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeSegments),l=new e.MeshStandardMaterial({color:`#ff3b30`,emissive:`#8c0b06`,emissiveIntensity:1.7,metalness:.35,roughness:.28}),u=new e.MeshStandardMaterial({color:`#c88cff`,emissive:`#7a18ff`,emissiveIntensity:1.75,metalness:.2,roughness:.22}),d=new e.MeshBasicMaterial({color:`#050505`,side:e.DoubleSide}),f=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1],[0,1,2],[0,1,-2],[0,-1,2],[0,-1,-2],[1,2,0],[-1,2,0],[1,-2,0],[-1,-2,0],[2,0,1],[-2,0,1],[2,0,-1],[-2,0,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),p=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),ee=new e.Vector3(0,1,0);return function(m,h=`regular`){let te=new e.Group,g=new e.Mesh(n,m);g.castShadow=!0,te.add(g);let ne=[],re=[],ie=h===`chaser`?f:p;for(let[n,f]of ie.entries()){let p=h===`chaser`?t.obstacleSpikeHeight*.7:t.obstacleSpikeHeight,g=new e.Group;g.position.copy(f).multiplyScalar(t.obstacleCoreRadius+p*.28),g.quaternion.setFromUnitVectors(ee,f);let ie=g.quaternion.clone(),ae=new e.Mesh(h===`chaser`?i:h===`shooter`?s:r,m);if(ae.castShadow=!0,g.add(ae),h===`chaser`){let t=new e.Mesh(a,l);t.position.y=p*.43,t.castShadow=!0,g.add(t)}if(h===`creeper`||h===`poisonCreeper`){let t=u.clone(),n=new e.Mesh(o,t);n.position.y=p*.47,n.castShadow=!0,g.add(n),re.push(t)}if(h===`shooter`){let t=new e.Mesh(c,d);t.rotation.x=-Math.PI/2,t.position.y=p*.41+.002,g.add(t)}ne.push({root:g,baseQuaternion:ie,phase:n*1.71}),te.add(g)}return te.userData.material=m,te.userData.spikes=ne,te.userData.creeperTipMaterials=re,te}}function it({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.OctahedronGeometry(n.cellRadius),i=new e.IcosahedronGeometry(n.chronoCellRadius,1),a=new e.OctahedronGeometry(.42),o={speed:`#ffcf76`,thorn:`#ff795f`,freezer:`#7bdcff`};return{createCell(){return new e.Mesh(r,new e.MeshStandardMaterial({color:t.cell,emissive:t.cellEmissive,emissiveIntensity:n.cellEmissiveIntensity,metalness:n.cellMetalness,roughness:n.cellRoughness}))},createChronoCell(){return new e.Mesh(i,new e.MeshStandardMaterial({color:t.chronoCell,emissive:t.chronoCellEmissive,emissiveIntensity:n.chronoCellEmissiveIntensity,metalness:.12,roughness:.42,transparent:!0}))},createBooster(t){let n=o[t];return new e.Mesh(a,new e.MeshStandardMaterial({color:n,emissive:n,emissiveIntensity:1.7,metalness:.25,roughness:.2}))}}}function at({THREE:e,SCENE:t,count:n,size:r,opacity:i}){let a=new Float32Array(n*3),o=new Float32Array(n*3);for(let r=0;r<n;r+=1){let n=e.MathUtils.randFloatSpread(2),i=Math.sqrt(1-n*n),s=Math.random()*Math.PI*2,c=r*3;a[c]=Math.cos(s)*i*t.starfieldRadius,a[c+1]=n*t.starfieldRadius,a[c+2]=Math.sin(s)*i*t.starfieldRadius;let l=Math.random();o[c]=.72+l*.28,o[c+1]=.82+l*.18,o[c+2]=1}let s=new e.BufferGeometry;s.setAttribute(`position`,new e.BufferAttribute(a,3)),s.setAttribute(`color`,new e.BufferAttribute(o,3));let c=new e.Points(s,new e.PointsMaterial({size:r,sizeAttenuation:!1,transparent:!0,opacity:i,vertexColors:!0,depthWrite:!1,fog:!1}));return c.frustumCulled=!1,c}function ot(e,t){let n=[];for(let r=2;r<t;r+=2)for(let t=0;t<80;t+=1){let i=t/80*Math.PI*2,a=(t+1)/80*Math.PI*2;n.push(new e.Vector3(Math.cos(i)*r,.01,Math.sin(i)*r),new e.Vector3(Math.cos(a)*r,.01,Math.sin(a)*r))}for(let r=0;r<12;r+=1){let i=r/12*Math.PI*2;n.push(new e.Vector3,new e.Vector3(Math.cos(i)*t,.01,Math.sin(i)*t))}return new e.BufferGeometry().setFromPoints(n)}function st(e,t){return new e.BufferGeometry().setFromPoints(Array.from({length:96},(n,r)=>{let i=r/96*Math.PI*2;return new e.Vector3(Math.cos(i)*t,.04,Math.sin(i)*t)}))}function ct({THREE:e,scene:t,COLORS:n,GAME:r,SCENE:i,LIGHTING:a,quality:o=`high`}){let s=new e.Group;function c(t){let n={low:.35,medium:.65,high:1}[t]??1;s.clear(),s.add(at({THREE:e,SCENE:i,count:Math.round(i.starCount*n),size:i.starSize,opacity:.84})),s.add(at({THREE:e,SCENE:i,count:Math.round(i.brightStarCount*n),size:i.brightStarSize,opacity:.96}))}c(o),t.add(s),t.add(new e.HemisphereLight(a.hemisphereSky,a.hemisphereGround,a.hemisphereIntensity));let l=new e.DirectionalLight(a.key,a.keyIntensity);l.position.set(-7,13,5),l.castShadow=!0,l.shadow.mapSize.set(1024,1024),t.add(l);let u=new e.Mesh(new e.CircleGeometry(r.arenaSize/2,96),new e.MeshStandardMaterial({color:n.floor,metalness:i.floorMetalness,roughness:i.floorRoughness,transparent:!0,opacity:i.floorOpacity,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.receiveShadow=!0,t.add(u);let d=new e.LineSegments(ot(e,r.arenaLimit),new e.LineBasicMaterial({color:n.gridMinor,transparent:!0,opacity:.8}));d.position.y=.01,t.add(d);let f=new e.LineLoop(st(e,r.arenaLimit),new e.LineDashedMaterial({color:n.arenaBoundary,dashSize:.45,gapSize:.2}));return f.computeLineDistances(),t.add(f),{starfield:s,floor:u,grid:d,arenaBoundary:f,keyLight:l,setQuality:c,resize(t,n=1){let i=(r.arenaLimit+t)*n;u.geometry.dispose(),u.geometry=new e.CircleGeometry((r.arenaSize/2+t)*n,96),d.geometry.dispose(),d.geometry=ot(e,i),f.geometry.dispose(),f.geometry=st(e,i),f.computeLineDistances()}}}function lt({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.IcosahedronGeometry(n.shooterProjectileRadius,1);return{createShooterProjectile(){return new e.Mesh(r,new e.MeshStandardMaterial({color:`#7dff9d`,emissive:`#00ff5a`,emissiveIntensity:4,metalness:.25,roughness:.16}))},createAutocannonProjectile(){return new e.Mesh(new e.SphereGeometry(.16,10,8),new e.MeshBasicMaterial({color:`#fff1a6`,transparent:!0,opacity:.95}))},createSplinter(){return new e.Mesh(new e.TetrahedronGeometry(.32),new e.MeshStandardMaterial({color:t.splinter,emissive:t.splinterEmissive,emissiveIntensity:1.3,metalness:.4,roughness:.3}))}}}function ut({THREE:e,COLORS:t,getQuality:n=()=>`high`}){let r=()=>({low:.45,medium:.7,high:1})[n()]??1;function i(t,n,r,i,a=1){let o=new e.Mesh(new e.RingGeometry(t,n,r),new e.MeshBasicMaterial({color:i,transparent:!0,opacity:a,side:e.DoubleSide,depthWrite:!1}));return o.rotation.x=-Math.PI/2,o}return{createExplosion(n,a){let o=i(.18,.42,Math.round(64*r()),t.banger);o.position.set(n.x,.05,n.z);let s=new e.Mesh(new e.SphereGeometry(1,Math.round(24*r()),Math.round(16*r())),new e.MeshBasicMaterial({color:t.banger,transparent:!0,opacity:.65,wireframe:!0,depthWrite:!1}));s.position.set(n.x,.85,n.z);let c=new e.PointLight(t.banger,10,a*2);return c.position.copy(s.position),{shockwave:o,blast:s,light:c}},createBangerPulse(e){let n=i(.22,.42,48,t.banger,.9);return n.position.set(e.x,.06,e.z),n},createShockwave(e){let n=i(.2,.42,64,t.slowAura,.95);return n.position.set(e.x,.07,e.z),n},createShieldBreak(t){let n=new e.Mesh(new e.SphereGeometry(.78,24,16),new e.MeshBasicMaterial({color:`#8cfff0`,transparent:!0,opacity:.84,wireframe:!0,depthWrite:!1}));n.position.copy(t);let r=new e.PointLight(`#63f5cd`,12,10);return r.position.copy(t),{sphere:n,light:r}},createPoisonTrail(n,i){let a=new e.Group;a.position.set(n.x,.035,n.z);let o=new e.Mesh(new e.CircleGeometry(i,16),new e.MeshBasicMaterial({color:t.poisonTrail,transparent:!0,opacity:.48,depthWrite:!1}));return o.rotation.x=-Math.PI/2,a.add(o),{visual:a,pool:o,vapor:Array.from({length:Math.max(1,Math.round(3*r()))},(n,r)=>{let o=new e.Mesh(new e.SphereGeometry(.16+r*.035,6,4),new e.MeshBasicMaterial({color:t.poisonTrail,transparent:!0,opacity:.62,depthWrite:!1})),s=r*Math.PI*2/3;return o.position.set(Math.cos(s)*i*.42,.12+r*.05,Math.sin(s)*i*.42),o.userData.phase=s,a.add(o),o})}},createPlayerDeath(n){let a=new e.Mesh(new e.SphereGeometry(.95,24,16),new e.MeshBasicMaterial({color:`#fff4cf`,transparent:!0,opacity:1,depthWrite:!1}));a.position.copy(n);let o=new e.Mesh(new e.IcosahedronGeometry(.7,2),new e.MeshBasicMaterial({color:t.playerRing,transparent:!0,opacity:.95,wireframe:!0,depthWrite:!1}));o.position.copy(n);let s=i(.24,.5,64,t.player);s.position.set(n.x,.06,n.z);let c=s.clone();c.material=s.material.clone();let l=new e.PointLight(`#fff4cf`,22,18);return l.position.copy(n),{flash:a,blast:o,shockwave:s,innerShockwave:c,light:l,fragments:Array.from({length:Math.max(6,Math.round(18*r()))},()=>{let r=new e.Mesh(new e.TetrahedronGeometry(e.MathUtils.randFloat(.08,.19),0),new e.MeshBasicMaterial({color:Math.random()>.45?t.playerRing:t.player,transparent:!0,opacity:1,depthWrite:!1}));return r.position.copy(n),r.userData.velocity=new e.Vector3(Math.random()-.5,Math.random()*.75+.18,Math.random()-.5).normalize().multiplyScalar(e.MathUtils.randFloat(4,10)),r})}}}}var w=Object.freeze({cellBank:`asteroid-belt-banked-cells`,sector:`asteroid-belt-selected-sector`,sectorHighScores:`asteroid-belt-sector-high-scores`,cash:`asteroid-belt-cash`,chronoshards:`asteroid-belt-chronoshards`,researchLab:`asteroid-belt-research-lab`,savedRound:`asteroid-belt-saved-round`,buildings:`asteroid-belt-buildings`,featureUnlocks:`asteroid-belt-feature-unlocks`,milestones:`asteroid-belt-milestones`,settings:`asteroid-belt-settings`,weaponry:`asteroid-belt-weaponry`,anomalyRewards:`asteroid-belt-anomaly-rewards`,artifacts:`asteroid-belt-artifacts`}),dt=[`t`,`i`,`e`,`r`].join(``),ft=`asteroid-belt-selected-${dt}`,pt=`asteroid-belt-${dt}-high-scores`,mt=[[`astroid-belt-banked-cells`,w.cellBank],[ft,w.sector],[pt,w.sectorHighScores],[`astroid-belt-selected-${dt}`,w.sector],[`astroid-belt-${dt}-high-scores`,w.sectorHighScores],[`astroid-belt-cash`,w.cash],[`astroid-belt-chronoshards`,w.chronoshards],[`astroid-belt-research-lab`,w.researchLab],[`astroid-belt-saved-round`,w.savedRound],[`astroid-belt-buildings`,w.buildings],[`astroid-belt-feature-unlocks`,w.featureUnlocks]];function ht(e=window.localStorage){for(let[t,n]of mt)try{e.getItem(n)===null&&e.getItem(t)!==null&&e.setItem(n,e.getItem(t))}catch{}try{let t=`${dt}-`,n=JSON.parse(e.getItem(w.sectorHighScores)??`null`);if(n&&typeof n==`object`){let t=Object.fromEntries(Object.entries(n).map(([e,t])=>[e.startsWith(dt)?`sector${e.slice(dt.length)}`:e,t]));e.setItem(w.sectorHighScores,JSON.stringify(t))}let r=JSON.parse(e.getItem(w.milestones)??`null`);r&&Array.isArray(r.claimed)&&(r.claimed=r.claimed.map(e=>typeof e==`string`&&e.startsWith(t)?`sector-${e.slice(t.length)}`:e),e.setItem(w.milestones,JSON.stringify(r)));let i=JSON.parse(e.getItem(w.savedRound)??`null`),a=`${dt}Index`;i&&typeof i==`object`&&Number.isFinite(i[a])&&!Number.isFinite(i.sectorIndex)&&(i.sectorIndex=i[a],e.setItem(w.savedRound,JSON.stringify(i)));let o=JSON.parse(e.getItem(w.anomalyRewards)??`null`),s=`claimed${dt[0].toUpperCase()}${dt.slice(1)}s`;o?.[s]&&!o.claimedSectors&&(o.claimedSectors=o[s],e.setItem(w.anomalyRewards,JSON.stringify(o)))}catch{}}function gt(e,t=0,n=window.localStorage){try{let r=Number(n.getItem(e));return Number.isFinite(r)&&r>=0?r:t}catch{return t}}function _t(e,t,n=window.localStorage){try{n.setItem(e,String(t))}catch{}}function vt(e,t=null,n=window.localStorage){try{return JSON.parse(n.getItem(e))??t}catch{return t}}function yt(e,t,n=window.localStorage){try{t==null?n.removeItem(e):n.setItem(e,JSON.stringify(t))}catch{}}function bt({THREE:e,SOUND:t,getSettings:n,getPlayer:r,getCamera:i}){let a,o,s=new Map,c;async function l(e,t){try{let n=await fetch(t);if(!n.ok)return;s.set(e,await a.decodeAudioData(await n.arrayBuffer()))}catch{}}function u(){if(!a){let e=window.AudioContext||window.webkitAudioContext;if(!e)return Promise.resolve();a=new e,o=a.createGain(),d(!0),o.connect(a.destination),c=Promise.all(Object.entries(t.assets).map(([e,t])=>l(e,t)))}let e=a.state===`suspended`?a.resume():Promise.resolve();return Promise.all([e,c])}function d(e=!1){if(!o||!a)return;let r=n(),i=t.masterVolume*(r.sound.muted?0:r.sound.masterVolume/100);e?o.gain.value=i:o.gain.setTargetAtTime(i,a.currentTime,.03)}function f(n){let a=n.clone().sub(r().position);a.y=0;let o=a.length(),s=e.MathUtils.lerp(t.spatialMinGain,1,(1-e.MathUtils.clamp(o/t.spatialMaxDistance,0,1))**2);if(o===0)return{attenuation:s,pan:0};let c=new e.Vector3(1,0,0).applyQuaternion(i().quaternion);return c.y=0,c.normalize(),{attenuation:s,pan:e.MathUtils.clamp(a.normalize().dot(c),-1,1)}}function p(e,t,r){let i=a.createGain(),s=a.createGain(),c=a.createStereoPanner?.(),l=a.currentTime,{attenuation:u,pan:d}=n().sound.spatialAudio?f(r):{attenuation:1,pan:0};i.gain.setValueAtTime(t,l),s.gain.setValueAtTime(u,l),e.connect(i),i.connect(s),c?(c.pan.setValueAtTime(d,l),s.connect(c),c.connect(o)):s.connect(o)}function ee(e,t,n,r,i,o){if(!a||a.state!==`running`)return;let s=a.createOscillator(),c=a.currentTime;s.type=o,s.frequency.setValueAtTime(e,c),s.frequency.linearRampToValueAtTime(t,c+n),p(s,r,i),s.start(c),s.stop(c+n)}function m(e,t,n){if(!a||a.state!==`running`)return;let r=a.currentTime,i=a.createBuffer(1,Math.ceil(a.sampleRate*e),a.sampleRate),o=i.getChannelData(0);for(let e=0;e<o.length;e+=1)o[e]=Math.random()*2-1;let s=a.createBufferSource(),c=a.createBiquadFilter(),l=a.createGain();s.buffer=i,c.type=`bandpass`,c.Q.value=.65,c.frequency.setValueAtTime(180,r),c.frequency.exponentialRampToValueAtTime(720,r+e),l.gain.setValueAtTime(1e-4,r),l.gain.exponentialRampToValueAtTime(1,r+.18),l.gain.exponentialRampToValueAtTime(1e-4,r+e),s.connect(c),c.connect(l),p(l,t,n),s.start(r)}function h(e,t){if(!a||a.state!==`running`)return;let n=a.currentTime,r=a.createBuffer(1,Math.ceil(a.sampleRate*.24),a.sampleRate),i=r.getChannelData(0);for(let e=0;e<i.length;e+=1)i[e]=(Math.random()*2-1)*(1-e/i.length);let o=a.createBufferSource(),s=a.createBiquadFilter(),c=a.createGain();o.buffer=r,s.type=`lowpass`,s.Q.value=1.2,s.frequency.setValueAtTime(1500,n),s.frequency.exponentialRampToValueAtTime(110,n+.24),c.gain.setValueAtTime(1e-4,n),c.gain.exponentialRampToValueAtTime(1,n+.012),c.gain.exponentialRampToValueAtTime(1e-4,n+.24),o.connect(s),s.connect(c),p(c,e,t),o.start(n)}function te(e,t,n,r){if(!a||a.state!==`running`)return;let i=s.get(e);if(!i){r();return}let o=a.createBufferSource();o.buffer=i,p(o,t,n),o.start()}return{initialize:u,setMasterVolume:d,playBangerPulse(n,r){let i=t.fallback.bangerPulse,a=e.MathUtils.lerp(i.startFrequency,i.endFrequency,n);te(`bangerPulse`,t.bangerPulseVolume,r,()=>ee(a,a,i.duration,t.bangerPulseVolume,r,i.type))},playFallingObstacle(e){let n=t.fallback.fallingObstacle;te(`fallingObstacle`,t.fallingObstacleVolume,e,()=>m(n.duration,t.fallingObstacleVolume,e))},playCellCollect(e){let n=t.fallback.cellCollect;te(`cellCollect`,t.cellCollectVolume,e,()=>ee(n.startFrequency,n.endFrequency,n.duration,t.cellCollectVolume,e,n.type))},playBoosterPickup(e,t){let[n,r]={speed:[480,900],thorn:[220,620],freezer:[720,260]}[t];ee(n,r,.22,.3,e,t===`freezer`?`sine`:`triangle`)},playShieldBreak(e){h(.52,e),ee(180,58,.2,.24,e,`sawtooth`)},playBuildingEffect(e,t){let[n,r]={chronoGenerator:[280,360],autocannon:[220,90],droneBay:[520,760],barrierNode:[260,440],overclockRelay:[440,600],salvageExtractor:[180,300]}[t];ee(n,r,.12,.16,e,`sine`)},playObstacleSummon(e){let n=t.fallback.obstacleSummon;te(`obstacleSummon`,t.obstacleSummonVolume,e,()=>ee(n.startFrequency,n.endFrequency,n.duration,t.obstacleSummonVolume,e,n.type))},playButtonClick(){let e=t.fallback.buttonClick,n=r().position;te(`buttonClick`,t.buttonClickVolume,n,()=>ee(e.startFrequency,e.endFrequency,e.duration,t.buttonClickVolume,n,e.type))}}}var xt=[[1e3,`M`],[900,`CM`],[500,`D`],[400,`CD`],[100,`C`],[90,`XC`],[50,`L`],[40,`XL`],[10,`X`],[9,`IX`],[5,`V`],[4,`IV`],[1,`I`]];function T(e){let t=Math.max(1,Math.floor(Number(e)||1)),n=``;for(let[e,r]of xt)for(;t>=e;)n+=r,t-=e;return n}function St({config:e,milestones:t,getResearchState:n,getMilestoneState:r,getBankedCells:i}){let a=t=>e.researches.find(e=>e.id===t),o=e=>n().levels[e]??0,s=e=>t.find(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)));function c(e){let n=r();return n.researchUnlocks.includes(e)||t.some(t=>n.claimed.includes(t.id)&&t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))}function l(t){return e.researches.filter(e=>e.effect?.stat===t).reduce((e,t)=>e+o(t.id)*t.effect.perLevel,0)}function u(e,t){let n=e.cost.jerk??1,r=e.cost.base*e.cost.multiplier**t*n**(t*(t-1)/2);return e.cost.currency===`cash`?Math.round(r*100)/100:Math.ceil(r)}function d(e){let t=e.requirements??{},n=s(e.id);if(n&&!r().debugAscensionsGranted&&!c(e.id))return S(`research.requires_sector_cells`,{cells:n.cells,sector:T(n.sector)});if(t.minBankedCells&&i()<t.minBankedCells)return S(`research.requires_banked_cells`,{cells:t.minBankedCells});if(t.researchId&&o(t.researchId)<1)return S(`research.requires_research`,{research:a(t.researchId).name});for(let[e,n]of Object.entries(t.researchLevels??{}))if(o(e)<n)return S(`research.requires_research_level`,{research:a(e).name,level:n});return``}function f(e,t=new Set){let n=s(e.id)?.sector??0;if(t.has(e.id))return{sector:n,depth:0};let r=e.requirements??{},i=[...r.researchId?[r.researchId]:[],...Object.keys(r.researchLevels??{})].map(a).filter(Boolean).map(n=>f(n,new Set(t).add(e.id)));return{sector:Math.max(n,...i.map(e=>e.sector)),depth:i.length?Math.max(...i.map(e=>e.depth))+1:0}}function p(e,t){let n=f(e),r=f(t);return n.sector-r.sector||n.depth-r.depth||e.name.localeCompare(t.name)}return{getResearchById:a,getResearchLevel:o,getResearchStatBonus:l,getResearchCost:u,getResearchDuration:(e,t)=>Math.round(e.duration.baseMs*e.duration.multiplier**t),getResearchLockReason:d,isResearchVisible:e=>!e.visibleWhen?.anyResearch||e.visibleWhen.anyResearch.some(e=>o(e)>0),compareResearchProgression:p}}var Ct=[{id:`regular`,category:`Enemies`,name:`Regular`,model:`spiked-enemy`,firstSector:1,description:`A stationary asteroid enemy. Keep clear of its body while collecting Cells.`},{id:`chaser`,category:`Enemies`,name:`Chaser`,model:`spiked-enemy`,firstSector:2,description:`Detects the ship within its range and pursues it.`},{id:`creeper`,category:`Enemies`,name:`Creeper`,model:`spiked-enemy`,firstSector:1,description:`Slowly closes in from any distance and becomes faster as it survives.`},{id:`poisonCreeper`,category:`Enemies`,name:`Poison Creeper`,model:`spiked-enemy`,firstSector:9,description:`A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind.`},{id:`banger`,category:`Enemies`,name:`Banger`,model:`spiked-enemy`,firstSector:3,description:`Arms itself, pulses a warning, then detonates over a wide area.`},{id:`shooter`,category:`Enemies`,name:`Shooter`,model:`spiked-enemy`,firstSector:3,description:`Fires projectiles at the ship when it enters firing range.`},{id:`porter`,category:`Enemies`,name:`Porter`,model:`spiked-enemy`,firstSector:5,description:`Occasionally teleports itself to random locations.`},{id:`magnet`,category:`Enemies`,name:`Magnet`,model:`spiked-enemy`,firstSector:6,description:`Pulls the ship toward itself while it is within range.`},{id:`spore`,category:`Enemies`,name:`Spore`,model:`spiked-enemy`,firstSector:7,description:`Bursts into small pieces of itself, then burst into even smaller pieces again.`},{id:`stoneRock`,category:`Meteors`,name:`Stone Rock`,model:`falling-rock`,firstSector:1,description:`A standard falling meteor. Avoid its marked impact point.`},{id:`fieryRock`,category:`Meteors`,name:`Fiery Rock`,model:`falling-rock`,firstSector:3,description:`A burning meteor that leaves a damaging fire hazard after impact.`},{id:`splinter`,category:`Meteors`,name:`Splinter`,model:`falling-rock`,firstSector:2,description:`Shatters on impact and sends fragments outward.`}].map(e=>({...e,category:S(`encyclopedia.category.${e.category.toLowerCase()}`,{},e.category),name:S(`enemy.${e.id}.name`,{},e.name),description:S(`enemy.${e.id}.description`,{},e.description)})),wt=[{heading:S(`patch_notes.artifacts`),changes:[S(`patch_notes.artifacts_1`),S(`patch_notes.artifacts_2`),S(`patch_notes.artifacts_3`)]},{heading:S(`patch_notes.improvements`),changes:[S(`patch_notes.improvements_1`),S(`patch_notes.improvements_2`)]}];function Tt(e,t){if(!e.effect)return t>0?`UNLOCKED`:`LOCKED`;let n=t*e.effect.perLevel;return e.effect.format===`percent`?`+${(n*100).toFixed(n*100%1?1:0)}%`:String(n)}function Et(e){let t=Math.max(0,Math.ceil(e/1e3)),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60;return n>0?`${n}h ${r}m`:r>0?`${r}m ${i}s`:`${i}s`}function E(e){let t=Math.abs(e),n=t>=0xe8d4a51000?[`T`,0xe8d4a51000]:t>=1e9?[`B`,1e9]:t>=1e6?[`M`,1e6]:t>=1e3?[`K`,1e3]:null;if(!n)return e.toLocaleString(void 0,{maximumFractionDigits:2});let r=e/n[1];return`${r.toFixed(Math.abs(r)<10?2:1)}${n[0]}`}function Dt(e,t){return e===`cash`?`$${E(t)}`:`✦ ${E(t)}`}var Ot=Array.from({length:14},(e,t)=>S(`tip.${t+1}`)),kt=[10,25,50,100,250,500],D=(e,t,n)=>({id:`sector-${e}-${kt[t]}`,sector:e,cells:kt[t],rewards:n}),O=e=>({type:`cash`,amount:e}),k=e=>({type:`chronoshards`,amount:e}),A=(...e)=>({type:`research`,researchIds:e}),At=e=>({type:`feature`,featureId:e}),jt=e=>({type:`sector`,sector:e}),Mt=[D(1,0,[O(25),At(`researchLab`),A(`player-speed-multiplier`)]),D(1,1,[O(50),A(`cash-cell-multiplier`),jt(2)]),D(1,2,[O(75),k(1)]),D(1,3,[O(100)]),D(1,4,[O(150)]),D(1,5,[O(250),k(3)]),D(2,0,[O(150),A(`cell-magnet`)]),D(2,1,[O(250),A(`unlock-speed-booster`),A(`unlock-shockwave`)]),D(2,2,[O(400),k(3),A(`speed-booster-duration`),jt(3)]),D(2,3,[O(650)]),D(2,4,[O(900),k(6),A(`shockwave-frequency`)]),D(2,5,[O(1250),k(10)]),D(3,0,[O(500),A(`unlock-slow-aura`,`unlock-orbital-electron`,`weapon-slots`)]),D(3,1,[O(750),k(5),A(`slow-aura-effect`,`electron-speed`)]),D(3,2,[O(1e3),A(`cell-increment-per-cell`),jt(4)]),D(3,3,[O(1500),k(10),A(`electron-stun-duration`)]),D(3,4,[O(2e3),A(`slow-aura-range`)]),D(3,5,[O(3e3),k(15)]),D(4,0,[O(1e3),A(`chrono-lifetime-multiplier`)]),D(4,1,[O(1500),k(10),A(`building-slots`)]),D(4,2,[O(2e3),A(`shield`)]),D(4,3,[O(3e3),k(15),A(`thorn-shield`),jt(5)]),D(4,4,[O(4500),A(`thorn-shield-duration`,`pushback`)]),D(4,5,[O(6e3),k(25),A(`shield-invulnerability-duration`,`shield-break-explosion`)]),D(5,0,[O(2e3),A(`freezer`,`weapon-recharge`,`lucky-find`)]),D(5,1,[O(3e3),k(15),A(`freezer-duration`,`weapon-recharge-rate`)]),D(5,2,[O(4e3),A(`regular-lifetime-debuff`,`weapon-charge-capacity`)]),D(5,3,[O(6e3),k(20),A(`chaser-range-debuff`),jt(6)]),D(5,4,[O(8e3),A(`creeper-speed-debuff`)]),D(5,5,[O(1e4),k(30)]),D(6,0,[O(4e3),A(`banger-range-debuff`)]),D(6,1,[O(6e3),k(20),A(`banger-enemy-destruction`)]),D(6,2,[O(8e3),A(`shooter-range-debuff`)]),D(6,3,[O(12e3),k(30),A(`shooter-projectile-debuff`),jt(7)]),D(6,4,[O(16e3),k(40)]),D(6,5,[O(2e4),k(50)]),D(7,0,[O(8e3),A(`porter-interval-debuff`)]),D(7,1,[O(12e3),k(30),A(`magnet-strength-debuff`)]),D(7,2,[O(16e3),A(`spore-speed-debuff`)]),D(7,3,[O(24e3),k(45),jt(8)]),D(7,4,[O(32e3),k(60)]),D(7,5,[O(4e4),k(80)]),D(8,0,[O(16e3),k(25)]),D(8,1,[O(24e3),k(40)]),D(8,2,[O(32e3),k(60)]),D(8,3,[O(48e3),k(80),jt(9)]),D(8,4,[O(64e3),k(120)]),D(8,5,[O(1e5),k(200)]),D(9,0,[O(32e3),A(`poison-creep-clean`)]),D(9,1,[O(48e3),k(50)]),D(9,2,[O(64e3),k(75)]),D(9,3,[O(96e3),k(100)]),D(9,4,[O(128e3),k(150)]),D(9,5,[O(2e5),k(250)])],Nt={purchaseCost:15,levelCopyRequirements:[3,5,10,25],weapons:{nuke:{name:`Nuke`,key:`1`,color:`#ff795f`,description:`Destroys a percentage of enemies in the arena.`,baseEffect:.3,effectPerLevel:.1},megaMagnet:{name:`Mega Magnet`,key:`2`,color:`#63f5cd`,description:`Pulls every Cell rapidly toward your ship.`,baseEffect:2.5,effectPerLevel:.8,duration:!0},atmosphereShield:{name:`Atmosphere Shield`,key:`3`,color:`#b59aff`,description:`Destroys and blocks falling meteors for a short time.`,baseEffect:4,effectPerLevel:1.2,duration:!0},phaseDash:{name:`Phase Dash`,key:`4`,color:`#78eaff`,description:`Dash through enemies and erase every enemy in your path.`,baseEffect:6.5,effectPerLevel:1.1},chronoFreeze:{name:`Chrono Freeze`,key:`5`,color:`#74bfff`,description:`Freezes every enemy and their lifetime for a short time.`,baseEffect:2.5,effectPerLevel:.65,duration:!0},plasmaOrbital:{name:`Plasma Orbital`,key:`6`,color:`#ff8cff`,description:`Deploys plasma orbitals that destroy enemies on contact.`,baseEffect:4,effectPerLevel:.8,duration:!0},cellOverdrive:{name:`Cell Overdrive`,key:`7`,color:`#ffd36f`,description:`Doubles Cells collected for a short time.`,baseEffect:4,effectPerLevel:.8,duration:!0},demonMode:{name:`Demon Mode`,key:`8`,color:`#ff465d`,description:`Move faster and destroy enemies you pass through.`,baseEffect:4,effectPerLevel:.8,duration:!0}}},Pt={...Nt,weapons:Object.fromEntries(Object.entries(Nt.weapons).map(([e,t])=>[e,{...t,name:S(`weapon.${e}.name`,{},t.name),description:S(`weapon.${e}.description`,{},t.description)}]))},Ft={artifacts:[{id:`broken-radar`,name:`Broken Radar`,icon:`broken-radar.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-2-500`,sector:2,cells:500},buff:{stat:`cellSpawnRate`,amount:.1,label:`+10% Cell spawn rate`}},{id:`ftl-schematics`,name:`FTL Schematics`,icon:`ftl-schematics.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-3-500`,sector:3,cells:500},buff:{stat:`playerSpeedMultiplier`,amount:.1,label:`+10% player movement speed`}},{id:`supply-depot`,name:`Supply Depot`,icon:`supply-depot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-4-500`,sector:4,cells:500},buff:{stat:`initialCellCount`,amount:5,label:`+5 initial Cells`}},{id:`broken-extractor`,name:`Broken Extractor`,icon:`broken-extractor.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-5-500`,sector:5,cells:500},buff:{stat:`cashMultiplier`,amount:.1,label:`+10% cash earned from Cells`}},{id:`construction-bot`,name:`Construction Bot`,icon:`construction-bot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-6-500`,sector:6,cells:500},buff:{stat:`buildingCostReduction`,amount:.1,label:`-10% Building prices`}},{id:`alientech-gizmo`,name:`Alientech Gizmo`,icon:`alientech-gizmo.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-7-500`,sector:7,cells:500},buff:{stat:`researchCostReduction`,amount:.2,label:`-20% Research cost`}},{id:`broken-hard-drive`,name:`Broken Hard-Drive`,icon:`broken-hard-drive.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-8-500`,sector:8,cells:500},buff:{stat:`weaponSlotCount`,amount:1,label:`+1 Weapon Slot`}},{id:`hubble-telescope`,name:`Hubble Telescope`,icon:`hubble-telescope.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-9-500`,sector:9,cells:500},buff:{stat:`effectRange`,amount:.2,label:`+20% player effect range`}},{id:`dark-core`,name:`Dark Core`,icon:`dark-core.svg`,repeatable:!0,requirement:{type:`anomaly-run-success`,cells:250},buff:{stat:`chronoshardGainMultiplier`,amount:.01,label:`+1% Chronoshards earned`}},{id:`map-to-earth`,name:`Map To Earth`,icon:`map-to-earth.svg`,requirement:{type:`hidden-world-map`,minSector:6,chance:.01},buff:{stat:`arenaSizeMultiplier`,amount:.2,label:`+20% arena size in every Sector`}}]},It={...Ft,artifacts:Ft.artifacts.map(e=>({...e,name:S(`artifact.${e.id}.name`,{},e.name),buff:{...e.buff,label:S(`artifact.${e.id}.buff`,{},e.buff.label)}}))},Lt=Object.freeze({"broken-radar":`ARTIFACT_BROKEN_RADAR`,"ftl-schematics":`ARTIFACT_FTL_SCHEMATICS`,"supply-depot":`ARTIFACT_SUPPLY_DEPOT`,"broken-extractor":`ARTIFACT_BROKEN_EXTRACTOR`,"construction-bot":`ARTIFACT_CONSTRUCTION_BOT`,"alientech-gizmo":`ARTIFACT_ALIENTECH_GIZMO`,"broken-hard-drive":`ARTIFACT_BROKEN_HARD_DRIVE`,"hubble-telescope":`ARTIFACT_HUBBLE_TELESCOPE`,"dark-core":`ARTIFACT_DARK_CORE`,"map-to-earth":`ARTIFACT_MAP_TO_EARTH`});function Rt(e){let t=Lt[e];!t||!window.steamShell?.unlockAchievement||window.steamShell.unlockAchievement(t).catch(e=>console.warn(`[Steamworks] achievement unlock failed:`,e))}async function zt(){if(!window.steamShell?.getAchievementStates)return{};try{return await window.steamShell.getAchievementStates(Object.values(Lt))}catch(e){return console.warn(`[Steamworks] achievement sync failed:`,e),{}}}var j=e=>`./assets/${e}`,Bt={chronoGenerator:j(`buildings/chrono-generator.svg`),autocannon:j(`buildings/autocannon.svg`),droneBay:j(`buildings/drone-bay.svg`),barrierNode:j(`buildings/barrier-node.svg`),overclockRelay:j(`buildings/overclock-relay.svg`),salvageExtractor:j(`buildings/salvage-extractor.svg`)},Vt={nuke:j(`weapons/nuke.svg`),megaMagnet:j(`weapons/mega-magnet.svg`),atmosphereShield:j(`weapons/atmosphere-shield.svg`),phaseDash:j(`weapons/phase-dash.svg`),chronoFreeze:j(`weapons/chrono-freeze.svg`),plasmaOrbital:j(`weapons/plasma-orbital.svg`),cellOverdrive:j(`weapons/cell-overdrive.svg`),demonMode:j(`weapons/demon-mode.svg`)},Ht={researchLab:j(`ui/research-lab.svg`),buildingSystem:j(`ui/building-system.svg`),weaponry:j(`ui/weaponry.svg`),home:j(`ui/home.svg`),encyclopedia:j(`ui/encyclopedia.svg`),settings:j(`ui/settings.svg`),artifacts:j(`ui/artifacts.svg`),shield:j(`ui/shield-charge.svg`),pause:j(`ui/pause.svg`)};function Ut(e){return j(`artifacts/${e}`)}function Wt(e){return Bt[e]??``}function Gt(e){return Vt[e]??``}function Kt(e){return Ht[e]??``}var qt={fire:{label:S(`status.fire`,{},`Burning`),duration:1.5,color:`#ff4f3e`,immunityResearchId:`fire-immunity`,requiresExposure:!0,refreshOnReapply:!1},poison:{label:S(`status.poison`,{},`Poisoned`),duration:3,color:`#91e85a`,immunityResearchId:`poison-immunity`,requiresExposure:!0,refreshOnReapply:!0}};function Jt(e,t){return`<span class="menu-button-icon" aria-hidden="true"><img data-menu-icon src="${Kt(e)}" alt=""><span class="menu-icon-fallback" hidden>${t}</span></span>`}function Yt({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button${e===`home-button`?` menu-home-button`:``}" id="${e}" type="button" aria-label="${r}" title="${r}">${Jt(t,n)}<span class="menu-button-label">${r}</span><span class="menu-button-lock" hidden></span></button>`}function Xt({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button menu-utility-button" id="${e}" type="button" aria-label="${r}" title="${r}">${Jt(t,n)}<span class="menu-button-label">${r}</span></button>`}var Zt=Kt(`shield`),Qt=Kt(`pause`);document.querySelector(`#app`).innerHTML=`
  <main class="game-shell">
    <canvas id="game" aria-label="Asteroid Belt game canvas"></canvas>
    <header class="hud">
      <div class="hud-left">
        <div class="cash-balance"><span class="currency-label">CASH</span><span id="cash">$000</span></div>
        <div class="chronoshard-balance"><span class="currency-label">CHRONOSHARDS</span><span id="chronoshards">✦ 0</span></div>
      </div>
      <div class="hud-sector" id="hud-sector" aria-label="Current difficulty sector"></div>
      <dl class="run-cell-counter"><div><dt>CELLS</dt><dd id="score">000</dd></div></dl>
      <button class="pause-button" id="pause-button" type="button" aria-label="Pause game"><img src="${Qt}" alt=""></button>
    </header>
    <div class="shield-indicators" id="shield-indicators" aria-label="Shield charges"></div>
    <div class="tower-health-hud hidden" id="tower-health-hud" role="status" aria-live="polite"><strong id="tower-health-label"></strong><div class="tower-health-track"><i id="tower-health-fill"></i></div></div>
    <div class="weapon-hud hidden" id="weapon-hud"></div>
    <aside class="instructions" aria-label="Game controls"><span class="controls-desktop"><span><b>MOVE</b> WASD</span><span><b>NAVIGATE</b> ↑↓</span><span><b>USE WEAPON</b> SPACE</span></span><span class="controls-mobile"><span><b>MOVE</b> JOYSTICK</span><span><b>SELECT / USE WEAPON</b> TAP A CARD</span></span></aside>
    <footer class="build-footer" aria-label="Build information">
      <span>v${We.version}</span><span>BUILD ${We.number}</span>
    </footer>
    <div class="virtual-joystick" id="virtual-joystick" aria-hidden="true">
      <div class="virtual-joystick-knob"></div>
    </div>
    <div class="cash-indicators" id="cash-indicators" aria-live="polite"></div>
    <div class="build-grid-ui hidden" id="build-grid-ui" aria-label="Build locations"></div>
    <div class="milestone-claim-toast hidden" id="milestone-claim-toast" role="status" aria-live="polite"></div>
    <div class="feature-lock-toast hidden" id="feature-lock-toast" role="status" aria-live="polite"></div>
    <div class="artifact-unlock-toast hidden" id="artifact-unlock-toast" role="status" aria-live="polite"></div>
    <section class="pause-menu hidden" id="pause-menu" aria-label="Pause menu">
      <p class="eyebrow">ROUND PAUSED</p>
      <h2>PAUSE</h2>
      <div class="pause-actions">
        <button id="reset-round-button" type="button">RESET</button>
        <button id="surrender-button" type="button">SURRENDER</button>
        <button class="secondary-button" id="resume-game-button" type="button">RETURN</button>
        <button id="return-menu-button" type="button">MAIN MENU</button>
      </div>
    </section>
    <section class="cheat-console hidden" id="cheat-console" aria-label="Debug console">
      <header><strong>${Ue.title}</strong><button id="close-cheat-console" type="button" aria-label="Close debug console">×</button></header>
      <p id="cheat-output">Enter a command.</p>
      <label><span>›</span><input id="cheat-input" type="text" autocomplete="off" spellcheck="false" placeholder="cash 1000"></label>
    </section>
    <section class="overlay" id="overlay" aria-live="polite">
      
      <div class="menu-content" id="menu-content">
        <div class="death-killer-heading">
          <h1 id="overlay-title">ASTEROID BELT</h1>
          <div class="death-killer-preview" id="death-killer-preview" hidden>
            <canvas id="death-killer-canvas" aria-label="Defeating enemy 3D model"></canvas>
          </div>
        </div>
        <p id="overlay-copy"></p>
        <p class="game-over-tip" id="game-over-tip" hidden></p>
        <div class="sector-selection" aria-label="Difficulty sector selection">
          <div class="sector-heading">Difficulty</div>
          <div class="sector-carousel">
            <button class="sector-nav" id="previous-sector" type="button" aria-label="Select previous sector">‹</button>
            <span class="sector-options" id="sector-options" aria-live="polite"></span>
            <button class="sector-nav" id="next-sector" type="button" aria-label="Select next sector">›</button>
          </div>
          <p class="highest-cell">HIGHEST CELL: <span id="highest-cells">000</span></p>
          <p class="sector-requirement" id="sector-requirement"></p>
          <button class="milestone-button" id="open-milestones-button" type="button">VIEW ASCENSION <span class="milestone-claim-count" id="milestone-claim-count" hidden>0</span></button>
        </div>
      </div>
      <div class="menu-actions">
          <button class="menu-start-button" id="start-button" type="button">START RUN</button>
          <button class="menu-start-button anomaly-run-button" id="anomaly-run-button" type="button">ANOMALY RUN</button>
          ${Yt({id:`home-button`,iconId:`home`,fallback:`H`,label:S(`menu.home`)})}
          ${Yt({id:`open-lab-button`,iconId:`researchLab`,fallback:`RL`,label:S(`menu.research_lab`)})}
          ${Yt({id:`open-weaponry-button`,iconId:`weaponry`,fallback:`W`,label:S(`menu.weaponry`)})}
          ${Yt({id:`open-building-button`,iconId:`buildingSystem`,fallback:`BS`,label:S(`menu.buildings`)})}
          ${Xt({id:`open-encyclopedia-button`,iconId:`encyclopedia`,fallback:`E`,label:S(`menu.encyclopedia`)})}
          ${Xt({id:`open-settings-button`,iconId:`settings`,fallback:`S`,label:S(`menu.settings`)})}
          ${Xt({id:`open-artifacts-button`,iconId:`artifacts`,fallback:`A`,label:S(`menu.artifacts`)})}
          
      </div>
      <section class="milestones-panel hidden" id="milestones-panel" aria-label="Ascension">
        <div class="milestones-header"><div><p class="eyebrow">BEST SINGLE RUN</p><h2>ASCENSION</h2><p>MAX CELLS <strong id="milestone-max-cells">000</strong></p></div><button class="secondary-button" id="close-milestones-button" type="button">BACK</button></div>
        <div class="milestone-sector-nav"><button id="previous-milestone-sector" type="button" aria-label="View previous milestone sector">‹</button><strong id="milestone-sector-label">SECTOR I</strong><button id="next-milestone-sector" type="button" aria-label="View next milestone sector">›</button></div>
        <div class="milestone-track" id="milestone-track"></div>
      </section>
      <section class="lab-panel hidden" id="lab-panel" aria-label="Research Lab">
        <div class="lab-header"><div><p class="eyebrow">PERMANENT UPGRADES</p><h2>RESEARCH LAB</h2></div><button class="secondary-button" id="close-lab-button" type="button">BACK</button></div>
        <p class="lab-balance">CASH <span id="lab-cash">$0</span><span id="lab-chronoshard-balance"> · CHRONOSHARDS <span id="lab-chronoshards">✦ 0</span></span></p>
        <p class="lab-message" id="lab-message" aria-live="polite"></p>
        <h3 id="research-slots-heading">ACTIVE SLOTS</h3><div class="research-slots" id="research-slots"></div>
        <h3>AVAILABLE RESEARCH</h3><label class="research-search"><span>SEARCH</span><input id="research-search" type="search" placeholder="Search research names" autocomplete="off"></label><div class="research-filters"><label><input id="hide-completed-researches" type="checkbox"> <span>Hide Completed Researches</span></label><label><input id="hide-locked-researches" type="checkbox"> <span>Hide Locked Researches</span></label></div><div class="research-list" id="research-list"></div>
      </section>
      <section class="encyclopedia-panel hidden" id="encyclopedia-panel" aria-label="Encyclopedia"><div class="lab-header"><div><p class="eyebrow">THREAT DATABASE</p><h2>ENCYCLOPEDIA</h2></div><button class="secondary-button" id="close-encyclopedia-button" type="button">BACK</button></div><div class="encyclopedia-list" id="encyclopedia-list"></div></section>
      <section class="artifact-panel hidden" id="artifact-panel" aria-label="Artifacts"><div class="lab-header"><div><p class="eyebrow">PERMANENT ACHIEVEMENTS</p><h2>ARTIFACTS</h2></div><button class="secondary-button" id="close-artifacts-button" type="button">BACK</button></div><p class="artifact-intro">Artifacts are permanent rewards earned by reaching achievement goals.</p><div class="artifact-grid" id="artifact-grid"></div></section>
      <section class="artifact-detail-modal hidden" id="artifact-detail-modal" aria-label="Artifact detail"><div id="artifact-detail-content"></div><button class="secondary-button" id="close-artifact-detail-button" type="button">BACK</button></section>
      <section class="building-panel hidden" id="building-panel"><div class="lab-header"><div><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING SYSTEM</h2></div><button class="secondary-button" id="close-building-button" type="button">BACK</button></div><p class="lab-balance">CASH <span id="building-cash"></span> · CHRONOSHARDS <span id="building-chronoshards"></span> · SLOTS <span id="building-slots"></span></p><div class="building-actions"><button id="enter-build-mode" type="button">BUILD MODE</button><button id="open-building-draft" type="button">UNLOCK A BUILDING</button></div><h3>UNLOCKED BUILDINGS</h3><div class="building-list" id="building-list"></div></section>
      <section class="building-draft-modal hidden" id="building-draft-modal" aria-label="Building Draft"><button class="upgrade-close" id="close-building-draft" type="button" aria-label="Close building draft">×</button><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING DRAFT</h2><p class="building-draft-balance">CHRONOSHARDS <span id="building-draft-chronoshards"></span></p><div class="building-list" id="building-draft-list"></div></section>
      <section class="weaponry-panel hidden" id="weaponry-panel" aria-label="Weaponry"><div class="lab-header"><div><p class="eyebrow">ACTIVE ARSENAL</p><h2>WEAPONRY</h2></div><button class="secondary-button" id="close-weaponry-button" type="button">BACK</button></div><p class="lab-balance">CHRONOSHARDS <span id="weaponry-chronoshards"></span></p><div class="weapon-buy-actions"><button class="weapon-buy-button" id="buy-weapon-button" type="button">BUY WEAPON · ✦ 35</button><button class="weapon-buy-button" id="buy-weapons-five-button" type="button">BUY WEAPON x5 · ✦ 175</button></div><p class="weapon-lucky-find-chance" id="weapon-lucky-find-chance" hidden>LUCKY FIND · 0% · 2 CARDS</p><h3>ROUND LOADOUT <span id="weapon-slot-count"></span></h3><div class="weapon-loadout" id="weapon-loadout"></div><h3>WEAPON CARDS</h3><div class="weapon-card-list" id="weapon-card-list"></div></section>
      <section class="weapon-reveal-modal hidden" id="weapon-reveal-modal" aria-label="Weapon purchase result" aria-live="polite"><div class="weapon-reveal-card"><p class="eyebrow" id="weapon-reveal-count"></p><p class="weapon-lucky-find-badge" aria-hidden="true">✦ LUCKY FIND · DOUBLE CARD ✦</p><p class="weapon-reveal-status" id="weapon-reveal-status"></p><img class="asset-card-art" id="weapon-reveal-art" alt=""><h2 id="weapon-reveal-name"></h2><p id="weapon-reveal-detail"></p><button id="weapon-reveal-continue" type="button">CLAIM</button></div></section>
      <section class="settings-panel hidden" id="settings-panel" aria-label="Settings"><div class="lab-header"><div><p class="eyebrow">PREFERENCES</p><h2>SETTINGS</h2></div><button class="secondary-button" id="close-settings-button" type="button">BACK</button></div><div class="settings-section"><h3>GRAPHICS</h3><div class="settings-row"><div><strong>Quality</strong><small>Changes render resolution and shadows.</small></div><div class="settings-options" id="graphics-quality-options"></div></div><label class="settings-row settings-toggle"><span><strong>Shadows</strong><small>Show dynamic object shadows.</small></span><input id="setting-shadows" type="checkbox"></label><label class="settings-row"><span><strong>HDR Emission</strong><small>Controls how far bright effects bloom beyond their models.</small></span><output id="hdr-emission-value"></output><input id="setting-hdr-emission" type="range" min="0" max="100" step="1"></label><label class="settings-row"><span><strong>Maximum FPS</strong><small>Limits rendering and simulation to reduce hardware load.</small></span><output id="max-fps-value"></output><input id="setting-max-fps" type="range" min="0" max="240" step="30"></label></div><div class="settings-section"><h3>GAMEPLAY</h3><label class="settings-row settings-toggle"><span><strong>Auto Pause</strong><small>Pause the run when the game loses focus.</small></span><input id="setting-auto-pause" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>High Contrast HUD</strong><small>Improves HUD readability.</small></span><input id="setting-high-contrast" type="checkbox"></label></div><div class="settings-section"><h3>SOUND</h3><label class="settings-row"><span><strong>Master Volume</strong><small>Controls all game sound effects.</small></span><output id="master-volume-value"></output><input id="setting-master-volume" type="range" min="0" max="100" step="1"></label><label class="settings-row settings-toggle"><span><strong>Mute All</strong><small>Instantly silence all sound effects.</small></span><input id="setting-muted" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>Spatial Audio</strong><small>Pan sounds based on their world position.</small></span><input id="setting-spatial-audio" type="checkbox"></label></div><div class="settings-section settings-actions"><button id="open-patch-notes-button" type="button">PATCH NOTES</button></div></section>
      <section class="patch-notes-panel hidden" id="patch-notes-panel" aria-label="Patch notes"><div class="lab-header"><div><p class="eyebrow">VERSION ${We.version} · BUILD ${We.number}</p><h2>PATCH NOTES</h2></div><button class="secondary-button" id="close-patch-notes-button" type="button">BACK</button></div>${wt.map(e=>`<article class="patch-notes-entry"><h3>${e.heading}</h3><ul>${e.changes.map(e=>`<li>${e}</li>`).join(``)}</ul></article>`).join(``)}</section>
    </section>
    <section class="anomaly-run-modal hidden" id="anomaly-run-modal" aria-label="Anomaly Run challenge"><div class="anomaly-run-card"><p class="eyebrow">WEEKLY ANOMALY</p><h2 id="anomaly-challenge-name"></h2><p id="anomaly-challenge-description"></p><p class="anomaly-reward" id="anomaly-reward"></p><p class="anomaly-reset" id="anomaly-reset"></p><p class="anomaly-time-warning hidden" id="anomaly-time-warning" role="alert"></p><div><button class="secondary-button" id="cancel-anomaly-run" type="button">BACK</button><button id="confirm-anomaly-run" type="button">START ANOMALY RUN</button></div></div></section>
    <div class="build-bar hidden" id="build-bar"><span id="build-status">SELECT A BUILDING</span><div id="build-options"></div><button id="exit-build-mode" type="button">DONE</button></div>
    <section class="building-upgrade hidden" id="building-upgrade"></section>
  </main>
`;var $t=document.querySelector(`#game`);for(let e of document.querySelectorAll(`[data-menu-icon]`))e.addEventListener(`error`,()=>{e.hidden=!0;let t=e.nextElementSibling;t&&(t.hidden=!1)});var en=document.querySelector(`#score`),tn=document.querySelector(`#hud-sector`),nn=document.querySelector(`#shield-indicators`),rn=document.querySelector(`#tower-health-hud`),an=document.querySelector(`#tower-health-label`),on=document.querySelector(`#tower-health-fill`),sn=document.querySelector(`#pause-button`),cn=document.querySelector(`#overlay`),ln=document.querySelector(`#save-slot-select`),un=document.querySelector(`#save-slot-grid`),dn=document.querySelector(`#overlay-title`),fn=document.querySelector(`#death-killer-preview`),pn=document.querySelector(`#death-killer-canvas`),mn=document.querySelector(`#overlay-copy`),hn=document.querySelector(`#game-over-tip`),gn=document.querySelector(`#start-button`),_n=document.querySelector(`#anomaly-run-button`),vn=document.querySelector(`#anomaly-run-modal`),yn=document.querySelector(`#anomaly-challenge-name`),bn=document.querySelector(`#anomaly-challenge-description`),xn=document.querySelector(`#anomaly-reward`),Sn=document.querySelector(`#anomaly-reset`),Cn=document.querySelector(`#anomaly-time-warning`),wn=document.querySelector(`#confirm-anomaly-run`),Tn=document.querySelector(`#cancel-anomaly-run`),M=document.querySelector(`#menu-content`),En=document.querySelector(`#open-milestones-button`),Dn=document.querySelector(`#milestones-panel`),On=document.querySelector(`#close-milestones-button`),kn=document.querySelector(`#milestone-max-cells`),An=document.querySelector(`#milestone-track`),jn=document.querySelector(`#milestone-claim-count`),Mn=document.querySelector(`#milestone-claim-toast`),Nn=document.querySelector(`#feature-lock-toast`),Pn=document.querySelector(`#artifact-unlock-toast`),Fn=document.querySelector(`#previous-milestone-sector`),In=document.querySelector(`#next-milestone-sector`),Ln=document.querySelector(`#milestone-sector-label`),Rn=document.querySelector(`#lab-panel`),zn=document.querySelector(`#open-lab-button`),Bn=document.querySelector(`#home-button`),Vn=document.querySelector(`#open-building-button`),Hn=document.querySelector(`#open-weaponry-button`),Un=document.querySelector(`#open-encyclopedia-button`),Wn=document.querySelector(`#encyclopedia-panel`),Gn=document.querySelector(`#close-encyclopedia-button`),Kn=document.querySelector(`#encyclopedia-list`),qn=document.querySelector(`#open-artifacts-button`),Jn=document.querySelector(`#artifact-panel`),Yn=document.querySelector(`#close-artifacts-button`),Xn=document.querySelector(`#artifact-grid`),Zn=document.querySelector(`#artifact-detail-modal`),Qn=document.querySelector(`#artifact-detail-content`),$n=document.querySelector(`#close-artifact-detail-button`),er=document.querySelector(`#weaponry-panel`),tr=document.querySelector(`#close-weaponry-button`),nr=document.querySelector(`#weaponry-chronoshards`),rr=document.querySelector(`#buy-weapon-button`),ir=document.querySelector(`#buy-weapons-five-button`),ar=document.querySelector(`#weapon-lucky-find-chance`),or=document.querySelector(`#weapon-reveal-modal`),sr=document.querySelector(`#weapon-reveal-count`),cr=document.querySelector(`#weapon-reveal-status`),lr=document.querySelector(`#weapon-reveal-art`),ur=document.querySelector(`#weapon-reveal-name`),dr=document.querySelector(`#weapon-reveal-detail`),fr=document.querySelector(`#weapon-reveal-continue`),pr=document.querySelector(`#weapon-slot-count`),mr=document.querySelector(`#weapon-loadout`),hr=document.querySelector(`#weapon-card-list`),gr=document.querySelector(`#weapon-hud`),_r=document.querySelector(`#open-settings-button`),vr=document.querySelector(`#exit-game-button`),yr=document.querySelector(`#settings-panel`),br=document.createElement(`div`);br.className=`settings-section`,br.innerHTML=`<h3>${S(`settings.language`)}</h3><div class="settings-row"><div><strong>${S(`settings.language`)}</strong><small>${S(`settings.language_help`)}</small></div><select id="language-select" class="language-select" aria-label="${S(`settings.language`)}"></select></div>`,yr.querySelector(`.lab-header`)?.after(br);var xr=document.querySelector(`#language-select`),Sr=document.querySelector(`#display-mode-options`),Cr=document.querySelector(`#display-resolution-options`),wr=document.querySelector(`#close-settings-button`),Tr=document.querySelector(`#open-patch-notes-button`),Er=document.querySelector(`#patch-notes-panel`),Dr=document.querySelector(`#close-patch-notes-button`),Or=document.querySelector(`#graphics-quality-options`),kr=document.querySelector(`#setting-shadows`),Ar=document.querySelector(`#setting-hdr-emission`),jr=document.querySelector(`#hdr-emission-value`),Mr=document.querySelector(`#setting-max-fps`),Nr=document.querySelector(`#max-fps-value`),Pr=document.querySelector(`#setting-auto-pause`),Fr=document.querySelector(`#setting-high-contrast`),Ir=document.querySelector(`#setting-master-volume`),Lr=document.querySelector(`#master-volume-value`),Rr=document.querySelector(`#setting-muted`),zr=document.querySelector(`#setting-spatial-audio`),Br=document.querySelector(`#building-panel`),Vr=document.querySelector(`#close-building-button`),Hr=document.querySelector(`#building-list`),Ur=document.querySelector(`#building-cash`),Wr=document.querySelector(`#building-chronoshards`),Gr=document.querySelector(`#building-slots`),Kr=document.querySelector(`#enter-build-mode`),qr=document.querySelector(`#open-building-draft`),Jr=document.querySelector(`#building-draft-modal`),Yr=document.querySelector(`#close-building-draft`),Xr=document.querySelector(`#building-draft-chronoshards`),Zr=document.querySelector(`#building-draft-list`),Qr=document.querySelector(`#build-bar`),$r=document.querySelector(`#build-status`),ei=document.querySelector(`#build-options`),ti=document.querySelector(`#build-grid-ui`),ni=document.querySelector(`#exit-build-mode`),ri=document.querySelector(`#building-upgrade`),ii=document.querySelector(`#close-lab-button`),ai=document.querySelector(`#lab-cash`),oi=document.querySelector(`#lab-chronoshard-balance`),si=document.querySelector(`#lab-chronoshards`),ci=document.querySelector(`#lab-message`);function li(){let e=(e,t)=>{let n=document.querySelector(e);n&&(n.textContent=S(t))};e(`.cash-balance .currency-label`,`hud.cash`),e(`.chronoshard-balance .currency-label`,`hud.chronoshards`),e(`.run-cell-counter dt`,`hud.cells`),e(`#pause-menu .eyebrow`,`menu.round_paused`),e(`#pause-menu h2`,`menu.pause`),e(`#reset-round-button`,`menu.reset`),e(`#surrender-button`,`menu.surrender`),e(`#resume-game-button`,`menu.return`),e(`#return-menu-button`,`menu.main_menu`),e(`#start-button`,`menu.start_run`),e(`#anomaly-run-button`,`anomaly.run`),e(`#cancel-anomaly-run`,`menu.back`),e(`#confirm-anomaly-run`,`anomaly.start`),e(`#close-settings-button`,`menu.back`),e(`#open-patch-notes-button`,`settings.patch_notes`),e(`#close-milestones-button`,`menu.back`),e(`#close-lab-button`,`menu.back`),e(`#close-encyclopedia-button`,`menu.back`),e(`#encyclopedia-panel .eyebrow`,`encyclopedia.threat_database`),e(`#encyclopedia-panel h2`,`menu.encyclopedia`),e(`#close-artifacts-button`,`menu.back`),e(`#close-artifact-detail-button`,`menu.back`),e(`#close-building-button`,`menu.back`),e(`#close-weaponry-button`,`menu.back`),e(`#close-patch-notes-button`,`menu.back`),e(`#patch-notes-panel h2`,`menu.patch_notes`);let t=document.querySelector(`#patch-notes-panel .eyebrow`);t&&(t.textContent=S(`patch_notes.version_build`,{version:We.version,build:We.number})),e(`#research-slots-heading`,`research.active_slots`),e(`#lab-panel h3:not(#research-slots-heading)`,`research.available_research`),e(`.research-search > span`,`research.search`);let n=document.querySelector(`#research-search`);n&&(n.placeholder=S(`research.search_placeholder`)),e(`#hide-completed-researches + span`,`research.hide_completed`),e(`#hide-locked-researches + span`,`research.hide_locked`),e(`#artifact-panel .eyebrow`,`artifact.permanent_achievements`),e(`#artifact-panel .artifact-intro`,`artifact.intro`),e(`#building-panel .eyebrow`,`building.permanent_defenses`),e(`#building-panel h2`,`building.system`),e(`#enter-build-mode`,`building.build_mode`),e(`#open-building-draft`,`building.unlock_a_building`),e(`#building-panel h3`,`building.unlocked_buildings`),e(`#building-draft-modal .eyebrow`,`building.permanent_defenses`),e(`#building-draft-modal h2`,`building.draft`),e(`#weaponry-panel .eyebrow`,`weapon.active_arsenal`),e(`#weaponry-panel h2`,`menu.weaponry`);let r=document.querySelectorAll(`#weaponry-panel h3`);r[0]&&(r[0].childNodes[0].textContent=`${S(`weapon.round_loadout`)} `),r[1]&&(r[1].textContent=S(`weapon.cards`)),e(`.controls-desktop span:nth-child(1) b`,`controls.move`),e(`.controls-desktop span:nth-child(2) b`,`controls.navigate`),e(`.controls-desktop span:nth-child(3) b`,`controls.use_weapon`),e(`.controls-mobile span:nth-child(1) b`,`controls.move`),e(`.controls-mobile span:nth-child(2) b`,`controls.select_weapon`);let i=(e,t)=>{let n=document.querySelector(e);n&&n.setAttribute(`aria-label`,S(t))};i(`#game`,`accessibility.game_canvas`),i(`#hud-sector`,`accessibility.current_sector`),i(`#pause-button`,`accessibility.pause_game`),i(`#shield-indicators`,`accessibility.shield_charges`),i(`.instructions`,`accessibility.game_controls`),i(`.build-footer`,`accessibility.build_information`),i(`#build-grid-ui`,`accessibility.build_locations`),i(`#pause-menu`,`accessibility.pause_menu`),i(`#cheat-console`,`accessibility.debug_console`),i(`#close-cheat-console`,`accessibility.close_debug_console`),i(`#save-slot-select`,`accessibility.save_slots`),i(`#death-killer-canvas`,`accessibility.defeating_enemy`),i(`.sector-selection`,`accessibility.sector_selection`),i(`#previous-sector`,`accessibility.previous_sector`),i(`#next-sector`,`accessibility.next_sector`),i(`#previous-milestone-sector`,`accessibility.previous_milestone_sector`),i(`#next-milestone-sector`,`accessibility.next_milestone_sector`);let a=document.querySelector(`#cheat-output`);a&&(a.textContent=S(`cheat.prompt`));let o=document.querySelector(`#cheat-input`);o&&(o.placeholder=S(`cheat.placeholder`)),[[`#graphics-quality-options`,`settings.graphics`],[`#setting-max-fps`,`settings.graphics`],[`#setting-master-volume`,`settings.sound`]].forEach(([e,t])=>{let n=document.querySelector(e)?.closest(`.settings-section`);n&&(n.querySelector(`h3`).textContent=S(t))}),[[`#graphics-quality-options`,`settings.quality`,`settings.quality_help`],[`#setting-shadows`,`settings.shadows`,`settings.shadows_help`],[`#setting-hdr-emission`,`settings.hdr_emission`,`settings.hdr_emission_help`],[`#setting-max-fps`,`settings.max_fps`,`settings.max_fps_help`],[`#setting-auto-pause`,`settings.auto_pause`,`settings.auto_pause_help`],[`#setting-high-contrast`,`settings.high_contrast_hud`,`settings.high_contrast_hud_help`],[`#setting-master-volume`,`settings.master_volume`,`settings.master_volume_help`],[`#setting-muted`,`settings.mute_all`,`settings.mute_all_help`],[`#setting-spatial-audio`,`settings.spatial_audio`,`settings.spatial_audio_help`]].forEach(([e,t,n])=>{let r=document.querySelector(e)?.closest(`.settings-row`);if(!r)return;let i=r.querySelector(`strong`),a=r.querySelector(`small`);i&&(i.textContent=S(t)),a&&(a.textContent=S(n))})}li();var ui=document.querySelector(`#research-slots`),di=document.querySelector(`#research-slots-heading`),fi=document.querySelector(`#research-list`),pi=document.querySelector(`#research-search`),mi=document.querySelector(`#hide-completed-researches`),hi=document.querySelector(`#hide-locked-researches`),gi=document.querySelector(`#cheat-console`),_i=document.querySelector(`#cheat-input`),vi=document.querySelector(`#cheat-output`),yi=document.querySelector(`#close-cheat-console`),bi=document.querySelector(`#pause-menu`),xi=document.querySelector(`#reset-round-button`),Si=document.querySelector(`#surrender-button`),Ci=document.querySelector(`#resume-game-button`),wi=document.querySelector(`#return-menu-button`),Ti=document.querySelector(`#cash`),Ei=document.querySelector(`#chronoshards`),Di=document.querySelector(`#cash-indicators`),Oi=document.querySelector(`#highest-cells`),ki=document.querySelector(`#sector-requirement`),Ai=document.querySelector(`#sector-options`),ji=document.querySelector(`#previous-sector`),Mi=document.querySelector(`#next-sector`),Ni=document.querySelector(`#virtual-joystick`),Pi=``;function Fi(){let e=Ot.filter(e=>e!==Pi),t=e[Math.floor(Math.random()*e.length)]??Ot[0];return Pi=t,t}var Ii=`asteroid-belt-active-save-slot`,Li=`asteroid-belt-save-slot-session`,Ri=3;ht();var{cellBank:zi,sector:Bi,sectorHighScores:Vi,cash:Hi,chronoshards:Ui,researchLab:Wi,savedRound:Gi,buildings:Ki,featureUnlocks:qi,milestones:Ji,settings:Yi,weaponry:Xi,anomalyRewards:Zi,artifacts:Qi}=w,$i=Object.keys(we);function ea(){let e=vt(Gi);return e&&typeof e==`object`?e:null}function ta(e){yt(Gi,e)}function na(){let e=vt(Vi,{});return!e||typeof e!=`object`?{}:Object.fromEntries($i.map(t=>[t,Number.isFinite(e[t])&&e[t]>=0?e[t]:0]))}function ra(){yt(Vi,la)}function ia(){try{let e=JSON.parse(window.localStorage.getItem(Ji));return!e||typeof e!=`object`?{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}:{version:Number(e.version)||0,claimed:Array.isArray(e.claimed)?e.claimed.filter(e=>Mt.some(t=>t.id===e)):[],researchUnlocks:Array.isArray(e.researchUnlocks)?e.researchUnlocks.filter(e=>Mt.some(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))):[],debugAscensionsGranted:!!e.debugAscensionsGranted}}catch{return{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}}}function aa(){yt(Ji,P)}function oa(){return Mt.filter(e=>P.claimed.includes(e.id)).flatMap(e=>e.rewards.filter(e=>e.type===`sector`).map(e=>e.sector-1)).reduce((e,t)=>Math.max(e,t),0)}function sa(e){return oa()+1>=e}var ca=gt(zi),la=na(),N=(()=>{let e=vt(Qi,{}),t=new Set(It.artifacts.map(e=>e.id));return{unlocked:Array.isArray(e?.unlocked)?e.unlocked.filter(e=>t.has(e)):[],resetAtScores:e?.resetAtScores&&typeof e.resetAtScores==`object`?e.resetAtScores:{},stackCounts:e?.stackCounts&&typeof e.stackCounts==`object`?e.stackCounts:null}})(),P=ia();P.version!==3&&(P.claimed=Mt.filter(e=>(la[$i[e.sector-1]]??0)>=e.cells).map(e=>e.id),P.version=3,aa());var F=Math.min(gt(Bi),oa()),ua=F,da=gt(Hi),I=gt(Ui),L=ea(),R=null,fa=(()=>{let e=vt(Zi,{}),t=e&&typeof e.claimedSectors==`object`?e.claimedSectors:{},n=Object.entries(t).flatMap(([e,t])=>(Array.isArray(t)?t:[]).map(t=>`${Ke.challenges[Number(e)%Ke.challenges.length]?.id??`cell-scout`}:sector${Number(t)+1}`));return{claimedSectors:t,darkCoreClaims:Array.isArray(e?.darkCoreClaims)?e.darkCoreClaims:[...new Set(n)]}})();if(!N.stackCounts){let e=Object.values(fa.claimedSectors).reduce((e,t)=>e+(Array.isArray(t)?new Set(t).size:0),0);N.stackCounts={"dark-core":e},e>0&&!N.unlocked.includes(`dark-core`)&&N.unlocked.push(`dark-core`),yt(Qi,N)}var pa=null,ma=!1,ha=0;function ga(){return Ke.challenges.find(e=>e.id===pa?.challengeId)??null}function _a(){return ga()?.type===`tower-defense`}var va=(()=>{try{let e=JSON.parse(localStorage.getItem(qi));return{researchLab:!!e?.researchLab,buildingSystem:!!e?.buildingSystem,weaponry:!!e?.weaponry}}catch{return{researchLab:!1,buildingSystem:!1,weaponry:!1}}})();P.claimed.includes(`sector-1-10`)&&!va.researchLab&&(va.researchLab=!0,io());var z=(()=>{try{let e=JSON.parse(localStorage.getItem(Xi));return{cards:e?.cards??{},loadout:Array.isArray(e?.loadout)?e.loadout:[],selected:e?.selected??0}}catch{return{cards:{},loadout:[],selected:0}}})(),ya=[],ba=0,B=(()=>{try{let e=JSON.parse(localStorage.getItem(Ki));return e?.unlocked?e:{unlocked:[],placed:[]}}catch{return{unlocked:[],placed:[]}}})(),xa=B.placed.filter(e=>e.type===`gapGenerator`);if(xa.length){da+=xa.reduce((e,t)=>e+(t.spent??260),0),B.placed=B.placed.filter(e=>e.type!==`gapGenerator`),B.unlocked=B.unlocked.filter(e=>e!==`gapGenerator`);try{localStorage.setItem(Hi,String(da)),localStorage.setItem(Ki,JSON.stringify(B))}catch{}}function Sa(){let e={language:Ie(),graphics:{quality:`high`,shadows:!0,hdrEmissionIntensity:.5},gameplay:{maxFps:120,autoPause:!0,highContrastHud:!1},sound:{masterVolume:100,muted:!1,spatialAudio:!0}};try{let t=JSON.parse(localStorage.getItem(Yi)),r=t?.graphics??{},i=t?.gameplay??{},a=Number.isFinite(r.hdrEmissionIntensity)?n.clamp(r.hdrEmissionIntensity,0,1):r.hdrEmission===!1?0:.5,o=Number.isFinite(i.maxFps)?n.clamp(i.maxFps,0,240):e.gameplay.maxFps;return{language:Be().includes(t?.language)?t.language:e.language,graphics:{...e.graphics,...r,hdrEmissionIntensity:a},gameplay:{...e.gameplay,...i,maxFps:o},sound:{...e.sound,...t?.sound}}}catch{return e}}var V=Sa();ze(V.language);function Ca(){yt(Yi,V)}var wa=Object.keys($e.types);B.unlocked=[...new Set(B.unlocked.filter(e=>wa.includes(e)))],B.placed=B.placed.filter(e=>wa.includes(e.type)),B.unlockCount=Number.isFinite(B.unlockCount)?B.unlockCount:B.unlocked.length,B.unlockOffers=Array.isArray(B.unlockOffers)?B.unlockOffers.filter(e=>wa.includes(e)&&!B.unlocked.includes(e)):[];var Ta=new Map,Ea=new Map,Da=!1,Oa=null,ka=``,Aa=!1,ja=!1,Ma=new Set;function Na(){return{unlockedSlots:1,levels:{},slots:Array(C.maxSlots).fill(null)}}function Pa(){try{let e=JSON.parse(window.localStorage.getItem(Wi));return!e||typeof e!=`object`?Na():{unlockedSlots:n.clamp(Number.parseInt(e.unlockedSlots,10)||1,1,C.maxSlots),levels:e.levels&&typeof e.levels==`object`?e.levels:{},slots:Array.from({length:C.maxSlots},(t,n)=>e.slots?.[n]??null)}}catch{return Na()}}var H=Pa(),Fa=!1;function Ia(){yt(Wi,H)}var{getResearchById:La,getResearchLevel:U,getResearchStatBonus:Ra,getResearchCost:za,getResearchDuration:Ba,getResearchLockReason:Va,isResearchVisible:Ha,compareResearchProgression:Ua}=St({config:C,milestones:Mt,getResearchState:()=>H,getMilestoneState:()=>P,getBankedCells:()=>ca});function Wa(e){return It.artifacts.filter(t=>N.unlocked.includes(t.id)&&t.buff.stat===e).reduce((e,t)=>e+t.buff.amount*Ga(t),0)}function Ga(e){return e.repeatable?Math.max(0,Number(N.stackCounts?.[e.id])||0):1}function W(e){return Ra(e)+Wa(e)}function Ka(e,t){let n=za(e,t)*Math.max(0,1-Wa(`researchCostReduction`));return e.cost.currency===`cash`?Math.round(n*100)/100:Math.ceil(n)}function qa(e,t){let n={chaser:`chaserRangeDebuff`,banger:`bangerRangeDebuff`,shooter:`shooterRangeDebuff`}[e];return n?t*Math.max(.5,1-W(n)):t}function Ja(){let e=Date.now(),t=!1,n=[];for(let r=0;r<H.unlockedSlots;r+=1){let i=H.slots[r];if(!i||C.durationsEnabled&&i.completesAt>e)continue;let a=La(i.researchId);H.levels[i.researchId]=Math.min(U(i.researchId)+1,a.maxLevel),H.slots[r]=null,n.push(a.name),t=!0}return t&&Ia(),n.length&&Ya(n.map(e=>S(`cheat.research_completed`,{research:e})).join(` `)),t}function Ya(e=``){ci.textContent=e}function Xa(){Ja(),ai.textContent=`$${E(da)}`,si.textContent=`✦ ${E(I)}`,oi.hidden=!C.durationsEnabled;let e=Date.now();di.hidden=!C.durationsEnabled,ui.hidden=!C.durationsEnabled,ui.innerHTML=C.durationsEnabled?H.slots.map((t,r)=>{let i=r+1;if(t){let r=La(t.researchId),a=Ba(r,t.level),o=Math.max(0,t.completesAt-e),s=n.clamp(1-o/a,0,1)*100;return`<article class="research-slot active"><span>${S(`research.slot`,{slot:i})}</span><strong>${r.name} · ${S(`weapon.level`,{level:t.level+1})}</strong><div class="research-progress"><i style="width:${s}%"></i></div><small>${S(`research.remaining`,{duration:Et(o)})}</small></article>`}if(i<=H.unlockedSlots)return`<article class="research-slot"><span>${S(`research.slot`,{slot:i})}</span><strong>${S(`research.available`)}</strong><small>${S(`research.select_below`)}</small></article>`;let a=C.slotUnlocks.find(e=>e.slot===i),o=!a.requirements?.minSector||sa(a.requirements.minSector),s=a.cost.currency===`cash`?da>=a.cost.amount:I>=a.cost.amount,c=o&&s?``:`disabled`,l=o?S(`research.unlock_for`,{cost:Dt(a.cost.currency,a.cost.amount)}):S(`research.unlock_sector`,{sector:T(a.requirements.minSector)});return`<article class="research-slot locked"><span>${S(`research.slot`,{slot:i})}</span><strong>${S(`research.locked`)}</strong><button data-unlock-slot="${i}" type="button" ${c}>${l}</button></article>`}).join(``):``;let t=new Map;for(let e of C.researches.filter(Ha)){let n=e.category??`General`;t.set(n,[...t.get(n)??[],e])}let r=ka.trim().toLocaleLowerCase(),i=[...t.entries()].sort(([e],[t])=>{let n=C.categoryOrder.indexOf(e),r=C.categoryOrder.indexOf(t);return(n<0?1e3:n)-(r<0?1e3:r)}).map(([e,t])=>[e,t.filter(e=>`${e.name} ${e.description}`.toLocaleLowerCase().includes(r)).filter(e=>!Aa||U(e.id)<e.maxLevel).filter(e=>!ja||!Va(e)).sort(Ua)]).filter(([,e])=>e.length);fi.innerHTML=i.length?i.map(([e,t])=>{let n=r||Ma.has(e);return`<section class="research-category ${n?`open`:``}"><button class="research-category-toggle" data-toggle-research-category="${e}" type="button" aria-expanded="${n}"><span>${e}</span><i aria-hidden="true">›</i></button><div class="research-grid">${t.map(e=>{let t=U(e.id),n=Va(e),r=C.durationsEnabled&&H.slots.some(t=>t?.researchId===e.id),i=t>=e.maxLevel,a=Ka(e,t),o=Ba(e,t),s=Fa||(e.cost.currency===`cash`?da>=a:I>=a),c=C.durationsEnabled&&!H.slots.slice(0,H.unlockedSlots).some(e=>!e),l=n||r||i||!s||c,u=n||r||i||c?`research-locked`:s?`research-affordable`:`research-unaffordable`,d=i?S(`research.max_level`):r?S(`research.in_progress`):n||(Fa?S(`research.free_enabled`):S(`research.cost`,{cost:`${Dt(e.cost.currency,a)}${C.durationsEnabled?` · ${Et(o)}`:``}`}));return`<article class="research-card"><div><span class="research-level">${S(`weapon.level`,{level:t})}/${e.maxLevel}</span><h4>${e.name}</h4><p>${e.description}</p><p class="research-effect">${Tt(e,t)} → ${Tt(e,Math.min(t+1,e.maxLevel))}</p><small>${d}</small></div><button class="${u}" data-start-research="${e.id}" type="button" ${l?`disabled`:``}>${S(i?`research.maxed`:`research.start`)}</button></article>`}).join(``)}</div></section>`}).join(``):`<p class="research-empty">${S(`research.no_search_results`)}</p>`}function Za(e){Ja();let t=La(e),n=U(e),r=Va(t),i=H.slots.slice(0,H.unlockedSlots).findIndex(e=>!e),a=Ka(t,n),o=t.cost.currency===`cash`?da:I,s=C.durationsEnabled&&H.slots.some(t=>t?.researchId===e);r||n>=t.maxLevel||C.durationsEnabled&&i<0||s||!Fa&&o<a||(Fa||(t.cost.currency===`cash`?Co(-a):wo(-a)),C.durationsEnabled?H.slots[i]={researchId:e,level:n,completesAt:Date.now()+Ba(t,n)}:(H.levels[e]=Math.min(n+1,t.maxLevel),e===`shield`&&X&&($c+=1,Js.visible=!0)),Ia(),Ya(C.durationsEnabled?S(`research.started`,{research:t.name,slot:i+1}):S(`research.upgraded`,{research:t.name,level:n+1})),Xa())}function Qa(e){let t=C.slotUnlocks.find(t=>t.slot===e);!t||e!==H.unlockedSlots+1||t.requirements?.minSector&&!sa(t.requirements.minSector)||(t.cost.currency===`cash`?da:I)<t.cost.amount||(t.cost.currency===`cash`?Co(-t.cost.amount):wo(-t.cost.amount),H.unlockedSlots=e,Ia(),Ya(S(`research.slot_unlocked`,{slot:e})),Xa())}function G(e){vi.textContent=e}function $a(e){if(!Ue.enabled)return;let t=e??gi.classList.contains(`hidden`);gi.classList.toggle(`hidden`,!t),t&&(pc.clear(),_i.focus(),_i.select())}function eo(){da=0,I=0,Co(),wo()}function to(){ca=0,F=0,P.claimed=[],P.researchUnlocks=[],P.debugAscensionsGranted=!1;for(let e of $i)la[e]=0;_t(zi,ca),_t(Bi,F),ra(),aa(),Hs(),Bo(),Go(),bd()}function no(){P.claimed=[],P.researchUnlocks=[],P.debugAscensionsGranted=!1,P.version=3;for(let e of $i)la[e]=0;F=0,_t(Bi,F),ra(),aa(),Hs(),Bo(),Go(),Xa(),bd()}function ro(){H.unlockedSlots=1,H.levels={},H.slots=Array(C.maxSlots).fill(null),Fa=!1,Ia(),Xa()}function io(){yt(qi,va)}function ao(){va={researchLab:!1,buildingSystem:!1,weaponry:!1},io(),fo()}function oo(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches&&window.innerHeight>=window.innerWidth}var so;function co(e,t){Nn.textContent=t;let n=gn.getBoundingClientRect(),r=_n.getBoundingClientRect();Nn.style.left=`${window.innerWidth/2}px`,Nn.style.top=`${Math.min(window.innerHeight-12,Math.max(n.bottom,r.bottom)+12)}px`,Nn.classList.remove(`hidden`),window.clearTimeout(so),so=window.setTimeout(()=>Nn.classList.add(`hidden`),4e3)}function lo(e){let t=C.featureUnlocks[e];if(oa()+1<t.minSector)return S(`cheat.feature_sector`,{sector:T(t.minSector)});if(t.requiredMilestone&&!P.claimed.includes(t.requiredMilestone)){let e=Mt.find(e=>e.id===t.requiredMilestone);if(e)return S(`cheat.feature_cells`,{cells:e.cells,sector:T(e.sector)})}return I<t.chronoshardCost?S(`cheat.feature_chronoshards`,{amount:t.chronoshardCost}):S(`cheat.feature_unavailable`)}function uo(e,t){return va[e]||po(e)?!0:(co(t,lo(e)),!1)}function fo(){for(let[e,t]of[[`researchLab`,zn],[`buildingSystem`,Vn],[`weaponry`,Hn]]){let n=C.featureUnlocks[e],r=va[e],i=oa()+1>=n.minSector&&(!n.requiredMilestone||P.claimed.includes(n.requiredMilestone)),a=S(e===`researchLab`?`menu.research_lab`:e===`buildingSystem`?`menu.buildings`:`menu.weaponry`);t.className=`menu-system-button ${r?`is-unlocked`:i?`is-unlockable`:`is-locked`}${t.classList.contains(`is-active`)?` is-active`:``}`,t.disabled=!1,t.querySelector(`.menu-button-label`).textContent=r?a:i?S(`menu.unlock_feature`,{feature:a,cost:n.chronoshardCost}):S(`menu.feature_sector`,{feature:a,sector:T(n.minSector)});let o=t.querySelector(`.menu-button-lock`);o.hidden=r||!oo(),o.innerHTML=i?`<span class="chronoshard-symbol" aria-hidden="true">✦</span><span>${n.chronoshardCost}</span>`:`<span>SECTOR ${T(n.minSector)}</span>`}}function po(e){let t=C.featureUnlocks[e];return va[e]||oa()+1<t.minSector||t.requiredMilestone&&!P.claimed.includes(t.requiredMilestone)||I<t.chronoshardCost?!1:(wo(-t.chronoshardCost),va[e]=!0,io(),fo(),!0)}function mo(){B={unlocked:[],placed:[],unlockCount:0,unlockOffers:[]},Oa=null,su(),yu(),Eu()}function ho(e=0){R={sectorIndex:n.clamp(e,0,$i.length-1),simulation:new Set},pa=null,Sd(),Hs(),bd(!1),X=!0,Gc=!1,Z=!1,q.visible=!0,M.classList.remove(`hidden`),cn.classList.add(`hidden`),bi.classList.add(`hidden`),ys(),Ad()}function go(e){let t=Ke.challenges.find(t=>t.id===e);return t?(R=null,Sd(),pa={challengeId:t.id,weekId:`debug-${t.id}`},Hs(),bd(),X=!0,Gc=!1,Z=!1,q.visible=!0,cn.classList.add(`hidden`),bi.classList.add(`hidden`),ys(),Ad(),!0):!1}function _o(e){let[t,r]=e;if(!t){ho(),G(S(`cheat.sandbox_started`));return}let i=Number(t);if(Number.isInteger(i)){R?(R.sectorIndex=n.clamp(i-1,0,$i.length-1),Hs(),Ad()):ho(i-1),G(S(`cheat.sandbox_sector`,{sector:T(R.sectorIndex+1)}));return}if(!R){G(S(`cheat.sandbox_start_first`));return}if(t===`simulate`){if(![`cell`,`enemies`,`all`].includes(r)){G(S(`cheat.sandbox_simulate_usage`));return}R.simulation=r===`all`?new Set([`cell`,`enemies`,`boosters`]):new Set([r]),G(S(`cheat.sandbox_simulation`,{type:r,sector:T(R.sectorIndex+1)}));return}if(t===`spawn`){let t=Object.keys(ke).find(e=>e.toLocaleLowerCase()===r?.toLocaleLowerCase()),i=Number(e[2]??1),a=Number.isInteger(i)?n.clamp(i,1,100):0;if(!t||!a){G(S(`cheat.sandbox_spawn_usage`,{enemies:Object.keys(ke).join(`, `)}));return}for(let e=0;e<a;e+=1)Ku(ou(v.obstacleMinDistance),t);G(S(`cheat.sandbox_spawned`,{count:a,enemy:t,plural:a===1?``:` enemies`}));return}G(S(`cheat.sandbox_usage`))}function vo(e){if(e.length<2){G(S(`cheat.artifact_usage`));return}let t=Number(e.at(-1)),n=e.slice(0,-1).join(`-`).replaceAll(`_`,`-`).toLowerCase(),r=It.artifacts.find(e=>e.id.toLowerCase()===n||e.name.replaceAll(` `,`-`).toLowerCase()===n);if(!r){G(S(`cheat.artifact_unknown`,{artifact:e.slice(0,-1).join(` `)}));return}if(!Number.isInteger(t)||t<=0||t>1e4){G(S(`cheat.artifact_stack_range`));return}if(r.repeatable){N.stackCounts[r.id]=Ga(r)+t,N.unlocked.includes(r.id)||(N.unlocked=[...N.unlocked,r.id]),Oo(),Ro(),G(S(`cheat.artifact_granted`,{count:t,artifact:r.name,stackWord:t===1?`stack`:`stacks`,total:Ga(r)}));return}N.unlocked.includes(r.id)||No(r),G(S(`cheat.artifact_unique`,{artifact:r.name}))}function yo(e){let[t,...n]=e.trim().toLowerCase().split(/\s+/),r=n[0];if(!t)return;if(t===Ue.commands.sandbox){_o(n);return}if(t===Ue.commands.gainArtifact){vo(n);return}if(t===Ue.commands.anomaly){let e=n.join(`-`);if(!e){G(S(`cheat.anomaly_usage`));return}if(!go(e)){G(S(`cheat.anomaly_unknown`,{id:e,available:Ke.challenges.map(e=>e.id).join(`, `)}));return}G(S(`cheat.anomaly_started`,{id:e,sector:T(F+1)})),$a(!1);return}if(t===Ue.commands.cell){let e=Number(n[0]);if(!Number.isInteger(e)||e<=0){G(S(`cheat.cell_usage`));return}if(!X||Gc){G(S(`cheat.cell_requires_round`));return}Q+=e,Ad(),ql(),_a()&&Q>=(ga()?.rewardCellTarget??1e3)&&kd(!0),G(S(`cheat.cell_granted`,{amount:e,total:Q}));return}if(t===Ue.commands.god){let e=n[0];if(![`on`,`off`].includes(e)){G(S(`cheat.god_usage`));return}ma=e===`on`,G(S(`cheat.god_state`,{state:S(ma?`cheat.on`:`cheat.off`)}));return}let i=Number(r);if(t===Ue.commands.cash||t===Ue.commands.chrono){if(!Number.isFinite(i)||i<=0){G(S(`cheat.amount_usage`,{command:t}));return}t===Ue.commands.cash?Co(i):wo(i),G(S(`cheat.amount_granted`,{amount:`${t===Ue.commands.cash?`$`:`✦ `}${i.toLocaleString()}`}));return}if(t===Ue.commands.freeResearch){Fa=!0,Xa(),G(S(`cheat.free_research`));return}if(t===Ue.commands.unlockSectors){let e=Mt.filter(e=>!P.claimed.includes(e.id)),t=P.debugAscensionsGranted?e:Mt;P.claimed=Mt.map(e=>e.id),P.researchUnlocks=[...new Set(Mt.flatMap(e=>e.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)))],P.debugAscensionsGranted=!0;let n=t.flatMap(e=>e.rewards).filter(e=>e.type===`cash`).reduce((e,t)=>e+t.amount,0),r=t.flatMap(e=>e.rewards).filter(e=>e.type===`chronoshards`).reduce((e,t)=>e+t.amount,0);n&&Co(n),r&&wo(r),aa(),Bo(),Xa(),Go(),G(S(`cheat.sectors_unlocked`,{rewards:n||r?` +$${E(n)} · +✦ ${E(r)}`:``}));return}if(t===Ue.commands.clearSave){if(!Ue.clearSaveTargets.includes(r)){G(S(`cheat.clear_usage`,{targets:Ue.clearSaveTargets.join(`, `)}));return}(r===`currency`||r===`all`)&&eo(),(r===`game_progress`||r===`all`)&&to(),(r===`milestones`||r===`all`)&&no(),(r===`research`||r===`all`)&&ro(),(r===`buildings`||r===`all`)&&mo(),(r===`weapons`||r===`all`)&&fu(),(r===`artifacts`||r===`all`)&&ko(),r===`all`&&ao(),G(S(`cheat.cleared`,{target:r.replace(`_`,` `)}));return}G(S(`cheat.unknown_command`,{command:t}))}function bo(){return we[$i[R?.sectorIndex??F]]}function xo(){let e=bo();if(e.maxActiveEnemies===void 0)return 1/0;let t=Math.max(0,Math.floor(e.maxActiveEnemies+Q*(e.maxActiveEnemiesIncrementPerCell??0)));return _a()?Math.max(1,Math.floor(t*(ga()?.difficultyMultiplier??1))):t}function So(e=0){ca+=e,_t(zi,ca),Bo()}function Co(e=0){da=Math.round((da+e)*100)/100,_t(Hi,da),Ti.textContent=`$${E(da)}`,Xa()}function wo(e=0){let t=e>0?e*(1+Wa(`chronoshardGainMultiplier`)):e;return I+=t,_t(Ui,I),Ei.textContent=`✦ ${E(I)}`,Xa(),t}function To(e,t){Eo(e,`+$${t}`,`cash-indicator`)}function Eo(e,t,n){let r=e.clone().project(js),i=document.createElement(`span`);i.className=n,i.textContent=t,i.style.left=`${(r.x*.5+.5)*window.innerWidth}px`,i.style.top=`${(-r.y*.5+.5)*window.innerHeight}px`,i.addEventListener(`animationend`,()=>i.remove()),Di.append(i)}function Do(){if(R)return;let e=$i[F];Q>(la[e]??0)&&(la[e]=Q,ra()),Mo(),aa(),Bo(),Xa(),Go()}function Oo(){yt(Qi,N)}function ko(){N={unlocked:[],resetAtScores:Object.fromEntries(It.artifacts.map(e=>[e.id,e.requirement.type===`sector-high-score`?la[$i[e.requirement.sector-1]]??0:0])),stackCounts:{}},Oo(),Ro()}function Ao(e){let{requirement:t}=e;return t.type===`sector-high-score`?S(`artifact.requirement_score`,{cells:t.cells,sector:T(t.sector)}):t.type===`milestone-claimed`?S(`artifact.requirement_milestone`,{sector:T(t.sector),cells:t.cells}):t.type===`anomaly-run-success`?S(`artifact.requirement_anomaly`,{cells:t.cells}):t.type===`hidden-world-map`?S(`artifact.requirement_hidden`):S(`artifact.requirement_default`)}function jo(e){let{requirement:t}=e;if(t.type===`sector-high-score`){let n=la[$i[t.sector-1]]??0;return n>=t.cells&&n>(N.resetAtScores[e.id]??-1)}return t.type===`milestone-claimed`&&P.claimed.includes(t.milestoneId)}function Mo(){return It.artifacts.filter(e=>jo(e)).reduce((e,t)=>No(t)||e,!1)}function No(e){return!e||N.unlocked.includes(e.id)?!1:(N.unlocked=[...N.unlocked,e.id],Oo(),Ro(),Lo(e),Rt(e.id),e.buff.stat===`arenaSizeMultiplier`&&Hs(),!0)}function Po(e){return e?.repeatable?(N.stackCounts[e.id]=Ga(e)+1,N.unlocked.includes(e.id)||(N.unlocked=[...N.unlocked,e.id]),Oo(),Ro(),Lo(e),Rt(e.id),!0):!1}async function Fo(){let e=await zt();for(let t of It.artifacts)e[Lt[t.id]]&&!N.unlocked.includes(t.id)&&No(t);for(let e of N.unlocked)Rt(e)}var Io;function Lo(e){Pn.textContent=S(`artifact.acquired_named`,{artifact:e.name.toUpperCase()}),Pn.classList.remove(`hidden`),window.clearTimeout(Io),Io=window.setTimeout(()=>Pn.classList.add(`hidden`),4e3)}function Ro(){Xn.innerHTML=It.artifacts.map(e=>{let t=N.unlocked.includes(e.id),n=Ga(e),r=t&&e.repeatable?`<b class="artifact-stack-count" aria-label="${S(`artifact.stacks`,{count:n})}">${n}</b>`:``,i=S(n===1?`artifact.stack`:`artifact.stacks_label`,{count:n});return`<button class="artifact-card ${t?`is-unlocked`:`is-locked`}" data-artifact-id="${e.id}" type="button"><span class="artifact-icon-wrap"><img src="${Ut(e.icon)}" alt="">${r}</span><span>${t?e.name:S(`artifact.unknown`)}</span><small>${t?e.repeatable?i:S(`weapon.unlocked`):S(`artifact.locked`)}</small></button>`}).join(``)}function zo(e){let t=It.artifacts.find(t=>t.id===e);if(!t)return;let n=N.unlocked.includes(t.id),r=Ga(t),i=t.repeatable&&n?S(`artifact.buff_per_stack`,{buff:t.buff.label,count:r,percent:Math.round(t.buff.amount*r*100)}):t.buff.label,a=S(r===1?`artifact.dark_core_stack`:`artifact.dark_core_stacks`,{count:r});Qn.innerHTML=`<img class="artifact-detail-icon ${n?``:`is-locked`}" src="${Ut(t.icon)}" alt=""><p class="eyebrow">${n?t.repeatable?a:S(`artifact.acquired`):S(`artifact.locked`)}</p><h2>${n?t.name:S(`artifact.unknown`)}</h2><div class="artifact-detail-section"><strong>${S(`artifact.to_acquire`)}</strong><p>${Ao(t)}</p></div><div class="artifact-detail-section"><strong>${S(`artifact.permanent_buff`)}</strong><p>${i}</p></div>`,Zn.classList.remove(`hidden`)}function Bo(){let e=oa();F>e&&(F=e),Ai.textContent=S(`hud.sector`,{sector:T(F+1)}),Oi.textContent=String(la[$i[F]]??0).padStart(3,`0`);let t=Mt.find(e=>e.sector===F+1&&!P.claimed.includes(e.id)),n=la[$i[F]]??0;ki.textContent=t?n>=t.cells?S(`milestone.ready`):S(`milestone.next`,{cells:t.cells}):S(`milestone.complete`),ji.disabled=F===0,Mi.disabled=F>=e;let r=Mt.filter(e=>!P.claimed.includes(e.id)&&(la[$i[e.sector-1]]??0)>=e.cells).length;jn.textContent=String(r),jn.hidden=r===0,fo(),wd()}function Vo(e){e<0||e>oa()||(F=e,_t(Bi,F),Hs(),Bo())}ji.addEventListener(`click`,()=>Vo(F-1)),Mi.addEventListener(`click`,()=>Vo(F+1)),En.addEventListener(`click`,()=>{ua=F,Kd(Dn,Go)}),On.addEventListener(`click`,()=>{Dn.classList.add(`hidden`),M.classList.remove(`hidden`)}),Fn.addEventListener(`click`,()=>{ua=Math.max(0,ua-1),Go()}),In.addEventListener(`click`,()=>{ua=Math.min(oa(),ua+1),Go()}),An.addEventListener(`click`,e=>{let t=e.target.closest(`[data-claim-milestone]`);t&&Wo(t.dataset.claimMilestone)});function Ho(e){return e.type===`cash`?S(`milestone.reward_cash`,{amount:e.amount.toLocaleString()}):e.type===`chronoshards`?S(`milestone.reward_chronoshards`,{amount:e.amount}):e.type===`sector`?S(`milestone.unlock_sector`,{sector:T(e.sector)}):e.type===`feature`?S(`milestone.unlock_feature`,{feature:e.featureId===`researchLab`?S(`menu.research_lab`):e.featureId}):e.type===`research`?S(`milestone.unlock_research`,{researches:e.researchIds.map(e=>La(e)?.name??e).join(`, `)}):S(`milestone.reward`,{},`Reward`)}var Uo;function Wo(e){let t=Mt.find(t=>t.id===e),n=t?la[$i[t.sector-1]]??0:0;if(!(!t||P.claimed.includes(t.id)||n<t.cells)){P.claimed.push(t.id),P.researchUnlocks=[...new Set([...P.researchUnlocks,...t.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)])];for(let e of t.rewards)e.type===`cash`&&Co(e.amount),e.type===`chronoshards`&&wo(e.amount),e.type===`feature`&&e.featureId in va&&(va[e.featureId]=!0);io(),Mo(),aa(),Mn.textContent=S(`milestone.reward_claimed`,{rewards:t.rewards.map(Ho).join(` · `)}),Mn.classList.remove(`hidden`),clearTimeout(Uo),Uo=setTimeout(()=>Mn.classList.add(`hidden`),3600),Bo(),Xa(),Go()}}function Go(){let e=ua+1,t=la[$i[ua]]??0;kn.textContent=String(t).padStart(3,`0`),Ln.textContent=S(`hud.sector`,{sector:T(e)}),Fn.disabled=ua===0,In.disabled=ua>=oa(),An.innerHTML=Mt.filter(t=>t.sector===e).map(n=>{let r=P.claimed.includes(n.id),i=t>=n.cells,a=Math.min(100,t/n.cells*100);return`<article class="milestone-card ${r?`claimed`:i?`reached`:``}"><div class="milestone-node">${r?`✓`:n.cells}</div><div><strong>${r?S(`milestone.secured`):S(`milestone.cells`,{cells:n.cells})}</strong><p>${n.rewards.map(Ho).join(` · `)}</p><div class="milestone-progress"><i style="width:${a}%"></i></div><small>${r?S(`milestone.auto_claimed`):S(`milestone.best`,{best:t,target:n.cells,sector:T(e)})}</small></div></article>`}).join(``);let n=Mt.filter(t=>t.sector===e);for(let[e,r]of n.entries()){let n=P.claimed.includes(r.id),i=t>=r.cells,a=An.children[e];if(a&&(n&&(a.querySelector(`small`).textContent=S(`milestone.claimed`)),i&&!n)){let e=document.createElement(`button`);e.className=`claim-milestone-button`,e.dataset.claimMilestone=r.id,e.type=`button`,e.textContent=S(`milestone.claim`),a.lastElementChild.append(e)}}}var Ko=bt({THREE:g,SOUND:Oe,getSettings:()=>V,getPlayer:()=>q,getCamera:()=>js}),qo=new ce({canvas:$t,antialias:V.graphics.quality!==`low`}),Jo,Yo,Xo=null,Zo=null,Qo=null,$o={low:{pixelRatioCap:1,textureFilter:r},medium:{pixelRatioCap:1.5,textureFilter:ee},high:{pixelRatioCap:v.maxPixelRatio,textureFilter:ee}};function es(){return $o[V.graphics.quality]??$o.high}function ts(){let e=es(),t=V.graphics.quality!==`low`;Jo&&qo.getContext().getContextAttributes().antialias!==t&&Ms(t);let r=n.clamp(V.graphics.hdrEmissionIntensity??.5,0,1)*.5;qo.setPixelRatio(Math.min(window.devicePixelRatio,e.pixelRatioCap)),Jo?.setPixelRatio(qo.getPixelRatio());let i=V.graphics.shadows&&V.graphics.quality!==`low`;Xo&&(Xo.castShadow=i),qo.shadowMap.enabled=i,qo.shadowMap.needsUpdate=i,Zo&&(Zo.magFilter=e.textureFilter,Zo.minFilter=e.textureFilter,Zo.needsUpdate=!0),Qo?.(V.graphics.quality),qo.toneMapping=r>0?4:0,qo.toneMappingExposure=.9+r*.2,Yo&&(Yo.enabled=r>0,Yo.strength=1.35*r)}function ns(){yt(Xi,z)}function rs(){return 1+U(`weapon-slots`)+Wa(`weaponSlotCount`)}function is(e){return z.cards[e]}var as=480,os=30,ss=180;function cs(){return U(`weapon-recharge`)>0}function ls(){return cs()?1+U(`weapon-charge-capacity`):1}function us(){return Math.max(ss,as-U(`weapon-recharge-rate`)*os)}function ds(e){return hl.get(e)??1}function fs(){hl.clear(),gl.clear();for(let e of z.loadout.filter(e=>is(e)))hl.set(e,1),gl.set(e,0)}function ps(e){if(!cs())return;let t=ls(),n=us(),r=!1;for(let i of z.loadout.filter(e=>is(e))){let a=ds(i);if(a>=t){gl.set(i,0);continue}let o=(gl.get(i)??0)+e,s=a;for(;o>=n&&s<t;)o-=n,s+=1,r=!0;hl.set(i,s),gl.set(i,s>=t?0:o)}r&&ys()}function ms(e){if(z.loadout.includes(e))return S(`weapon.remove_loadout`);if(z.loadout.length<rs())return S(`weapon.add_loadout`);let t=z.loadout[z.selected],n=Pt.weapons[t];return n?S(`weapon.replace_with`,{weapon:n.name.toUpperCase()}):S(`weapon.replace_selected`)}function hs(e){return Pt.levelCopyRequirements[e-1]??1/0}function gs(e){let t=is(e),n=Pt.weapons[e];return t&&n?n.baseEffect+n.effectPerLevel*(t.level-1):0}function _s(e){return{megaMagnet:sl,atmosphereShield:cl,chronoFreeze:ll,plasmaOrbital:ul,cellOverdrive:dl,demonMode:fl}[e]??0}function vs(){for(let e of gr.querySelectorAll(`[data-weapon-duration]`)){let t=e.dataset.weaponDuration,r=gs(t);e.style.setProperty(`--weapon-progress`,String(r>0?n.clamp(_s(t)/r,0,1):0))}}function ys(){let e=z.loadout.filter(e=>is(e));gr.classList.toggle(`hidden`,!X||!e.length),gr.innerHTML=e.map((e,t)=>{let n=ds(e),r=ls(),i=String(n);return`<button class="${t===z.selected?`selected`:``} ${n===0?`spent`:``} ${n>=r?`is-charge-full`:``}" data-use-weapon="${e}" type="button" ${n===0?`disabled`:``}><span class="weapon-hud-icon ${Pt.weapons[e].duration?`has-duration`:``}" data-weapon-duration="${Pt.weapons[e].duration?e:``}"><img class="weapon-hud-art" src="${Gt(e)}" alt=""></span><b>${t+1}</b><span class="weapon-hud-name">${Pt.weapons[e].name}</span><i>${i}</i></button>`}).join(``),vs()}function bs(){nr.textContent=`✦ ${E(I)}`,rr.textContent=S(`weapon.buy_with_cost`,{cost:E(Pt.purchaseCost)}),ir.textContent=S(`weapon.buy_five_with_cost`,{cost:E(Pt.purchaseCost*5)}),rr.disabled=I<Pt.purchaseCost,ir.disabled=I<Pt.purchaseCost*5;let e=Cs();ar.hidden=e<=0,ar.textContent=S(`weapon.lucky_find_cards`,{chance:Math.round(e*100)});let t=rs();pr.textContent=String(z.loadout.length),pr.classList.toggle(`is-full`,z.loadout.length>=t),mr.innerHTML=Array.from({length:rs()},(e,t)=>{let n=z.loadout[t];return`<button data-select-weapon-slot="${t}" type="button" class="${t===z.selected?`selected`:``}">${n?Pt.weapons[n].name:S(`weapon.empty_slot`)}</button>`}).join(``),hr.innerHTML=Object.entries(Pt.weapons).map(([e,t])=>{let n=is(e),r=`<img class="asset-card-art" src="${Gt(e)}" alt="">`;if(!n)return`<article class="weapon-card locked">${r}<strong>${t.name}</strong><small>${S(`weapon.not_collected`)}</small></article>`;let i=hs(n.level);return`<article class="weapon-card ${z.loadout.includes(e)?`selected`:``}">${r}<strong>${t.name} · ${S(`weapon.level`,{level:n.level})}</strong><small>${t.description}</small><em>${n.level>=5?S(`weapon.max_level`):S(`weapon.copy_progress_short`,{copies:n.copies,required:i,level:n.level+1})}</em><button data-toggle-weapon="${e}" type="button">${ms(e)}</button></article>`}).join(``),ys()}function xs(){let e=ya[ba];e&&(or.dataset.revealType=e.type,sr.textContent=S(`weapon.number`,{current:ba+1,total:ya.length}),cr.textContent=e.status,lr.src=Gt(e.id),lr.alt=e.name,ur.textContent=e.name,dr.textContent=e.detail,fr.textContent=ba===ya.length-1?S(`weapon.claim`):S(`weapon.next`),or.classList.remove(`hidden`),or.classList.remove(`is-revealing`),or.offsetWidth,or.classList.add(`is-revealing`))}function Ss(e){let t=Pt.weapons[e],n=is(e);if(!n)return n={level:1,copies:0},z.cards[e]=n,{id:e,name:t.name,type:`unlock`,status:S(`weapon.unlocked`),detail:S(`weapon.unlocked_level`)};n.copies+=1;let r=hs(n.level);return n.copies>=r&&n.level<5?(n.copies-=r,n.level+=1,{id:e,name:t.name,type:`level-up`,status:S(`weapon.level_up`,{level:n.level}),detail:S(`weapon.upgraded_level`,{level:n.level})}):n.level>=5?{id:e,name:t.name,type:`max-copy`,status:S(`weapon.max_level_copy`),detail:S(`weapon.max_level_detail`)}:{id:e,name:t.name,type:`copy`,status:S(`weapon.copy`,{level:n.level}),detail:S(`weapon.copy_progress`,{copies:n.copies,required:r,level:n.level+1})}}function Cs(){return n.clamp(W(`luckyFindChance`),0,1)}function ws(e){let t=Pt.purchaseCost*e;if(I<t)return;wo(-t);let n=[],r=Object.keys(Pt.weapons);for(let t=0;t<e;t+=1){let e=r[Math.floor(Math.random()*r.length)],t=Math.random()<Cs(),i=Ss(e);if(!t){n.push(i);continue}let a=Ss(e);n.push({...a,type:`lucky-find`,status:S(`weapon.lucky_find_double`),detail:i.type===`unlock`?S(`weapon.lucky_find_unlock`):S(`weapon.lucky_find_received`,{detail:a.detail})})}ya=n,ba=0,ns(),bs(),xs()}function Ts(){if(ba<ya.length-1){ba+=1,xs();return}ya=[],ba=0,delete or.dataset.revealType,or.classList.remove(`is-revealing`),or.classList.add(`hidden`),bs()}function Es(e){if(X||!is(e))return;let t=z.loadout.indexOf(e);t>=0?z.loadout.splice(t,1):z.loadout.length<rs()?(z.loadout.push(e),z.selected=z.loadout.length-1):z.loadout[z.selected]=e,z.selected=Math.min(z.selected,Math.max(z.loadout.length-1,0)),ns(),bs()}function Ds(e=z.loadout[z.selected]){let t=is(e);if(!X||Z||!t||!z.loadout.includes(e))return;let n=ds(e);if(n<=0)return;Pt.weapons[e];let r=gs(e);if(e===`nuke`){let e=[...Y].sort(()=>Math.random()-.5).slice(0,Math.ceil(Y.length*Math.min(r,.9)));Ld(q.position,e)}if(e===`megaMagnet`&&(sl=r),e===`atmosphereShield`){cl=r;for(let e of Dc)K.remove(e.obstacle,e.shadow,e.targetRing);Dc.length=0}e===`phaseDash`&&Os(r),e===`chronoFreeze`&&(ll=r),e===`plasmaOrbital`&&(ul=r),e===`cellOverdrive`&&(dl=r),e===`demonMode`&&(fl=r),hl.set(e,n-1),gl.has(e)||gl.set(e,0),ys(),Ko.playBuildingEffect(q.position,`overclockRelay`)}function Os(e){let t=new h(mc.x,0,mc.y);t.lengthSq()===0?t.set(Math.sin(q.rotation.y),0,Math.cos(q.rotation.y)):t.normalize();let n=q.position.clone(),r=Vs(n.clone().addScaledVector(t,e),v.playerRadius);for(let e of[...Y])ld(e.position,n,r)>e.userData.colliderRadius+.8||(dd(e.position,.5),Nu(e));let i=new Se(new re().setFromPoints([n.clone().setY(.25),r.clone().setY(.25)]),new ne({color:`#78eaff`,transparent:!0,opacity:.95,depthWrite:!1}));K.add(i),pl.push({trail:i,age:0}),q.position.copy(r),Ws=Math.atan2(t.x,t.z)}qo.setSize(window.innerWidth,window.innerHeight),qo.outputColorSpace=l;var K=new u;K.background=new ie(y.background);function ks(){let t=new oe,n=new i({color:`#29375c`,emissive:`#101936`,emissiveIntensity:.45,metalness:.78,roughness:.28}),r=new i({color:`#ffcf76`,emissive:`#ff9f43`,emissiveIntensity:1,metalness:.52,roughness:.2}),a=new _(new he(1.15,1.4,.65,10),n);a.position.y=.33;let o=new _(new he(.56,.82,5.8,10),n);o.position.y=3.45;let s=new _(new he(.88,.58,1.05,10),r);s.position.y=6.55;let c=new e(`#ffcf76`,.8,6,2);return c.position.y=7.15,t.add(a,o,s,c),t.traverse(e=>{e.isMesh&&(e.castShadow=!0,e.receiveShadow=!0)}),t.visible=!1,t}var As=ks();K.add(As);var js=new ue(Te.fov,window.innerWidth/window.innerHeight,Te.near,Te.far);js.position.set(0,Te.distance*Math.tan(n.degToRad(Te.angle)),Te.distance),js.lookAt(0,0,0),Jo=new ge(qo),Jo.addPass(new pe(K,js)),Yo=new ve(new t(window.innerWidth,window.innerHeight),.675,.48,1.1),Jo.addPass(Yo),Jo.setSize(window.innerWidth,window.innerHeight);function Ms(e){qo.dispose(),qo=new ce({canvas:$t,antialias:e}),qo.setSize(window.innerWidth,window.innerHeight),qo.outputColorSpace=l,Jo=new ge(qo),Jo.addPass(new pe(K,js)),Yo=new ve(new t(window.innerWidth,window.innerHeight),.675,.48,1.1),Jo.addPass(Yo),Jo.setSize(window.innerWidth,window.innerHeight)}var{starfield:Ns,floor:Ps,grid:Fs,arenaBoundary:Is,keyLight:Ls,setQuality:Rs,resize:zs}=ct({THREE:g,scene:K,COLORS:y,GAME:v,SCENE:Ee,LIGHTING:De,quality:V.graphics.quality});Xo=Ls,Qo=Rs,ts();function Bs(){return(v.arenaLimit+bo().extraArenaPadding)*(1+Wa(`arenaSizeMultiplier`))}function Vs(e,t=0){let n=Math.max(0,Bs()-t),r=Math.hypot(e.x,e.z);if(r>n){let t=n/r;e.x*=t,e.z*=t}return e}function Hs(){zs(bo().extraArenaPadding,1+Wa(`arenaSizeMultiplier`))}var Us=new ie(y.slowAura),Ws=0,Gs=et({THREE:g,COLORS:y,ENTITIES:b,GAME:v}),{player:q,playerCore:Ks,slowAuraRing:qs,shieldBubble:Js}=Gs;K.add(q);var J={...et({THREE:g,COLORS:{...y,player:`#ff4d4d`,playerEmissive:`#9d1010`,playerWing:`#ff6767`,playerWingEmissive:`#9d1010`,playerRing:`#ffaaa0`,slowAura:`#ff4d4d`},ENTITIES:b,GAME:v,opacity:.72}),active:!1};J.player.visible=!1;var Ys=new oe,Xs=new _(new Ce(1.3,.055,10,48),new m({color:`#b59aff`,transparent:!0,opacity:.9,depthWrite:!1}));Xs.rotation.x=Math.PI/2;var Zs=new _(new le(.95,1.28,48),new m({color:`#d5c9ff`,transparent:!0,opacity:.18,side:2,depthWrite:!1}));Zs.rotation.x=-Math.PI/2;var Qs=new _(new f(1.42,32,16,0,Math.PI*2,0,Math.PI/2),new m({color:`#a998ff`,transparent:!0,opacity:.15,wireframe:!0,depthWrite:!1}));Ys.position.y=.92,Ys.add(Xs,Zs,Qs),Ys.visible=!1,q.add(Ys);var $s=Array.from({length:3},()=>{let e=new _(new f(.2,14,10),new i({color:`#ffb5ff`,emissive:`#ff45e9`,emissiveIntensity:3,metalness:.2,roughness:.15}));return e.visible=!1,q.add(e),e}),ec=new _(new Ce(1.25,.07,8,40),new m({color:`#ff465d`,transparent:!0,opacity:.8,depthWrite:!1}));ec.rotation.x=Math.PI/2,ec.position.y=.1,ec.visible=!1,q.add(ec);var tc=new oe;for(let e=0;e<12;e+=1){let t=e*Math.PI*2/12,n=new _(new ae(.12,1.05+e%3*.16,5),new m({color:`#ff465d`,transparent:!0,opacity:.46,depthWrite:!1})),r=new h(Math.cos(t),.1+e%2*.12,Math.sin(t));n.position.copy(r.clone().multiplyScalar(.95)),n.quaternion.setFromUnitVectors(new h(0,1,0),r.normalize()),tc.add(n)}tc.visible=!1,q.add(tc);var nc=document.createElement(`canvas`);nc.width=128,nc.height=128;var rc=nc.getContext(`2d`);rc.font=`900 108px Arial`,rc.textAlign=`center`,rc.textBaseline=`middle`,rc.lineWidth=8,rc.strokeStyle=`#6b4710`,rc.strokeText(`$`,64,65),rc.fillStyle=`#ffd36f`,rc.fillText(`$`,64,65),Zo=new de(nc),Zo.magFilter=es().textureFilter,Zo.minFilter=es().textureFilter,Zo.needsUpdate=!0;var ic=new a(new s({map:Zo,transparent:!0,depthWrite:!1}));ic.position.set(0,2.2,0),ic.scale.set(.7,.7,1),ic.visible=!1,q.add(ic);var ac=new Map;for(let[e,[t,n]]of Object.entries(Pt.weapons).filter(([,e])=>e.duration).entries()){let r=new _(new le(1.42+e*.11,1.49+e*.11,96),new m({color:n.color,transparent:!0,opacity:.9,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.userData.height=.2+e*.025,r.position.y=r.userData.height,r.visible=!1,r.geometry.setDrawRange(0,0),K.add(r),ac.set(t,r)}var oc=new _(new f(.19,16,12),new i({color:`#d9ffff`,emissive:`#42eaff`,emissiveIntensity:3.2,metalness:.2,roughness:.12})),sc=new _(new f(.33,14,10),new m({color:`#4eeeff`,transparent:!0,opacity:.24,depthWrite:!1}));oc.add(sc);var cc=new re;cc.setAttribute(`position`,new _e(new Float32Array(27),3).setUsage(se));var lc=new Se(cc,new ne({color:`#a9ffff`,transparent:!0,opacity:.8,depthWrite:!1}));lc.frustumCulled=!1,oc.visible=!1,lc.visible=!1,K.add(oc,lc);var uc=0,dc=new h,fc=new h,pc=new Set,mc=new t,hc=null,gc=null,_c=58,vc=12,yc=36,bc=new t,xc=28,Sc=new Map,Cc=null,wc=!1,Tc=[],Ec=[],Y=[],Dc=[],Oc=[],kc=[],Ac=[],jc=[],Mc=[],Nc=[],Pc=[],Fc=[],Ic=[],Lc=[],Rc=[],zc=[],Bc=[],Vc=[],Hc=[],Uc=[],Wc=new p,X=!1,Z=!1,Gc=!1,Q=0,Kc=0,qc=0,Jc=0,Yc=0,Xc=0,Zc=0,Qc=null,$c=0,el=0,tl=.5,nl=0,rl=0,il=0,al=0,ol=0,sl=0,cl=0,ll=0,ul=0,dl=0,fl=0,pl=[],ml=new Map,hl=new Map,gl=new Map,_l=new be(b.obstacleRadius,b.fallingRockDetail),{createShooterProjectile:vl,createAutocannonProjectile:yl,createSplinter:bl}=lt({THREE:g,COLORS:y,ENTITIES:b}),{createCell:xl,createChronoCell:Sl,createBooster:Cl}=it({THREE:g,COLORS:y,ENTITIES:b}),wl=rt({THREE:g,ENTITIES:b}),{createExplosion:Tl,createBangerPulse:El,createShockwave:Dl,createShieldBreak:Ol,createPoisonTrail:kl,createPlayerDeath:Al}=ut({THREE:g,COLORS:y,getQuality:()=>V.graphics.quality}),jl=new ie(y.creeper),Ml=new ie(y.poisonCreeper),Nl=new ie(y.creeperEmissive),Pl=new ie(y.poisonCreeperEmissive);function Fl(e,t){let n=new ce({canvas:t,alpha:!0,antialias:!0});n.setPixelRatio(Math.min(window.devicePixelRatio,2)),n.setSize(210,150,!1);let r=new u,a=new ue(32,210/150,.1,20);a.position.set(0,1.3,4.8),a.lookAt(0,0,0),r.add(new te(`#d9f9ff`,`#07141d`,2.6));let o=new fe(`#fff4cf`,2.8);o.position.set(2,3,4),r.add(o);let s=e.model===`spiked-enemy`?ke[e.id]:Ae[e.id],c=new i({color:s.color,emissive:s.emissive,emissiveIntensity:s.emissiveIntensity??1.35,metalness:b.obstacleMetalness,roughness:b.obstacleRoughness}),l=e.model===`spiked-enemy`?wl(c,e.id):new _(_l,c);l.rotation.set(.28,-.55,.14),r.add(l),n.render(r,a),c.dispose(),n.dispose()}var Il=null,Ll=!1;function Rl(){if(Je.endpoint)return Je.endpoint;if(qe.endpoint)try{return new URL(`/time`,qe.endpoint).toString()}catch{}return Je.publicEndpoint}async function zl(){let e=Rl();if(!e)throw Error(S(`error.server_time_unconfigured`));let t=new AbortController,n=window.setTimeout(()=>t.abort(),8e3),r=performance.now();try{let n=await fetch(e,{cache:`no-store`,signal:t.signal});if(!n.ok)throw Error(S(`error.server_time_request`,{status:n.status}));let i=await n.json(),a=Date.parse(i?.now??i?.utc_iso);if(!Number.isFinite(a))throw Error(S(`error.server_time_invalid`));return new Date(a+(performance.now()-r)/2)}finally{window.clearTimeout(n)}}function Bl(e=Il??new Date){let t=new Date(`${Ke.weeklyAnchorDate}T00:00:00Z`),n=Date.UTC(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate());return Math.max(0,Math.floor((n-t.getTime())/6048e5))}function Vl(e=Il??new Date){return String(Bl(e))}function Hl(e=Il??new Date){let t=new Date(`${Ke.weeklyAnchorDate}T00:00:00Z`);return t.setUTCDate(t.getUTCDate()+(Bl(e)+1)*7),t}function Ul(e){return`${String(e.getUTCDate()).padStart(2,`0`)}.${String(e.getUTCMonth()+1).padStart(2,`0`)}.${e.getUTCFullYear()}`}function Wl(e=Vl()){return Ke.challenges[Number(e)%Ke.challenges.length]}function Gl(e){return Ke.rewardBaseChronoshards+e*Ke.rewardChronoshardStepPerSector}function Kl(e=Vl(),t=F){return(fa.claimedSectors[e]??[]).includes(String(t))}function ql(){let e=ga(),t=e?.rewardCellTarget??Ke.rewardCellTarget;if(!pa||!e||Q<t)return;let n=String(F),r=`${e.id}:sector${F+1}`;if(!fa.darkCoreClaims.includes(r)){fa.darkCoreClaims.push(r);let e=It.artifacts.find(e=>e.requirement.type===`anomaly-run-success`);e&&(Po(e),Eo(q.position,S(`anomaly.dark_core_stack`,{artifact:e.name.toUpperCase()}),`chronoshard-indicator`))}let i=fa.claimedSectors[pa.weekId]??[];if(!i.includes(n)){fa.claimedSectors[pa.weekId]=[...i,n];let e=wo(Gl(F));Eo(q.position,S(`message.anomaly_reward`,{amount:E(e)}),`chronoshard-indicator`)}yt(Zi,fa),wd()}function Jl(e){!_a()||!X||Gc||(ga(),ha=Math.max(0,ha-e),Ad(),ha===0&&kd(!1))}function Yl(){if(!_a()||!X||Gc)return;Q+=1,ql();let e=ga()?.rewardCellTarget??1e3;Q>=e&&kd(!0)}function Xl(){let e=oa()+1,t=e=>[...e].map(e=>e===` `?` `:`?`).join(``);Kn.innerHTML=Ct.map(n=>{let r=n.firstSector<=e,i=r?`<canvas data-encyclopedia-model="${n.id}" width="210" height="150" aria-label="${n.name} model"></canvas>`:`<div class="encyclopedia-unknown-icon" role="img" aria-label="${S(`encyclopedia.unknown_enemy`)}">?</div>`;return`<article class="encyclopedia-entry ${r?``:`locked`}"><h3>${n.name}</h3>${i}<p>${r?n.description:t(n.description)}</p></article>`}).join(``);for(let e of Kn.querySelectorAll(`[data-encyclopedia-model]`)){let t=Ct.find(t=>t.id===e.dataset.encyclopediaModel);t&&Fl(t,e)}}var Zl=new u,Ql=new ue(34,1,.1,20);Ql.position.set(0,.1,3.25);var $l=new ce({canvas:pn,alpha:!0,antialias:!0});$l.setPixelRatio(Math.min(window.devicePixelRatio,2)),$l.setSize(76,60,!1),Zl.add(new te(`#d9f9ff`,`#07141d`,2.5));var eu=new fe(`#fff4cf`,3);eu.position.set(2,3,4),Zl.add(eu);var tu=null;function nu(e){let t=e.toLowerCase();return Object.keys(ke).find(e=>t.includes(e))??null}function ru(){tu&&=(Zl.remove(tu),tu.userData.material?.dispose(),null),fn.hidden=!0,M.classList.remove(`is-death-screen`)}function iu(e){let t=nu(e);if(!t)return ru(),!1;ru();let n=ke[t];return tu=wl(new i({color:n.color,emissive:n.emissive,emissiveIntensity:1.35,metalness:b.obstacleMetalness,roughness:b.obstacleRoughness}),t),tu.rotation.set(.25,0,-.16),Zl.add(tu),pn.setAttribute(`aria-label`,S(`accessibility.enemy_model`,{enemy:t})),fn.hidden=!1,M.classList.add(`is-death-screen`),!0}function au(e){!tu||fn.hidden||(tu.rotation.y+=e*1.8,tu.rotation.x+=e*.24,$l.render(Zl,Ql))}function ou(e=0){let t=Bs(),n;do{let e=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*t;n=new h(Math.cos(e)*r,0,Math.sin(e)*r)}while(n.distanceTo(q.position)<e);return n}function su(){yt(Ki,B)}function cu(e,t=Math.ceil){return t(e*Math.max(0,1-Wa(`buildingCostReduction`)))}function lu(){return cu(60+B.unlockCount*30)}function uu(){let e=Object.keys($e.types).filter(e=>!B.unlocked.includes(e)),t=B.unlockOffers.filter(t=>e.includes(t));return t.length?t:(B.unlockOffers=[...e].sort(()=>Math.random()-.5).slice(0,3),su(),B.unlockOffers)}function du(e){let t=uu(),n=lu();!t.includes(e)||I<n||(wo(-n),B.unlocked.push(e),B.unlockCount+=1,B.unlockOffers=[],su(),Eu())}function fu(){z={cards:{},loadout:[],selected:0},ya=[],ba=0,or.classList.add(`hidden`),ns(),bs()}function pu(){let e=uu(),t=lu(),n=I>=t;Xr.textContent=`✦ ${E(I)}`,Zr.innerHTML=e.length?`<p class="building-draft-copy">${S(`building.choose_offer`,{count:e.length,cost:E(t)})}</p>${e.map(e=>{let r=$e.types[e];return`<article class="building-card building-offer"><img class="asset-card-art" src="${Wt(e)}" alt=""><strong>${r.name}</strong><small>${S(`building.permanent_unlock`)}</small><button data-building-offer="${e}" ${n?``:`disabled`}>${S(`building.unlock_cost`,{cost:E(t)})}</button></article>`}).join(``)}`:`<p class="building-draft-copy">${S(`building.all_unlocked`)}</p>`}function mu(){return 3+U(`building-slots`)}function hu(e){return 1+B.placed.filter(t=>t.type===e).reduce((e,t)=>e+Object.values(t.upgrades).reduce((e,t)=>e+t,0),0)}function gu(e,t){let n=$e.types[e.type].upgrades[t],r=e.upgrades[t]??0;return cu(n.base*1.65**r)}function _u(e){return Math.round((e.spent??$e.types[e.type].baseCost)*100)/100}function vu(e){let t=$e.types[e.type],{group:n,effectRing:r,barrierField:i}=tt({THREE:g,building:e,config:t,range:Mu(e,`range`)});n.userData.buildingId=e.id,K.add(n),Ta.set(e.id,n),Ea.set(e.id,{timer:0,active:0,effectRing:r,barrierField:i})}function yu(){for(let e of Ta.values())K.remove(e);Ta.clear(),Ea.clear();for(let e of B.placed)vu(e)}function bu(e){let t=$e.types[e];return cu(t.baseCost*t.costMultiplier**B.placed.filter(t=>t.type===e).length)}function xu(){let e=[];for(let t=-10;t<=10;t+=2)for(let n=-10;n<=10;n+=2)Math.hypot(t,n)<=$e.placementRadius&&Math.hypot(t,n)>=$e.spawnClearance&&e.push({x:t,z:n});return e}function Su(){if(!Da){ti.replaceChildren(),ti.classList.add(`hidden`);return}let e=Oa?bu(Oa):0,t=B.placed.length>=mu();ti.innerHTML=xu().map(({x:n,z:r})=>{let i=B.placed.find(e=>e.x===n&&e.z===r),a=i?`<span class="build-name" data-build-x="${n}" data-build-z="${r}">${$e.types[i.type].name}</span>`:``;return`<button class="build-site ${i?`occupied`:``}" data-build-x="${n}" data-build-z="${r}" type="button" ${!i&&!t||i?``:`disabled`}>${i?S(`building.upgrade`):t?S(`building.slot_limit`):`$${e}`}</button>${a}`}).join(``),ti.classList.remove(`hidden`),requestAnimationFrame(Cu)}function Cu(){if(Da)for(let e of ti.querySelectorAll(`[data-build-x]`)){let t=e.classList.contains(`build-name`),n=new h(Number(e.dataset.buildX),t?1.25:.08,Number(e.dataset.buildZ)).project(js);e.style.left=`${(n.x*.5+.5)*window.innerWidth}px`;let r=e.classList.contains(`occupied`)?38:0;e.style.top=`${(-n.y*.5+.5)*window.innerHeight+r}px`}}function wu(e){q.visible=!e&&!Gc,oc.visible=!e&&U(`unlock-orbital-electron`)>0&&!Gc,lc.visible=!e&&U(`unlock-orbital-electron`)>0&&!Gc;for(let t of Tc)t.visible=!e;for(let t of Ec)t.visible=!e;for(let t of Lc)t.visible=!e;for(let t of Y)t.visible=!e,t.userData.rangeIndicator&&(t.userData.rangeIndicator.visible=!e),t.userData.magnetPulse&&(t.userData.magnetPulse.visible=!e);for(let t of Ic)t.spore.visible=!e;for(let t of Pc)t.projectile.visible=!e;for(let t of Vc)t.mesh.visible=!e;for(let t of Dc)t.obstacle.visible=!e,t.shadow.visible=!e,t.targetRing.visible=!e;for(let t of Uc)t.ring.visible=!e,t.glow.visible=!e,t.beam.visible=!e;for(let t of jc)t.shockwave.visible=!e,t.blast.visible=!e,t.light.visible=!e;for(let t of Hc){t.flash.visible=!e,t.blast.visible=!e,t.shockwave.visible=!e,t.innerShockwave.visible=!e,t.light.visible=!e;for(let n of t.fragments)n.visible=!e}for(let t of Oc)t.visual.visible=!e,t.light.visible=!e;for(let t of kc)t.visual.visible=!e;for(let t of Ac)t.piece.visible=!e;for(let t of Nc)t.pulse.visible=!e;for(let t of Rc)t.shockwave.visible=!e;for(let t of Bc)t.ring.visible=!e,t.glow.visible=!e;for(let t of ac.values())e&&(t.visible=!1)}function Tu(e,t){let n=B.placed.find(n=>n.x===e&&n.z===t);if(n){ku(n);return}let r=bu(Oa);if(B.placed.length>=mu()||da<r)return;Co(-r);let i={id:crypto.randomUUID(),type:Oa,x:e,z:t,upgrades:{},spent:r};B.placed.push(i),su(),vu(i),Eu()}function Eu(){Kr.disabled=X,Ur.textContent=`$${E(da)}`,Wr.textContent=`✦ ${E(I)}`,Gr.textContent=`${B.placed.length}/${mu()}`,Hr.innerHTML=B.unlocked.length?B.unlocked.map(e=>`<article class="building-card"><img class="asset-card-art" src="${Wt(e)}" alt=""><strong>${$e.types[e].name}</strong><small>${S(`building.build_cost`,{cost:E(bu(e))})}</small><span class="building-unlocked-state">${S(`building.unlocked`)}</span></article>`).join(``):`<p class="building-draft-copy">${S(`building.none_unlocked`)}</p>`,pu(),ei.innerHTML=B.unlocked.map(e=>`<button data-select-building="${e}" class="${Oa===e?`selected`:``}" type="button" aria-label="${$e.types[e].name} · ${S(`building.level`,{level:hu(e)})}"><img src="${Wt(e)}" alt=""><small>${S(`building.level`,{level:hu(e)})}</small></button>`).join(``),$r.textContent=qd()?`${B.placed.length}/${mu()}`:S(`building.build_mode_slots`,{used:B.placed.length,total:mu()}),Su()}function Du(){X||!B.unlocked.length||(bc.set(0,0),xc=28,Da=!0,Oa=B.unlocked[0],wu(!0),cn.classList.add(`hidden`),Qr.classList.remove(`hidden`),Eu())}function Ou(){Da=!1,Sc.clear(),Cc=null,Oa=null,wu(!1),ti.classList.add(`hidden`),Qr.classList.add(`hidden`),cn.classList.remove(`hidden`),ri.classList.add(`hidden`)}function ku(e){let t=$e.types[e.type];ri.innerHTML=`<button class="upgrade-close" data-close-building-upgrade="1" type="button" aria-label="${S(`building.upgrade`)}">×</button><p class="eyebrow">${S(`building.installed_defense`)}</p><h3>${t.name}</h3><p class="building-upgrade-summary">${S(`building.choose_upgrade`)}</p><div class="upgrade-grid">${Object.entries(t.upgrades).map(([t,n])=>{let r=e.upgrades[t]??0,i=gu(e,t);return`<button data-upgrade-building="${e.id}" data-upgrade-key="${t}" type="button"><span>${n.name}</span><strong>${S(`building.upgrade_level`,{current:r,next:r+1})}</strong><small>$${E(i)}</small></button>`}).join(``)}</div><button data-destroy-building="${e.id}" class="demolish-button" type="button">${S(`building.demolish_refund`,{amount:E(_u(e))})}</button>`,ri.classList.remove(`hidden`)}function Au(e,t){let n=$e.types[e.type],r=t===`interval`?`frequency`:t,i=(n.upgrades[r]?.step??0)*(e.upgrades[r]??0),a=t===`slow`?(n.upgrades.effectiveness?.step??0)*(e.upgrades.effectiveness??0):0;return(n.effect[t]??0)+i+a}function ju(e,t){return e.type===`overclockRelay`||t===`count`?1:1+B.placed.filter(t=>t.type===`overclockRelay`&&t.id!==e.id&&cd(e,t)<=Au(t,`range`)).reduce((e,t)=>e+Au(t,`effectiveness`),0)}function Mu(e,t){let n=Au(e,t),r=ju(e,t);return t===`interval`||t===`period`?n/r:n*r}function Nu(e,t=!0){K.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Yu(e);let n=Y.indexOf(e);n>=0&&Y.splice(n,1),n>=0&&t&&Yl()}function Pu(){let e=Math.random()*Math.PI*2,t=Math.max(1,Bs()-v.obstacleColliderRadius);return new h(Math.cos(e)*t,v.obstacleGroundHeight,Math.sin(e)*t)}function Fu(){return nt(g)}function Iu(e,t,n){let r=Fu(),i=new h(e.x,1.4,e.z),a=t.position.clone().setY(.48),o=a.clone().sub(i).setY(0).normalize(),s=new h(-o.z,0,o.x).multiplyScalar((Math.random()-.5)*2.2),c=i.clone().lerp(a,.48).add(s);c.y=3.2+Math.random()*1.1,r.position.copy(i),K.add(r),Vc.push({mesh:r,target:t,start:i,control:c,speed:n,age:0,duration:Math.max(1.35,Math.min(4.5,i.distanceTo(a)/Math.max(n,1)))})}function Lu(e){for(let t of B.placed){if(t.type!==`barrierNode`||Ea.get(t.id)?.active<=0)continue;let n=Mu(t,`range`)+e.userData.colliderRadius+.08,r=e.position.x-t.x,i=e.position.z-t.z,a=Math.hypot(r,i);if(a>=n)continue;let o=a>.001?r/a:1,s=a>.001?i/a:0;e.position.x=t.x+o*n,e.position.z=t.z+s*n,Vs(e.position)}}function Ru(e,t){for(let t=Vc.length-1;t>=0;--t){let n=Vc[t];if(n.age+=e,!Y.includes(n.target)){K.remove(n.mesh),Vc.splice(t,1);continue}let r=n.target.position.clone().setY(.48),i=Math.min(n.age/n.duration,1),a=1-i,o=n.start.clone().multiplyScalar(a*a).addScaledVector(n.control,2*a*i).addScaledVector(r,i*i),s=Math.min(i+.025,1),c=1-s,l=n.start.clone().multiplyScalar(c*c).addScaledVector(n.control,2*c*s).addScaledVector(r,s*s);n.mesh.position.copy(o),n.mesh.lookAt(l);for(let t of n.mesh.userData.rotors)t.rotation.y+=e*38;i>=1&&(Y.includes(n.target)&&(dd(n.target.position,.52),Nu(n.target)),K.remove(n.mesh),Vc.splice(t,1))}for(let t=Fc.length-1;t>=0;--t){let n=Fc[t];if(n.age+=e,!Y.includes(n.target)){K.remove(n.mesh),Fc.splice(t,1);continue}let r=n.target.position.clone().sub(n.mesh.position);r.y=0;let i=r.length();i>.001&&n.direction.lerp(r.multiplyScalar(1/i),1-Math.exp(-12*e)).normalize(),n.mesh.position.addScaledVector(n.direction,14*e),n.mesh.rotation.x+=e*12,n.mesh.scale.setScalar(.85+Math.sin(n.age*28)*.12),i<=v.obstacleColliderRadius+.24?(K.remove(n.mesh),Y.indexOf(n.target)>=0&&(dd(n.target.position,.58),Nu(n.target)),Fc.splice(t,1)):n.age>2.5&&(K.remove(n.mesh),Fc.splice(t,1))}for(let n of B.placed){let r=Ea.get(n.id);if(!r)continue;let i=Ta.get(n.id),a=$e.types[n.type];r.timer+=e,r.effectRing.rotation.z+=e*1.4;let o=a.effect.range?Mu(n,`range`):0;if(r.effectRing.scale.setScalar(o),r.effectRing.material.opacity=.12+Math.sin(t*3)*.06,n.type===`overclockRelay`&&(r.effectRing.material.opacity=.3+Math.sin(t*6)*.12,i.rotation.y+=e*.7),n.type===`droneBay`&&r.timer>=Math.max(2,Mu(n,`period`))){r.timer=0;let e=[...Y].sort(()=>Math.random()-.5).slice(0,Math.floor(Mu(n,`count`)));for(let t of e)Iu(n,t,Mu(n,`droneSpeed`));e.length&&Ko.playBuildingEffect(i.position,n.type)}if(n.type===`barrierNode`){let a=Math.max(2,Mu(n,`period`));r.timer>=a&&(r.timer=0,r.active=Mu(n,`duration`),Ko.playBuildingEffect(i.position,n.type)),r.active=Math.max(0,r.active-e),r.barrierField&&(r.barrierField.visible=r.active>0,r.barrierField.scale.set(o,1,o),r.barrierField.rotation.y+=e*1.8,r.barrierField.children[0].material.opacity=r.active>0?.14+Math.sin(t*10)*.05:0),r.effectRing.material.opacity=r.active>0?.58:.12}if(n.type===`salvageExtractor`&&r.timer>=Math.max(3,Mu(n,`period`))){r.timer=0;let e=Y.filter(e=>cd(e.position,n)<=o).sort(()=>Math.random()-.5).slice(0,Math.floor(Mu(n,`count`)));for(let t of e){let e=v.cellCashValue*bo().cashValueMultiplier*(1+W(`cashMultiplier`))+Mu(n,`cash`);_a()||zu({position:{x:t.position.x,y:v.playerStartHeight,z:t.position.z},cashValue:e}),dd(t.position,.42),Nu(t)}e.length&&Ko.playBuildingEffect(i.position,n.type)}if(n.type===`autocannon`&&r.timer>=Math.max(.35,Mu(n,`interval`))){r.timer=0;let e=Y.filter(e=>cd(e.position,n)<=o).sort((e,t)=>cd(e.position,n)-cd(t.position,n))[0];if(e){let t=e.position.clone().sub(i.position);t.y=0,t.normalize(),i.rotation.y=Math.atan2(t.x,t.z);let r=yl();r.position.copy(i.position).addScaledVector(t,.95),r.position.y=.7,K.add(r),Fc.push({mesh:r,direction:t,destination:e.position.clone().setY(.7),target:e,age:0}),Ko.playBuildingEffect(i.position,n.type)}}}}function zu(e){let t=xl();e?t.position.set(e.position.x,e.position.y,e.position.z):t.position.copy(ou(v.cellMinDistance)),e||(t.position.y=v.playerStartHeight),t.userData.phase=e?.phase??Math.random()*Math.PI*2,t.userData.cashValue=e?.cashValue??v.cellCashValue*bo().cashValueMultiplier*(1+W(`cashMultiplier`)),K.add(t),Tc.push(t)}function Bu(e){if(Ec.length>0)return;let t=It.artifacts.find(e=>e.requirement.type===`hidden-world-map`),n=!!e?.isMapToEarth||!!(!e&&t&&F+1>=t.requirement.minSector&&!N.unlocked.includes(t.id)&&Math.random()<t.requirement.chance),r=n?Vu():Sl();e?r.position.set(e.position.x,e.position.y,e.position.z):r.position.copy(ou(v.chronoCellMinDistance)),e||(r.position.y=v.playerStartHeight),r.userData.phase=e?.phase??Math.random()*Math.PI*2,r.userData.age=e?.age??0,r.userData.isMapToEarth=n,K.add(r),Ec.push(r)}function Vu(){let e=new _(new f(b.chronoCellRadius*1.18,20,14),new i({color:`#378ac3`,emissive:`#0b385d`,emissiveIntensity:2.4,metalness:.28,roughness:.48,transparent:!0}));return e.add(new xe(new o(new f(b.chronoCellRadius*1.21,10,7)),new ne({color:`#83e9cf`,transparent:!0,opacity:.72}))),e}function Hu(e,t){let n=Cl(e);t?n.position.set(t.position.x,t.position.y,t.position.z):(n.position.copy(ou(v.cellMinDistance)),n.position.y=v.playerStartHeight),n.userData.type=e,K.add(n),Lc.push(n)}function Uu(e,t){e===`speed`&&(il=v.speedBoosterBaseDuration+W(`speedBoosterDuration`)),e===`thorn`&&(al=v.thornShieldBaseDuration+W(`thornShieldDuration`)),e===`freezer`&&(ol=v.freezerBaseDuration+W(`freezerDuration`)),Ko.playBoosterPickup(t,e)}function Wu(e){Ku(ou(v.obstacleMinDistance),e)}function Gu(e){let t=_a()?ga():null,n=bo(),r=(t?.enemyTypes??n.availableObstacleTypes).map(e=>({type:e,weight:t?.enemySpawnWeights?.[e]??n[`${e}SpawnWeight`]??0})),i=r.reduce((e,t)=>e+t.weight,0),a=Math.random()*i,o=e?.type??r[r.length-1].type;for(let t of e?[]:r)if(a-=t.weight,a<=0){o=t.type;break}let s=e?.position??(t&&o!==`regular`?Pu():ou(v.obstacleMinDistance)),c=ke[o],l=new _(new le(b.spawnRingInnerRadius,b.spawnRingOuterRadius,b.spawnRingSegments),new m({color:c.color,transparent:!0,opacity:x.spawnRingBaseOpacity,side:2,depthWrite:!1}));l.rotation.x=-Math.PI/2,l.position.set(s.x,.03,s.z);let u=new _(new ye(b.spawnCueGlowRadius,b.spawnRingSegments),new m({color:c.color,transparent:!0,opacity:x.spawnCueGlowBaseOpacity,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.set(s.x,.02,s.z);let d=new _(new he(.42,1.12,b.spawnCueBeamHeight,b.spawnRingSegments,1,!0),new m({color:c.color,transparent:!0,opacity:x.spawnCueBeamBaseOpacity,side:2,depthWrite:!1}));d.position.set(s.x,b.spawnCueBeamHeight/2,s.z),K.add(l,u,d),Uc.push({ring:l,glow:u,beam:d,position:s,type:o,age:e?.age??0}),e||Ko.playObstacleSummon(s)}function Ku(e,t,r){let a=ke[t],o=wl(new i({color:a.color,emissive:a.emissive,emissiveIntensity:t===`spore`?2.3:1,metalness:b.obstacleMetalness,roughness:b.obstacleRoughness}),t);o.position.copy(e),o.position.y=v.obstacleGroundHeight,o.userData.type=t,o.userData.id=r?.id??crypto.randomUUID(),o.userData.age=r?.age??0,o.userData.lifetimeAge=r?.lifetimeAge??0,o.userData.speed=r?.speed??n.randFloat(.8,1.45),o.userData.pulseTimer=r?.pulseTimer??0,o.userData.bangerFlash=0,o.userData.shotCooldown=r?.shotCooldown??0,o.userData.teleportTimer=r?.teleportTimer??0,o.userData.poisonTrailTimer=r?.poisonTrailTimer??0,o.userData.teleportTarget=r?.teleportTarget?new h(r.teleportTarget.x,r.teleportTarget.y,r.teleportTarget.z):null,o.userData.colliderRadius=v.obstacleColliderRadius,o.userData.electronStunnedOnce=!!r?.electronStunnedOnce;let s=new oe,l=new m({color:`#fff3a6`,transparent:!0,opacity:.9,depthWrite:!1});for(let e=0;e<3;e+=1){let t=new _(new c(.13,0),l.clone()),n=e*Math.PI*2/3;t.position.set(Math.cos(n)*.42,Math.sin(e*2.2)*.09,Math.sin(n)*.42),t.rotation.set(Math.PI/4,n,Math.PI/4),s.add(t)}s.position.y=1.08,s.visible=!1,o.add(s),o.userData.stunStars=s;let u=new oe,d=new m({color:`#c59cff`,transparent:!0,opacity:.76,depthWrite:!1}),f=new _(new Ce(.28,.028,6,18),d);f.rotation.x=Math.PI/2,u.add(f);for(let e of[Math.PI/4,-Math.PI/4]){let t=new _(new me(.48,.04,.035),d.clone());t.rotation.y=e,u.add(t)}if(u.position.y=1.08,u.visible=o.userData.electronStunnedOnce,o.add(u),o.userData.electronImmunityMarker=u,t===`chaser`||t===`banger`||t===`shooter`||t===`magnet`){let t=new _(new le(a.range-b.chaserRangeIndicatorWidth,a.range,b.chaserRangeIndicatorSegments),new m({color:a.color,transparent:!0,opacity:x.chaserRangeIndicatorBaseOpacity,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.025,e.z),o.userData.rangeIndicator=t,K.add(t)}if(t===`magnet`){let t=new _(new le(.18,.3,b.chaserRangeIndicatorSegments),new m({color:y.slowAura,transparent:!0,opacity:.5,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.035,e.z),o.userData.magnetPulse=t,o.userData.magnetPulsePhase=r?.magnetPulsePhase??Math.random(),K.add(t)}K.add(o),Y.push(o),t===`porter`&&o.userData.teleportTarget&&Ju(o)}function qu(){let e=Math.random()*Math.PI*2,t=n.randFloat(b.porterTeleportMinDistance,b.porterTeleportMaxDistance);return Vs(new h(q.position.x+Math.cos(e)*t,v.obstacleGroundHeight,q.position.z+Math.sin(e)*t))}function Ju(e){let t=e.userData.teleportTarget,n=new _(new le(.4,.65,32),new m({color:y.porter,transparent:!0,opacity:.8,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(t.x,.04,t.z);let r=new _(new he(.18,.7,2.8,20,1,!0),new m({color:y.porter,transparent:!0,opacity:.25,side:2,depthWrite:!1}));r.position.set(t.x,1.4,t.z),e.userData.teleportEffect={ring:n,beam:r},K.add(n,r)}function Yu(e){let t=e.userData.teleportEffect;t&&K.remove(t.ring,t.beam),e.userData.teleportEffect=null}function Xu(e,t,n=1,r={}){let a=n===1?.6:.4,o=wl(new i({color:y.spore,emissive:y.sporeEmissive,emissiveIntensity:3*a,metalness:b.obstacleMetalness,roughness:b.obstacleRoughness}),`spore`);o.userData.hdrEmissionScale=a,o.scale.setScalar(n===1?b.sporeFragmentScale:b.sporeFragmentChildScale),o.position.copy(e),K.add(o),Ic.push({spore:o,direction:t.clone(),generation:n,age:r.age??0})}function Zu(e,t=1){let n=t===1?b.sporeFragmentCount:b.sporeFragmentChildCount,r=Math.random()*Math.PI*2;for(let i=0;i<n;i+=1){let a=r+i*(Math.PI*2/n);Xu(new h(e.x,v.playerStartHeight,e.z),new h(Math.cos(a),0,Math.sin(a)),t)}}function Qu(e){let t=e.position.clone();K.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Yu(e);let n=Y.indexOf(e);n>=0&&Y.splice(n,1),Zu(t)}function $u(e){let t=vl();t.position.set(e.position.x,v.playerStartHeight,e.position.z);let n=_a(),r=(n?As.position:q.position).clone().sub(t.position);r.y=0,r.lengthSq()===0?r.set(0,0,1):r.normalize(),t.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),K.add(t),Pc.push({projectile:t,direction:r,age:0,distanceTravelled:0,maxRange:qa(`shooter`,ke.shooter.range),targetTower:n})}function ed(){for(let e=0;e<v.obstacleColliderIterations;e+=1)for(let e=0;e<Y.length-1;e+=1){let t=Y[e];for(let n=e+1;n<Y.length;n+=1){let r=Y[n],i=t.userData.colliderRadius+r.userData.colliderRadius,a=r.position.x-t.position.x,o=r.position.z-t.position.z,s=a*a+o*o;if(s>=i*i)continue;let c=ke[t.userData.type],l=ke[r.userData.type];t.userData.type===`creeper`&&l.speed===0&&(t.userData.staticCollisionSlow=v.creeperStaticCollisionSlowDuration),r.userData.type===`creeper`&&c.speed===0&&(r.userData.staticCollisionSlow=v.creeperStaticCollisionSlowDuration);let u=Math.sqrt(s),d=u>.001?a/u:(e+n)%2?1:-1,f=u>.001?o/u:0,p=(i-u)/2;t.position.x-=d*p,t.position.z-=f*p,r.position.x+=d*p,r.position.z+=f*p,Vs(t.position),Vs(r.position)}}}function td(){if(cl>0)return;let e=bo(),t=e.availableFallingRockTypes.map(t=>({type:t,weight:e[`${t}SpawnWeight`]??0})),r=t.reduce((e,t)=>e+t.weight,0),i=Math.random()*r,a=t[t.length-1].type;for(let e of t)if(i-=e.weight,i<=0){a=e.type;break}let o=q.position.clone();o.x+=n.randFloatSpread(v.fallingRockImpactOffset*2),o.z+=n.randFloatSpread(v.fallingRockImpactOffset*2),Vs(o),nd(o,void 0,a)}function nd(e,t,n=t?.type??`stoneRock`){let r=Ae[n],a=new _(_l,new i({color:r.color,emissive:r.emissive,emissiveIntensity:r.emissiveIntensity,metalness:b.fallingObstacleMetalness,roughness:b.fallingObstacleRoughness}));a.position.set(e.x,v.fallingBlockStartHeight,e.z),a.castShadow=!0;let o=new _(new ye(1.15,32),new m({color:y.targetShadow,transparent:!0,opacity:.7,depthWrite:!1}));o.rotation.x=-Math.PI/2,o.position.set(e.x,.025,e.z);let s=new _(new le(1.18,1.3,32),new m({color:y.targetRing,transparent:!0,opacity:.95,side:2,depthWrite:!1}));s.rotation.x=-Math.PI/2,s.position.set(e.x,.03,e.z),K.add(a,o,s),Dc.push({obstacle:a,shadow:o,targetRing:s,target:e.clone(),type:n,age:t?.age??0,landed:t?.landed??!1,impactTriggered:t?.impactTriggered??!1}),t||Ko.playFallingObstacle(e)}function rd(t,r){let a=new oe;a.position.set(t.x,.05,t.z);let o=new _(new he(v.fieryRockFireRadius,v.fieryRockFireRadius*.82,.06,32),new m({color:y.fire,transparent:!0,opacity:.34,depthWrite:!1}));a.add(o);let s=[];for(let e=0;e<v.fieryRockFlameCount;e+=1){let t=e/v.fieryRockFlameCount*Math.PI*2+Math.random()*.45,r=e===0?0:n.randFloat(.18,v.fieryRockFireRadius*.66),o=n.randFloat(.75,1.7)*(e===0?1.3:1),c=new _(new ae(n.randFloat(.15,.32),o,5),new i({color:e%3==0?`#ffe19a`:y.fire,emissive:y.fieryRockEmissive,emissiveIntensity:2.6,transparent:!0,opacity:.86,roughness:.45,depthWrite:!1}));c.position.set(Math.cos(t)*r,o/2,Math.sin(t)*r),c.rotation.z=n.randFloatSpread(.28),c.rotation.x=n.randFloatSpread(.28),c.userData.baseHeight=o,c.userData.phase=Math.random()*Math.PI*2,a.add(c),s.push(c)}let c=[];for(let e=0;e<v.fieryRockEmberCount;e+=1){let e=new _(new d(n.randFloat(.035,.08),0),new m({color:`#ffe19a`,transparent:!0,opacity:.9,depthWrite:!1}));e.userData.angle=Math.random()*Math.PI*2,e.userData.distance=n.randFloat(.1,v.fieryRockFireRadius*.72),e.userData.height=n.randFloat(.2,1.7),e.userData.speed=n.randFloat(.7,1.5),e.userData.phase=Math.random()*Math.PI*2,a.add(e),c.push(e)}let l=new e(y.fire,5.5,v.fieryRockFireRadius*3);l.position.set(t.x,1.2,t.z),K.add(a,l),Oc.push({visual:a,ground:o,flames:s,embers:c,light:l,position:t.clone(),age:r?.age??0})}function id(e,t){let{visual:n,pool:r,vapor:i}=kl(e,b.poisonCreeperTrailRadius);K.add(n),kc.push({visual:n,pool:r,vapor:i,position:e.clone(),age:t?.age??0})}function ad(e,t,n=0){let r=bl();r.position.copy(e),K.add(r),Ac.push({piece:r,direction:t,age:n})}function od(e){let t=Math.random()*Math.PI*2;for(let r=0;r<v.splinterPieceCount;r+=1){let i=t+r*(Math.PI*2/v.splinterPieceCount)+n.randFloatSpread(.35);ad(new h(e.x,.72,e.z),new h(Math.cos(i),0,Math.sin(i)))}}function sd(e){for(let t of e)K.remove(t);e.length=0}function cd(e,t){return Math.hypot(e.x-t.x,e.z-t.z)}function ld(e,t,r){let i=r.x-t.x,a=r.z-t.z,o=i*i+a*a;if(o===0)return Math.hypot(e.x-t.x,e.z-t.z);let s=n.clamp(((e.x-t.x)*i+(e.z-t.z)*a)/o,0,1);return Math.hypot(e.x-(t.x+i*s),e.z-(t.z+a*s))}function ud(e,t,r){let i=U(`unlock-orbital-electron`)>0&&!Da&&!Gc;if(oc.visible=i,lc.visible=i,!i)return!1;uc+=e*(v.orbitalElectronBaseSpeed+W(`electronSpeed`));let a=v.orbitalElectronOrbitRadius*r;oc.position.set(q.position.x+Math.cos(uc)*a,q.position.y+.12+Math.sin(t*9)*.08,q.position.z+Math.sin(uc)*a),oc.rotation.y+=e*8,sc.scale.setScalar(.9+Math.sin(t*12)*.18);let o=cc.attributes.position.array;for(let e=0;e<=8;e+=1){let r=e/8,i=e===0||e===8?0:Math.sin(t*34+e*4.7)*.12;o[e*3]=n.lerp(q.position.x,oc.position.x,r)+Math.sin(uc)*i,o[e*3+1]=n.lerp(q.position.y,oc.position.y,r)+(e%2?.08:-.06)+i*.3,o[e*3+2]=n.lerp(q.position.z,oc.position.z,r)-Math.cos(uc)*i}return cc.attributes.position.needsUpdate=!0,lc.material.opacity=.55+Math.sin(t*18)*.22,dc.copy(oc.position),!0}function dd(e,t){let n=Tl(e,t);K.add(n.shockwave,n.blast,n.light),jc.push({...n,radius:t,age:0})}function fd(e,t,n){let r=El(e);K.add(r),Nc.push({pulse:r,radius:t,age:0}),Ko.playBangerPulse(n,e)}function pd(e,t,n=0,r=[]){let i=Dl(e);K.add(i),Rc.push({shockwave:i,origin:e.clone(),radius:t,age:n,affected:new Set(Y.filter(e=>r.includes(e.userData.id)))})}function md(){let e=v.shockwaveBaseRadius*(1+W(`effectRange`));pd(q.position,e)}function hd(e){let t=Al(e);K.add(t.flash,t.blast,t.shockwave,t.innerShockwave,t.light,...t.fragments),Hc.push({...t,age:0})}function gd(e){for(let t=Hc.length-1;t>=0;--t){let r=Hc[t];r.age+=e;let i=Math.min(r.age/v.playerDeathVfxDuration,1);r.flash.scale.setScalar(n.lerp(.25,3.8,i)),r.flash.material.opacity=Math.max(0,1-i*3.5),r.blast.scale.setScalar(n.lerp(.2,5.4,i)),r.blast.rotation.y+=e*12,r.blast.rotation.x+=e*7,r.blast.material.opacity=.95*(1-i),r.shockwave.scale.setScalar(n.lerp(.2,15,i)),r.shockwave.material.opacity=1-i,r.innerShockwave.scale.setScalar(n.lerp(.1,8,i)),r.innerShockwave.material.opacity=Math.max(0,1-i*1.8),r.light.intensity=22*(1-i);for(let t of r.fragments)t.position.addScaledVector(t.userData.velocity,e),t.userData.velocity.y-=e*7,t.rotation.x+=e*12,t.rotation.z+=e*9,t.material.opacity=1-i;i===1&&(K.remove(r.flash,r.blast,r.shockwave,r.innerShockwave,r.light,...r.fragments),Hc.splice(t,1))}}function _d(e){let t=e.position.clone(),n=qa(`banger`,ke.banger.range),r=W(`bangerEnemyDestroyChance`),i=cd(q.position,t)<=n;for(let i=Y.length-1;i>=0;--i){let a=Y[i];(a===e||cd(a.position,t)<=n&&Math.random()<r)&&(K.remove(a,a.userData.rangeIndicator,a.userData.magnetPulse),Y.splice(i,1))}dd(t,n),i&&Od(`BANGER DETONATION`)}function vd(e){let t=Ke.challenges.find(e=>e.id===pa?.challengeId);if(!t||t.type!==`cell-scout`)return;let n=e?new h(e.x,e.y,e.z):new h().setFromCylindricalCoords(Math.min(Bs()-1.2,7.5),Math.random()*Math.PI*2,v.playerStartHeight);J.player.position.copy(n),J.player.rotation.y=e?.heading??0,J.player.visible=!0,J.slowAuraRing.visible=!1,J.shieldBubble.visible=!1,J.active=!0,K.add(J.player)}function yd(e,t){if(!J.active)return;let n=Tc.reduce((e,t)=>!e||cd(t.position,J.player.position)<cd(e.position,J.player.position)?t:e,null);if(n){let t=n.position.clone().sub(J.player.position);if(t.y=0,t.lengthSq()>0&&(t.normalize(),J.player.position.addScaledVector(t,Md()*.65*e),J.player.rotation.y=Math.atan2(t.x,t.z)),J.player.position.distanceTo(n.position)<v.cellPickupRadius){let e=Tc.indexOf(n);e>=0&&(K.remove(n),Tc.splice(e,1))}}J.updateVisuals(e,t,x.playerRingSpinSpeed)}function bd(e=!0){sd(Tc),sd(Ec),sd(Lc);for(let e of Y)K.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Yu(e);Y.length=0;for(let e of Ic)K.remove(e.spore);Ic.length=0;for(let e of Dc)K.remove(e.obstacle,e.shadow,e.targetRing);Dc.length=0;for(let e of Oc)K.remove(e.visual,e.light);Oc.length=0;for(let e of kc)K.remove(e.visual);kc.length=0;for(let e of Ac)K.remove(e.piece);Ac.length=0;for(let e of jc)K.remove(e.shockwave,e.blast,e.light);jc.length=0;for(let e of Mc)K.remove(e.sphere,e.light);Mc.length=0;for(let e of Nc)K.remove(e.pulse);Nc.length=0;for(let e of Pc)K.remove(e.projectile);Pc.length=0;for(let e of Fc)K.remove(e.mesh);Fc.length=0;for(let e of Vc)K.remove(e.mesh);Vc.length=0;for(let e of Rc)K.remove(e.shockwave);Rc.length=0;for(let e of Bc)K.remove(e.ring,e.glow);Bc.length=0,zc.length=0;for(let e of Hc)K.remove(e.flash,e.blast,e.shockwave,e.innerShockwave,e.light,...e.fragments);Hc.length=0;for(let e of Uc)K.remove(e.ring,e.glow,e.beam);Uc.length=0,K.remove(J.player),J.player.visible=!1,J.active=!1,q.position.set(0,v.playerStartHeight,_a()?3:0),q.rotation.y=0,Ws=0,q.visible=!0,uc=0,oc.visible=!1,lc.visible=!1,Q=0,Kc=0,qc=0,Jc=0,Yc=0,Xc=0,Zc=0,$c=U(`shield`),el=0,rl=0,il=0,al=0,ol=0,sl=0,cl=0,ll=0,ul=0,dl=0,fl=0,Ys.visible=!1,ec.visible=!1,tc.visible=!1,ic.visible=!1;for(let e of ac.values())e.visible=!1,e.geometry.setDrawRange(0,0);for(let e of $s)e.visible=!1;for(let e of pl)K.remove(e.trail);pl.length=0,ml.clear();let t=_a()?ga():null;if(ha=t?.towerHitpoints??0,As.visible=!!t,rn.classList.toggle(`hidden`,!t),fs(),Js.visible=$c>0,en.textContent=`000`,e){if(!t){for(let e=0;e<v.initialCellCount+W(`initialCellCount`);e+=1)zu();for(let e of v.initialObstacleTypes)bo().availableObstacleTypes.includes(e)&&Wu(e)}vd()}}function $(e){return{x:e.x,y:e.y,z:e.z}}function xd(){L={sectorIndex:F,anomalyRun:pa,anomalyScout:J.active?{...$(J.player.position),heading:J.player.rotation.y}:null,player:$(q.position),playerHeading:q.rotation.y,score:Q,elapsed:Kc,spawnTimer:qc,chronoCellTimer:Jc,obstacleSpawnTimer:Yc,hazardTimer:Xc,shockwaveTimer:Zc,shieldCharges:$c,shieldInvulnerability:el,towerHealth:ha,boosterTimer:rl,speedBoosterTime:il,thornShieldTime:al,freezerTime:ol,weaponCharges:Object.fromEntries(hl),weaponRechargeTimers:Object.fromEntries(gl),cells:Tc.map(e=>({position:$(e.position),phase:e.userData.phase,cashValue:e.userData.cashValue})),chronoCells:Ec.map(e=>({position:$(e.position),phase:e.userData.phase,age:e.userData.age,isMapToEarth:!!e.userData.isMapToEarth})),boosters:Lc.map(e=>({type:e.userData.type,position:$(e.position)})),obstacles:Y.map(e=>({id:e.userData.id,position:$(e.position),type:e.userData.type,age:e.userData.age,lifetimeAge:e.userData.lifetimeAge,speed:e.userData.speed,pulseTimer:e.userData.pulseTimer,shotCooldown:e.userData.shotCooldown,teleportTimer:e.userData.teleportTimer,poisonTrailTimer:e.userData.poisonTrailTimer,teleportTarget:e.userData.teleportTarget&&$(e.userData.teleportTarget),magnetPulsePhase:e.userData.magnetPulsePhase,electronStunnedOnce:e.userData.electronStunnedOnce})),spores:Ic.map(e=>({position:$(e.spore.position),direction:$(e.direction),generation:e.generation,age:e.age})),shooterProjectiles:Pc.map(e=>({position:$(e.projectile.position),direction:$(e.direction),age:e.age,distanceTravelled:e.distanceTravelled,maxRange:e.maxRange,targetTower:!!e.targetTower})),fallingObstacles:Dc.map(e=>({target:$(e.target),type:e.type,age:e.age,landed:e.landed,impactTriggered:e.impactTriggered})),fireHazards:Oc.map(e=>({position:$(e.position),age:e.age})),poisonTrails:kc.map(e=>({position:$(e.position),age:e.age})),splinterPieces:Ac.map(e=>({position:$(e.piece.position),direction:$(e.direction),age:e.age})),buildingRuntime:B.placed.map(e=>({id:e.id,timer:Ea.get(e.id)?.timer??0,active:Ea.get(e.id)?.active??0})),autocannonProjectiles:Fc.map(e=>({position:$(e.mesh.position),direction:$(e.direction),destination:$(e.destination),targetId:e.target.userData.id,age:e.age})),shockwaves:Rc.map(e=>({origin:$(e.origin),radius:e.radius,age:e.age,affectedIds:[...e.affected].map(e=>e.userData.id)})),shockwavePushes:zc.map(e=>({obstacleId:e.obstacle.userData.id,direction:$(e.direction),distance:e.distance,remaining:e.remaining})),warnings:Uc.map(e=>({position:$(e.position),type:e.type,age:e.age}))},ta(L),wd()}function Sd(){L=null,ta(null),wd()}function Cd(){if(!L)return!1;F=Math.min(L.sectorIndex??0,oa()),pa=Ke.challenges.some(e=>e.id===L.anomalyRun?.challengeId)?L.anomalyRun:null,Hs(),bd(!1),q.position.set(L.player.x,L.player.y,L.player.z),q.rotation.y=L.playerHeading??0,Ws=q.rotation.y,Q=L.score??0,Kc=L.elapsed??0,qc=L.spawnTimer??0,Jc=L.chronoCellTimer??0,Yc=L.obstacleSpawnTimer??0,Xc=L.hazardTimer??0,Zc=L.shockwaveTimer??0,$c=L.shieldCharges??U(`shield`),el=L.shieldInvulnerability??0,ha=L.towerHealth??ga()?.towerHitpoints??0,As.visible=_a(),rl=L.boosterTimer??0,il=L.speedBoosterTime??0,al=L.thornShieldTime??0,ol=L.freezerTime??0;for(let e of z.loadout.filter(e=>is(e))){let t=Number(L.weaponCharges?.[e]);hl.set(e,n.clamp(Number.isFinite(t)?t:1,0,ls()));let r=Number(L.weaponRechargeTimers?.[e]);gl.set(e,Number.isFinite(r)?Math.max(0,r):0)}Js.visible=$c>0,vd(L.anomalyScout);for(let e of L.cells??[])zu(e);for(let e of L.chronoCells??[])Bu(e);for(let e of L.obstacles??[])Ku(new h(e.position.x,e.position.y,e.position.z),e.type,e);for(let e of L.boosters??[])Hu(e.type,e);for(let e of L.spores??[])Xu(new h(e.position.x,e.position.y,e.position.z),new h(e.direction.x,e.direction.y,e.direction.z),e.generation??1,e);for(let e of L.shooterProjectiles??[]){let t=vl();t.position.set(e.position.x,e.position.y,e.position.z),K.add(t),Pc.push({projectile:t,direction:new h(e.direction.x,e.direction.y,e.direction.z),age:e.age??0,distanceTravelled:e.distanceTravelled??0,maxRange:e.maxRange??qa(`shooter`,ke.shooter.range),targetTower:!!e.targetTower})}for(let e of L.fallingObstacles??[])nd(new h(e.target.x,e.target.y,e.target.z),e);for(let e of L.fireHazards??[])rd(new h(e.position.x,e.position.y,e.position.z),e);for(let e of L.poisonTrails??[])id(new h(e.position.x,e.position.y,e.position.z),e);for(let e of L.splinterPieces??[])ad(new h(e.position.x,e.position.y,e.position.z),new h(e.direction.x,e.direction.y,e.direction.z),e.age);for(let e of L.buildingRuntime??[]){let t=Ea.get(e.id);t&&(t.timer=e.timer??0,t.active=e.active??0)}for(let e of L.autocannonProjectiles??[]){let t=Y.find(t=>t.userData.id===e.targetId);if(!t)continue;let n=yl();n.position.set(e.position.x,e.position.y,e.position.z),K.add(n),Fc.push({mesh:n,direction:new h(e.direction.x,e.direction.y,e.direction.z),destination:new h(e.destination.x,e.destination.y,e.destination.z),target:t,age:e.age??0})}for(let e of L.shockwaves??[])pd(new h(e.origin.x,e.origin.y,e.origin.z),e.radius,e.age??0,e.affectedIds??[]);for(let e of L.shockwavePushes??[]){let t=Y.find(t=>t.userData.id===e.obstacleId);t&&zc.push({obstacle:t,direction:new h(e.direction.x,e.direction.y,e.direction.z),distance:e.distance,remaining:e.remaining})}for(let e of L.warnings??[])Gu({...e,position:new h(e.position.x,e.position.y,e.position.z)});return Ad(),!0}function wd(){gn.textContent=S(L?`menu.continue`:`menu.start_run`);let e=Kl(),t=sa(Ke.unlockSector);_n.textContent=t?e?`${S(`anomaly.run`)} (${S(`anomaly.reward_claimed`)})`:S(`anomaly.run`):`${S(`anomaly.run`)} · ${S(`hud.sector`,{sector:T(Ke.unlockSector)})}`,_n.title=t?S(e?`anomaly.reward_claimed`:`anomaly.weekly`):S(`milestone.unlock_sector`,{sector:T(Ke.unlockSector)}),_n.disabled=!!L||e||!t||Ll}async function Td(){if(!Ll){Ll=!0,Il=null,yn.textContent=S(`anomaly.verifying_title`),bn.textContent=S(`anomaly.verifying_copy`),xn.hidden=!0,Sn.hidden=!0,Cn.hidden=!0,wn.hidden=!0,vn.classList.remove(`hidden`),wd();try{Il=await zl();let e=Vl(Il),t=Wl(e);yn.textContent=`${t.name} (${S(`hud.sector`,{sector:T(F+1)})})`,bn.textContent=t.description,xn.textContent=S(`anomaly.reward`,{cells:t.rewardCellTarget??Ke.rewardCellTarget,reward:Gl(F)}),Sn.textContent=S(`anomaly.reset`,{date:Ul(Hl(Il))}),xn.hidden=!1,Sn.hidden=!1,Kl(e)?(Cn.textContent=S(`anomaly.reward_claimed`),Cn.hidden=!1):wn.hidden=!1}catch{yn.textContent=S(`anomaly.time_unverified_title`),bn.textContent=S(`anomaly.time_unverified_copy`),Cn.textContent=S(`anomaly.time_unverified_error`),Cn.hidden=!1}finally{Ll=!1,wd()}}}function Ed(){if(R){Sd(),Z=!1,X=!1,bi.classList.add(`hidden`),dn.textContent=`ASTEROID BELT`,dn.classList.remove(`death-title`),ru(),mn.textContent=S(`message.sandbox_closed`),hn.hidden=!0,M.classList.remove(`hidden`),Rn.classList.add(`hidden`),cn.classList.remove(`hidden`);return}xd(),Z=!1,X=!1,bi.classList.add(`hidden`),dn.textContent=`ASTEROID BELT`,dn.classList.remove(`death-title`),ru(),mn.textContent=S(`message.round_saved`),hn.hidden=!0,M.classList.remove(`hidden`),Rn.classList.add(`hidden`),cn.classList.remove(`hidden`)}function Dd(){let e=q.position.clone(),t=Ol(e);K.add(t.sphere,t.light),Mc.push({...t,age:0}),Ko.playShieldBreak(e),nl=tl;let n=W(`shieldBreakExplosionRadius`);if(n<=0)return;let r=3+n;dd(e,r);for(let t=Y.length-1;t>=0;--t){let n=Y[t];cd(n.position,e)>r||Nu(n)}}function Od(e=`SIGNAL LOST`){if(!X||Gc||ma||el>0)return;if($c>0){--$c,el=v.shieldInvulnerabilityDuration+W(`shieldInvulnerabilityDuration`),Dd(),Js.visible=$c>0,Js.scale.setScalar(1.7);return}X=!1,Gc=!0,Z=!1,Js.visible=!1,hd(q.position),q.visible=!1,oc.visible=!1,lc.visible=!1,gr.classList.add(`hidden`),bi.classList.add(`hidden`),Sd(),Do();let t=iu(e),n=e.toLocaleLowerCase().replace(/\s+(collision|detonation|projectile|impact|damage)$/,``);dn.textContent=t?S(`message.killed_by`,{cause:``}).trim():S(`message.killed_by`,{cause:n.toUpperCase()}),dn.classList.add(`death-title`),mn.textContent=S(`message.energy_secured`,{count:Q,cellWord:S(Q===1?`message.cell_singular`:`message.cell_plural`)}),hn.textContent=S(`message.tip`,{tip:Fi()}),hn.hidden=!1,gn.textContent=S(`menu.run_again`),cn.classList.remove(`hidden`)}function kd(e){!_a()||!X||Gc||(e&&ql(),X=!1,Gc=!0,Z=!1,Sd(),Do(),gr.classList.add(`hidden`),rn.classList.add(`hidden`),bi.classList.add(`hidden`),dn.textContent=S(e?`anomaly.tower_defended`:`anomaly.tower_destroyed`),dn.classList.toggle(`death-title`,!e),mn.textContent=S(e?`anomaly.tower_defended_copy`:`anomaly.tower_destroyed_copy`,{cells:Q}),hn.hidden=!0,gn.textContent=S(`menu.run_again`),cn.classList.remove(`hidden`))}function Ad(){en.textContent=String(Q).padStart(3,`0`),tn.textContent=R?S(`hud.sandbox_sector`,{sector:T(R.sectorIndex+1)}):`${S(`hud.sector`,{sector:T(F+1)})}${pa?S(`hud.anomaly_suffix`):``}`,nn.innerHTML=`<span class="shield-indicators-label">${S(`hud.shields`)}</span>${Array.from({length:$c},()=>`<img src="${Zt}" alt="">`).join(``)}`,nn.hidden=$c===0,nn.setAttribute(`aria-label`,`${$c} shield ${$c===1?`charge`:`charges`} remaining`);let e=_a()?ga():null;rn.classList.toggle(`hidden`,!X||!e),e&&(an.textContent=S(`anomaly.tower_health`,{current:ha,maximum:e.towerHitpoints}),on.style.transform=`scaleX(${n.clamp(ha/e.towerHitpoints,0,1)})`)}function jd(){return fl>0||_a()}function Md(){return v.playerSpeed*(1+W(`playerSpeedMultiplier`))*(il>0?2:1)*(jd()?1.8:1)}function Nd(e,t){for(let e of ml.values())e.exposed=!1;let r=bo(),i=_a()?ga()?.difficultyMultiplier??1:1,a=n.lerp(.16,.03,F/Math.max($i.length-1,1)),o=(v.regularObstacleLifetime+r.obstacleLifetimeOffset+Q*(v.regularObstacleLifetimeIncreasePerCell+r.obstacleLifetimeIncreasePerCellOffset))*Math.max(.5,1-W(`regularLifetimeDebuff`)),s=Math.max(1,o-Y.length*.1),c=Math.max(v.obstacleSpawnWarningDuration,(v.obstacleSpawnInterval+r.obstacleSpawnIntervalOffset-Q*(v.obstacleSpawnDecreasePerCell+r.obstacleSpawnDecreasePerCellOffset))*(1-a)/i),l=Math.max(1,Math.floor((v.obstacleSpawnCount+r.obstacleSpawnCountOffset+Q*r.obstacleSpawnCountIncreasePerCell)*v.difficultyPressureMultiplier*i)),u=new h(!!pc.has(`KeyD`)-+!!pc.has(`KeyA`)+mc.x,0,!!pc.has(`KeyS`)-+!!pc.has(`KeyW`)+mc.y);u.lengthSq()>0&&(u.normalize(),q.position.addScaledVector(u,Md()*e),Ws=Math.atan2(u.x,u.z));let d=Math.atan2(Math.sin(Ws-q.rotation.y),Math.cos(Ws-q.rotation.y));q.rotation.y+=d*(1-Math.exp(-10*e)),Vs(q.position),Gs.updateVisuals(e,t,x.playerRingSpinSpeed);let f=U(`unlock-slow-aura`)>0,p=1+W(`effectRange`),ee=v.slowAuraBaseRange*p,m=n.clamp(v.slowAuraBaseEffect+W(`slowAuraEffect`),0,.9);qs.visible=f,f&&(qs.scale.setScalar(ee),qs.material.opacity=.22+Math.sin(t*3.5)*.08,qs.rotation.z+=e*.35);let te=ud(e,t,p);el>0&&(el=Math.max(0,el-e)),il=Math.max(0,il-e),al=Math.max(0,al-e),ol=Math.max(0,ol-e),sl=Math.max(0,sl-e),cl=Math.max(0,cl-e),ll=Math.max(0,ll-e),ul=Math.max(0,ul-e),dl=Math.max(0,dl-e),fl=Math.max(0,fl-e),ps(e);let g=gs(`atmosphereShield`);if(Ys.visible=cl>0,cl>0){let n=g>0?cl/g:0;Xs.rotation.z+=e*2.7,Zs.rotation.z-=e*1.5,Ys.scale.setScalar(1+Math.sin(t*9)*.08),Xs.material.opacity=.52+n*.38,Zs.material.opacity=.08+n*.18,Qs.material.opacity=.06+n*.18}if(ec.visible=jd(),tc.visible=jd(),jd()){ec.rotation.z+=e*5,ec.scale.setScalar(1+Math.sin(t*14)*.12),ec.material.opacity=.55+Math.sin(t*18)*.2,tc.rotation.y-=e*1.7,tc.scale.setScalar(1+Math.sin(t*16)*.14);for(let e of tc.children)e.material.opacity=.26+Math.sin(t*12+e.position.x*4)*.16}ic.visible=dl>0,dl>0&&(ic.material.rotation+=e*2.8,ic.position.y=2.2+Math.sin(t*5)*.15,ic.scale.setScalar(.65+Math.sin(t*7)*.08));for(let[e,n]of $s.entries()){if(n.visible=ul>0,!n.visible)continue;let r=t*5+e*Math.PI*2/$s.length;n.position.set(Math.cos(r)*2.2,.55+Math.sin(r*2)*.18,Math.sin(r)*2.2),n.scale.setScalar(.9+Math.sin(t*12+e)*.18),n.getWorldPosition(fc);for(let e of[...Y])e.position.distanceTo(fc)<=e.userData.colliderRadius+.3&&(dd(e.position,.42),Nu(e))}for(let t=pl.length-1;t>=0;--t){let n=pl[t];n.age+=e,n.trail.material.opacity=Math.max(0,.95-n.age*2.5),n.age>=.4&&(K.remove(n.trail),pl.splice(t,1))}for(let[t,r]of ac){let i=gs(t),a=_s(t),o=i>0?n.clamp(a/i,0,1):0;if(r.visible=o>0,!r.visible){r.geometry.setDrawRange(0,0);continue}r.position.set(q.position.x,r.userData.height,q.position.z);let s=r.geometry.index?.count??0;r.geometry.setDrawRange(0,Math.max(3,Math.floor(s*o/3)*3)),r.rotation.z-=e*(1.1+o),r.material.opacity=.28+o*.65}if(vs(),Ks.material.emissive.set(`#000000`),Ks.material.emissiveIntensity=0,$c>0||el>0||al>0?(Js.visible=!0,Js.scale.setScalar(1+Math.sin(t*12)*.08+(el>0?.2:0)),Js.material.color.set(al>0?`#ff795f`:y.slowAura),Js.material.opacity=al>0||el>0?.65:.18):Js.visible=!1,U(`unlock-shockwave`)>0){Zc+=e;let t=v.shockwaveBaseInterval/(1+W(`shockwaveFrequency`));Zc>=t&&(md(),Zc=0)}Ru(e,t),yd(e,t);for(let n=Tc.length-1;n>=0;--n){let r=Tc[n];r.rotation.y+=e*x.cellSpinSpeed,r.position.y=x.cellBobBaseHeight+Math.sin(t*x.cellBobSpeed+r.userData.phase)*x.cellBobAmplitude;let i=W(`cellMagnetSpeed`),a=q.position.clone().sub(r.position);if(a.y=0,sl>0?a.lengthSq()>0&&r.position.addScaledVector(a.normalize(),22*e):i>0&&a.length()<=v.cellMagnetRange*p&&r.position.addScaledVector(a.normalize(),(v.cellMagnetBaseSpeed+i)*e),r.position.distanceTo(q.position)<v.cellPickupRadius){Ko.playCellCollect(r.position),K.remove(r),Tc.splice(n,1);let e=dl>0?2:1;Q+=e,R||(So(e),Co(r.userData.cashValue*e),To(r.position,r.userData.cashValue*e)),ql()}}for(let n=Lc.length-1;n>=0;--n){let r=Lc[n];r.rotation.y+=e*3,r.position.y=v.playerStartHeight+Math.sin(t*4+n)*.16,r.position.distanceTo(q.position)<v.cellPickupRadius&&(Uu(r.userData.type,r.position),K.remove(r),Lc.splice(n,1))}for(let n=Ec.length-1;n>=0;--n){let r=Ec[n];r.userData.age+=e;let i=v.chronoCellLifetime*(1+W(`chronoLifetimeMultiplier`)),a=r.userData.age/i;if(r.rotation.x+=e*x.chronoCellSpinSpeed,r.rotation.y+=e*x.chronoCellSpinSpeed*.7,r.position.y=x.cellBobBaseHeight+Math.sin(t*x.chronoCellBobSpeed+r.userData.phase)*x.chronoCellBobAmplitude,r.material.emissiveIntensity=b.chronoCellEmissiveIntensity+Math.sin(t*8)*.8,r.material.opacity=a>.7?1-(a-.7)/.3:1,r.userData.isMapToEarth)for(let e of r.children)e.material.opacity=r.material.opacity*.72;if(r.position.distanceTo(q.position)<v.cellPickupRadius){if(Ko.playCellCollect(r.position),r.userData.isMapToEarth){No(It.artifacts.find(e=>e.requirement.type===`hidden-world-map`))&&Eo(r.position,S(`artifact.acquired`),`chronoshard-indicator`),K.remove(r),Ec.splice(n,1);continue}let e=wo(v.chronoCellChronoshardValue);Eo(r.position,`+✦${E(e)}`,`chronoshard-indicator`),K.remove(r),Ec.splice(n,1);continue}a>=1&&(K.remove(r),Ec.splice(n,1))}let ne=[],re=[];for(let r=Y.length-1;r>=0;--r){let i=Y[r],a=ke[i.userData.type],o=qa(i.userData.type,a.range);if(ll>0){i.userData.material.emissive.set(`#77c8ff`),i.userData.material.emissiveIntensity=2+Math.sin(t*12)*.5,i.rotation.y+=e*.35;continue}if(i.userData.lifetimeAge+=e,i.userData.lifetimeAge>s){Nu(i,!1);continue}let c=s-i.userData.lifetimeAge;if(c<=v.obstacleDespawnWarningDuration){let e=1-c/v.obstacleDespawnWarningDuration,t=n.lerp(v.obstacleDespawnWarningStartFrequency,v.obstacleDespawnWarningEndFrequency,e);i.visible=Math.sin(i.userData.lifetimeAge*t*Math.PI*2)>-.1}else i.visible=!0;let l=q.position.clone().sub(i.position);l.y=0;let u=_a()?ga():null,d=As.position.clone().sub(i.position);d.y=0;let h=u?d:l,g=i.userData.type===`creeper`||i.userData.type===`poisonCreeper`;g&&(i.userData.staticCollisionSlow=Math.max(0,(i.userData.staticCollisionSlow??0)-e));let ie=B.placed.filter(e=>e.type===`chronoGenerator`&&cd(i.position,e)<=Mu(e,`range`)).reduce((e,t)=>Math.max(e,Mu(t,`slow`)),0);if(i.userData.material.emissive.set(a.emissive),i.userData.type===`poisonCreeper`){let e=(Math.sin(t*2.7+i.userData.speed)+1)/2;i.userData.material.color.lerpColors(jl,Ml,e),i.userData.material.emissive.lerpColors(Nl,Pl,e),i.userData.material.emissiveIntensity=1.2+e*.75}if(ie>0&&i.userData.material.emissive.lerp(Us,n.clamp(ie*1.6,0,.82)),al>0&&l.length()<v.playerRadius){Nu(i);continue}if(jd()&&l.length()<v.playerRadius+.3){dd(i.position,.5),Nu(i);continue}i.userData.electronStun=Math.max(0,(i.userData.electronStun??0)-e),i.userData.electronHitCooldown=Math.max(0,(i.userData.electronHitCooldown??0)-e),te&&!i.userData.electronStunnedOnce&&i.userData.electronHitCooldown===0&&ld(i.position,q.position,dc)<=v.orbitalElectronHitRadius+i.userData.colliderRadius&&(i.userData.electronStun=v.orbitalElectronBaseStunDuration+W(`electronStunDuration`),i.userData.electronStunMax=i.userData.electronStun,i.userData.electronHitCooldown=.18,i.userData.electronStunnedOnce=!0);let ae=i.userData.electronImmunityMarker;if(ae.visible=i.userData.electronStunnedOnce,ae.visible&&(ae.rotation.y+=e*1.8),i.userData.electronStun>0){let r=n.clamp(i.userData.electronStun/(i.userData.electronStunMax||1),0,1),a=i.userData.stunStars;a.visible=!0,a.rotation.y+=e*(5+r*7),a.scale.setScalar(.55+r*.45);for(let t of a.children)t.rotation.x+=e*8,t.rotation.z+=e*5,t.material.opacity=.08+r*.32;i.userData.material.emissive.set(`#5eeeff`),i.userData.material.emissiveIntensity=.8+Math.sin(t*26)*.3,i.rotation.y+=e*1.5;continue}if(i.userData.stunStars.visible=!1,i.userData.material.emissiveIntensity=1,ol>0)continue;let oe=(f&&l.length()<=ee?1-m:1)*(1-ie),se=W(`pushbackSpeed`);if(se>0&&a.speed===0&&l.length()<=v.pushbackBaseRange*p){let t=i.position.clone().sub(q.position);t.y=0,t.lengthSq()>0&&i.position.addScaledVector(t.normalize(),(v.pushbackBaseSpeed+se)*e)}let ce=u&&i.userData.type===`regular`;if(!ce&&(u||h.length()<=o)&&(a.speed>0||u)){let t=g?Math.max(.5,1-W(`creeperSpeedDebuff`)):1,r=g?Math.min(i.userData.lifetimeAge/s,1):0,o=u?.enemyMovementSpeeds?.[i.userData.type],c=u?o??Math.max(a.speed,1):g?n.lerp(a.speed,v.playerSpeed*.9,r):a.speed,l=g&&i.userData.staticCollisionSlow>0?v.creeperStaticCollisionSpeedMultiplier:1;i.position.addScaledVector(h.clone().normalize(),c*t*oe*l*e)}if(i.userData.rangeIndicator){let e=i.userData.rangeIndicator,n=u||l.length()<=o,r=1+Math.sin(t*x.chaserRangeIndicatorPulseSpeed)*x.chaserRangeIndicatorPulseAmount;e.position.set(i.position.x,.025,i.position.z),e.scale.setScalar(n?r:1),e.material.opacity=n?x.chaserRangeIndicatorActiveOpacity:x.chaserRangeIndicatorBaseOpacity}if(i.userData.magnetPulse){let e=i.userData.magnetPulse,n=(t*.85+i.userData.magnetPulsePhase)%1;e.position.set(i.position.x,.035,i.position.z),e.scale.setScalar(o*(1.1-n*.9)),e.material.opacity=.5*(1-n)}let le=i.userData.type;if(le===`creeper`||le===`poisonCreeper`)for(let e of i.userData.spikes??[])e.root.quaternion.copy(e.baseQuaternion),e.root.rotateX(Math.sin(t*4.6+e.phase)*.1),e.root.rotateZ(Math.cos(t*3.8+e.phase)*.075);if(le===`porter`)for(let e of i.userData.spikes??[]){let n=.86+(Math.sin(t*4.4+e.phase)+1)*.12;e.root.scale.set(1,n,1)}if(i.rotation.y+=e*(le===`chaser`?4.2:i.userData.speed*oe),i.position.y=x.obstacleBobBaseHeight+Math.sin(t*x.obstacleBobSpeed+i.position.x)*x.obstacleBobAmplitude,i.userData.type===`poisonCreeper`&&(i.userData.poisonTrailTimer+=e,i.userData.poisonTrailTimer>=b.poisonCreeperTrailInterval&&(i.userData.poisonTrailTimer=0,id(i.position))),i.userData.type===`creeper`||i.userData.type===`poisonCreeper`){let e=1.7+(Math.sin(t*5.4+i.userData.id.length)+1)*1.4;for(let t of i.userData.creeperTipMaterials??[])t.emissiveIntensity=e}if(i.userData.type===`banger`){i.userData.age+=e*oe;let t=Math.min(i.userData.age/b.bangerFuseDuration,1),r=(Math.sin(i.userData.age*x.bangerFusePulseSpeed)+1)/2;i.userData.bangerFlash=Math.max(0,(i.userData.bangerFlash??0)-e*4.8),i.userData.material.emissive.set(`#ff160d`),i.userData.material.emissiveIntensity=x.bangerFuseEmissiveBaseIntensity+r*x.bangerFuseEmissivePulseAmount+i.userData.bangerFlash*4,i.userData.pulseTimer=(i.userData.pulseTimer??0)+e*oe;let a=n.lerp(v.bangerPulseStartInterval,v.bangerPulseEndInterval,t);i.userData.pulseTimer>=a&&(fd(i.position,o,t),i.userData.bangerFlash=1,i.userData.pulseTimer=0),i.userData.age>=b.bangerFuseDuration&&ne.push(i);continue}if(i.userData.type===`shooter`&&(i.userData.shotCooldown=Math.max(0,i.userData.shotCooldown-e),(u?d.length():l.length())<=o&&i.userData.shotCooldown===0&&($u(i),i.userData.shotCooldown=b.shooterProjectileCooldown)),i.userData.type===`magnet`&&l.length()<=o){let t=i.position.clone().sub(q.position);t.y=0,t.lengthSq()>0&&q.position.addScaledVector(t.normalize(),b.magnetPullSpeed*Math.max(.5,1-W(`magnetStrengthDebuff`))*e)}if(i.userData.type===`porter`){i.userData.teleportTimer+=e;let n=b.porterTeleportInterval*(1+W(`porterIntervalBonus`)),r=n-b.porterWarningDuration;if(i.userData.teleportTimer>=r&&!i.userData.teleportTarget&&(i.userData.teleportTarget=qu(),Ju(i)),i.userData.teleportTarget){let e=(Math.sin(t*22)+1)/2;i.userData.material.emissiveIntensity=.8+e*3,i.userData.teleportEffect.ring.scale.setScalar(1+e*.35),i.userData.teleportEffect.ring.material.opacity=.45+e*.5,i.userData.teleportEffect.beam.material.opacity=.14+e*.3}i.userData.teleportTimer>=n&&(i.position.copy(i.userData.teleportTarget),Yu(i),i.userData.teleportTarget=null,i.userData.teleportTimer=0,i.userData.material.emissiveIntensity=1)}if(i.userData.type===`spore`){i.userData.age+=e;let t=i.userData.hdrEmissionScale??.5;i.userData.material.emissiveIntensity=(2.2+(Math.sin(i.userData.age*10)+1)*1.5)*t,i.userData.age>=b.sporeFuseDuration&&re.push(i)}if(!ce&&u&&d.length()<=u.towerRadius+i.userData.colliderRadius){Jl(u.towerContactDamage),Nu(i,!1);continue}Lu(i),i.position.distanceTo(q.position)<v.playerRadius&&(jd()?(dd(i.position,.5),Nu(i)):Od(`${i.userData.type.toUpperCase()} COLLISION`))}ed();for(let e of ne)Y.includes(e)&&_d(e);for(let e of re)Y.includes(e)&&Qu(e);for(let t=Ic.length-1;t>=0;--t){let n=Ic[t];n.age+=e;let r=Math.min(n.age/b.sporeFragmentDuration,1),i=b.sporeFragmentSpeed*(1-r)*Math.max(.5,1-W(`sporeSpeedDebuff`));if(n.spore.position.addScaledVector(n.direction,i*e),n.spore.rotation.x+=e*7,n.spore.rotation.z+=e*5,r>=1){n.generation===1&&Zu(n.spore.position,2),K.remove(n.spore),n.spore.userData.material?.dispose(),Ic.splice(t,1);continue}Math.hypot(n.spore.position.x,n.spore.position.z)>Bs()&&(K.remove(n.spore),n.spore.userData.material?.dispose(),Ic.splice(t,1))}for(let t=Pc.length-1;t>=0;--t){let n=Pc[t];n.age+=e;let r=b.shooterProjectileSpeed*Math.max(.5,1-W(`shooterProjectileSpeedDebuff`))*e;n.projectile.position.addScaledVector(n.direction,r),n.distanceTravelled+=r,n.projectile.rotation.x+=e*9,n.projectile.rotation.y+=e*12;let i=n.targetTower?As.position:q.position,a=n.targetTower?ga()?.towerRadius??1.15:v.playerRadius;if(n.projectile.position.distanceTo(i)<a+b.shooterProjectileRadius){K.remove(n.projectile),Pc.splice(t,1),n.targetTower?Jl(ga()?.towerProjectileDamage??1):Od(`SHOOTER PROJECTILE`);continue}n.distanceTravelled>=n.maxRange&&(K.remove(n.projectile),Pc.splice(t,1))}for(let t=jc.length-1;t>=0;--t){let r=jc[t];r.age+=e;let i=Math.min(r.age/v.bangerExplosionVfxDuration,1);r.shockwave.scale.setScalar(n.lerp(.3,r.radius/.42,i)),r.shockwave.material.opacity=1-i,r.blast.scale.setScalar(n.lerp(.2,r.radius,i)),r.blast.material.opacity=.65*(1-i),r.light.intensity=10*(1-i),i===1&&(K.remove(r.shockwave,r.blast,r.light),jc.splice(t,1))}for(let t=Mc.length-1;t>=0;--t){let r=Mc[t];r.age+=e;let i=Math.min(r.age/.42,1);r.sphere.scale.setScalar(n.lerp(.45,4.8,i)),r.sphere.material.opacity=.84*(1-i)**2,r.light.intensity=12*(1-i),i===1&&(K.remove(r.sphere,r.light),Mc.splice(t,1))}for(let t=Nc.length-1;t>=0;--t){let r=Nc[t];r.age+=e;let i=Math.min(r.age/v.bangerPulseVfxDuration,1);r.pulse.scale.setScalar(n.lerp(.2,r.radius/.42,i)),r.pulse.material.opacity=.9*(1-i),i===1&&(K.remove(r.pulse),Nc.splice(t,1))}for(let t=Rc.length-1;t>=0;--t){let r=Rc[t];r.age+=e;let i=Math.min(r.age/v.shockwaveVfxDuration,1);r.shockwave.scale.setScalar(n.lerp(.25,r.radius/.42,i)),r.shockwave.material.opacity=.95*(1-i);let a=r.radius*i;for(let e of Y){if(r.affected.has(e))continue;let t=e.position.clone().sub(r.origin);t.y=0;let n=t.length();n>a||(r.affected.add(e),n<.01?t.set(Math.random()-.5,0,Math.random()-.5).normalize():t.normalize(),zc.push({obstacle:e,direction:t,distance:v.shockwavePushDistance*(1-n/r.radius),remaining:.28}))}i===1&&(K.remove(r.shockwave),Rc.splice(t,1))}for(let t=Bc.length-1;t>=0;--t){let r=Bc[t];r.age+=e;let i=Math.min(r.age/r.duration,1),a=r.radius*i;r.ring.scale.setScalar(n.lerp(.2,r.radius/.58,i)),r.glow.scale.setScalar(n.lerp(.08,r.radius,i)),r.ring.material.opacity=.98*(1-i*.38),r.glow.material.opacity=.24*(1-i);for(let e of r.targets)r.hit.has(e)||!Y.includes(e)||Math.hypot(e.position.x-r.origin.x,e.position.z-r.origin.z)>a||(r.hit.add(e),dd(e.position,.82),Nu(e));i===1&&(K.remove(r.ring,r.glow),Bc.splice(t,1))}for(let t=zc.length-1;t>=0;--t){let n=zc[t];if(!Y.includes(n.obstacle)){zc.splice(t,1);continue}let r=Math.min(e/n.remaining,1);n.obstacle.position.addScaledVector(n.direction,n.distance*r),Vs(n.obstacle.position),n.distance*=1-r,n.remaining-=e,n.remaining<=0&&zc.splice(t,1)}for(let t=Dc.length-1;t>=0;--t){let r=Dc[t];r.age+=e;let i=Math.min(r.age/v.fallingBlockDuration,1),a=1-(1-i)**3;r.obstacle.position.y=n.lerp(v.fallingBlockStartHeight,v.fallingBlockGroundHeight,a),r.obstacle.rotation.x+=e*x.fallingObstacleSpinXSpeed,r.obstacle.rotation.z+=e*x.fallingObstacleSpinZSpeed,r.shadow.scale.setScalar(x.targetShadowBaseScale+i*x.targetShadowScaleGrowth),r.shadow.material.opacity=x.targetShadowBaseOpacity+i*x.targetShadowOpacityGrowth;let o=1+Math.sin(r.age*x.targetRingPulseSpeed)*x.targetRingPulseAmount;r.targetRing.scale.setScalar((x.targetRingBaseScale+i*x.targetRingScaleGrowth)*o),r.targetRing.material.opacity=x.targetRingBaseOpacity-i*x.targetRingOpacityFade;let s=q.position.distanceTo(r.target);!r.landed&&i>.82&&s<v.playerRadius&&(r.type===`fieryRock`?Fd(`fire`,`fiery-rock-impact`):Od(`METEOR IMPACT`)),i===1&&(r.landed=!0,r.impactTriggered||(r.impactTriggered=!0,r.type===`fieryRock`&&rd(r.target),r.type===`splinter`&&od(r.target)),r.obstacle.position.y=v.fallingBlockGroundHeight,r.shadow.material.opacity=Math.max(0,.88-(r.age-v.fallingBlockDuration)*1.8),r.targetRing.material.opacity=Math.max(0,.55-(r.age-v.fallingBlockDuration)*1.5),r.age>v.fallingBlockLifetime&&(K.remove(r.obstacle,r.shadow,r.targetRing),Dc.splice(t,1)))}for(let t=Oc.length-1;t>=0;--t){let n=Oc[t];n.age+=e;let r=n.age/v.fieryRockFireDuration,i=1+Math.sin(n.age*9)*.1,a=Math.max(0,1-r);n.ground.scale.setScalar(i*(.9+r*.2)),n.ground.material.opacity=.34*a,n.visual.rotation.y+=e*.5;for(let e of n.flames){let t=.82+Math.sin(n.age*12+e.userData.phase)*.18;e.scale.y=t*a,e.material.opacity=.86*a}for(let e of n.embers){let t=(n.age*e.userData.speed+e.userData.phase)%1,r=e.userData.distance*(.55+t*.7);e.position.set(Math.cos(e.userData.angle+n.age)*r,t*e.userData.height+.16,Math.sin(e.userData.angle+n.age)*r),e.material.opacity=.85*a*(1-t),e.scale.setScalar(.6+(1-t)*.7)}n.light.intensity=Math.max(0,(5.5+Math.sin(n.age*14))*a),cd(q.position,n.position)<v.fieryRockFireRadius&&Fd(`fire`,`fiery-rock`),r>=1&&(K.remove(n.visual,n.light),Oc.splice(t,1))}for(let n=kc.length-1;n>=0;--n){let r=kc[n];r.age+=e;let i=v.poisonTrailDuration*(1-W(`poisonTrailDurationReduction`)),a=r.age/i,o=Math.max(0,1-a),s=1+Math.sin(t*5+n)*.08;r.pool.scale.setScalar(s*(.92+a*.16)),r.pool.material.opacity=.48*o;for(let e of r.vapor){let n=(Math.sin(t*2.8+e.userData.phase)+1)/2;e.position.y=.1+n*.26,e.material.opacity=.62*o*(.55+n*.45),e.scale.setScalar(.9+n*.62)}cd(q.position,r.position)<b.poisonCreeperTrailRadius&&Fd(`poison`,`poison-creeper-trail`),a>=1&&(K.remove(r.visual),kc.splice(n,1))}let ie=Id(e,t);if(ie){let e=.3+(Math.sin(t*18)+1)*.2;Ks.material.emissive.set(ie.color),Ks.material.emissiveIntensity=e}for(let t=Ac.length-1;t>=0;--t){let n=Ac[t];n.age+=e;let r=v.splinterPieceDistance/v.splinterPieceDuration;n.piece.position.addScaledVector(n.direction,r*e),n.piece.rotation.x+=e*8,n.piece.rotation.z+=e*6,n.piece.position.distanceTo(q.position)<v.playerRadius*.7&&Od(`SPLINTER IMPACT`),n.age>=v.splinterPieceDuration&&(K.remove(n.piece),Ac.splice(t,1))}for(let t=Uc.length-1;t>=0;--t){let n=Uc[t];n.age+=e;let r=n.age/v.obstacleSpawnWarningDuration,i=1+Math.sin(n.age*x.spawnRingPulseSpeed)*x.spawnRingPulseAmount;n.ring.scale.setScalar((x.spawnRingBaseScale+r*x.spawnRingScaleGrowth)*i),n.ring.material.opacity=x.spawnRingBaseOpacity*(1-r),n.ring.rotation.z-=e*2;let a=1+Math.sin(n.age*x.spawnRingPulseSpeed*.55)*x.spawnCueGlowPulseAmount;n.glow.scale.setScalar(a*(.85+r*.25)),n.glow.material.opacity=x.spawnCueGlowBaseOpacity*(1-r*.3),n.beam.scale.set(.8+r*.2,1,.8+r*.2),n.beam.material.opacity=x.spawnCueBeamBaseOpacity*(1-r*.45),n.beam.rotation.y+=e*1.6,r>=1&&(Y.length<xo()&&Ku(n.position,n.type),K.remove(n.ring,n.glow,n.beam),Uc.splice(t,1))}qc+=e,rl+=e,Jc+=e,Yc+=e,Xc+=e;let ae=W(`cellSpawnRate`)+Q*W(`cellSpawnRatePerCell`),oe=!_a()&&(!R||R.simulation.has(`cell`)),se=!R||R.simulation.has(`enemies`),ce=!R||R.simulation.has(`boosters`);if(oe&&qc>v.cellSpawnInterval/(1+ae)&&(zu(),qc=0),ce&&rl>v.boosterSpawnInterval){let e=[U(`unlock-speed-booster`)>0&&`speed`,U(`thorn-shield`)>0&&`thorn`,U(`freezer`)>0&&`freezer`].filter(Boolean);e.length&&Hu(e[Math.floor(Math.random()*e.length)]),rl=0}if(oe&&Jc>v.chronoCellSpawnInterval/(1+W(`chronoSpawnRate`))&&(Bu(),Jc=0),se&&Yc>c){let e=Math.max(0,xo()-Y.length-Uc.length);for(let t=0;t<Math.min(l,e);t+=1)Gu();Yc=0}let le=Math.max(v.fallingBlockMinInterval/v.fallingRockSpawnFrequencyMultiplier,(v.fallingBlockBaseInterval+r.fallingRockSpawnIntervalOffset-Q*(v.fallingBlockIntervalPerCell+r.fallingRockSpawnDecreasePerCellOffset))*(1-a)/v.fallingRockSpawnFrequencyMultiplier);!_a()&&se&&Xc>le&&(td(),Xc=0),Kc+=e,Ad()}function Pd(e){requestAnimationFrame(Pd);let t=V.gameplay.maxFps;if(t>0){let n=1e3/t;if(Qc!==null&&e<Qc)return;let r=Qc??e;Qc=r+(Math.floor(Math.max(0,e-r)/n)+1)*n}else Qc=null;Wc.update(e);let r=Math.min(Wc.getDelta(),.05),i=Wc.getElapsed();if(X&&!Z&&Nd(r,i),gd(r),Da)js.position.set(bc.x,xc,bc.y+.01),js.lookAt(bc.x,0,bc.y);else{if(js.position.set(q.position.x,$d(),q.position.z+Qd()),nl>0){let e=(nl/tl)**1.5;js.position.x+=n.randFloatSpread(.22)*e,js.position.y+=n.randFloatSpread(.14)*e,js.position.z+=n.randFloatSpread(.22)*e,nl=Math.max(0,nl-r)}js.lookAt(q.position.x,0,q.position.z)}Da&&Cu(),Ns.position.copy(js.position),V.graphics.hdrEmissionIntensity>0?Jo.render():qo.render(K,js),au(r)}function Fd(e,t=`unknown`){let n=qt[e];if(!n||!X||Gc||el>0||n.immunityResearchId&&U(n.immunityResearchId)>0)return!1;if($c>0)return Od(),!1;let r=ml.get(e);return r?(r.exposed=!0,!n.requiresExposure&&n.refreshOnReapply&&(r.remaining=n.duration),!0):(ml.set(e,{type:e,source:t,remaining:n.duration,maxDuration:n.duration,exposed:!0}),!0)}function Id(e,t){let n=null;for(let[t,r]of ml){let i=qt[t];if(i.requiresExposure&&!r.exposed){ml.delete(t);continue}if(r.remaining-=e,r.remaining<=0){ml.delete(t),Od(S(`status.damage`,{status:i.label.toUpperCase()}));continue}(!n||r.remaining/r.maxDuration>n.remaining/n.maxDuration)&&(n=r)}return n?qt[n.type]:null}function Ld(e,t){let n=new _(new le(.2,.58,96),new m({color:`#ff795f`,transparent:!0,opacity:1,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(e.x,.1,e.z);let r=new _(new le(.01,1,96),new m({color:`#ffbe75`,transparent:!0,opacity:.22,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.position.set(e.x,.075,e.z),K.add(n,r),Bc.push({origin:e.clone(),ring:n,glow:r,radius:Bs()*1.1,age:0,duration:2.2,targets:new Set(t),hit:new Set}),dd(e,2.1)}function Rd(){li();let e={en:`language.english`,tr:`language.turkish`,es:`language.spanish`};xr.innerHTML=Be().map(t=>`<option value="${t}">${S(e[t]??`language.${t}`,{},t)}</option>`).join(``),xr.value=V.language,Or.innerHTML=[`low`,`medium`,`high`].map(e=>`<button data-graphics-quality="${e}" class="${V.graphics.quality===e?`selected`:``}" type="button">${S(`settings.${e}`)}</button>`).join(``),kr.checked=V.graphics.shadows;let t=Math.round(V.graphics.hdrEmissionIntensity*100);Ar.value=String(t),jr.value=`${t}%`,Mr.value=V.gameplay.maxFps,Nr.value=V.gameplay.maxFps===0?S(`settings.unlimited`):`${V.gameplay.maxFps} FPS`,Pr.checked=V.gameplay.autoPause,Fr.checked=V.gameplay.highContrastHud,Ir.value=V.sound.masterVolume,Lr.value=`${V.sound.masterVolume}%`,Rr.checked=V.sound.muted,zr.checked=V.sound.spatialAudio,document.querySelector(`.game-shell`).classList.toggle(`high-contrast-hud`,V.gameplay.highContrastHud),zd()}async function zd(){if(!Sr||!Cr||!window.steamShell?.getDisplaySettings)return;let e=await window.steamShell.getDisplaySettings();Sr.innerHTML=`<button data-display-mode="fullscreen" class="${e.fullscreen?`selected`:``}" type="button">${S(`settings.fullscreen`)}</button><button data-display-mode="windowed" class="${e.fullscreen?``:`selected`}" type="button">${S(`settings.windowed`)}</button>`,Cr.innerHTML=[[1280,720],[1600,900],[1920,1080],[2560,1440]].filter(([t,n])=>t<=e.maxWidth&&n<=e.maxHeight).map(([t,n])=>`<button data-display-resolution="${t}x${n}" class="${!e.fullscreen&&e.width===t&&e.height===n?`selected`:``}" type="button">${t}×${n}</button>`).join(``)}function Bd(){Ca(),Ko.setMasterVolume(),Rd()}async function Vd(e=!1){if(e&&!Il)return;await Ko.initialize(),Ko.playButtonClick();let t=!!L;t?Cd():(R=null,pa=e?{challengeId:Wl().id,weekId:Vl()}:null,bd()),X=!0,Gc=!1,Z=!1,dn.classList.remove(`death-title`),ru(),Rn.classList.add(`hidden`),M.classList.remove(`hidden`),cn.classList.add(`hidden`),vn.classList.add(`hidden`),ys(),t||Ze({sector:F+1,buildVersion:We.version,platform:window.steamShell?`steam`:`web`})}gn.addEventListener(`click`,()=>Vd()),_n.addEventListener(`click`,Td),Tn.addEventListener(`click`,()=>vn.classList.add(`hidden`)),wn.addEventListener(`click`,()=>Vd(!0));function Hd(){Rn.classList.add(`hidden`),Br.classList.add(`hidden`),Jr.classList.add(`hidden`),ri.classList.add(`hidden`),er.classList.add(`hidden`),or.classList.add(`hidden`),Wn.classList.add(`hidden`),Jn.classList.add(`hidden`),Zn.classList.add(`hidden`),yr.classList.add(`hidden`),Er.classList.add(`hidden`),Dn.classList.add(`hidden`),vn.classList.add(`hidden`),Nn.classList.add(`hidden`)}var Ud=new Map([[Rn,zn],[Br,Vn],[er,Hn],[Wn,Un],[Jn,qn],[yr,_r]]);function Wd(e=Bn){document.querySelectorAll(`.menu-system-button`).forEach(t=>t.classList.toggle(`is-active`,t===e))}function Gd(){Hd(),M.classList.remove(`hidden`),Wd()}function Kd(e,t){Hd(),M.classList.add(`hidden`),e.classList.remove(`hidden`),Wd(Ud.get(e)),t?.()}Bn.addEventListener(`click`,e=>{e.stopPropagation(),Gd()}),zn.addEventListener(`click`,e=>{e.stopPropagation(),uo(`researchLab`,zn)&&(Ya(),Kd(Rn,Xa))}),_r.addEventListener(`click`,e=>{e.stopPropagation(),Kd(yr,Rd)}),Tr.addEventListener(`click`,()=>Kd(Er)),vr?.addEventListener(`click`,()=>{if(window.dispatchEvent(new Event(`asteroid-belt:exit-requested`)),window.steamShell?.quit){window.steamShell.quit();return}window.close()}),wr.addEventListener(`click`,()=>{yr.classList.add(`hidden`),M.classList.remove(`hidden`)}),Dr.addEventListener(`click`,()=>{Er.classList.add(`hidden`),yr.classList.remove(`hidden`)}),yr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-graphics-quality]`);t&&(V.graphics.quality=t.dataset.graphicsQuality,ts(),Bd())}),xr.addEventListener(`change`,()=>{V.language=xr.value,ze(V.language),Ca(),window.location.reload()}),yr.addEventListener(`click`,async e=>{let t=e.target.closest(`[data-display-mode]`)?.dataset.displayMode,n=e.target.closest(`[data-display-resolution]`)?.dataset.displayResolution;if(t&&window.steamShell?.setFullscreen&&await window.steamShell.setFullscreen(t===`fullscreen`),n&&window.steamShell?.setResolution){let[e,t]=n.split(`x`).map(Number);await window.steamShell.setResolution(e,t)}(t||n)&&zd()}),kr.addEventListener(`change`,()=>{V.graphics.shadows=kr.checked,ts(),Bd()}),Ar.addEventListener(`input`,()=>{V.graphics.hdrEmissionIntensity=Number(Ar.value)/100,ts(),Bd()}),Mr.addEventListener(`input`,()=>{V.gameplay.maxFps=Number(Mr.value),Bd()}),Pr.addEventListener(`change`,()=>{V.gameplay.autoPause=Pr.checked,Bd()}),Fr.addEventListener(`change`,()=>{V.gameplay.highContrastHud=Fr.checked,Bd()}),Ir.addEventListener(`input`,()=>{V.sound.masterVolume=Number(Ir.value),Bd()}),Rr.addEventListener(`change`,()=>{V.sound.muted=Rr.checked,Bd()}),zr.addEventListener(`change`,()=>{V.sound.spatialAudio=zr.checked,Bd()}),ii.addEventListener(`click`,()=>{Rn.classList.add(`hidden`),M.classList.remove(`hidden`)}),cn.addEventListener(`click`,e=>{let t=e.composedPath();!Rn.classList.contains(`hidden`)&&!t.includes(Rn)&&(Rn.classList.add(`hidden`),M.classList.remove(`hidden`)),!yr.classList.contains(`hidden`)&&!t.includes(yr)&&(yr.classList.add(`hidden`),M.classList.remove(`hidden`)),!Br.classList.contains(`hidden`)&&!t.includes(Br)&&!t.includes(Jr)&&(Jr.classList.add(`hidden`),Br.classList.add(`hidden`),M.classList.remove(`hidden`)),!er.classList.contains(`hidden`)&&or.classList.contains(`hidden`)&&!t.includes(er)&&(er.classList.add(`hidden`),M.classList.remove(`hidden`)),!Wn.classList.contains(`hidden`)&&!t.includes(Wn)&&(Wn.classList.add(`hidden`),M.classList.remove(`hidden`)),!Jn.classList.contains(`hidden`)&&!t.includes(Jn)&&!t.includes(Zn)&&(Zn.classList.add(`hidden`),Jn.classList.add(`hidden`),M.classList.remove(`hidden`),Wd())}),Vn.addEventListener(`click`,e=>{e.stopPropagation(),uo(`buildingSystem`,Vn)&&Kd(Br,Eu)}),Hn.addEventListener(`click`,e=>{e.stopPropagation(),!(X||!uo(`weaponry`,Hn))&&Kd(er,bs)}),Un.addEventListener(`click`,e=>{e.stopPropagation(),Kd(Wn,Xl)}),qn.addEventListener(`click`,e=>{e.stopPropagation(),Kd(Jn,Ro)}),Gn.addEventListener(`click`,()=>{Wn.classList.add(`hidden`),M.classList.remove(`hidden`)}),Yn.addEventListener(`click`,()=>{Zn.classList.add(`hidden`),Jn.classList.add(`hidden`),M.classList.remove(`hidden`),Wd()}),Xn.addEventListener(`click`,e=>{let t=e.target.closest(`[data-artifact-id]`);t&&zo(t.dataset.artifactId)}),$n.addEventListener(`click`,()=>Zn.classList.add(`hidden`)),tr.addEventListener(`click`,()=>{er.classList.add(`hidden`),M.classList.remove(`hidden`)}),rr.addEventListener(`click`,()=>ws(1)),ir.addEventListener(`click`,()=>ws(5)),fr.addEventListener(`click`,Ts),hr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-weapon]`);t&&Es(t.dataset.toggleWeapon)}),mr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-weapon-slot]`);X||!t||(z.selected=Number(t.dataset.selectWeaponSlot),ns(),bs())}),gr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-use-weapon]`);t&&Ds(t.dataset.useWeapon)}),Vr.addEventListener(`click`,()=>{Jr.classList.add(`hidden`),Br.classList.add(`hidden`),M.classList.remove(`hidden`)}),qr.addEventListener(`click`,()=>{pu(),Jr.classList.remove(`hidden`)}),Yr.addEventListener(`click`,()=>Jr.classList.add(`hidden`)),Kr.addEventListener(`click`,Du),ni.addEventListener(`click`,Ou),Jr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-building-offer]`);t&&du(t.dataset.buildingOffer)}),Qr.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-building]`);t&&(Oa=t.dataset.selectBuilding,Eu())}),ti.addEventListener(`click`,e=>{if(wc){wc=!1;return}let t=e.target.closest(`[data-build-x]`);t&&Tu(Number(t.dataset.buildX),Number(t.dataset.buildZ))}),ri.addEventListener(`click`,e=>{let t=e.target.closest(`[data-upgrade-building]`),n=e.target.closest(`[data-destroy-building]`);if(e.target.closest(`[data-close-building-upgrade]`)){ri.classList.add(`hidden`);return}if(n){let e=B.placed.find(e=>e.id===n.dataset.destroyBuilding);if(!e||!window.confirm(S(`building.demolish_confirm`,{building:$e.types[e.type].name,refund:E(_u(e))})))return;Co(_u(e)),B.placed=B.placed.filter(t=>t.id!==e.id),su(),yu(),Eu(),ri.classList.add(`hidden`);return}if(t){let e=B.placed.find(e=>e.id===t.dataset.upgradeBuilding);if(!e)return;let n=gu(e,t.dataset.upgradeKey);if(da<n)return;Co(-n),e.upgrades[t.dataset.upgradeKey]=(e.upgrades[t.dataset.upgradeKey]??0)+1,e.spent=(e.spent??$e.types[e.type].baseCost)+n,su(),yu(),ku(e)}}),Rn.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-research-category]`),n=e.target.closest(`[data-start-research]`),r=e.target.closest(`[data-unlock-slot]`);if(t){let e=t.dataset.toggleResearchCategory;Ma.has(e)?Ma.delete(e):Ma.add(e),Xa();return}n&&Za(n.dataset.startResearch),r&&Qa(Number.parseInt(r.dataset.unlockSlot,10))}),pi.addEventListener(`input`,()=>{ka=pi.value,Xa()}),mi.addEventListener(`change`,()=>{Aa=mi.checked,Xa()}),hi.addEventListener(`change`,()=>{ja=hi.checked,Xa()}),xi.addEventListener(`click`,()=>{Sd(),bd(!R),Z=!1,X=!0,bi.classList.add(`hidden`)}),Si.addEventListener(`click`,()=>{Da&&Ou(),Sd(),R=null,pa=null,bd(!0),Z=!1,X=!1,Gc=!1,bi.classList.add(`hidden`),gr.classList.add(`hidden`),dn.textContent=`ASTEROID BELT`,dn.classList.remove(`death-title`),ru(),mn.textContent=S(`message.run_surrendered`),hn.hidden=!0,Gd(),cn.classList.remove(`hidden`)}),Ci.addEventListener(`click`,()=>{Z=!1,bi.classList.add(`hidden`)}),wi.addEventListener(`click`,Ed),sn.addEventListener(`click`,()=>{X&&(Z=!Z,bi.classList.toggle(`hidden`,!Z))}),document.addEventListener(`click`,e=>{if(bi.classList.contains(`hidden`))return;let t=e.composedPath();t.includes(bi)||t.includes(sn)||(Z=!1,bi.classList.add(`hidden`))}),yi.addEventListener(`click`,()=>$a(!1)),_i.addEventListener(`keydown`,e=>{e.key===`Enter`&&(e.preventDefault(),yo(_i.value),_i.value=``),e.key===`Escape`&&(e.preventDefault(),$a(!1)),e.stopPropagation()}),window.addEventListener(`keydown`,e=>{if(gi.classList.contains(`hidden`)){if(e.key===`Escape`&&X){e.preventDefault(),Z=!Z,bi.classList.toggle(`hidden`,!Z);return}if(Ue.enabled&&e.key===Ue.hotkey){e.preventDefault(),$a();return}if(X&&!Z&&e.code===`ArrowUp`){e.preventDefault(),z.selected=(z.selected-1+Math.max(z.loadout.length,1))%Math.max(z.loadout.length,1),ys();return}if(X&&!Z&&e.code===`ArrowDown`){e.preventDefault(),z.selected=(z.selected+1)%Math.max(z.loadout.length,1),ys();return}if(X&&!Z&&e.code===`Space`){e.preventDefault(),Ds();return}[`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`].includes(e.code)&&e.preventDefault(),pc.add(e.code)}}),window.addEventListener(`keyup`,e=>pc.delete(e.code));function qd(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches}function Jd(){let[e,t]=Sc.values();return Math.hypot(e.x-t.x,e.y-t.y)}function Yd(e){return!Da||!qd()||e.button!==0?!1:(e.preventDefault(),Sc.set(e.pointerId,{x:e.clientX,y:e.clientY}),Sc.size===2&&(Cc={distance:Jd(),height:xc}),!0)}function Xd(e){let t=Sc.get(e.pointerId);if(!t||!Da)return;e.preventDefault();let r={x:e.clientX,y:e.clientY};if(Sc.set(e.pointerId,r),Sc.size===1){let e=r.x-t.x,i=r.y-t.y;if(Math.hypot(e,i)<.5)return;let a=2*xc*Math.tan(n.degToRad(Te.fov/2));bc.x-=e/window.innerWidth*a*js.aspect,bc.y-=i/window.innerHeight*a,wc=!0}else if(Sc.size===2&&Cc){let e=Jd();e>0&&(xc=n.clamp(Cc.height*Cc.distance/e,vc,yc)),wc=!0}}function Zd(e){Sc.delete(e.pointerId)&&(Sc.size<2&&(Cc=null),wc&&window.setTimeout(()=>{wc=!1},250))}function Qd(){let e=window.matchMedia(`(hover: none) and (pointer: coarse) and (orientation: portrait)`).matches;return Te.distance*(e?Te.portraitDistanceMultiplier:1)}function $d(){return Qd()*Math.tan(n.degToRad(Te.angle))}function ef(e){if(!gc)return;let t=e.clientX-gc.x,n=e.clientY-gc.y,r=Math.hypot(t,n),i=Math.min(r,_c),a=r?i/r:0,o=t*a,s=n*a,c=r<8?0:i/_c;mc.set(o/_c*c,s/_c*c),Ni.querySelector(`.virtual-joystick-knob`).style.transform=`translate(${o}px, ${s}px)`}function tf(e){e&&e.pointerId!==hc||(hc=null,gc=null,mc.set(0,0),Ni.classList.remove(`active`),Ni.querySelector(`.virtual-joystick-knob`).style.transform=``)}$t.addEventListener(`pointerdown`,e=>{if(Da){Yd(e);return}!qd()||!X||Z||e.button!==0||hc!==null||(e.preventDefault(),hc=e.pointerId,gc={x:e.clientX,y:e.clientY},Ni.style.left=`${e.clientX}px`,Ni.style.top=`${e.clientY}px`,Ni.classList.add(`active`),$t.setPointerCapture(e.pointerId),ef(e))}),$t.addEventListener(`pointermove`,e=>{e.pointerId===hc&&(e.preventDefault(),ef(e))}),$t.addEventListener(`pointerup`,tf),$t.addEventListener(`pointercancel`,tf),$t.addEventListener(`lostpointercapture`,tf),ti.addEventListener(`pointerdown`,Yd),window.addEventListener(`pointermove`,Xd,{passive:!1}),window.addEventListener(`pointerup`,Zd),window.addEventListener(`pointercancel`,Zd),window.addEventListener(`blur`,()=>{pc.clear(),tf()}),document.addEventListener(`visibilitychange`,()=>{!document.hidden||!V.gameplay.autoPause||!X||Z||(Z=!0,bi.classList.remove(`hidden`))}),window.addEventListener(`resize`,()=>{fo(),js.aspect=window.innerWidth/window.innerHeight,js.updateProjectionMatrix(),qo.setSize(window.innerWidth,window.innerHeight),Jo.setSize(window.innerWidth,window.innerHeight),Da&&Cu()}),un?.addEventListener(`click`,e=>{let t=Number(e.target.closest(`[data-save-slot]`)?.dataset.saveSlot);!Number.isInteger(t)||t<1||t>Ri||(localStorage.setItem(Ii,String(t)),sessionStorage.setItem(Li,String(t)),window.location.reload())});async function nf(){}Hs(),yu(),Ja(),So(),Co(),wo(),Go(),Xa(),Rd(),Mo(),Ro(),Fo(),wd(),Wd(),bd(),ln&&(ln.hidden=!0),nf(),Pd(),setInterval(()=>{(Ja()||!Rn.classList.contains(`hidden`))&&Xa()},1e3);