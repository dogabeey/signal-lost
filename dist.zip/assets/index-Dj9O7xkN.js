import{t as e}from"./rolldown-runtime-DK3Fl9T5.js";import{$ as t,A as n,B as r,C as i,D as a,E as o,F as s,G as c,H as l,I as u,J as d,K as f,L as p,M as m,N as h,O as g,P as _,Q as v,R as y,S as b,T as x,U as S,V as C,W as w,X as T,Y as ee,Z as te,_ as ne,_t as re,a as ie,at as ae,b as oe,bt as se,c as ce,ct as le,d as ue,dt as de,et as fe,f as pe,ft as me,g as he,gt as ge,h as _e,ht as ve,i as ye,it as be,j as xe,k as Se,l as Ce,lt as we,m as Te,mt as Ee,n as De,nt as Oe,o as ke,ot as Ae,p as je,pt as Me,q as Ne,r as Pe,rt as Fe,s as Ie,st as Le,t as Re,tt as ze,u as Be,ut as Ve,v as He,vt as Ue,w as We,x as Ge,y as Ke,yt as E,z as qe}from"./three--l62wOBY.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var Je=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),Ye=1234567,Xe=Math.PI/180,Ze=180/Math.PI;function Qe(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(Je[e&255]+Je[e>>8&255]+Je[e>>16&255]+Je[e>>24&255]+`-`+Je[t&255]+Je[t>>8&255]+`-`+Je[t>>16&15|64]+Je[t>>24&255]+`-`+Je[n&63|128]+Je[n>>8&255]+`-`+Je[n>>16&255]+Je[n>>24&255]+Je[r&255]+Je[r>>8&255]+Je[r>>16&255]+Je[r>>24&255]).toLowerCase()}function $e(e,t,n){return Math.max(t,Math.min(n,e))}function et(e,t){return(e%t+t)%t}function tt(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function nt(e,t,n){return e===t?0:(n-e)/(t-e)}function rt(e,t,n){return(1-n)*e+n*t}function it(e,t,n,r){return rt(e,t,1-Math.exp(-n*r))}function at(e,t=1){return t-Math.abs(et(e,t*2)-t)}function ot(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function st(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function ct(e,t){return e+Math.floor(Math.random()*(t-e+1))}function lt(e,t){return e+Math.random()*(t-e)}function ut(e){return e*(.5-Math.random())}function dt(e){e!==void 0&&(Ye=e);let t=Ye+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function ft(e){return e*Xe}function pt(e){return e*Ze}function mt(e){return!(e&e-1)&&e!==0}function ht(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function gt(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function _t(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),l=a((t+r)/2),u=o((t+r)/2),d=a((t-r)/2),f=o((t-r)/2),p=a((r-t)/2),m=o((r-t)/2);switch(i){case`XYX`:e.set(s*u,c*d,c*f,s*l);break;case`YZY`:e.set(c*f,s*u,c*d,s*l);break;case`ZXZ`:e.set(c*d,c*f,s*u,s*l);break;case`XZX`:e.set(s*u,c*m,c*p,s*l);break;case`YXY`:e.set(c*p,s*u,c*m,s*l);break;case`ZYZ`:e.set(c*m,c*p,s*u,s*l);break;default:console.warn(`../math.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function vt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`Invalid component type.`)}}function yt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`Invalid component type.`)}}var bt={DEG2RAD:Xe,RAD2DEG:Ze,generateUUID:Qe,clamp:$e,euclideanModulo:et,mapLinear:tt,inverseLerp:nt,lerp:rt,damp:it,pingpong:at,smoothstep:ot,smootherstep:st,randInt:ct,randFloat:lt,randFloatSpread:ut,seededRandom:dt,degToRad:ft,radToDeg:pt,isPowerOfTwo:mt,ceilPowerOfTwo:ht,floorPowerOfTwo:gt,setQuaternionFromProperEuler:_t,normalize:yt,denormalize:vt},D=class e{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(o===0){e[t+0]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u;return}if(o===1){e[t+0]=d,e[t+1]=f,e[t+2]=p,e[t+3]=m;return}if(u!==m||s!==d||c!==f||l!==p){let e=1-o,t=s*d+c*f+l*p+u*m,n=t>=0?1:-1,r=1-t*t;if(r>2**-52){let i=Math.sqrt(r),a=Math.atan2(i,t*n);e=Math.sin(e*a)/i,o=Math.sin(o*a)/i}let i=o*n;if(s=s*e+d*i,c=c*e+f*i,l=l*e+p*i,u=u*e+m*i,e===1-o){let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new e(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:console.warn(`../math.Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<2**-52?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs($e(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,r=this._y,i=this._z,a=this._w,o=a*e._w+n*e._x+r*e._y+i*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=r,this._z=i,this;let s=1-o*o;if(s<=2**-52){let e=1-t;return this._w=e*a+t*this._w,this._x=e*n+t*this._x,this._y=e*r+t*this._y,this._z=e*i+t*this._z,this.normalize(),this}let c=Math.sqrt(s),l=Math.atan2(c,o),u=Math.sin((1-t)*l)/c,d=Math.sin(t*l)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=r*u+this._y*d,this._z=i*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},O=class e{constructor(t=0,n=0,r=0){this.isVector3=!0,e.prototype.isVector3=!0,this.x=t,this.y=n,this.z=r}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(St.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(St.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return xt.copy(this).projectOnVector(e),this.sub(xt)}reflect(e){return this.sub(xt.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($e(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}abs(){return this.x=Math.abs(this.x),this.y=Math.abs(this.y),this.z=Math.abs(this.z),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},xt=new O,St=new D,Ct=2e3,wt=2001,Tt=class e{constructor(t,n,r,i,a,o,s,c,l,u,d,f,p,m,h,g){this.isMatrix4=!0,e.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,n,r,i,a,o,s,c,l,u,d,f,p,m,h,g)}extractPosition(e){return console.warn(`THREE.Matrix4: .extractPosition() has been renamed to .copyPosition().`),this.copyPosition(e)}multiplyToArray(e,t,n){return console.error(`THREE.Matrix4: .multiplyToArray() has been removed.`),this}setRotationFromQuaternion(e){return this.makeRotationFromQuaternion(e)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,r=1/Et.setFromMatrixColumn(e,0).length(),i=1/Et.setFromMatrixColumn(e,1).length(),a=1/Et.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Ot,e,kt)}lookAt(e,t,n){let r=this.elements;return Mt.subVectors(e,t),Mt.lengthSq()===0&&(Mt.z=1),Mt.normalize(),At.crossVectors(n,Mt),At.lengthSq()===0&&(Math.abs(n.z)===1?Mt.x+=1e-4:Mt.z+=1e-4,Mt.normalize(),At.crossVectors(n,Mt)),At.normalize(),jt.crossVectors(Mt,At),r[0]=At.x,r[4]=jt.x,r[8]=Mt.x,r[1]=At.y,r[5]=jt.y,r[9]=Mt.y,r[2]=At.z,r[6]=jt.z,r[10]=Mt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],ee=r[5],te=r[9],ne=r[13],re=r[2],ie=r[6],ae=r[10],oe=r[14],se=r[3],ce=r[7],le=r[11],ue=r[15];return i[0]=a*x+o*T+s*re+c*se,i[4]=a*S+o*ee+s*ie+c*ce,i[8]=a*C+o*te+s*ae+c*le,i[12]=a*w+o*ne+s*oe+c*ue,i[1]=l*x+u*T+d*re+f*se,i[5]=l*S+u*ee+d*ie+f*ce,i[9]=l*C+u*te+d*ae+f*le,i[13]=l*w+u*ne+d*oe+f*ue,i[2]=p*x+m*T+h*re+g*se,i[6]=p*S+m*ee+h*ie+g*ce,i[10]=p*C+m*te+h*ae+g*le,i[14]=p*w+m*ne+h*oe+g*ue,i[3]=_*x+v*T+y*re+b*se,i[7]=_*S+v*ee+y*ie+b*ce,i[11]=_*C+v*te+y*ae+b*le,i[15]=_*w+v*ne+y*oe+b*ue,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15];return p*(+i*s*u-r*c*u-i*o*d+n*c*d+r*o*f-n*s*f)+m*(+t*s*f-t*c*d+i*a*d-r*a*f+r*c*l-i*s*l)+h*(+t*c*u-t*o*f-i*a*u+n*a*f+i*o*l-n*c*l)+g*(-r*o*l-t*s*u+t*o*d+r*a*u-n*a*d+n*s*l)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=u*h*c-m*d*c+m*s*f-o*h*f-u*s*g+o*d*g,v=p*d*c-l*h*c-p*s*f+a*h*f+l*s*g-a*d*g,y=l*m*c-p*u*c+p*o*f-a*m*f-l*o*g+a*u*g,b=p*u*s-l*m*s-p*o*d+a*m*d+l*o*h-a*u*h,x=t*_+n*v+r*y+i*b;if(x===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let S=1/x;return e[0]=_*S,e[1]=(m*d*i-u*h*i-m*r*f+n*h*f+u*r*g-n*d*g)*S,e[2]=(o*h*i-m*s*i+m*r*c-n*h*c-o*r*g+n*s*g)*S,e[3]=(u*s*i-o*d*i-u*r*c+n*d*c+o*r*f-n*s*f)*S,e[4]=v*S,e[5]=(l*h*i-p*d*i+p*r*f-t*h*f-l*r*g+t*d*g)*S,e[6]=(p*s*i-a*h*i-p*r*c+t*h*c+a*r*g-t*s*g)*S,e[7]=(a*d*i-l*s*i+l*r*c-t*d*c-a*r*f+t*s*f)*S,e[8]=y*S,e[9]=(p*u*i-l*m*i-p*n*f+t*m*f+l*n*g-t*u*g)*S,e[10]=(a*m*i-p*o*i+p*n*c-t*m*c-a*n*g+t*o*g)*S,e[11]=(l*o*i-a*u*i-l*n*c+t*u*c+a*n*f-t*o*f)*S,e[12]=b*S,e[13]=(l*m*r-p*u*r+p*n*d-t*m*d-l*n*h+t*u*h)*S,e[14]=(p*o*r-a*m*r-p*n*s+t*m*s+a*n*h-t*o*h)*S,e[15]=(a*u*r-l*o*r+l*n*s-t*u*s-a*n*d+t*o*d)*S,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements,i=Et.set(r[0],r[1],r[2]).length(),a=Et.set(r[4],r[5],r[6]).length(),o=Et.set(r[8],r[9],r[10]).length();this.determinant()<0&&(i=-i),e.x=r[12],e.y=r[13],e.z=r[14],Dt.copy(this);let s=1/i,c=1/a,l=1/o;return Dt.elements[0]*=s,Dt.elements[1]*=s,Dt.elements[2]*=s,Dt.elements[4]*=c,Dt.elements[5]*=c,Dt.elements[6]*=c,Dt.elements[8]*=l,Dt.elements[9]*=l,Dt.elements[10]*=l,t.setFromRotationMatrix(Dt),n.x=i,n.y=a,n.z=o,this}makePerspective(e,t,n,r,i,a,o=Ct){let s=this.elements,c=2*i/(t-e),l=2*i/(n-r),u=(t+e)/(t-e),d=(n+r)/(n-r),f,p;if(o===2e3)f=-(a+i)/(a-i),p=-2*a*i/(a-i);else if(o===2001)f=-a/(a-i),p=-a*i/(a-i);else throw Error(`Matrix4.makePerspective(): Invalid coordinate system: `+o);return s[0]=c,s[4]=0,s[8]=u,s[12]=0,s[1]=0,s[5]=l,s[9]=d,s[13]=0,s[2]=0,s[6]=0,s[10]=f,s[14]=p,s[3]=0,s[7]=0,s[11]=-1,s[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=Ct){let s=this.elements,c=1/(t-e),l=1/(n-r),u=1/(a-i),d=(t+e)*c,f=(n+r)*l,p,m;if(o===2e3)p=(a+i)*u,m=-2*u;else if(o===2001)p=i*u,m=-1*u;else throw Error(`../math.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return s[0]=2*c,s[4]=0,s[8]=0,s[12]=-d,s[1]=0,s[5]=2*l,s[9]=0,s[13]=-f,s[2]=0,s[6]=0,s[10]=m,s[14]=-p,s[3]=0,s[7]=0,s[11]=0,s[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Et=new O,Dt=new Tt,Ot=new O(0,0,0),kt=new O(1,1,1),At=new O,jt=new O,Mt=new O,Nt=new Tt,Pt=new D,Ft=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new e(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin($e(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-$e(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin($e(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-$e(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin($e(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-$e(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:console.warn(`../math.Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Nt.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Nt,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Pt.setFromEuler(this),this.setFromQuaternion(Pt,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(e){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Ft.DEFAULT_ORDER=`XYZ`;var It=class e{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($e(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};It.isVector2=!0;var Lt=class e{constructor(t=0,n=0,r=0,i=1){e.prototype.isVector4=!0,this.x=t,this.y=n,this.z=r,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Rt=class e{constructor(t,n,r,i,a,o,s,c,l){e.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,n,r,i,a,o,s,c,l)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(zt.makeScale(e,t)),this}rotate(e){return this.premultiply(zt.makeRotation(-e)),this}translate(e,t){return this.premultiply(zt.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new e().fromArray(this.elements)}},zt=new Rt,Bt;(function(e){e[e.Random=0]=`Random`,e[e.Loop=1]=`Loop`,e[e.PingPong=2]=`PingPong`,e[e.Burst=3]=`Burst`})(Bt||={});function Vt(e,t,n,r){let i;switch(Bt.Random===e?t=Math.random():Bt.Burst===e&&r.isBursting&&(t=r.burstParticleIndex/r.burstParticleCount),i=n>0?Math.floor(t/n)*n:t,e){case Bt.Loop:i%=1;break;case Bt.PingPong:i=Math.abs(i%2-1)}return i}var Ht=class e{constructor(e,t,n,r){this.p=[e,t,n,r]}genValue(e){let t=e*e,n=e*e*e,r=1-e,i=r*r,a=i*r;return this.p[0]*a+this.p[1]*i*e*3+this.p[2]*r*t*3+this.p[3]*n}derivativeCoefficients(e){let t=[];for(let n=e,r=n.length-1;r>0;r--){let e=[];for(let t=0;t<r;t++){let i=r*(n[t+1]-n[t]);e.push(i)}t.push(e),n=e}return t}getSlope(e){let t=this.derivativeCoefficients(this.p)[0],n=1-e,r=n*n,i=n*e*2,a=e*e;return r*t[0]+i*t[1]+a*t[2]}controlCurve(e,t){this.p[1]=e/3+this.p[0],this.p[2]=this.p[3]-t/3}hull(e){let t=this.p,n=[],r,i=0,a=0,o=0,s=[];for(s[i++]=t[0],s[i++]=t[1],s[i++]=t[2],s[i++]=t[3];t.length>1;){for(n=[],a=0,o=t.length-1;a<o;a++)r=e*t[a]+(1-e)*t[a+1],s[i++]=r,n.push(r);t=n}return s}split(t){let n=this.hull(t);return{left:new e(n[0],n[4],n[7],n[9]),right:new e(n[9],n[8],n[6],n[3]),span:n}}clone(){return new e(this.p[0],this.p[1],this.p[2],this.p[3])}toJSON(){return{p0:this.p[0],p1:this.p[1],p2:this.p[2],p3:this.p[3]}}static fromJSON(t){return new e(t.p0,t.p1,t.p2,t.p3)}},Ut=e=>({r:e.x,g:e.y,b:e.z,a:e.w}),Wt=e=>new Lt(e.r,e.g,e.b,e.a),Gt=(e,t)=>{switch(t){case`Vector3`:return new O(e.x,e.y,e.z);case`Vector4`:return new Lt(e.x,e.y,e.z,e.w);case`Color`:return new O(e.r,e.g,e.b);case`Number`:return e;default:return e}},Kt=(e,t)=>{switch(t){case`Vector3`:return{x:e.x,y:e.y,z:e.z};case`Vector4`:return{x:e.x,y:e.y,z:e.z,w:e.w};case`Color`:return{r:e.x,g:e.y,b:e.z};case`Number`:return e;default:return e}},qt=class e{constructor(e,t){this.a=e,this.b=t,this.type=`value`}startGen(e){}genColor(e,t){let n=Math.random();return t.copy(this.a).lerp(this.b,n)}toJSON(){return{type:`RandomColor`,a:Ut(this.a),b:Ut(this.b)}}static fromJSON(t){return new e(Wt(t.a),Wt(t.b))}clone(){return new e(this.a.clone(),this.b.clone())}},Jt=class e{constructor(e,t){this.a=e,this.b=t,this.indexCount=-1,this.type=`value`}startGen(e){this.indexCount=e.length,e.push(Math.random())}genColor(e,t){return this.indexCount===-1&&this.startGen(e),t.copy(this.a).lerp(this.b,e[this.indexCount])}toJSON(){return{type:`ColorRange`,a:Ut(this.a),b:Ut(this.b)}}static fromJSON(t){return new e(Wt(t.a),Wt(t.b))}clone(){return new e(this.a.clone(),this.b.clone())}},Yt=class e{constructor(e,t){this.subType=t,this.type=`function`,this.keys=e}findKey(e){let t=0,n=0,r=this.keys.length-1;for(;n+1<r;)if(t=Math.floor((n+r)/2),e<this.getStartX(t))r=t-1;else if(e>this.getEndX(t))n=t+1;else return t;for(let t=n;t<=r;t++)if(e>=this.getStartX(t)&&e<=this.getEndX(t))return t;return-1}getStartX(e){return this.keys[e][1]}getEndX(e){return e+1<this.keys.length?this.keys[e+1][1]:1}genValue(e,t){let n=this.findKey(t);return this.subType===`Number`?n===-1?this.keys[0][0]:n+1>=this.keys.length?this.keys[this.keys.length-1][0]:(this.keys[n+1][0]-this.keys[n][0])*((t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))+this.keys[n][0]:n===-1?e.copy(this.keys[0][0]):n+1>=this.keys.length?e.copy(this.keys[this.keys.length-1][0]):e.copy(this.keys[n][0]).lerp(this.keys[n+1][0],(t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))}toJSON(){return this.keys[0][0].constructor.name,{type:`CLinearFunction`,subType:this.subType,keys:this.keys.map(([e,t])=>({value:Kt(e,this.subType),pos:t}))}}static fromJSON(t){return new e(t.keys.map(e=>[Gt(e.value,t.subType),e.pos]),t.subType)}clone(){return this.subType===`Number`?new e(this.keys.map(([e,t])=>[e,t]),this.subType):new e(this.keys.map(([e,t])=>[e.clone(),t]),this.subType)}},Xt=new O,Zt=class e{constructor(e=[[new O(0,0,0),0],[new O(1,1,1),0]],t=[[1,0],[1,1]]){this.type=`function`,this.color=new Yt(e,`Color`),this.alpha=new Yt(t,`Number`)}genColor(e,t,n){return this.color.genValue(Xt,n),t.set(Xt.x,Xt.y,Xt.z,this.alpha.genValue(1,n))}toJSON(){return{type:`Gradient`,color:this.color.toJSON(),alpha:this.alpha.toJSON()}}static fromJSON(t){if(t.functions){let n=t.functions.map(e=>[Jt.fromJSON(e.function).a,e.start]);return t.functions.length>0&&n.push([Jt.fromJSON(t.functions[t.functions.length-1].function).b,1]),new e(n.map(e=>[new O(e[0].x,e[0].y,e[0].z),e[1]]),n.map(e=>[e[0].w,e[1]]))}{let n=new e;return n.alpha=Yt.fromJSON(t.alpha),n.color=Yt.fromJSON(t.color),n}}clone(){let t=new e;return t.alpha=this.alpha.clone(),t.color=this.color.clone(),t}startGen(e){}},Qt=new Lt,$t=class e{constructor(e,t){this.indexCount=0,this.type=`function`,this.gradient1=e,this.gradient2=t}startGen(e){this.indexCount=e.length,e.push(Math.random())}genColor(e,t,n){return this.gradient1.genColor(e,t,n),this.gradient2.genColor(e,Qt,n),e&&e[this.indexCount]!==void 0?t.lerp(Qt,e[this.indexCount]):t.lerp(Qt,Math.random()),t}toJSON(){return{type:`RandomColorBetweenGradient`,gradient1:this.gradient1.toJSON(),gradient2:this.gradient2.toJSON()}}static fromJSON(t){return new e(Zt.fromJSON(t.gradient1),Zt.fromJSON(t.gradient2))}clone(){return new e(this.gradient1.clone(),this.gradient2.clone())}},en=class e{constructor(e){this.color=e,this.type=`value`}startGen(e){}genColor(e,t){return t.copy(this.color)}toJSON(){return{type:`ConstantColor`,color:Ut(this.color)}}static fromJSON(t){return new e(Wt(t.color))}clone(){return new e(this.color.clone())}};function tn(e){switch(e.type){case`ConstantColor`:return en.fromJSON(e);case`ColorRange`:return Jt.fromJSON(e);case`RandomColor`:return qt.fromJSON(e);case`Gradient`:return Zt.fromJSON(e);case`RandomColorBetweenGradient`:return $t.fromJSON(e);default:return new en(new Lt(1,1,1,1))}}var k=class e{constructor(e){this.value=e,this.type=`value`}startGen(e){}genValue(e){return this.value}toJSON(){return{type:`ConstantValue`,value:this.value}}static fromJSON(t){return new e(t.value)}clone(){return new e(this.value)}},nn=class e{constructor(e,t){this.a=e,this.b=t,this.indexCount=-1,this.type=`value`}startGen(e){this.indexCount=e.length,e.push(Math.random())}genValue(e){return this.indexCount===-1&&this.startGen(e),bt.lerp(this.a,this.b,e[this.indexCount])}toJSON(){return{type:`IntervalValue`,a:this.a,b:this.b}}static fromJSON(t){return new e(t.a,t.b)}clone(){return new e(this.a,this.b)}},rn=class{constructor(){this.functions=[]}findFunction(e){let t=0,n=0,r=this.functions.length-1;for(;n+1<r;)if(t=Math.floor((n+r)/2),e<this.getStartX(t))r=t-1;else if(e>this.getEndX(t))n=t+1;else return t;for(let t=n;t<=r;t++)if(e>=this.functions[t][1]&&e<=this.getEndX(t))return t;return-1}getStartX(e){return this.functions[e][1]}setStartX(e,t){e>0&&(this.functions[e][1]=t)}getEndX(e){return e+1<this.functions.length?this.functions[e+1][1]:1}setEndX(e,t){e+1<this.functions.length&&(this.functions[e+1][1]=t)}insertFunction(e,t){let n=this.findFunction(e);this.functions.splice(n+1,0,[t,e])}removeFunction(e){return this.functions.splice(e,1)[0][0]}getFunction(e){return this.functions[e][0]}setFunction(e,t){this.functions[e][0]=t}get numOfFunctions(){return this.functions.length}},an=class e extends rn{constructor(e=[[new Ht(0,1/3,1/3*2,1),0]]){super(),this.type=`function`,this.functions=e}genValue(e,t=0){let n=this.findFunction(t);return n===-1?0:this.functions[n][0].genValue((t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))}toSVG(e,t){if(t<1)return``;let n=[`M`,0,this.functions[0][0].p[0]].join(` `);for(let r=1/t;r<=1;r+=1/t)n=[n,`L`,r*e,this.genValue(void 0,r)].join(` `);return n}toJSON(){return{type:`PiecewiseBezier`,functions:this.functions.map(([e,t])=>({function:e.toJSON(),start:t}))}}static fromJSON(t){return new e(t.functions.map(e=>[Ht.fromJSON(e.function),e.start]))}clone(){return new e(this.functions.map(([e,t])=>[e.clone(),t]))}startGen(e){}};function A(e){switch(e.type){case`ConstantValue`:return k.fromJSON(e);case`IntervalValue`:return nn.fromJSON(e);case`PiecewiseBezier`:return an.fromJSON(e);default:return new k(0)}}var on=class e{constructor(){this.indexCount=0,this.type=`rotation`}startGen(e){this.indexCount=e.length,e.push(new D);let t,n,r,i,a,o;do t=Math.random()*2-1,n=Math.random()*2-1,r=t*t+n*n;while(r>1);do i=Math.random()*2-1,a=Math.random()*2-1,o=i*i+a*a;while(o>1);let s=Math.sqrt((1-r)/o);e[this.indexCount].set(t,n,s*i,s*a)}genValue(e,t,n,r){return this.indexCount===-1&&this.startGen(e),t.copy(e[this.indexCount]),t}toJSON(){return{type:`RandomQuat`}}static fromJSON(t){return new e}clone(){return new e}},sn=class e{constructor(e,t){this.axis=e,this.angle=t,this.type=`rotation`}startGen(e){this.angle.startGen(e)}genValue(e,t,n,r){return t.setFromAxisAngle(this.axis,this.angle.genValue(e,r)*n)}toJSON(){return{type:`AxisAngle`,axis:{x:this.axis.x,y:this.axis.y,z:this.axis.z},angle:this.angle.toJSON()}}static fromJSON(t){return new e(new O(t.axis.x,t.axis.y,t.axis.z),A(t.angle))}clone(){return new e(this.axis.clone(),this.angle.clone())}},cn=class e{constructor(e,t,n,r){this.angleX=e,this.angleY=t,this.angleZ=n,this.type=`rotation`,this.eular=new Ft(0,0,0,r)}startGen(e){this.angleX.startGen(e),this.angleY.startGen(e),this.angleZ.startGen(e)}genValue(e,t,n,r){return this.eular.set(this.angleX.genValue(e,r)*n,this.angleY.genValue(e,r)*n,this.angleZ.genValue(e,r)*n),t.setFromEuler(this.eular)}toJSON(){return{type:`Euler`,angleX:this.angleX.toJSON(),angleY:this.angleY.toJSON(),angleZ:this.angleZ.toJSON(),eulerOrder:this.eular.order}}static fromJSON(t){return new e(A(t.angleX),A(t.angleY),A(t.angleZ),t.eulerOrder)}clone(){return new e(this.angleX,this.angleY,this.angleZ,this.eular.order)}};function ln(e){switch(e.type){case`AxisAngle`:return sn.fromJSON(e);case`Euler`:return cn.fromJSON(e);case`RandomQuat`:return on.fromJSON(e);default:return new on}}var un=class e{constructor(e,t,n){this.x=e,this.y=t,this.z=n,this.type=`vec3function`}startGen(e){this.x.startGen(e),this.y.startGen(e),this.z.startGen(e)}genValue(e,t,n){return t.set(this.x.genValue(e,n),this.y.genValue(e,n),this.z.genValue(e,n))}toJSON(){return{type:`Vector3Function`,x:this.x.toJSON(),y:this.y.toJSON(),z:this.z.toJSON()}}static fromJSON(t){return new e(A(t.x),A(t.y),A(t.z))}clone(){return new e(this.x,this.y,this.z)}};function dn(e){switch(e.type){case`Vector3Function`:return un.fromJSON(e);default:return new un(new k(0),new k(0),new k(0))}}function fn(e){switch(e.type){case`ConstantValue`:case`IntervalValue`:case`PiecewiseBezier`:return A(e);case`AxisAngle`:case`RandomQuat`:case`Euler`:return ln(e);case`Vector3Function`:return dn(e);default:return new k(0)}}var pn=class e{constructor(e={}){this.type=`cone`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.angle=e.angle??Math.PI/6,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[]}update(e,t){Bt.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t),r=bt.lerp(1-this.thickness,1,Math.random()),i=n*this.arc,a=Math.sqrt(r),o=Math.sin(i),s=Math.cos(i);e.position.x=a*s,e.position.y=a*o,e.position.z=0;let c=this.angle*a;e.velocity.set(0,0,Math.cos(c)).addScaledVector(e.position,Math.sin(c)).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius)}toJSON(){return{type:`cone`,radius:this.radius,arc:this.arc,thickness:this.thickness,angle:this.angle,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,angle:t.angle,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,angle:this.angle,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},mn=class e{constructor(e={}){this.type=`circle`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[]}update(e,t){this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t),r=bt.lerp(1-this.thickness,1,Math.random()),i=n*this.arc;e.position.x=Math.cos(i),e.position.y=Math.sin(i),e.position.z=0,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*r)}toJSON(){return{type:`circle`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}};function hn(e,t){return Math.floor(Math.random()*(t-e))+e}var gn=new O(0,1,0),_n=new O(0,0,0),vn=new O(1,1,1),yn=new O(0,0,1),bn=class e{constructor(e={}){this.type=`donut`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.donutRadius=e.donutRadius??this.radius*.2,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[],this._m1=new Tt}update(e,t){Bt.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=bt.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=r*Math.PI*2,s=Math.sin(a),c=Math.cos(a);if(e.position.x=this.radius*c,e.position.y=this.radius*s,e.position.z=0,e.velocity.z=this.donutRadius*i*Math.sin(o),e.velocity.x=this.donutRadius*i*Math.cos(o)*c,e.velocity.y=this.donutRadius*i*Math.cos(o)*s,e.position.add(e.velocity),e.velocity.normalize().multiplyScalar(e.startSpeed),e.rotation instanceof D){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(_n,e.velocity,gn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`donut`,radius:this.radius,arc:this.arc,thickness:this.thickness,donutRadius:this.donutRadius,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,donutRadius:t.donutRadius,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,donutRadius:this.donutRadius,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},xn=class e{constructor(){this.type=`point`,this._m1=new Tt}update(e,t){}initialize(e){let t=Math.random(),n=Math.random(),r=t*Math.PI*2,i=Math.acos(2*n-1),a=Math.cbrt(Math.random()),o=Math.sin(r),s=Math.cos(r),c=Math.sin(i),l=Math.cos(i);if(e.velocity.x=a*c*s,e.velocity.y=a*c*o,e.velocity.z=a*l,e.velocity.multiplyScalar(e.startSpeed),e.position.setScalar(0),e.rotation instanceof D){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(_n,e.velocity,gn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`point`}}static fromJSON(t){return new e}clone(){return new e}},Sn=class e{constructor(e={}){this.type=`sphere`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[],this._m1=new Tt}update(e,t){Bt.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=bt.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=Math.acos(2*r-1),s=Math.sin(a),c=Math.cos(a),l=Math.sin(o),u=Math.cos(o);if(e.position.x=l*c,e.position.y=l*s,e.position.z=u,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*i),e.rotation instanceof D){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(_n,e.position,gn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`sphere`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},Cn=class e{constructor(e={}){this.type=`hemisphere`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[],this._m1=new Tt}update(e,t){Bt.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=bt.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=Math.acos(r),s=Math.sin(a),c=Math.cos(a),l=Math.sin(o),u=Math.cos(o);if(e.position.x=l*c,e.position.y=l*s,e.position.z=u,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*i),e.rotation instanceof D){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(_n,e.position,gn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`hemisphere`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},wn=class e{constructor(e={}){this.type=`grid`,this.width=e.width??1,this.height=e.height??1,this.column=e.column??10,this.row=e.row??10}initialize(e){let t=Math.floor(Math.random()*this.row),n=Math.floor(Math.random()*this.column);e.position.x=n*this.width/this.column-this.width/2,e.position.y=t*this.height/this.row-this.height/2,e.position.z=0,e.velocity.set(0,0,e.startSpeed)}toJSON(){return{type:`grid`,width:this.width,height:this.height,column:this.column,row:this.row}}static fromJSON(t){return new e(t)}clone(){return new e({width:this.width,height:this.height,column:this.column,row:this.row})}update(e,t){}},Tn=class e{constructor(e={}){this.type=`rectangle`,this.currentValue=0,this.width=e.width??10,this.height=e.height??10,this.thickness=e.thickness??1,this.mode=e.mode??Bt.Random,this.spread=e.spread??0,this.speed=e.speed??new k(1),this.memory=[],this._m1=new Tt}update(e,t){this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t}initialize(e,t){let n=Vt(this.mode,this.currentValue,this.spread,t)*(2*(this.width+this.height)),r,i;n<this.width?(r=n-this.width/2,i=-this.height/2):n<this.width+this.height?(r=this.width/2,i=n-this.width-this.height/2):n<2*this.width+this.height?(r=this.width/2-(n-this.width-this.height),i=this.height/2):(r=-this.width/2,i=this.height/2-(n-2*this.width-this.height));let a=Math.random(),o=1-this.thickness*a;if(e.position.x=r*o,e.position.y=i*o,e.position.z=0,e.velocity.x=r,e.velocity.y=i,e.velocity.z=0,e.velocity.normalize().multiplyScalar(e.startSpeed),e.rotation instanceof D){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(_n,e.velocity,gn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`rectangle`,width:this.width,height:this.height,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({width:t.width,height:t.height,thickness:t.thickness,mode:t.mode,speed:t.speed?A(t.speed):void 0,spread:t.spread})}clone(){return new e({width:this.width,height:this.height,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},En={circle:{type:`circle`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:mn,loadJSON:mn.fromJSON},cone:{type:`cone`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:pn,loadJSON:pn.fromJSON},donut:{type:`donut`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`donutRadius`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:bn,loadJSON:bn.fromJSON},point:{type:`point`,params:[],constructor:xn,loadJSON:xn.fromJSON},sphere:{type:`sphere`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:Sn,loadJSON:Sn.fromJSON},hemisphere:{type:`hemisphere`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:Cn,loadJSON:Cn.fromJSON},grid:{type:`grid`,params:[[`width`,[`number`]],[`height`,[`number`]],[`rows`,[`number`]],[`column`,[`number`]]],constructor:wn,loadJSON:wn.fromJSON},rectangle:{type:`rectangle`,params:[[`width`,[`number`]],[`height`,[`number`]],[`thickness`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:Tn,loadJSON:Tn.fromJSON}};function Dn(e,t){return En[e.type].loadJSON(e,t)}var On=class e{constructor(e){this.color=e,this.type=`ColorOverLife`}initialize(e){this.color.startGen(e.memory)}update(e,t){this.color.genColor(e.memory,e.color,e.age/e.life),e.color.x*=e.startColor.x,e.color.y*=e.startColor.y,e.color.z*=e.startColor.z,e.color.w*=e.startColor.w}frameUpdate(e){}toJSON(){return{type:this.type,color:this.color.toJSON()}}static fromJSON(t){return new e(tn(t.color))}clone(){return new e(this.color.clone())}reset(){}},kn=class e{constructor(e){this.angularVelocity=e,this.type=`RotationOverLife`}initialize(e){typeof e.rotation==`number`&&this.angularVelocity.startGen(e.memory)}update(e,t){typeof e.rotation==`number`&&(e.rotation+=t*this.angularVelocity.genValue(e.memory,e.age/e.life))}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON()}}static fromJSON(t){return new e(A(t.angularVelocity))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone())}reset(){}},An=class e{constructor(e){this.angularVelocity=e,this.type=`Rotation3DOverLife`,this.tempQuat=new D,this.tempQuat2=new D}initialize(e){e.rotation instanceof D&&(e.angularVelocity=new D,this.angularVelocity.startGen(e.memory))}update(e,t){e.rotation instanceof D&&(this.angularVelocity.genValue(e.memory,this.tempQuat,t,e.age/e.life),e.rotation.multiply(this.tempQuat))}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON()}}static fromJSON(t){return new e(ln(t.angularVelocity))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone())}reset(){}},jn=class e{initialize(e,t){this.ps=t,this.x.startGen(e.memory),this.y.startGen(e.memory),this.z.startGen(e.memory)}constructor(e,t,n){this.x=e,this.y=t,this.z=n,this.type=`ForceOverLife`,this._temp=new O,this._tempScale=new O,this._tempQ=new D}update(e,t){this._temp.set(this.x.genValue(e.memory,e.age/e.life),this.y.genValue(e.memory,e.age/e.life),this.z.genValue(e.memory,e.age/e.life)),this.ps.worldSpace||this._temp.multiply(this._tempScale).applyQuaternion(this._tempQ),e.velocity.addScaledVector(this._temp,t)}toJSON(){return{type:this.type,x:this.x.toJSON(),y:this.y.toJSON(),z:this.z.toJSON()}}static fromJSON(t){return new e(A(t.x),A(t.y),A(t.z))}frameUpdate(e){if(this.ps&&!this.ps.worldSpace){let e=this._temp,t=this._tempQ,n=this._tempScale;this.ps.emitter.matrixWorld.decompose(e,t,n),t.invert(),n.set(1/n.x,1/n.y,1/n.z)}}clone(){return new e(this.x.clone(),this.y.clone(),this.z.clone())}reset(){}},Mn=class e{initialize(e){this.size.startGen(e.memory)}constructor(e){this.size=e,this.type=`SizeOverLife`}update(e){this.size instanceof un?this.size.genValue(e.memory,e.size,e.age/e.life).multiply(e.startSize):e.size.copy(e.startSize).multiplyScalar(this.size.genValue(e.memory,e.age/e.life))}toJSON(){return{type:this.type,size:this.size.toJSON()}}static fromJSON(t){return new e(fn(t.size))}frameUpdate(e){}clone(){return new e(this.size.clone())}reset(){}},Nn=class e{initialize(e){this.speed.startGen(e.memory)}constructor(e){this.speed=e,this.type=`SpeedOverLife`}update(e){e.speedModifier=this.speed.genValue(e.memory,e.age/e.life)}toJSON(){return{type:this.type,speed:this.speed.toJSON()}}static fromJSON(t){return new e(A(t.speed))}frameUpdate(e){}clone(){return new e(this.speed.clone())}reset(){}},Pn=class e{constructor(e){this.frame=e,this.type=`FrameOverLife`}initialize(e){this.frame.startGen(e.memory)}update(e,t){this.frame instanceof an&&(e.uvTile=this.frame.genValue(e.memory,e.age/e.life))}frameUpdate(e){}toJSON(){return{type:this.type,frame:this.frame.toJSON()}}static fromJSON(t){return new e(A(t.frame))}clone(){return new e(this.frame.clone())}reset(){}},Fn=class e{constructor(e,t=new O(0,1,0)){this.orbitSpeed=e,this.axis=t,this.type=`OrbitOverLife`,this.temp=new O,this.rotation=new D}initialize(e){this.orbitSpeed.startGen(e.memory)}update(e,t){this.temp.copy(e.position).projectOnVector(this.axis),this.rotation.setFromAxisAngle(this.axis,this.orbitSpeed.genValue(e.memory,e.age/e.life)*t),e.position.sub(this.temp),e.position.applyQuaternion(this.rotation),e.position.add(this.temp)}frameUpdate(e){}toJSON(){return{type:this.type,orbitSpeed:this.orbitSpeed.toJSON(),axis:[this.axis.x,this.axis.y,this.axis.z]}}static fromJSON(t){return new e(A(t.orbitSpeed),t.axis?new O(t.axis[0],t.axis[1],t.axis[2]):void 0)}clone(){return new e(this.orbitSpeed.clone())}reset(){}},In=class{constructor(e){this.data=e,this.next=null,this.prev=null}hasPrev(){return this.prev!==null}hasNext(){return this.next!==null}},Ln=class{constructor(){this.length=0,this.head=this.tail=null}isEmpty(){return this.head===null}clear(){this.length=0,this.head=this.tail=null}front(){return this.head===null?null:this.head.data}back(){return this.tail===null?null:this.tail.data}dequeue(){if(this.head){let e=this.head.data;return this.head=this.head.next,this.head?this.head.prev=null:this.tail=null,this.length--,e}}pop(){if(this.tail){let e=this.tail.data;return this.tail=this.tail.prev,this.tail?this.tail.next=null:this.head=null,this.length--,e}}queue(e){let t=new In(e);this.tail||=t,this.head&&(this.head.prev=t,t.next=this.head),this.head=t,this.length++}push(e){let t=new In(e);this.head||=t,this.tail&&(this.tail.next=t,t.prev=this.tail),this.tail=t,this.length++}insertBefore(e,t){let n=new In(t);n.next=e,n.prev=e.prev,n.prev!==null&&(n.prev.next=n),n.next.prev=n,e==this.head&&(this.head=n),this.length++}remove(e){if(this.head===null||this.tail===null)return;let t=this.head;for(e===this.head.data&&(this.head=this.head.next),e===this.tail.data&&(this.tail=this.tail.prev);t.next!==null&&t.data!==e;)t=t.next;t.data===e&&(t.prev!==null&&(t.prev.next=t.next),t.next!==null&&(t.next.prev=t.prev),this.length--)}*values(){let e=this.head;for(;e!==null;)yield e.data,e=e.next}},Rn=class{constructor(){this.position=new O,this.velocity=new O,this.age=0,this.life=1,this.size=new O,this.rotation=0,this.color=new Lt(1,1,1,1),this.uvTile=0,this.memory=[]}get died(){return this.age>=this.life}reset(){this.memory.length=0,this.position.set(0,0,0),this.velocity.set(0,0,0),this.age=0,this.life=1,this.size.set(1,1,1),this.rotation=0,this.color.set(1,1,1,1),this.uvTile=0}},zn=class{constructor(){this.startSpeed=0,this.startColor=new Lt,this.startSize=new O(1,1,1),this.position=new O,this.velocity=new O,this.age=0,this.life=1,this.size=new O(1,1,1),this.speedModifier=1,this.rotation=0,this.color=new Lt,this.uvTile=0,this.memory=[]}get died(){return this.age>=this.life}reset(){this.memory.length=0}},Bn=class{constructor(e,t,n){this.position=e,this.size=t,this.color=n}},Vn=class{constructor(){this.startSpeed=0,this.startColor=new Lt,this.startSize=new O(1,1,1),this.position=new O,this.velocity=new O,this.age=0,this.life=1,this.size=new O(1,1,1),this.length=100,this.speedModifier=1,this.color=new Lt,this.previous=new Ln,this.uvTile=0,this.memory=[]}update(){for(this.age<=this.life?this.previous.push(new Bn(this.position.clone(),this.size.x,this.color.clone())):this.previous.length>0&&this.previous.dequeue();this.previous.length>this.length;)this.previous.dequeue()}get died(){return this.age>=this.life}reset(){this.memory.length=0,this.previous.clear()}},Hn=class e{initialize(e){this.width.startGen(e.memory)}constructor(e){this.width=e,this.type=`WidthOverLength`}update(e){if(e instanceof Vn){let t=e.previous.values();for(let n=0;n<e.previous.length;n++){let r=t.next();r.value.size=this.width.genValue(e.memory,(e.previous.length-n)/e.length)}}}frameUpdate(e){}toJSON(){return{type:this.type,width:this.width.toJSON()}}static fromJSON(t){return new e(A(t.width))}clone(){return new e(this.width.clone())}reset(){}},Un=class e{constructor(e,t){this.direction=e,this.magnitude=t,this.type=`ApplyForce`,this.memory={data:[],dataCount:0},this.magnitudeValue=this.magnitude.genValue(this.memory)}initialize(e){}update(e,t){e.velocity.addScaledVector(this.direction,this.magnitudeValue*t)}frameUpdate(e){this.magnitudeValue=this.magnitude.genValue(this.memory)}toJSON(){return{type:this.type,direction:[this.direction.x,this.direction.y,this.direction.z],magnitude:this.magnitude.toJSON()}}static fromJSON(t){return new e(new O(t.direction[0],t.direction[1],t.direction[2]),A(t.magnitude??t.force))}clone(){return new e(this.direction.clone(),this.magnitude.clone())}reset(){}},Wn=class e{constructor(e,t){this.center=e,this.magnitude=t,this.type=`GravityForce`,this.temp=new O}initialize(e){}update(e,t){this.temp.copy(this.center).sub(e.position).normalize(),e.velocity.addScaledVector(this.temp,this.magnitude/e.position.distanceToSquared(this.center)*t)}frameUpdate(e){}toJSON(){return{type:this.type,center:[this.center.x,this.center.y,this.center.z],magnitude:this.magnitude}}static fromJSON(t){return new e(new O(t.center[0],t.center[1],t.center[2]),t.magnitude)}clone(){return new e(this.center.clone(),this.magnitude)}reset(){}},Gn=class e{constructor(e){this.angle=e,this.type=`ChangeEmitDirection`,this._temp=new O,this._q=new D,this.memory={data:[],dataCount:0}}initialize(e){let t=e.velocity.length();t!=0&&(e.velocity.normalize(),e.velocity.x===0&&e.velocity.y===0?this._temp.set(0,e.velocity.z,0):this._temp.set(-e.velocity.y,e.velocity.x,0),this.angle.startGen(this.memory),this._q.setFromAxisAngle(this._temp.normalize(),this.angle.genValue(this.memory)),this._temp.copy(e.velocity),e.velocity.applyQuaternion(this._q),this._q.setFromAxisAngle(this._temp,Math.random()*Math.PI*2),e.velocity.applyQuaternion(this._q),e.velocity.setLength(t))}update(e,t){}frameUpdate(e){}toJSON(){return{type:this.type,angle:this.angle.toJSON()}}static fromJSON(t){return new e(A(t.angle))}clone(){return new e(this.angle)}reset(){}},Kn;(function(e){e[e.Death=0]=`Death`,e[e.Birth=1]=`Birth`,e[e.Frame=2]=`Frame`})(Kn||={});var qn=class e{constructor(e,t,n,r=Kn.Frame,i=1){this.particleSystem=e,this.useVelocityAsBasis=t,this.subParticleSystem=n,this.mode=r,this.emitProbability=i,this.type=`EmitSubParticleSystem`,this.q_=new D,this.v_=new O,this.v2_=new O,this.subEmissions=[],this.subParticleSystem&&this.subParticleSystem.system&&(this.subParticleSystem.system.onlyUsedByOther=!0)}initialize(e){}update(e,t){(this.mode===Kn.Frame||this.mode===Kn.Birth&&e.age===0||this.mode===Kn.Death&&e.age+t>=e.life)&&this.emit(e,t)}emit(e,t){if(!this.subParticleSystem||Math.random()>this.emitProbability)return;let n=new Tt;this.setMatrixFromParticle(n,e),this.subEmissions.push({burstParticleCount:0,burstParticleIndex:0,isBursting:!1,burstIndex:0,burstWaveIndex:0,time:0,waitEmiting:0,matrix:n,travelDistance:0,particle:e})}frameUpdate(e){if(this.subParticleSystem)for(let t=0;t<this.subEmissions.length;t++)if(this.subEmissions[t].time>=this.subParticleSystem.system.duration)this.subEmissions[t]=this.subEmissions[this.subEmissions.length-1],this.subEmissions.length=this.subEmissions.length-1,t--;else{let n=this.subEmissions[t];n.particle&&n.particle.age<n.particle.life?this.setMatrixFromParticle(n.matrix,n.particle):n.particle=void 0,this.subParticleSystem.system.emit(e,n,n.matrix)}}toJSON(){return{type:this.type,subParticleSystem:this.subParticleSystem?this.subParticleSystem.uuid:``,useVelocityAsBasis:this.useVelocityAsBasis,mode:this.mode,emitProbability:this.emitProbability}}static fromJSON(t,n){return new e(n,t.useVelocityAsBasis,t.subParticleSystem,t.mode,t.emitProbability)}clone(){return new e(this.particleSystem,this.useVelocityAsBasis,this.subParticleSystem,this.mode,this.emitProbability)}reset(){}setMatrixFromParticle(e,t){let n;if(t.rotation===void 0||this.useVelocityAsBasis){if(t.velocity.x===0&&t.velocity.y===0&&(t.velocity.z===1||t.velocity.z===0))e.set(1,0,0,t.position.x,0,1,0,t.position.y,0,0,1,t.position.z,0,0,0,1);else{this.v_.copy(yn).cross(t.velocity),this.v2_.copy(t.velocity).cross(this.v_);let n=this.v_.length(),r=this.v2_.length();e.set(this.v_.x/n,this.v2_.x/r,t.velocity.x,t.position.x,this.v_.y/n,this.v2_.y/r,t.velocity.y,t.position.y,this.v_.z/n,this.v2_.z/r,t.velocity.z,t.position.z,0,0,0,1)}}else t.rotation instanceof D?n=t.rotation:(this.q_.setFromAxisAngle(yn,t.rotation),n=this.q_),e.compose(t.position,n,vn);this.particleSystem.worldSpace||e.multiplyMatrices(this.particleSystem.emitter.matrixWorld,e)}},Jn=.5*(Math.sqrt(3)-1),Yn=(3-Math.sqrt(3))/6,Xn=1/3,Zn=1/6,Qn=(Math.sqrt(5)-1)/4,$n=(5-Math.sqrt(5))/20,er=new Float32Array([1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,-1]),tr=new Float32Array([0,1,1,1,0,1,1,-1,0,1,-1,1,0,1,-1,-1,0,-1,1,1,0,-1,1,-1,0,-1,-1,1,0,-1,-1,-1,1,0,1,1,1,0,1,-1,1,0,-1,1,1,0,-1,-1,-1,0,1,1,-1,0,1,-1,-1,0,-1,1,-1,0,-1,-1,1,1,0,1,1,1,0,-1,1,-1,0,1,1,-1,0,-1,-1,1,0,1,-1,1,0,-1,-1,-1,0,1,-1,-1,0,-1,1,1,1,0,1,1,-1,0,1,-1,1,0,1,-1,-1,0,-1,1,1,0,-1,1,-1,0,-1,-1,1,0,-1,-1,-1,0]),nr=class{constructor(e=Math.random){let t=typeof e==`function`?e:ir(e);this.p=rr(t),this.perm=new Uint8Array(512),this.permMod12=new Uint8Array(512);for(let e=0;e<512;e++)this.perm[e]=this.p[e&255],this.permMod12[e]=this.perm[e]%12}noise2D(e,t){let n=this.permMod12,r=this.perm,i=0,a=0,o=0,s=(e+t)*Jn,c=Math.floor(e+s),l=Math.floor(t+s),u=(c+l)*Yn,d=c-u,f=l-u,p=e-d,m=t-f,h,g;p>m?(h=1,g=0):(h=0,g=1);let _=p-h+Yn,v=m-g+Yn,y=p-1+2*Yn,b=m-1+2*Yn,x=c&255,S=l&255,C=.5-p*p-m*m;if(C>=0){let e=n[x+r[S]]*3;C*=C,i=C*C*(er[e]*p+er[e+1]*m)}let w=.5-_*_-v*v;if(w>=0){let e=n[x+h+r[S+g]]*3;w*=w,a=w*w*(er[e]*_+er[e+1]*v)}let T=.5-y*y-b*b;if(T>=0){let e=n[x+1+r[S+1]]*3;T*=T,o=T*T*(er[e]*y+er[e+1]*b)}return 70*(i+a+o)}noise3D(e,t,n){let r=this.permMod12,i=this.perm,a,o,s,c,l=(e+t+n)*Xn,u=Math.floor(e+l),d=Math.floor(t+l),f=Math.floor(n+l),p=(u+d+f)*Zn,m=u-p,h=d-p,g=f-p,_=e-m,v=t-h,y=n-g,b,x,S,C,w,T;_>=v?v>=y?(b=1,x=0,S=0,C=1,w=1,T=0):_>=y?(b=1,x=0,S=0,C=1,w=0,T=1):(b=0,x=0,S=1,C=1,w=0,T=1):v<y?(b=0,x=0,S=1,C=0,w=1,T=1):_<y?(b=0,x=1,S=0,C=0,w=1,T=1):(b=0,x=1,S=0,C=1,w=1,T=0);let ee=_-b+Zn,te=v-x+Zn,ne=y-S+Zn,re=_-C+2*Zn,ie=v-w+2*Zn,ae=y-T+2*Zn,oe=_-1+3*Zn,se=v-1+3*Zn,ce=y-1+3*Zn,le=u&255,ue=d&255,de=f&255,fe=.6-_*_-v*v-y*y;if(fe<0)a=0;else{let e=r[le+i[ue+i[de]]]*3;fe*=fe,a=fe*fe*(er[e]*_+er[e+1]*v+er[e+2]*y)}let pe=.6-ee*ee-te*te-ne*ne;if(pe<0)o=0;else{let e=r[le+b+i[ue+x+i[de+S]]]*3;pe*=pe,o=pe*pe*(er[e]*ee+er[e+1]*te+er[e+2]*ne)}let me=.6-re*re-ie*ie-ae*ae;if(me<0)s=0;else{let e=r[le+C+i[ue+w+i[de+T]]]*3;me*=me,s=me*me*(er[e]*re+er[e+1]*ie+er[e+2]*ae)}let he=.6-oe*oe-se*se-ce*ce;if(he<0)c=0;else{let e=r[le+1+i[ue+1+i[de+1]]]*3;he*=he,c=he*he*(er[e]*oe+er[e+1]*se+er[e+2]*ce)}return 32*(a+o+s+c)}noise4D(e,t,n,r){let i=this.perm,a,o,s,c,l,u=(e+t+n+r)*Qn,d=Math.floor(e+u),f=Math.floor(t+u),p=Math.floor(n+u),m=Math.floor(r+u),h=(d+f+p+m)*$n,g=d-h,_=f-h,v=p-h,y=m-h,b=e-g,x=t-_,S=n-v,C=r-y,w=0,T=0,ee=0,te=0;b>x?w++:T++,b>S?w++:ee++,b>C?w++:te++,x>S?T++:ee++,x>C?T++:te++,S>C?ee++:te++;let ne=+(w>=3),re=+(T>=3),ie=+(ee>=3),ae=+(te>=3),oe=+(w>=2),se=+(T>=2),ce=+(ee>=2),le=+(te>=2),ue=+(w>=1),de=+(T>=1),fe=+(ee>=1),pe=+(te>=1),me=b-ne+$n,he=x-re+$n,ge=S-ie+$n,_e=C-ae+$n,ve=b-oe+2*$n,ye=x-se+2*$n,be=S-ce+2*$n,xe=C-le+2*$n,Se=b-ue+3*$n,Ce=x-de+3*$n,we=S-fe+3*$n,Te=C-pe+3*$n,Ee=b-1+4*$n,De=x-1+4*$n,Oe=S-1+4*$n,ke=C-1+4*$n,Ae=d&255,je=f&255,Me=p&255,Ne=m&255,Pe=.6-b*b-x*x-S*S-C*C;if(Pe<0)a=0;else{let e=i[Ae+i[je+i[Me+i[Ne]]]]%32*4;Pe*=Pe,a=Pe*Pe*(tr[e]*b+tr[e+1]*x+tr[e+2]*S+tr[e+3]*C)}let Fe=.6-me*me-he*he-ge*ge-_e*_e;if(Fe<0)o=0;else{let e=i[Ae+ne+i[je+re+i[Me+ie+i[Ne+ae]]]]%32*4;Fe*=Fe,o=Fe*Fe*(tr[e]*me+tr[e+1]*he+tr[e+2]*ge+tr[e+3]*_e)}let Ie=.6-ve*ve-ye*ye-be*be-xe*xe;if(Ie<0)s=0;else{let e=i[Ae+oe+i[je+se+i[Me+ce+i[Ne+le]]]]%32*4;Ie*=Ie,s=Ie*Ie*(tr[e]*ve+tr[e+1]*ye+tr[e+2]*be+tr[e+3]*xe)}let Le=.6-Se*Se-Ce*Ce-we*we-Te*Te;if(Le<0)c=0;else{let e=i[Ae+ue+i[je+de+i[Me+fe+i[Ne+pe]]]]%32*4;Le*=Le,c=Le*Le*(tr[e]*Se+tr[e+1]*Ce+tr[e+2]*we+tr[e+3]*Te)}let Re=.6-Ee*Ee-De*De-Oe*Oe-ke*ke;if(Re<0)l=0;else{let e=i[Ae+1+i[je+1+i[Me+1+i[Ne+1]]]]%32*4;Re*=Re,l=Re*Re*(tr[e]*Ee+tr[e+1]*De+tr[e+2]*Oe+tr[e+3]*ke)}return 27*(a+o+s+c+l)}};function rr(e){let t=new Uint8Array(256);for(let e=0;e<256;e++)t[e]=e;for(let n=0;n<255;n++){let r=n+~~(e()*(256-n)),i=t[n];t[n]=t[r],t[r]=i}return t}function ir(e){let t=0,n=0,r=0,i=1,a=ar();return t=a(` `),n=a(` `),r=a(` `),t-=a(e),t<0&&(t+=1),n-=a(e),n<0&&(n+=1),r-=a(e),r<0&&(r+=1),function(){let e=2091639*t+i*23283064365386963e-26;return t=n,n=r,r=e-(i=e|0)}}function ar(){let e=4022871197;return function(t){t=t.toString();for(let n=0;n<t.length;n++){e+=t.charCodeAt(n);let r=.02519603282416938*e;e=r>>>0,r-=e,r*=e,e=r>>>0,r-=e,e+=r*4294967296}return(e>>>0)*23283064365386963e-26}}var or=class e{constructor(e,t,n,r){this.scale=e,this.octaves=t,this.velocityMultiplier=n,this.timeScale=r,this.type=`TurbulenceField`,this.generator=new nr,this.timeOffset=new O,this.temp=new O,this.temp2=new O,this.timeOffset.x=Math.random()/this.scale.x*this.timeScale.x,this.timeOffset.y=Math.random()/this.scale.y*this.timeScale.y,this.timeOffset.z=Math.random()/this.scale.z*this.timeScale.z}initialize(e){}update(e,t){let n=e.position.x/this.scale.x,r=e.position.y/this.scale.y,i=e.position.z/this.scale.z;this.temp.set(0,0,0);let a=1;for(let e=0;e<this.octaves;e++)this.temp2.set(this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.x*a)/a,this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.y*a)/a,this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.z*a)/a),this.temp.add(this.temp2),a*=2;this.temp.multiply(this.velocityMultiplier),e.velocity.addScaledVector(this.temp,t)}toJSON(){return{type:this.type,scale:[this.scale.x,this.scale.y,this.scale.z],octaves:this.octaves,velocityMultiplier:[this.velocityMultiplier.x,this.velocityMultiplier.y,this.velocityMultiplier.z],timeScale:[this.timeScale.x,this.timeScale.y,this.timeScale.z]}}frameUpdate(e){this.timeOffset.x+=e*this.timeScale.x,this.timeOffset.y+=e*this.timeScale.y,this.timeOffset.z+=e*this.timeScale.z}static fromJSON(t){return new e(new O(t.scale[0],t.scale[1],t.scale[2]),t.octaves,new O(t.velocityMultiplier[0],t.velocityMultiplier[1],t.velocityMultiplier[2]),new O(t.timeScale[0],t.timeScale[1],t.timeScale[2]))}clone(){return new e(this.scale.clone(),this.octaves,this.velocityMultiplier.clone(),this.timeScale.clone())}reset(){}},sr=[],cr=new O,lr=new D,ur=class e{constructor(e,t,n=new k(1),r=new k(0)){if(this.frequency=e,this.power=t,this.positionAmount=n,this.rotationAmount=r,this.type=`Noise`,this.duration=0,sr.length===0)for(let e=0;e<100;e++)sr.push(new nr)}initialize(e){e.lastPosNoise=new O,e.lastRotNoise=typeof e.rotation==`number`?0:new D,e.generatorIndex=[hn(0,100),hn(0,100),hn(0,100),hn(0,100)],this.positionAmount.startGen(e.memory),this.rotationAmount.startGen(e.memory),this.frequency.startGen(e.memory),this.power.startGen(e.memory)}update(e,t){let n=this.frequency.genValue(e.memory,e.age/e.life),r=this.power.genValue(e.memory,e.age/e.life),i=this.positionAmount.genValue(e.memory,e.age/e.life),a=this.rotationAmount.genValue(e.memory,e.age/e.life);i>0&&e.lastPosNoise!==void 0&&(e.position.sub(e.lastPosNoise),cr.set(sr[e.generatorIndex[0]].noise2D(0,e.age*n)*r*i,sr[e.generatorIndex[1]].noise2D(0,e.age*n)*r*i,sr[e.generatorIndex[2]].noise2D(0,e.age*n)*r*i),e.position.add(cr),e.lastPosNoise.copy(cr)),a>0&&e.lastRotNoise!==void 0&&(typeof e.rotation==`number`?(e.rotation-=e.lastRotNoise,e.rotation+=sr[e.generatorIndex[3]].noise2D(0,e.age*n)*Math.PI*r*a):(e.lastRotNoise.invert(),e.rotation.multiply(e.lastRotNoise),lr.set(sr[e.generatorIndex[0]].noise2D(0,e.age*n)*r*a,sr[e.generatorIndex[1]].noise2D(0,e.age*n)*r*a,sr[e.generatorIndex[2]].noise2D(0,e.age*n)*r*a,sr[e.generatorIndex[3]].noise2D(0,e.age*n)*r*a).normalize(),e.rotation.multiply(lr),e.lastRotNoise.copy(lr)))}toJSON(){return{type:this.type,frequency:this.frequency.toJSON(),power:this.power.toJSON(),positionAmount:this.positionAmount.toJSON(),rotationAmount:this.rotationAmount.toJSON()}}frameUpdate(e){this.duration+=e}static fromJSON(t){return new e(A(t.frequency),A(t.power),A(t.positionAmount),A(t.rotationAmount))}clone(){return new e(this.frequency.clone(),this.power.clone(),this.positionAmount.clone(),this.rotationAmount.clone())}reset(){}},dr=class e{constructor(e=0,t=0,n=new O){this.scaleX=e,this.scaleY=t,this.position=n,this.locations=[]}transform(e,t){e.x=this.locations[t%this.locations.length].x*this.scaleX+this.position.x,e.y=this.locations[t%this.locations.length].y*this.scaleY+this.position.y,e.z=this.position.z}static fromJSON(t){let n=new e(t.scaleX,t.scaleY,new O(t.position[0],t.position[1],t.position[2]));return n.locations=t.locations.map(e=>new It(e.x,e.y)),n}clone(){let t=new e(this.scaleX,this.scaleY,this.position.clone());return t.locations=this.locations.map(e=>e.clone()),t}toJSON(){return{scaleX:this.scaleX,scaleY:this.scaleY,position:this.position,locations:this.locations.map(e=>({x:e.x,y:e.y}))}}fromImage(e,t){let n=document.createElement(`canvas`);n.width=e.width,n.height=e.height;let r=n.getContext(`2d`);if(!r)return;r.drawImage(e,0,0);let i=r.getImageData(0,0,n.width,n.height,{colorSpace:`srgb`});n.remove(),this.locations.length=0;for(let e=0;e<i.height;e++)for(let n=0;n<i.width;n++)i.data[(e*i.width+n)*4+3]>t&&this.locations.push(new It(n,i.height-e))}};function fr(e){switch(e.type){case`TextureSequencer`:return dr.fromJSON(e);default:return new dr}}var pr=class e{constructor(e){this.type=`ApplySequences`,this.sequencers=[],this.time=0,this.index=0,this.pCount=0,this.tempV=new O,this.delay=e}initialize(e){e.id=this.pCount,e.dst=new O,e.begin=new O,e.inMotion=!1,this.pCount++}reset(){this.time=0,this.index=0,this.pCount=0}update(t,n){let r=this.sequencers[this.index],i=t.id*this.delay;this.time>=r[0].a+i&&this.time<=r[0].b+i?(t.inMotion||(t.inMotion=!0,t.begin.copy(t.position),r[1].transform(t.dst,t.id)),t.position.lerpVectors(t.begin,t.dst,e.BEZIER.genValue((this.time-r[0].a-i)/(r[0].b-r[0].a)))):this.time>r[0].b+i&&(t.inMotion=!1)}frameUpdate(e){for(;this.index+1<this.sequencers.length&&this.time>=this.sequencers[this.index+1][0].a;)this.index++;this.time+=e}appendSequencer(e,t){this.sequencers.push([e,t])}toJSON(){return{type:this.type,delay:this.delay,sequencers:this.sequencers.map(([e,t])=>({range:e.toJSON(),sequencer:t.toJSON()}))}}static fromJSON(t){let n=new e(t.delay);return t.sequencers.forEach(e=>{n.sequencers.push([A(e.range),fr(e.sequencer)])}),n}clone(){let t=new e(this.delay);return t.sequencers=this.sequencers.map(e=>[e[0].clone(),e[1].clone()]),t}};pr.BEZIER=new Ht(0,0,1,1);var mr;function hr(e){mr=e}function gr(){return mr}var _r=class e{constructor(e,t){this.resolver=e,this.bounce=t,this.type=`ApplyCollision`,this.tempV=new O}initialize(e){}update(e,t){this.resolver.resolve(e.position,this.tempV)&&e.velocity.reflect(this.tempV).multiplyScalar(this.bounce)}frameUpdate(e){}toJSON(){return{type:this.type,bounce:this.bounce}}static fromJSON(t){return new e(gr(),t.bounce)}clone(){return new e(this.resolver,this.bounce)}reset(){}},vr=class e{constructor(e,t){this.color=e,this.speedRange=t,this.type=`ColorBySpeed`}initialize(e){this.color.startGen(e.memory)}update(e,t){let n=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);this.color.genColor(e.memory,e.color,n),e.color.x*=e.startColor.x,e.color.y*=e.startColor.y,e.color.z*=e.startColor.z,e.color.w*=e.startColor.w}frameUpdate(e){}toJSON(){return{type:this.type,color:this.color.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(tn(t.color),nn.fromJSON(t.speedRange))}clone(){return new e(this.color.clone(),this.speedRange.clone())}reset(){}},yr=class e{initialize(e){this.size.startGen(e.memory)}constructor(e,t){this.size=e,this.speedRange=t,this.type=`SizeBySpeed`}update(e){let t=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);this.size instanceof un?this.size.genValue(e.memory,e.size,t).multiply(e.startSize):e.size.copy(e.startSize).multiplyScalar(this.size.genValue(e.memory,t))}toJSON(){return{type:this.type,size:this.size.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(fn(t.size),nn.fromJSON(t.speedRange))}frameUpdate(e){}clone(){return new e(this.size.clone(),this.speedRange.clone())}reset(){}},br=class e{constructor(e,t){this.angularVelocity=e,this.speedRange=t,this.type=`RotationBySpeed`,this.tempQuat=new D}initialize(e){typeof e.rotation==`number`&&this.angularVelocity.startGen(e.memory)}update(e,t){if(typeof e.rotation==`number`){let n=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);e.rotation+=t*this.angularVelocity.genValue(e.memory,n)}}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(A(t.angularVelocity),nn.fromJSON(t.speedRange))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone(),this.speedRange.clone())}reset(){}},xr=class e{initialize(e){this.speed.startGen(e.memory)}constructor(e,t){this.speed=e,this.dampen=t,this.type=`LimitSpeedOverLife`}update(e,t){let n=e.velocity.length(),r=this.speed.genValue(e.memory,e.age/e.life);if(n>r){let i=(n-r)/n;e.velocity.multiplyScalar(1-i*this.dampen*t*20)}}toJSON(){return{type:this.type,speed:this.speed.toJSON(),dampen:this.dampen}}static fromJSON(t){return new e(A(t.speed),t.dampen)}frameUpdate(e){}clone(){return new e(this.speed.clone(),this.dampen)}reset(){}},Sr={ApplyForce:{type:`ApplyForce`,constructor:Un,params:[[`direction`,[`vec3`]],[`magnitude`,[`value`]]],loadJSON:Un.fromJSON},Noise:{type:`Noise`,constructor:ur,params:[[`frequency`,[`value`]],[`power`,[`value`]],[`positionAmount`,[`value`]],[`rotationAmount`,[`value`]]],loadJSON:ur.fromJSON},TurbulenceField:{type:`TurbulenceField`,constructor:or,params:[[`scale`,[`vec3`]],[`octaves`,[`number`]],[`velocityMultiplier`,[`vec3`]],[`timeScale`,[`vec3`]]],loadJSON:or.fromJSON},GravityForce:{type:`GravityForce`,constructor:Wn,params:[[`center`,[`vec3`]],[`magnitude`,[`number`]]],loadJSON:Wn.fromJSON},ColorOverLife:{type:`ColorOverLife`,constructor:On,params:[[`color`,[`colorFunc`]]],loadJSON:On.fromJSON},RotationOverLife:{type:`RotationOverLife`,constructor:kn,params:[[`angularVelocity`,[`value`,`valueFunc`]]],loadJSON:kn.fromJSON},Rotation3DOverLife:{type:`Rotation3DOverLife`,constructor:An,params:[[`angularVelocity`,[`rotationFunc`]]],loadJSON:An.fromJSON},SizeOverLife:{type:`SizeOverLife`,constructor:Mn,params:[[`size`,[`value`,`valueFunc`,`vec3Func`]]],loadJSON:Mn.fromJSON},ColorBySpeed:{type:`ColorBySpeed`,constructor:vr,params:[[`color`,[`colorFunc`]],[`speedRange`,[`range`]]],loadJSON:vr.fromJSON},RotationBySpeed:{type:`RotationBySpeed`,constructor:br,params:[[`angularVelocity`,[`value`,`valueFunc`]],[`speedRange`,[`range`]]],loadJSON:br.fromJSON},SizeBySpeed:{type:`SizeBySpeed`,constructor:yr,params:[[`size`,[`value`,`valueFunc`,`vec3Func`]],[`speedRange`,[`range`]]],loadJSON:yr.fromJSON},SpeedOverLife:{type:`SpeedOverLife`,constructor:Nn,params:[[`speed`,[`value`,`valueFunc`]]],loadJSON:Nn.fromJSON},FrameOverLife:{type:`FrameOverLife`,constructor:Pn,params:[[`frame`,[`value`,`valueFunc`]]],loadJSON:Pn.fromJSON},ForceOverLife:{type:`ForceOverLife`,constructor:jn,params:[[`x`,[`value`,`valueFunc`]],[`y`,[`value`,`valueFunc`]],[`z`,[`value`,`valueFunc`]]],loadJSON:jn.fromJSON},OrbitOverLife:{type:`OrbitOverLife`,constructor:Fn,params:[[`orbitSpeed`,[`value`,`valueFunc`]],[`axis`,[`vec3`]]],loadJSON:Fn.fromJSON},WidthOverLength:{type:`WidthOverLength`,constructor:Hn,params:[[`width`,[`value`,`valueFunc`]]],loadJSON:Hn.fromJSON},ChangeEmitDirection:{type:`ChangeEmitDirection`,constructor:Gn,params:[[`angle`,[`value`]]],loadJSON:Gn.fromJSON},EmitSubParticleSystem:{type:`EmitSubParticleSystem`,constructor:qn,params:[[`particleSystem`,[`self`]],[`useVelocityAsBasis`,[`boolean`]],[`subParticleSystem`,[`particleSystem`]],[`mode`,[`number`]],[`emitProbability`,[`number`]]],loadJSON:qn.fromJSON},LimitSpeedOverLife:{type:`LimitSpeedOverLife`,constructor:xr,params:[[`speed`,[`value`,`valueFunc`]],[`dampen`,[`number`]]],loadJSON:xr.fromJSON}};function Cr(e,t){return Sr[e.type]?Sr[e.type].loadJSON(e,t):null}var wr=[];function Tr(e){if(!wr.find(t=>t.id===e.id)){e.initialize();for(let t of e.emitterShapes)En[t.type]||(En[t.type]=t);for(let t of e.behaviors)Sr[t.type]||(Sr[t.type]=t)}}function Er(e){let t=wr.find(t=>t.id===e);if(t){for(let e of t.emitterShapes)En[e.type]&&delete En[e.type];for(let e of t.behaviors)Sr[e.type]&&delete Sr[e.type]}}var Dr=e({ApplyCollision:()=>_r,ApplyForce:()=>Un,ApplySequences:()=>pr,AxisAngleGenerator:()=>sn,BatchedParticleRenderer:()=>li,BatchedRenderer:()=>ci,BehaviorFromJSON:()=>Cr,BehaviorTypes:()=>Sr,Bezier:()=>Ht,ChangeEmitDirection:()=>Gn,CircleEmitter:()=>mn,ColorBySpeed:()=>vr,ColorGeneratorFromJSON:()=>tn,ColorOverLife:()=>On,ColorRange:()=>Jt,ConeEmitter:()=>pn,ConstantColor:()=>en,ConstantValue:()=>k,DEG2RAD:()=>Xe,DonutEmitter:()=>bn,EmitSubParticleSystem:()=>qn,EmitterFromJSON:()=>Dn,EmitterMode:()=>Bt,EmitterShapes:()=>En,Euler:()=>Ft,EulerGenerator:()=>cn,ForceOverLife:()=>jn,FrameOverLife:()=>Pn,GeneratorFromJSON:()=>fn,Gradient:()=>Zt,GravityForce:()=>Wn,GridEmitter:()=>wn,HemisphereEmitter:()=>Cn,IntervalValue:()=>nn,LimitSpeedOverLife:()=>xr,MathUtils:()=>bt,Matrix3:()=>Rt,Matrix4:()=>Tt,MeshSurfaceEmitter:()=>Or,MeshSurfaceEmitterPlugin:()=>kr,NodeParticle:()=>Rn,Noise:()=>ur,OrbitOverLife:()=>Fn,ParticleEmitter:()=>Br,ParticleMeshPhysicsMaterial:()=>ri,ParticleMeshStandardMaterial:()=>ni,ParticleSystem:()=>Jr,PiecewiseBezier:()=>an,PiecewiseFunction:()=>rn,Plugins:()=>wr,PointEmitter:()=>xn,QuarksLoader:()=>di,QuarksPrefab:()=>ui,QuarksUtil:()=>fi,Quaternion:()=>D,RAD2DEG:()=>Ze,RandomColor:()=>qt,RandomColorBetweenGradient:()=>$t,RandomQuatGenerator:()=>on,RecordState:()=>Bn,RectangleEmitter:()=>Tn,RenderMode:()=>j,Rotation3DOverLife:()=>An,RotationBySpeed:()=>br,RotationGeneratorFromJSON:()=>ln,RotationOverLife:()=>kn,SequencerFromJSON:()=>fr,SizeBySpeed:()=>yr,SizeOverLife:()=>Mn,SpeedOverLife:()=>Nn,SphereEmitter:()=>Sn,SpriteBatch:()=>ii,SpriteParticle:()=>zn,SubParticleEmitMode:()=>Kn,TextureSequencer:()=>dr,TrailBatch:()=>si,TrailParticle:()=>Vn,TurbulenceField:()=>or,VFXBatch:()=>Vr,ValueGeneratorFromJSON:()=>A,Vector2:()=>It,Vector3:()=>O,Vector3Function:()=>un,Vector3GeneratorFromJSON:()=>dn,Vector4:()=>Lt,WebGLCoordinateSystem:()=>Ct,WebGPUCoordinateSystem:()=>wt,WidthOverLength:()=>Hn,ceilPowerOfTwo:()=>ht,clamp:()=>$e,damp:()=>it,degToRad:()=>ft,denormalize:()=>vt,euclideanModulo:()=>et,floorPowerOfTwo:()=>gt,generateUUID:()=>Qe,getPhysicsResolver:()=>gr,getValueFromEmitterMode:()=>Vt,inverseLerp:()=>nt,isPowerOfTwo:()=>mt,lerp:()=>rt,loadPlugin:()=>Tr,mapLinear:()=>tt,normalize:()=>yt,pingpong:()=>at,radToDeg:()=>pt,randFloat:()=>lt,randFloatSpread:()=>ut,randInt:()=>ct,registerShaderChunks:()=>zr,seededRandom:()=>dt,setPhysicsResolver:()=>hr,setQuaternionFromProperEuler:()=>_t,smootherstep:()=>st,smoothstep:()=>ot,unloadPlugin:()=>Er}),Or=class e{get geometry(){return this._geometry}set geometry(e){if(this._geometry=e,e===void 0||typeof e==`string`)return;let t=new ge;this._triangleIndexToArea.length=0;let n=0;if(!e.getIndex())return;let r=e.getIndex().array,i=r.length/3;this._triangleIndexToArea.push(0);for(let a=0;a<i;a++)t.setFromAttributeAndIndices(e.getAttribute(`position`),r[a*3],r[a*3+1],r[a*3+2]),n+=t.getArea(),this._triangleIndexToArea.push(n);e.userData.triangleIndexToArea=this._triangleIndexToArea}constructor(e){this.type=`mesh_surface`,this._triangleIndexToArea=[],this._tempA=new E,this._tempB=new E,this._tempC=new E,e&&(this.geometry=e)}initialize(e){let t=this._geometry;if(!t||t.getIndex()===null){e.position.set(0,0,0),e.velocity.set(0,0,1).multiplyScalar(e.startSpeed);return}let n=this._triangleIndexToArea.length-1,r=0,i=n,a=Math.random()*this._triangleIndexToArea[n];for(;r+1<i;){let e=Math.floor((r+i)/2);a<this._triangleIndexToArea[e]?i=e:r=e}let o=Math.random(),s=Math.random();o+s>1&&(o=1-o,s=1-s);let c=t.getIndex().array[r*3],l=t.getIndex().array[r*3+1],u=t.getIndex().array[r*3+2],d=t.getAttribute(`position`);this._tempA.fromBufferAttribute(d,c),this._tempB.fromBufferAttribute(d,l),this._tempC.fromBufferAttribute(d,u),this._tempB.sub(this._tempA),this._tempC.sub(this._tempA),this._tempA.addScaledVector(this._tempB,o).addScaledVector(this._tempC,s),e.position.copy(this._tempA),this._tempA.copy(this._tempB).cross(this._tempC).normalize(),e.velocity.copy(this._tempA).normalize().multiplyScalar(e.startSpeed)}toJSON(){return{type:`mesh_surface`,mesh:this._geometry?this._geometry.uuid:``}}static fromJSON(t,n){return new e(n.geometries[t.geometry])}clone(){return new e(this._geometry)}update(e,t){}},kr={id:`three.quarks`,initialize:()=>{},emitterShapes:[{type:`mesh_surface`,params:[[`geometry`,[`geometry`]]],constructor:Or,loadJSON:Or.fromJSON}],behaviors:[]},Ar=`
#ifdef SOFT_PARTICLES

    /* #ifdef LOGDEPTH
    float distSample = linearize_depth_log(sampleDepth, near, far);
    #else
    float distSample = ortho ? linearize_depth_ortho(sampleDepth, near, far) : linearize_depth(sampleDepth, near, far);
    #endif */

    vec2 p2 = projPosition.xy / projPosition.w;
    
    p2 = 0.5 * p2 + 0.5;

    float readDepth = texture2D(depthTexture, p2.xy).r;
    float viewDepth = linearize_depth(readDepth);

    float softParticlesFade = saturate(SOFT_INV_FADE_DISTANCE * ((viewDepth - SOFT_NEAR_FADE) - linearDepth));
    
    gl_FragColor *= softParticlesFade;

    //gl_FragColor = vec4(softParticlesFade , 0, 0, 1);
#endif
`,jr=`
#ifdef SOFT_PARTICLES

    uniform sampler2D depthTexture;
    uniform vec4 projParams;
    uniform vec2 softParams;

    varying vec4 projPosition;
    varying float linearDepth;

    #define SOFT_NEAR_FADE softParams.x
    #define SOFT_INV_FADE_DISTANCE softParams.y

    #define zNear projParams.x
    #define zFar projParams.y

    float linearize_depth(float d)
    {
        return (zFar * zNear) / (zFar - d * (zFar - zNear));
    }

#endif
`,Mr=`
#ifdef SOFT_PARTICLES
    varying vec4 projPosition;
    varying float linearDepth;
#endif
`,Nr=`
#ifdef SOFT_PARTICLES
    projPosition = gl_Position;
    linearDepth = -mvPosition.z;
#endif
`,Pr=`
#ifdef USE_MAP
    vec4 texelColor = texture2D( map, vUv);
    #ifdef TILE_BLEND
        texelColor = mix( texelColor, texture2D( map, vUvNext ), vUvBlend );
    #endif
    diffuseColor *= texelColor;
#endif
`,Fr=`
#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;
#ifdef TILE_BLEND
    varying vec2 vUvNext;
    varying float vUvBlend;
#endif

#endif
#ifdef USE_MAP

	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#ifdef TILE_BLEND
    varying vec2 vMapUvNext;
#endif

#endif
#ifdef USE_ALPHAMAP

	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;

#endif
#ifdef USE_DISPLACEMENTMAP

	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SPECULARMAP

	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,Ir=`
#ifdef UV_TILE
    attribute float uvTile;
    uniform vec2 tileCount;
    
    mat3 makeTileTransform(float uvTile) {
        float col = mod(uvTile, tileCount.x);
        float row = (tileCount.y - floor(uvTile / tileCount.x) - 1.0);
        
        return mat3(
          1.0 / tileCount.x, 0.0, 0.0,
          0.0, 1.0 / tileCount.y, 0.0, 
          col / tileCount.x, row / tileCount.y, 1.0);
    }
#else
    mat3 makeTileTransform(float uvTile) {
        return mat3(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0);
    }
#endif

#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;
#ifdef TILE_BLEND
    varying vec2 vUvNext;
    varying float vUvBlend;
#endif

#endif
#ifdef USE_MAP

	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#ifdef TILE_BLEND
    varying vec2 vMapUvNext;
#endif

#endif
#ifdef USE_ALPHAMAP

	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;

#endif
#ifdef USE_DISPLACEMENTMAP

	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SPECULARMAP

	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,Lr=`
#ifdef UV_TILE
    mat3 tileTransform = makeTileTransform(floor(uvTile));
    #ifdef TILE_BLEND
        mat3 nextTileTransform = makeTileTransform(ceil(uvTile));
        vUvBlend = fract(uvTile);
    #endif
#else
    mat3 tileTransform = makeTileTransform(0.0);
#endif

#if defined( USE_UV ) || defined( USE_ANISOTROPY )

vUv = (tileTransform *vec3( uv, 1 )).xy;
#if defined( TILE_BLEND ) && defined( UV_TILE )
    vUvNext = (nextTileTransform *vec3( uv, 1 )).xy;
#endif

#endif
#ifdef USE_MAP

vMapUv = ( tileTransform * (mapTransform * vec3( MAP_UV, 1 ) )).xy;
#if defined( TILE_BLEND ) && defined( UV_TILE )
    vMapUvNext = (nextTileTransform * (mapTransform * vec3( MAP_UV, 1 ))).xy;
#endif

#endif
#ifdef USE_ALPHAMAP

vAlphaMapUv = ( tileTransform * (alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) )).xy;
    
#endif
#ifdef USE_LIGHTMAP

vLightMapUv = ( tileTransform * (lightMapTransform * vec3( LIGHTMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_AOMAP

vAoMapUv = ( tileTransform * (aoMapTransform * vec3( AOMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_BUMPMAP

vBumpMapUv = ( tileTransform * (bumpMapTransform * vec3( BUMPMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_NORMALMAP

vNormalMapUv = ( tileTransform * (normalMapTransform * vec3( NORMALMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_DISPLACEMENTMAP

vDisplacementMapUv = ( tileTransform * (displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_EMISSIVEMAP

vEmissiveMapUv = ( tileTransform * (emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_METALNESSMAP

vMetalnessMapUv = ( tileTransform * (metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_ROUGHNESSMAP

vRoughnessMapUv = ( tileTransform * (roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_ANISOTROPYMAP

vAnisotropyMapUv = ( tileTransform * (anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOATMAP

vClearcoatMapUv = ( tileTransform * (clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

vClearcoatNormalMapUv = ( tileTransform * (clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

vClearcoatRoughnessMapUv = ( tileTransform * (clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_IRIDESCENCEMAP

vIridescenceMapUv = ( tileTransform * (iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

vIridescenceThicknessMapUv = ( tileTransform * (iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SHEEN_COLORMAP

vSheenColorMapUv = ( tileTransform * (sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

vSheenRoughnessMapUv = ( tileTransform * (sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULARMAP

vSpecularMapUv = ( tileTransform * (specularMapTransform * vec3( SPECULARMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULAR_COLORMAP

vSpecularColorMapUv = ( tileTransform * (specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

vSpecularIntensityMapUv = ( tileTransform * (specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_TRANSMISSIONMAP

vTransmissionMapUv = ( tileTransform * transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_THICKNESSMAP

vThicknessMapUv = ( tileTransform * thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) )).xy;

#endif

`,Rr=ye;function zr(){Rr.tile_pars_vertex=Ir,Rr.tile_vertex=Lr,Rr.tile_pars_fragment=Fr,Rr.tile_fragment=Pr,Rr.soft_pars_vertex=Mr,Rr.soft_vertex=Nr,Rr.soft_pars_fragment=jr,Rr.soft_fragment=Ar}var Br=class extends Ne{constructor(e){super(),this.type=`ParticleEmitter`,this.system=e}clone(){let e=this.system.clone();return e.emitter.copy(this,!0),e.emitter}dispose(){}extractFromCache(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}toJSON(e,t={}){let n=this.children;this.children=this.children.filter(e=>e.type!==`ParticleSystemPreview`);let r=super.toJSON(e);return this.children=n,this.system!==null&&(r.object.ps=this.system.toJSON(e,t)),r}},j;(function(e){e[e.BillBoard=0]=`BillBoard`,e[e.StretchedBillBoard=1]=`StretchedBillBoard`,e[e.Mesh=2]=`Mesh`,e[e.Trail=3]=`Trail`,e[e.HorizontalBillBoard=4]=`HorizontalBillBoard`,e[e.VerticalBillBoard=5]=`VerticalBillBoard`})(j||={});var Vr=class extends l{constructor(e){super(),this.type=`VFXBatch`,this.maxParticles=1e3,this.systems=new Set;let t=new h;t.mask=e.layers.mask;let n=e.material.clone();n.defines={},Object.assign(n.defines,e.material.defines),this.settings={instancingGeometry:e.instancingGeometry,renderMode:e.renderMode,renderOrder:e.renderOrder,material:n,uTileCount:e.uTileCount,vTileCount:e.vTileCount,blendTiles:e.blendTiles,softParticles:e.softParticles,softNearFade:e.softNearFade,softFarFade:e.softFarFade,layers:t},this.frustumCulled=!1,this.renderOrder=this.settings.renderOrder}addSystem(e){this.systems.add(e)}removeSystem(e){this.systems.delete(e)}applyDepthTexture(e){let t=this.material.uniforms.depthTexture;t&&t.value!==e&&(t.value=e,this.material.needsUpdate=!0)}getVisibleSystems(){return Array.from(this.systems).filter(e=>e.emitter.visible)}},Hr=new O(0,0,1),Ur=new D,Wr=new O,Gr=new O;new O;var Kr=60,qr=new v(1,1,1,1),Jr=class e{set time(e){this.emissionState.time=e}get time(){return this.emissionState.time}get layers(){return this.rendererSettings.layers}get texture(){return this.rendererSettings.material.map}set texture(e){this.rendererSettings.material.map=e,this.neededToUpdateRender=!0}get material(){return this.rendererSettings.material}set material(e){this.rendererSettings.material=e,this.neededToUpdateRender=!0}get uTileCount(){return this.rendererSettings.uTileCount}set uTileCount(e){this.rendererSettings.uTileCount=e,this.neededToUpdateRender=!0}get vTileCount(){return this.rendererSettings.vTileCount}set vTileCount(e){this.rendererSettings.vTileCount=e,this.neededToUpdateRender=!0}get blendTiles(){return this.rendererSettings.blendTiles}set blendTiles(e){this.rendererSettings.blendTiles=e,this.neededToUpdateRender=!0}get softParticles(){return this.rendererSettings.softParticles}set softParticles(e){this.rendererSettings.softParticles=e,this.neededToUpdateRender=!0}get softNearFade(){return this.rendererSettings.softNearFade}set softNearFade(e){this.rendererSettings.softNearFade=e,this.neededToUpdateRender=!0}get softFarFade(){return this.rendererSettings.softFarFade}set softFarFade(e){this.rendererSettings.softFarFade=e,this.neededToUpdateRender=!0}get instancingGeometry(){return this.rendererSettings.instancingGeometry}set instancingGeometry(e){this.restart(),this.particles.length=0,this.rendererSettings.instancingGeometry=e,this.neededToUpdateRender=!0}get renderMode(){return this.rendererSettings.renderMode}set renderMode(e){if(this.rendererSettings.renderMode!==e){let t=!1;switch(this.rendererSettings.renderMode===j.Trail&&(t=!0),this.rendererSettings.renderMode===j.Mesh&&(this.startRotation=new k(0)),e){case j.Trail:this.rendererEmitterSettings={startLength:new k(30),followLocalOrigin:!1},t=!0;break;case j.Mesh:this.rendererEmitterSettings={geometry:qr},this.startRotation=new sn(new O(0,1,0),new k(0));break;case j.StretchedBillBoard:this.rendererEmitterSettings={speedFactor:0,lengthFactor:2},this.rendererSettings.instancingGeometry=qr;break;case j.BillBoard:case j.VerticalBillBoard:case j.HorizontalBillBoard:this.rendererEmitterSettings={},this.rendererSettings.instancingGeometry=qr}this.rendererSettings.renderMode=e,t&&(this.restart(),this.particles.length=0),this.neededToUpdateRender=!0}}get renderOrder(){return this.rendererSettings.renderOrder}set renderOrder(e){this.rendererSettings.renderOrder=e,this.neededToUpdateRender=!0}get blending(){return this.rendererSettings.material.blending}set blending(e){this.rendererSettings.material.blending=e,this.neededToUpdateRender=!0}constructor(e){if(this.temp=new O,this.travelDistance=0,this.normalMatrix=new Rt,this.memory=[],this.listeners={},this.firstTimeUpdate=!0,this.autoDestroy=e.autoDestroy!==void 0&&e.autoDestroy,this.duration=e.duration??1,this.looping=e.looping===void 0||e.looping,this.prewarm=e.prewarm!==void 0&&e.prewarm,this.startLife=e.startLife??new k(5),this.startSpeed=e.startSpeed??new k(0),this.startRotation=e.startRotation??new k(0),this.startSize=e.startSize??new k(1),this.startColor=e.startColor??new en(new Lt(1,1,1,1)),this.emissionOverTime=e.emissionOverTime??new k(10),this.emissionOverDistance=e.emissionOverDistance??new k(0),this.emissionBursts=e.emissionBursts??[],this.onlyUsedByOther=e.onlyUsedByOther??!1,this.emitterShape=e.shape??new Sn,this.behaviors=e.behaviors??[],this.worldSpace=e.worldSpace??!1,this.rendererEmitterSettings=e.rendererEmitterSettings??{},e.renderMode===j.StretchedBillBoard){let t=this.rendererEmitterSettings;e.speedFactor!==void 0&&(t.speedFactor=e.speedFactor),t.speedFactor=t.speedFactor??0,t.lengthFactor=t.lengthFactor??0}this.rendererSettings={instancingGeometry:e.instancingGeometry??qr,renderMode:e.renderMode??j.BillBoard,renderOrder:e.renderOrder??0,material:e.material,uTileCount:e.uTileCount??1,vTileCount:e.vTileCount??1,blendTiles:e.blendTiles??!1,softParticles:e.softParticles??!1,softNearFade:e.softNearFade??0,softFarFade:e.softFarFade??0,layers:e.layers??new h},this.neededToUpdateRender=!0,this.particles=[],this.startTileIndex=e.startTileIndex||new k(0),this.emitter=new Br(this),this.paused=!1,this.particleNum=0,this.emissionState={isBursting:!1,burstParticleIndex:0,burstParticleCount:0,burstIndex:0,burstWaveIndex:0,time:0,waitEmiting:0,travelDistance:0},this.emissionBursts.forEach(e=>e.count.startGen(this.memory)),this.emissionOverDistance.startGen(this.memory),this.emitEnded=!1,this.markForDestroy=!1,this.prewarmed=!1}pause(){this.paused=!0}play(){this.paused=!1}stop(){this.restart(),this.pause()}spawn(e,t,n){Ur.setFromRotationMatrix(n);let r=Wr,i=Ur,a=Gr;n.decompose(r,i,a);for(let r=0;r<e;r++){for(t.burstParticleIndex=r,this.particleNum++;this.particles.length<this.particleNum;)this.rendererSettings.renderMode===j.Trail?this.particles.push(new Vn):this.particles.push(new zn);let e=this.particles[this.particleNum-1];if(e.reset(),e.speedModifier=1,this.startColor.startGen(e.memory),this.startColor.genColor(e.memory,e.startColor,this.emissionState.time),e.color.copy(e.startColor),this.startSpeed.startGen(e.memory),e.startSpeed=this.startSpeed.genValue(e.memory,t.time/this.duration),this.startLife.startGen(e.memory),e.life=this.startLife.genValue(e.memory,t.time/this.duration),e.age=0,this.startSize.startGen(e.memory),this.startSize.type===`vec3function`)this.startSize.genValue(e.memory,e.startSize,t.time/this.duration);else{let n=this.startSize.genValue(e.memory,t.time/this.duration);e.startSize.set(n,n,n)}if(this.startTileIndex.startGen(e.memory),e.uvTile=this.startTileIndex.genValue(e.memory),e.size.copy(e.startSize),this.rendererSettings.renderMode===j.Mesh||this.rendererSettings.renderMode===j.BillBoard||this.rendererSettings.renderMode===j.VerticalBillBoard||this.rendererSettings.renderMode===j.HorizontalBillBoard||this.rendererSettings.renderMode===j.StretchedBillBoard){let n=e;this.startRotation.startGen(e.memory),this.rendererSettings.renderMode===j.Mesh?(n.rotation instanceof D||(n.rotation=new D),this.startRotation.type===`rotation`?this.startRotation.genValue(e.memory,n.rotation,1,t.time/this.duration):n.rotation.setFromAxisAngle(Hr,this.startRotation.genValue(n.memory,t.time/this.duration))):n.rotation=this.startRotation.type===`rotation`?0:this.startRotation.genValue(n.memory,t.time/this.duration)}else if(this.rendererSettings.renderMode===j.Trail){let n=e;this.rendererEmitterSettings.startLength.startGen(n.memory),n.length=this.rendererEmitterSettings.startLength.genValue(n.memory,t.time/this.duration)}if(this.emitterShape.initialize(e,t),this.rendererSettings.renderMode===j.Trail&&this.rendererEmitterSettings.followLocalOrigin){let t=e;t.localPosition=new O().copy(t.position)}this.worldSpace?(e.position.applyMatrix4(n),e.startSize.multiply(a).abs(),e.size.copy(e.startSize),e.velocity.multiply(a).applyMatrix3(this.normalMatrix),e.rotation&&e.rotation instanceof D&&e.rotation.multiplyQuaternions(Ur,e.rotation)):this.onlyUsedByOther&&(e.parentMatrix=n);for(let t=0;t<this.behaviors.length;t++)this.behaviors[t].initialize(e,this)}}endEmit(){this.emitEnded=!0,this.autoDestroy&&(this.markForDestroy=!0),this.fire({type:`emitEnd`,particleSystem:this})}dispose(){this._renderer&&this._renderer.deleteSystem(this),this.emitter.dispose(),this.emitter.parent&&this.emitter.parent.remove(this.emitter),this.fire({type:`destroy`,particleSystem:this})}restart(){this.memory.length=0,this.paused=!1,this.particleNum=0,this.emissionState.isBursting=!1,this.emissionState.burstIndex=0,this.emissionState.burstWaveIndex=0,this.emissionState.time=0,this.emissionState.waitEmiting=0,this.behaviors.forEach(e=>{e.reset()}),this.emitEnded=!1,this.markForDestroy=!1,this.prewarmed=!1,this.emissionBursts.forEach(e=>e.count.startGen(this.memory)),this.emissionOverDistance.startGen(this.memory)}update(e){if(this.paused)return;let t=this.emitter;for(;t.parent;)t=t.parent;if(t.type!==`Scene`){this.dispose();return}if(this.firstTimeUpdate&&(this.firstTimeUpdate=!1,this.emitter.updateWorldMatrix(!0,!1)),this.emitEnded&&this.particleNum===0){this.markForDestroy&&this.emitter.parent&&this.dispose();return}if(this.looping&&this.prewarm&&!this.prewarmed){this.prewarmed=!0;for(let e=0;e<this.duration*Kr;e++)this.update(1/Kr)}e>.1&&(e=.1),this.neededToUpdateRender&&=(this._renderer&&this._renderer.updateSystem(this),!1),this.onlyUsedByOther||this.emit(e,this.emissionState,this.emitter.matrixWorld),this.emitterShape.update(this,e);for(let t=0;t<this.behaviors.length;t++){this.behaviors[t].frameUpdate(e);for(let n=0;n<this.particleNum;n++)this.particles[n].died||this.behaviors[t].update(this.particles[n],e)}for(let t=0;t<this.particleNum;t++)this.rendererEmitterSettings.followLocalOrigin&&this.particles[t].localPosition?(this.particles[t].position.copy(this.particles[t].localPosition),this.particles[t].parentMatrix?this.particles[t].position.applyMatrix4(this.particles[t].parentMatrix):this.particles[t].position.applyMatrix4(this.emitter.matrixWorld)):this.particles[t].position.addScaledVector(this.particles[t].velocity,e*this.particles[t].speedModifier),this.particles[t].age+=e;if(this.rendererSettings.renderMode===j.Trail)for(let e=0;e<this.particleNum;e++)this.particles[e].update();for(let e=0;e<this.particleNum;e++){let t=this.particles[e];t.died&&(!(t instanceof Vn)||t.previous.length===0)&&(this.particles[e]=this.particles[this.particleNum-1],this.particles[this.particleNum-1]=t,this.particleNum--,e--,this.fire({type:`particleDied`,particleSystem:this,particle:t}))}}emit(e,t,n){t.time>this.duration&&(this.looping?(t.time-=this.duration,t.burstIndex=0,this.behaviors.forEach(e=>{e.reset()})):!this.emitEnded&&!this.onlyUsedByOther&&this.endEmit()),this.normalMatrix.getNormalMatrix(n);let r=Math.ceil(t.waitEmiting);for(this.spawn(r,t,n),t.waitEmiting-=r;t.burstIndex<this.emissionBursts.length&&this.emissionBursts[t.burstIndex].time<=t.time;){if(Math.random()<this.emissionBursts[t.burstIndex].probability){let e=this.emissionBursts[t.burstIndex].count.genValue(this.memory,this.time);t.isBursting=!0,t.burstParticleCount=e,this.spawn(e,t,n),t.isBursting=!1}t.burstIndex++}if(!this.emitEnded&&(t.waitEmiting+=e*this.emissionOverTime.genValue(this.memory,t.time/this.duration),t.previousWorldPos!=null)){this.temp.set(n.elements[12],n.elements[13],n.elements[14]),t.travelDistance+=t.previousWorldPos.distanceTo(this.temp);let e=this.emissionOverDistance.genValue(this.memory,t.time/this.duration);if(t.travelDistance*e>0){let n=Math.floor(t.travelDistance*e);t.travelDistance-=n/e,t.waitEmiting+=n}}t.previousWorldPos===void 0&&(t.previousWorldPos=new O),t.previousWorldPos.set(n.elements[12],n.elements[13],n.elements[14]),t.time+=e}toJSON(e,t={}){if((e===void 0||typeof e==`string`)&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}}),e.materials[this.rendererSettings.material.uuid]=this.rendererSettings.material.toJSON(e),t.useUrlForImage&&this.texture?.source!==void 0){let t=this.texture.source;e.images[t.uuid]={uuid:t.uuid,url:this.texture.image.url}}let n;n=this.renderMode===j.Trail?{startLength:this.rendererEmitterSettings.startLength.toJSON(),followLocalOrigin:this.rendererEmitterSettings.followLocalOrigin}:this.renderMode===j.Mesh?{}:this.renderMode===j.StretchedBillBoard?{speedFactor:this.rendererEmitterSettings.speedFactor,lengthFactor:this.rendererEmitterSettings.lengthFactor}:{};let r=this.rendererSettings.instancingGeometry;return e.geometries&&!e.geometries[r.uuid]&&(e.geometries[r.uuid]=r.toJSON()),{version:`3.0`,autoDestroy:this.autoDestroy,looping:this.looping,prewarm:this.prewarm,duration:this.duration,shape:this.emitterShape.toJSON(),startLife:this.startLife.toJSON(),startSpeed:this.startSpeed.toJSON(),startRotation:this.startRotation.toJSON(),startSize:this.startSize.toJSON(),startColor:this.startColor.toJSON(),emissionOverTime:this.emissionOverTime.toJSON(),emissionOverDistance:this.emissionOverDistance.toJSON(),emissionBursts:this.emissionBursts.map(e=>({time:e.time,count:e.count.toJSON(),probability:e.probability,interval:e.interval,cycle:e.cycle})),onlyUsedByOther:this.onlyUsedByOther,instancingGeometry:this.rendererSettings.instancingGeometry.uuid,renderOrder:this.renderOrder,renderMode:this.renderMode,rendererEmitterSettings:n,material:this.rendererSettings.material.uuid,layers:this.layers.mask,startTileIndex:this.startTileIndex.toJSON(),uTileCount:this.uTileCount,vTileCount:this.vTileCount,blendTiles:this.blendTiles,softParticles:this.rendererSettings.softParticles,softFarFade:this.rendererSettings.softFarFade,softNearFade:this.rendererSettings.softNearFade,behaviors:this.behaviors.map(e=>e.toJSON()),worldSpace:this.worldSpace}}static fromJSON(t,n,r){let i=Dn(t.shape,n),a;if(t.renderMode===j.Trail){let e=t.rendererEmitterSettings;a={startLength:e.startLength==null?new k(30):A(e.startLength),followLocalOrigin:e.followLocalOrigin}}else t.renderMode===j.Mesh?a={}:t.renderMode===j.StretchedBillBoard?(a=t.rendererEmitterSettings,t.speedFactor!=null&&(a.speedFactor=t.speedFactor)):a={};let o=new h;t.layers&&(o.mask=t.layers);let s=new e({autoDestroy:t.autoDestroy,looping:t.looping,prewarm:t.prewarm,duration:t.duration,shape:i,startLife:A(t.startLife),startSpeed:A(t.startSpeed),startRotation:fn(t.startRotation),startSize:fn(t.startSize),startColor:tn(t.startColor),emissionOverTime:A(t.emissionOverTime),emissionOverDistance:A(t.emissionOverDistance),emissionBursts:t.emissionBursts?.map(e=>({time:e.time,count:typeof e.count==`number`?new k(e.count):A(e.count),probability:e.probability??1,interval:e.interval??.1,cycle:e.cycle??1})),onlyUsedByOther:t.onlyUsedByOther,instancingGeometry:n.geometries[t.instancingGeometry],renderMode:t.renderMode,rendererEmitterSettings:a,renderOrder:t.renderOrder,layers:o,material:t.material?n.materials[t.material]:t.texture?new S({map:n.textures[t.texture],transparent:t.transparent??!0,blending:t.blending,side:2}):new S({color:16777215,transparent:!0,blending:2,side:2}),startTileIndex:typeof t.startTileIndex==`number`?new k(t.startTileIndex):A(t.startTileIndex),uTileCount:t.uTileCount,vTileCount:t.vTileCount,blendTiles:t.blendTiles,softParticles:t.softParticles,softFarFade:t.softFarFade,softNearFade:t.softNearFade,behaviors:[],worldSpace:t.worldSpace});return s.behaviors=t.behaviors.map(e=>{let t=Cr(e,s);return t&&t.type===`EmitSubParticleSystem`&&(r[e.subParticleSystem]=t),t}).filter(e=>e!==null),s}addBehavior(e){this.behaviors.push(e)}getRendererSettings(){return this.rendererSettings}addEventListener(e,t){this.listeners[e]||(this.listeners[e]=[]),this.listeners[e].push(t)}removeAllEventListeners(e){this.listeners[e]&&(this.listeners[e]=[])}removeEventListener(e,t){if(this.listeners[e]){let n=this.listeners[e].indexOf(t);n!==-1&&this.listeners[e].splice(n,1)}}fire(e){this.listeners[e.type]&&this.listeners[e.type].forEach(t=>t(e))}clone(){let t=[];for(let e of this.emissionBursts){let n={};Object.assign(n,e),t.push(n)}let n=[];for(let e of this.behaviors)n.push(e.clone());let r;r=this.renderMode===j.Trail?{startLength:this.rendererEmitterSettings.startLength.clone(),followLocalOrigin:this.rendererEmitterSettings.followLocalOrigin}:this.renderMode===j.StretchedBillBoard?{lengthFactor:this.rendererEmitterSettings.lengthFactor,speedFactor:this.rendererEmitterSettings.speedFactor}:{};let i=new h;return i.mask=this.layers.mask,new e({autoDestroy:this.autoDestroy,looping:this.looping,duration:this.duration,shape:this.emitterShape.clone(),startLife:this.startLife.clone(),startSpeed:this.startSpeed.clone(),startRotation:this.startRotation.clone(),startSize:this.startSize.clone(),startColor:this.startColor.clone(),emissionOverTime:this.emissionOverTime.clone(),emissionOverDistance:this.emissionOverDistance.clone(),emissionBursts:t,onlyUsedByOther:this.onlyUsedByOther,instancingGeometry:this.rendererSettings.instancingGeometry,renderMode:this.renderMode,renderOrder:this.renderOrder,rendererEmitterSettings:r,material:this.rendererSettings.material,startTileIndex:this.startTileIndex,uTileCount:this.uTileCount,vTileCount:this.vTileCount,blendTiles:this.blendTiles,softParticles:this.softParticles,softFarFade:this.softFarFade,softNearFade:this.softNearFade,behaviors:n,worldSpace:this.worldSpace,layers:i})}},Yr=`

#include <common>
#include <color_pars_fragment>
#include <map_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
#include <alphatest_pars_fragment>

#include <tile_pars_fragment>
#include <soft_pars_fragment>

void main() {

    #include <clipping_planes_fragment>
    
    vec3 outgoingLight = vec3( 0.0 );
    vec4 diffuseColor = vColor;
    
    #include <logdepthbuf_fragment>
    
    #include <tile_fragment>
    #include <alphatest_fragment>

    outgoingLight = diffuseColor.rgb;
    
    #ifdef USE_COLOR_AS_ALPHA
    gl_FragColor = vec4( outgoingLight, diffuseColor.r );
    #else
    gl_FragColor = vec4( outgoingLight, diffuseColor.a );
    #endif
    
    #include <soft_fragment>
    #include <tonemapping_fragment>
}
`,Xr=`
#define STANDARD

#ifdef PHYSICAL
#define IOR
#define USE_SPECULAR
#endif

uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;

#ifdef IOR
uniform float ior;
#endif

#ifdef USE_SPECULAR
uniform float specularIntensity;
uniform vec3 specularColor;

#ifdef USE_SPECULAR_COLORMAP
uniform sampler2D specularColorMap;
#endif

#ifdef USE_SPECULAR_INTENSITYMAP
uniform sampler2D specularIntensityMap;
#endif
#endif

#ifdef USE_CLEARCOAT
uniform float clearcoat;
uniform float clearcoatRoughness;
#endif

#ifdef USE_DISPERSION
uniform float dispersion;
#endif

#ifdef USE_IRIDESCENCE
uniform float iridescence;
uniform float iridescenceIOR;
uniform float iridescenceThicknessMinimum;
uniform float iridescenceThicknessMaximum;
#endif

#ifdef USE_SHEEN
uniform vec3 sheenColor;
uniform float sheenRoughness;

#ifdef USE_SHEEN_COLORMAP
uniform sampler2D sheenColorMap;
#endif

#ifdef USE_SHEEN_ROUGHNESSMAP
uniform sampler2D sheenRoughnessMap;
#endif
#endif

#ifdef USE_ANISOTROPY
uniform vec2 anisotropyVector;

#ifdef USE_ANISOTROPYMAP
uniform sampler2D anisotropyMap;
#endif
#endif

varying vec3 vViewPosition;

#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

vec4 diffuseColor = vec4( diffuse, opacity );
#include <clipping_planes_fragment>

ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
vec3 totalEmissiveRadiance = emissive;

#include <logdepthbuf_fragment>
#include <map_fragment>
#include <color_fragment>
#include <alphamap_fragment>
#include <alphatest_fragment>
#include <alphahash_fragment>
#include <roughnessmap_fragment>
#include <metalnessmap_fragment>
#include <normal_fragment_begin>
#include <normal_fragment_maps>
#include <clearcoat_normal_fragment_begin>
#include <clearcoat_normal_fragment_maps>
#include <emissivemap_fragment>

// accumulation
#include <lights_physical_fragment>
#include <lights_fragment_begin>
#include <lights_fragment_maps>
#include <lights_fragment_end>

// modulation
#include <aomap_fragment>

vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;

#include <transmission_fragment>

vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;

#ifdef USE_SHEEN

// Sheen energy compensation approximation calculation can be found at the end of
// https://drive.google.com/file/d/1T0D1VSyR4AllqIJTQAraEIzjlb5h4FKH/view?usp=sharing
float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );

outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;

#endif

#ifdef USE_CLEARCOAT

float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );

vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );

outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;

#endif

#include <opaque_fragment>
#include <tonemapping_fragment>
#include <colorspace_fragment>
#include <fog_fragment>
#include <premultiplied_alpha_fragment>
#include <dithering_fragment>
}`,Zr=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute float rotation;
attribute vec3 size;

void main() {
	
    vec2 alignedPosition = position.xy * size.xy;
    
    vec2 rotatedPosition;
    rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
    rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
#ifdef HORIZONTAL
    vec4 mvPosition = modelMatrix * vec4( offset, 1.0 );
    mvPosition.x += rotatedPosition.x;
    mvPosition.z -= rotatedPosition.y;
    mvPosition = viewMatrix * mvPosition;
#elif defined(VERTICAL)
    vec4 mvPosition = modelMatrix * vec4( offset, 1.0 );
    mvPosition.y += rotatedPosition.y;
    mvPosition = viewMatrix * mvPosition;
    mvPosition.x += rotatedPosition.x;
#else
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    mvPosition.xy += rotatedPosition;
#endif

	vColor = color;

	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>

	#include <clipping_planes_vertex>

	#include <tile_vertex>
	#include <soft_vertex>
}
`,Qr=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute vec4 rotation;
attribute vec3 size;
// attribute vec4 color;

void main() {

    float x2 = rotation.x + rotation.x, y2 = rotation.y + rotation.y, z2 = rotation.z + rotation.z;
    float xx = rotation.x * x2, xy = rotation.x * y2, xz = rotation.x * z2;
    float yy = rotation.y * y2, yz = rotation.y * z2, zz = rotation.z * z2;
    float wx = rotation.w * x2, wy = rotation.w * y2, wz = rotation.w * z2;
    float sx = size.x, sy = size.y, sz = size.z;
    
    mat4 matrix = mat4(( 1.0 - ( yy + zz ) ) * sx, ( xy + wz ) * sx, ( xz - wy ) * sx, 0.0,  // 1. column
                      ( xy - wz ) * sy, ( 1.0 - ( xx + zz ) ) * sy, ( yz + wx ) * sy, 0.0,  // 2. column
                      ( xz + wy ) * sz, ( yz - wx ) * sz, ( 1.0 - ( xx + yy ) ) * sz, 0.0,  // 3. column
                      offset.x, offset.y, offset.z, 1.0);
    
    vec4 mvPosition = modelViewMatrix * (matrix * vec4( position, 1.0 ));

	vColor = color;

	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
    #include <tile_vertex>
    #include <soft_vertex>
}
`,$r=`
#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>

attribute vec3 offset;
attribute vec4 rotation;
attribute vec3 size;
#include <tile_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

    #include <tile_vertex>
    float x2 = rotation.x + rotation.x, y2 = rotation.y + rotation.y, z2 = rotation.z + rotation.z;
    float xx = rotation.x * x2, xy = rotation.x * y2, xz = rotation.x * z2;
    float yy = rotation.y * y2, yz = rotation.y * z2, zz = rotation.z * z2;
    float wx = rotation.w * x2, wy = rotation.w * y2, wz = rotation.w * z2;
    float sx = size.x, sy = size.y, sz = size.z;

    mat4 particleMatrix = mat4(( 1.0 - ( yy + zz ) ) * sx, ( xy + wz ) * sx, ( xz - wy ) * sx, 0.0,  // 1. column
                      ( xy - wz ) * sy, ( 1.0 - ( xx + zz ) ) * sy, ( yz + wx ) * sy, 0.0,  // 2. column
                      ( xz + wy ) * sz, ( yz - wx ) * sz, ( 1.0 - ( xx + yy ) ) * sz, 0.0,  // 3. column
                      offset.x, offset.y, offset.z, 1.0);

#include <color_vertex>
#include <morphinstance_vertex>
#include <morphcolor_vertex>
#include <batching_vertex>

#include <beginnormal_vertex>
#include <morphnormal_vertex>
#include <skinbase_vertex>
#include <skinnormal_vertex>

	// replace defaultnormal_vertex
	vec3 transformedNormal = objectNormal;
    mat3 m = mat3( particleMatrix );
    transformedNormal /= vec3( dot( m[ 0 ], m[ 0 ] ), dot( m[ 1 ], m[ 1 ] ), dot( m[ 2 ], m[ 2 ] ) );
    transformedNormal = m * transformedNormal;
    transformedNormal = normalMatrix * transformedNormal;
    #ifdef FLIP_SIDED
        transformedNormal = - transformedNormal;
    #endif
    #ifdef USE_TANGENT
        vec3 transformedTangent = ( modelViewMatrix * vec4( objectTangent, 0.0 ) ).xyz;
        #ifdef FLIP_SIDED
        transformedTangent = - transformedTangent;
        #endif
    #endif

	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>

	// replace include <project_vertex>
  vec4 mvPosition = vec4( transformed, 1.0 );
  mvPosition = modelViewMatrix * (particleMatrix * mvPosition);
	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	
	vViewPosition = - mvPosition.xyz;
	
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
    vWorldPosition = worldPosition.xyz;
#endif
}
`,ei=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute float rotation;
attribute vec3 size;
attribute vec4 velocity;

uniform float speedFactor;

void main() {
    float lengthFactor = velocity.w;
    float avgSize = (size.x + size.y) * 0.5;
#ifdef USE_SKEW
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    vec3 viewVelocity = normalMatrix * velocity.xyz;

    vec3 scaledPos = vec3(position.xy * size.xy, position.z);
    float vlength = length(viewVelocity);
    vec3 projVelocity =  dot(scaledPos, viewVelocity) * viewVelocity / vlength;
    mvPosition.xyz += scaledPos + projVelocity * (speedFactor / avgSize + lengthFactor / vlength);
#else
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    vec3 viewVelocity = normalMatrix * velocity.xyz;
    float vlength = length(viewVelocity); 
    mvPosition.xyz += position.y * normalize(cross(mvPosition.xyz, viewVelocity)) * avgSize; // switch the cross to  match unity implementation
    mvPosition.xyz -= (position.x + 0.5) * viewVelocity * (1.0 + lengthFactor / vlength) * avgSize; // minus position.x to match unity implementation
#endif
	vColor = color;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <tile_vertex>
	#include <soft_vertex>
}
`;function ti(e){return e===0?`uv`:`uv${e}`}var ni=class extends c{constructor(e){super(e)}onBeforeCompile(e,t){super.onBeforeCompile(e,t),e.vertexShader=$r,e.fragmentShader=Xr}},ri=class extends w{constructor(e){super(e)}onBeforeCompile(e,t){super.onBeforeCompile(e,t),e.vertexShader=$r,e.fragmentShader=Xr}},ii=class extends Vr{constructor(e){super(e),this.vector_=new O,this.vector2_=new O,this.vector3_=new O,this.quaternion_=new D,this.quaternion2_=new D,this.quaternion3_=new D,this.rotationMat_=new Rt,this.rotationMat2_=new Rt,this.maxParticles=1e3,this.setupBuffers(),this.rebuildMaterial()}buildExpandableBuffers(){this.offsetBuffer=new Se(new Float32Array(this.maxParticles*3),3),this.offsetBuffer.setUsage(i),this.geometry.setAttribute(`offset`,this.offsetBuffer),this.colorBuffer=new Se(new Float32Array(this.maxParticles*4),4),this.colorBuffer.setUsage(i),this.geometry.setAttribute(`color`,this.colorBuffer),this.settings.renderMode===j.Mesh?(this.rotationBuffer=new Se(new Float32Array(this.maxParticles*4),4),this.rotationBuffer.setUsage(i),this.geometry.setAttribute(`rotation`,this.rotationBuffer)):(this.settings.renderMode===j.BillBoard||this.settings.renderMode===j.HorizontalBillBoard||this.settings.renderMode===j.VerticalBillBoard||this.settings.renderMode===j.StretchedBillBoard)&&(this.rotationBuffer=new Se(new Float32Array(this.maxParticles),1),this.rotationBuffer.setUsage(i),this.geometry.setAttribute(`rotation`,this.rotationBuffer)),this.sizeBuffer=new Se(new Float32Array(this.maxParticles*3),3),this.sizeBuffer.setUsage(i),this.geometry.setAttribute(`size`,this.sizeBuffer),this.uvTileBuffer=new Se(new Float32Array(this.maxParticles),1),this.uvTileBuffer.setUsage(i),this.geometry.setAttribute(`uvTile`,this.uvTileBuffer),this.settings.renderMode===j.StretchedBillBoard&&(this.velocityBuffer=new Se(new Float32Array(this.maxParticles*4),4),this.velocityBuffer.setUsage(i),this.geometry.setAttribute(`velocity`,this.velocityBuffer))}setupBuffers(){this.geometry&&this.geometry.dispose(),this.geometry=new n,this.geometry.setIndex(this.settings.instancingGeometry.getIndex()),this.settings.instancingGeometry.hasAttribute(`normal`)&&this.geometry.setAttribute(`normal`,this.settings.instancingGeometry.getAttribute(`normal`)),this.geometry.setAttribute(`position`,this.settings.instancingGeometry.getAttribute(`position`)),this.settings.instancingGeometry.hasAttribute(`uv`)&&this.geometry.setAttribute(`uv`,this.settings.instancingGeometry.getAttribute(`uv`)),this.buildExpandableBuffers()}expandBuffers(e){for(;e>=this.maxParticles;)this.maxParticles*=2;this.setupBuffers()}rebuildMaterial(){this.layers.mask=this.settings.layers.mask;let e={},t={};this.settings.material.type!==`MeshStandardMaterial`&&this.settings.material.type!==`MeshPhysicalMaterial`&&(e.map=new re(this.settings.material.map)),this.settings.material.alphaTest&&(t.USE_ALPHATEST=``,e.alphaTest=new re(this.settings.material.alphaTest)),t.USE_UV=``;let n=this.settings.uTileCount,r=this.settings.vTileCount;(n>1||r>1)&&(t.UV_TILE=``,e.tileCount=new re(new It(n,r))),this.settings.material.defines&&this.settings.material.defines.USE_COLOR_AS_ALPHA!==void 0&&(t.USE_COLOR_AS_ALPHA=``),this.settings.material.normalMap&&(t.USE_NORMALMAP=``,t.NORMALMAP_UV=ti(this.settings.material.normalMap.channel),e.normalMapTransform=new re(new Rt().copy(this.settings.material.normalMap.matrix))),this.settings.material.map&&(t.USE_MAP=``,this.settings.blendTiles&&(t.TILE_BLEND=``),t.MAP_UV=ti(this.settings.material.map.channel),e.mapTransform=new re(new Rt().copy(this.settings.material.map.matrix))),t.USE_COLOR_ALPHA=``;let i;if(this.settings.softParticles){t.SOFT_PARTICLES=``;let n=this.settings.softNearFade,r=1/(this.settings.softFarFade-this.settings.softNearFade);e.softParams=new re(new It(n,r)),e.depthTexture=new re(null);let a=e.projParams=new re(new Lt);i=(e,t,n)=>{a.value.set(n.near,n.far,0,0)}}let a=!1;if(this.settings.renderMode===j.BillBoard||this.settings.renderMode===j.VerticalBillBoard||this.settings.renderMode===j.HorizontalBillBoard||this.settings.renderMode===j.Mesh){let n,r;this.settings.renderMode===j.Mesh?this.settings.material.type===`MeshStandardMaterial`||this.settings.material.type===`MeshPhysicalMaterial`?(t.USE_COLOR=``,n=$r,r=Xr,a=!0):(n=Qr,r=Yr):(n=Zr,r=Yr),this.settings.renderMode===j.VerticalBillBoard?t.VERTICAL=``:this.settings.renderMode===j.HorizontalBillBoard&&(t.HORIZONTAL=``);let i=!1;this.settings.renderMode===j.Mesh&&(this.settings.material.type===`MeshStandardMaterial`?(this.material=new ni({}),this.material.copy(this.settings.material),this.material.uniforms=e,this.material.defines=t,i=!0):this.settings.material.type===`MeshPhysicalMaterial`&&(this.material=new ri({}),this.material.copy(this.settings.material),this.material.uniforms=e,this.material.defines=t,i=!0)),i||(this.material=new ae({uniforms:e,defines:t,vertexShader:n,fragmentShader:r,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,blending:this.settings.material.blending,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha,side:this.settings.material.side,alphaTest:this.settings.material.alphaTest,depthTest:this.settings.material.depthTest,lights:a}))}else if(this.settings.renderMode===j.StretchedBillBoard)e.speedFactor=new re(1),this.material=new ae({uniforms:e,defines:t,vertexShader:ei,fragmentShader:Yr,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,blending:this.settings.material.blending,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha,side:this.settings.material.side,alphaTest:this.settings.material.alphaTest,depthTest:this.settings.material.depthTest});else throw Error(`render mode unavailable`);this.material&&i&&(this.material.onBeforeRender=i)}update(){let e=0,t=0,n=this.getVisibleSystems();for(let e of n)t+=e.particleNum;t>this.maxParticles&&this.expandBuffers(t);for(let t of n){t.emitter.updateMatrixWorld&&(t.emitter.updateWorldMatrix(!0,!1),t.emitter.updateMatrixWorld(!0));let n=t.particles,r=t.particleNum,i=this.quaternion2_,a=this.vector2_,o=this.vector3_;t.emitter.matrixWorld.decompose(a,i,o),this.rotationMat_.setFromMatrix4(t.emitter.matrixWorld);for(let a=0;a<r;a++,e++){let r=n[a];if(this.settings.renderMode===j.Mesh){let n;if(t.worldSpace)n=r.rotation;else{let e;e=r.parentMatrix?this.quaternion3_.setFromRotationMatrix(r.parentMatrix):i,n=this.quaternion_,n.copy(e).multiply(r.rotation)}this.rotationBuffer.setXYZW(e,n.x,n.y,n.z,n.w)}else(this.settings.renderMode===j.StretchedBillBoard||this.settings.renderMode===j.VerticalBillBoard||this.settings.renderMode===j.HorizontalBillBoard||this.settings.renderMode===j.BillBoard)&&this.rotationBuffer.setX(e,r.rotation);let s;if(t.worldSpace?s=r.position:(s=this.vector_,r.parentMatrix?s.copy(r.position).applyMatrix4(r.parentMatrix):s.copy(r.position).applyMatrix4(t.emitter.matrixWorld)),this.offsetBuffer.setXYZ(e,s.x,s.y,s.z),this.colorBuffer.setXYZW(e,r.color.x,r.color.y,r.color.z,r.color.w),t.worldSpace||r.parentMatrix?this.sizeBuffer.setXYZ(e,r.size.x,r.size.y,r.size.z):this.sizeBuffer.setXYZ(e,r.size.x*Math.abs(o.x),r.size.y*Math.abs(o.y),r.size.z*Math.abs(o.z)),this.uvTileBuffer.setX(e,r.uvTile),this.settings.renderMode===j.StretchedBillBoard&&this.velocityBuffer){let n=t.rendererEmitterSettings.speedFactor;n===0&&(n=.001);let i=t.rendererEmitterSettings.lengthFactor,a;t.worldSpace?a=r.velocity:(a=this.vector_,r.parentMatrix?(this.rotationMat2_.setFromMatrix4(r.parentMatrix),a.copy(r.velocity).applyMatrix3(this.rotationMat2_)):a.copy(r.velocity).applyMatrix3(this.rotationMat_)),this.velocityBuffer.setXYZW(e,a.x*n,a.y*n,a.z*n,i)}}}this.geometry.instanceCount=e,e>0&&(this.offsetBuffer.clearUpdateRanges(),this.offsetBuffer.addUpdateRange(0,e*3),this.offsetBuffer.needsUpdate=!0,this.sizeBuffer.clearUpdateRanges(),this.sizeBuffer.addUpdateRange(0,e*3),this.sizeBuffer.needsUpdate=!0,this.colorBuffer.clearUpdateRanges(),this.colorBuffer.addUpdateRange(0,e*4),this.colorBuffer.needsUpdate=!0,this.uvTileBuffer.clearUpdateRanges(),this.uvTileBuffer.addUpdateRange(0,e),this.uvTileBuffer.needsUpdate=!0,this.settings.renderMode===j.StretchedBillBoard&&this.velocityBuffer&&(this.velocityBuffer.clearUpdateRanges(),this.velocityBuffer.addUpdateRange(0,e*4),this.velocityBuffer.needsUpdate=!0),this.settings.renderMode===j.Mesh?(this.rotationBuffer.clearUpdateRanges(),this.rotationBuffer.addUpdateRange(0,e*4),this.rotationBuffer.needsUpdate=!0):(this.settings.renderMode===j.StretchedBillBoard||this.settings.renderMode===j.HorizontalBillBoard||this.settings.renderMode===j.VerticalBillBoard||this.settings.renderMode===j.BillBoard)&&(this.rotationBuffer.clearUpdateRanges(),this.rotationBuffer.addUpdateRange(0,e),this.rotationBuffer.needsUpdate=!0))}dispose(){this.geometry.dispose()}},ai=`

#include <common>
#include <tile_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

uniform sampler2D alphaMap;
uniform float useAlphaMap;
uniform float visibility;
uniform float alphaTest;

varying vec4 vColor;
    
void main() {
    #include <clipping_planes_fragment>
    #include <logdepthbuf_fragment>

    vec4 diffuseColor = vColor;
    
    #ifdef USE_MAP
    #include <tile_fragment>
    #ifndef USE_COLOR_AS_ALPHA
    #endif
    #endif
    if( useAlphaMap == 1. ) diffuseColor.a *= texture2D( alphaMap, vUv).a;
    if( diffuseColor.a < alphaTest ) discard;
    gl_FragColor = diffuseColor;

    #include <fog_fragment>
    #include <tonemapping_fragment>
}`,oi=`
#include <common>
#include <tile_pars_vertex>
#include <color_pars_vertex>
#include <clipping_planes_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <fog_pars_vertex>

attribute vec3 previous;
attribute vec3 next;
attribute float side;
attribute float width;

uniform vec2 resolution;
uniform float lineWidth;
uniform float sizeAttenuation;
    
vec2 fix(vec4 i, float aspect) {
    vec2 res = i.xy / i.w;
    res.x *= aspect;
    return res;
}
    
void main() {

    #include <tile_vertex>
    
    float aspect = resolution.x / resolution.y;

    vColor = color;

    mat4 m = projectionMatrix * modelViewMatrix;
    vec4 finalPosition = m * vec4( position, 1.0 );
    vec4 prevPos = m * vec4( previous, 1.0 );
    vec4 nextPos = m * vec4( next, 1.0 );

    vec2 currentP = fix( finalPosition, aspect );
    vec2 prevP = fix( prevPos, aspect );
    vec2 nextP = fix( nextPos, aspect );

    float w = lineWidth * width;

    vec2 dir;
    if( nextP == currentP ) dir = normalize( currentP - prevP );
    else if( prevP == currentP ) dir = normalize( nextP - currentP );
    else {
        vec2 dir1 = normalize( currentP - prevP );
        vec2 dir2 = normalize( nextP - currentP );
        dir = normalize( dir1 + dir2 );

        vec2 perp = vec2( -dir1.y, dir1.x );
        vec2 miter = vec2( -dir.y, dir.x );
        //w = clamp( w / dot( miter, perp ), 0., 4., * lineWidth * width );

    }

    //vec2 normal = ( cross( vec3( dir, 0. ) vec3( 0., 0., 1. ) ) ).xy;
    vec4 normal = vec4( -dir.y, dir.x, 0., 1. );
    normal.xy *= .5 * w;
    normal *= projectionMatrix;
    if( sizeAttenuation == 0. ) {
        normal.xy *= finalPosition.w;
        normal.xy /= ( vec4( resolution, 0., 1. ) * projectionMatrix ).xy;
    }

    finalPosition.xy += normal.xy * side;

    gl_Position = finalPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	
    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );
    
	#include <fog_vertex>
}`,si=class extends Vr{constructor(e){super(e),this.vector_=new O,this.vector2_=new O,this.vector3_=new O,this.quaternion_=new D,this.maxParticles=1e4,this.setupBuffers(),this.rebuildMaterial()}setupBuffers(){this.geometry&&this.geometry.dispose(),this.geometry=new _e,this.indexBuffer=new Te(new Uint32Array(this.maxParticles*6),1),this.indexBuffer.setUsage(i),this.geometry.setIndex(this.indexBuffer),this.positionBuffer=new Te(new Float32Array(this.maxParticles*6),3),this.positionBuffer.setUsage(i),this.geometry.setAttribute(`position`,this.positionBuffer),this.previousBuffer=new Te(new Float32Array(this.maxParticles*6),3),this.previousBuffer.setUsage(i),this.geometry.setAttribute(`previous`,this.previousBuffer),this.nextBuffer=new Te(new Float32Array(this.maxParticles*6),3),this.nextBuffer.setUsage(i),this.geometry.setAttribute(`next`,this.nextBuffer),this.widthBuffer=new Te(new Float32Array(this.maxParticles*2),1),this.widthBuffer.setUsage(i),this.geometry.setAttribute(`width`,this.widthBuffer),this.sideBuffer=new Te(new Float32Array(this.maxParticles*2),1),this.sideBuffer.setUsage(i),this.geometry.setAttribute(`side`,this.sideBuffer),this.uvBuffer=new Te(new Float32Array(this.maxParticles*4),2),this.uvBuffer.setUsage(i),this.geometry.setAttribute(`uv`,this.uvBuffer),this.colorBuffer=new Te(new Float32Array(this.maxParticles*8),4),this.colorBuffer.setUsage(i),this.geometry.setAttribute(`color`,this.colorBuffer)}expandBuffers(e){for(;e>=this.maxParticles;)this.maxParticles*=2;this.setupBuffers()}rebuildMaterial(){this.layers.mask=this.settings.layers.mask;let e={lineWidth:{value:1},map:{value:null},useMap:{value:0},alphaMap:{value:null},useAlphaMap:{value:0},resolution:{value:new It(1,1)},sizeAttenuation:{value:1},visibility:{value:1},alphaTest:{value:0}},t={};if(t.USE_UV=``,t.USE_COLOR_ALPHA=``,this.settings.material.map&&(t.USE_MAP=``,t.MAP_UV=ti(this.settings.material.map.channel),e.map=new re(this.settings.material.map),e.mapTransform=new re(new Rt().copy(this.settings.material.map.matrix))),this.settings.material.defines&&this.settings.material.defines.USE_COLOR_AS_ALPHA!==void 0&&(t.USE_COLOR_AS_ALPHA=``),this.settings.renderMode===j.Trail)this.material=new ae({uniforms:e,defines:t,vertexShader:oi,fragmentShader:ai,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,side:this.settings.material.side,blending:this.settings.material.blending||2,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha});else throw Error(`render mode unavailable`)}update(){let e=0,t=0,n=0,r=this.getVisibleSystems();for(let e of r)for(let t=0;t<e.particleNum;t++)n+=e.particles[t].previous.length*2;n>this.maxParticles&&this.expandBuffers(n);for(let n of r){n.emitter.updateMatrixWorld&&(n.emitter.updateWorldMatrix(!0,!1),n.emitter.updateMatrixWorld(!0));let r=this.quaternion_,i=this.vector2_,a=this.vector3_;n.emitter.matrixWorld.decompose(i,r,a);let o=n.particles,s=n.particleNum,c=this.settings.uTileCount,l=this.settings.vTileCount,u=1/c,d=1/l;for(let r=0;r<s;r++){let i=o[r],s=i.uvTile%l,c=Math.floor(i.uvTile/l+.001),f=i.previous.values(),p=f.next(),m=p.value,h=m;p.done||(p=f.next());let g;g=p.value===void 0?h:p.value;for(let r=0;r<i.previous.length;r++,e+=2){if(this.positionBuffer.setXYZ(e,h.position.x,h.position.y,h.position.z),this.positionBuffer.setXYZ(e+1,h.position.x,h.position.y,h.position.z),n.worldSpace?(this.positionBuffer.setXYZ(e,h.position.x,h.position.y,h.position.z),this.positionBuffer.setXYZ(e+1,h.position.x,h.position.y,h.position.z)):(i.parentMatrix?this.vector_.copy(h.position).applyMatrix4(i.parentMatrix):this.vector_.copy(h.position).applyMatrix4(n.emitter.matrixWorld),this.positionBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.positionBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),n.worldSpace?(this.previousBuffer.setXYZ(e,m.position.x,m.position.y,m.position.z),this.previousBuffer.setXYZ(e+1,m.position.x,m.position.y,m.position.z)):(i.parentMatrix?this.vector_.copy(m.position).applyMatrix4(i.parentMatrix):this.vector_.copy(m.position).applyMatrix4(n.emitter.matrixWorld),this.previousBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.previousBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),n.worldSpace?(this.nextBuffer.setXYZ(e,g.position.x,g.position.y,g.position.z),this.nextBuffer.setXYZ(e+1,g.position.x,g.position.y,g.position.z)):(i.parentMatrix?this.vector_.copy(g.position).applyMatrix4(i.parentMatrix):this.vector_.copy(g.position).applyMatrix4(n.emitter.matrixWorld),this.nextBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.nextBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),this.sideBuffer.setX(e,1),this.sideBuffer.setX(e+1,-1),n.worldSpace)this.widthBuffer.setX(e,h.size),this.widthBuffer.setX(e+1,h.size);else if(i.parentMatrix)this.widthBuffer.setX(e,h.size),this.widthBuffer.setX(e+1,h.size);else{let t=(Math.abs(a.x)+Math.abs(a.y)+Math.abs(a.z))/3;this.widthBuffer.setX(e,h.size*t),this.widthBuffer.setX(e+1,h.size*t)}this.uvBuffer.setXY(e,(r/i.previous.length+s)*u,(l-c-1)*d),this.uvBuffer.setXY(e+1,(r/i.previous.length+s)*u,(l-c)*d),this.colorBuffer.setXYZW(e,h.color.x,h.color.y,h.color.z,h.color.w),this.colorBuffer.setXYZW(e+1,h.color.x,h.color.y,h.color.z,h.color.w),r+1<i.previous.length&&(this.indexBuffer.setX(t*3,e),this.indexBuffer.setX(t*3+1,e+1),this.indexBuffer.setX(t*3+2,e+2),t++,this.indexBuffer.setX(t*3,e+2),this.indexBuffer.setX(t*3+1,e+1),this.indexBuffer.setX(t*3+2,e+3),t++),m=h,h=g,p.done||(p=f.next(),p.value!==void 0&&(g=p.value))}}}this.positionBuffer.clearUpdateRanges(),this.positionBuffer.addUpdateRange(0,e*3),this.positionBuffer.needsUpdate=!0,this.previousBuffer.clearUpdateRanges(),this.previousBuffer.addUpdateRange(0,e*3),this.previousBuffer.needsUpdate=!0,this.nextBuffer.clearUpdateRanges(),this.nextBuffer.addUpdateRange(0,e*3),this.nextBuffer.needsUpdate=!0,this.sideBuffer.clearUpdateRanges(),this.sideBuffer.addUpdateRange(0,e),this.sideBuffer.needsUpdate=!0,this.widthBuffer.clearUpdateRanges(),this.widthBuffer.addUpdateRange(0,e),this.widthBuffer.needsUpdate=!0,this.uvBuffer.clearUpdateRanges(),this.uvBuffer.addUpdateRange(0,e*2),this.uvBuffer.needsUpdate=!0,this.colorBuffer.clearUpdateRanges(),this.colorBuffer.addUpdateRange(0,e*4),this.colorBuffer.needsUpdate=!0,this.indexBuffer.clearUpdateRanges(),this.indexBuffer.addUpdateRange(0,t*3),this.indexBuffer.needsUpdate=!0,this.geometry.setDrawRange(0,t*3)}dispose(){this.geometry.dispose()}},ci=class e extends Ne{constructor(){super(),this.batches=[],this.systemToBatchIndex=new Map,this.type=`BatchedRenderer`,this.depthTexture=null}static equals(e,t){return e.material.side===t.material.side&&e.material.blending===t.material.blending&&e.material.blendSrc===t.material.blendSrc&&e.material.blendDst===t.material.blendDst&&e.material.blendEquation===t.material.blendEquation&&e.material.premultipliedAlpha===t.material.premultipliedAlpha&&e.material.transparent===t.material.transparent&&e.material.depthTest===t.material.depthTest&&e.material.type===t.material.type&&e.material.alphaTest===t.material.alphaTest&&e.material.map===t.material.map&&e.renderMode===t.renderMode&&e.blendTiles===t.blendTiles&&e.softParticles===t.softParticles&&e.softFarFade===t.softFarFade&&e.softNearFade===t.softNearFade&&e.uTileCount===t.uTileCount&&e.vTileCount===t.vTileCount&&e.instancingGeometry===t.instancingGeometry&&e.renderOrder===t.renderOrder&&e.layers.mask===t.layers.mask}addSystem(t){t._renderer=this;let n=t.getRendererSettings();for(let r=0;r<this.batches.length;r++)if(e.equals(this.batches[r].settings,n)){this.batches[r].addSystem(t),this.systemToBatchIndex.set(t,r);return}let r;switch(n.renderMode){case j.Trail:r=new si(n);break;case j.Mesh:case j.BillBoard:case j.VerticalBillBoard:case j.HorizontalBillBoard:case j.StretchedBillBoard:r=new ii(n)}this.depthTexture&&r.applyDepthTexture(this.depthTexture),r.addSystem(t),this.batches.push(r),this.systemToBatchIndex.set(t,this.batches.length-1),this.add(r)}deleteSystem(e){let t=this.systemToBatchIndex.get(e);t!=null&&(this.batches[t].removeSystem(e),this.systemToBatchIndex.delete(e))}setDepthTexture(e){this.depthTexture=e;for(let t of this.batches)t.applyDepthTexture(e)}updateSystem(e){this.deleteSystem(e),this.addSystem(e)}update(e){this.systemToBatchIndex.forEach((t,n)=>{n.update(e)});for(let e=0;e<this.batches.length;e++)this.batches[e].update()}},li=ci,ui=class e extends o{constructor(){super(),this.type=`QuarksPrefab`,this.animationData=[],this.isPlaying=!1,this.currentTime=-1e-5,this.timeScale=1,this.duration=0,this._mixers=new Map,this._tempAnimationJSON=[],this._clock=new He(!0)}registerBatchedRenderer(e){this._batchedRenderer=e}getOrCreateMixer(e){if(!this._mixers.has(e)){let t=new ce(e);this._mixers.set(e,t)}return this._mixers.get(e)}addThreeAnimation(e,t,n=0,i=t.duration,a=!1){let o=this.getOrCreateMixer(e),s=o.clipAction(t);a||(s.setLoop(r,1),s.clampWhenFinished=!0);let c={startTime:n,duration:i,type:`three`,loop:a,target:e,clip:t,mixer:o,action:s};return this.animationData.push(c),this.updateDuration(),c}addParticleSystemAnimation(e,t=0,n=0,r=!1){n<=0&&(n=e.system.duration);let i={startTime:t,duration:n,type:`ps`,loop:r,target:e};return this.animationData.push(i),this.pause(),this.updateDuration(),i}removeAnimation(e){this.animationData.splice(e,1),this.updateDuration()}play(){this.isPlaying||=!0}pause(){this.isPlaying&&(this.isPlaying=!1,this.animationData.forEach(e=>{e.target&&(e.type===`ps`&&!e.target.system.paused?e.target.system.pause():e.type===`three`&&e.action&&e.action.isRunning()&&(e.action.paused=!0))}))}stop(){this.pause(),this.currentTime=-1e-5,this.animationData.forEach(e=>{e.type===`ps`&&e.target?e.target.system.stop():e.type===`three`&&e.mixer&&e.action&&e.action.reset()})}update(e){if(!this.isPlaying)return;let t=e===void 0?this._clock.getDelta():e;this.currentTime+=t*this.timeScale,this.currentTime>this.duration&&this.stop();let n=new Set;this.animationData.forEach(e=>{let{startTime:r,duration:i,type:a,loop:o,target:s,action:c,mixer:l}=e,u=r+i,d=this.currentTime>=r,f=this.currentTime>u,p=Math.abs(this.currentTime-r)<t;a===`three`&&c&&l?d&&!f?(p?(c.reset(),c.play()):c.paused&&(c.paused=!1,c.play()),this.currentTime-r,n.add(l)):f&&(c.paused=!0):a===`ps`&&s&&(d&&!f?p&&e.target.system.restart():f&&e.target.system.endEmit())}),n.forEach(e=>{e.update(t)})}setTime(e){let t=this.currentTime;this.currentTime=e,this.animationData.forEach(n=>{let{startTime:r,duration:i,type:a,target:o,action:s,mixer:c}=n;a===`three`&&s&&c?(s.reset(),e>=r&&e<r+i&&(s.time=e-r,s.play(),c.update(0),s.paused=!this.isPlaying)):a===`ps`&&o&&(e>=r&&e<r+i?(t<r||t>=r+i)&&o.system.restart():o.system.endEmit())})}getDuration(){return this.duration}updateDuration(){let e=0;this.animationData.forEach(t=>{let n=t.startTime+t.duration;n>e&&(e=n)}),this.duration=e}resolveReferences(e){this._tempAnimationJSON.forEach(t=>{let n;if(e.traverse(e=>{e.uuid===t.targetUUID&&(n=e)}),n){if(t.type===`three`&&t.clipUUID){let e;n.animations&&(e=n.animations.find(e=>e.uuid===t.clipUUID)),e&&this.addThreeAnimation(n,e,t.startTime,t.duration,t.loop)}else t.type===`ps`&&this.addParticleSystemAnimation(n,t.startTime,t.duration,t.loop)}}),this.updateDuration(),this._tempAnimationJSON=[]}toJSON(){let e=super.toJSON();return e.object.animationData=this.animationData.map(e=>({startTime:e.startTime,duration:e.duration,type:e.type,targetUUID:e.target.uuid,clipUUID:e.clip?.uuid,loop:e.loop})),e}static fromJSON(t){let n=new e;return t.animationData&&(n._tempAnimationJSON=t.animationData),n}},di=class extends d{constructor(e){super(e)}linkReference(e){let t={};e.traverse(function(e){t[e.uuid]=e}),e.traverse(function(e){if(e.type===`ParticleEmitter`){let n=e.system;n.emitterShape;for(let e=0;e<n.behaviors.length;e++)n.behaviors[e]instanceof qn&&(n.behaviors[e].subParticleSystem=t[n.behaviors[e].subParticleSystem])}})}parse(e,t){let n=super.parse(e,t);return this.linkReference(n),n}parseObject(e,n,r,i,c){let u;function d(e){return n[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined geometry`,e),n[e]}function f(e){if(e!==void 0){if(Array.isArray(e)){let t=[];for(let n=0,i=e.length;n<i;n++){let i=e[n];r[i]===void 0&&console.warn(`THREE.ObjectLoader: Undefined material`,i),t.push(r[i])}return t}return r[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined material`,e),r[e]}}function h(e){return i[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined texture`,e),i[e]}let g,v,S={textures:i,geometries:n,materials:r},C={};switch(e.type){case`QuarksPrefab`:u=ui.fromJSON(e);break;case`ParticleEmitter`:u=Jr.fromJSON(e.ps,S,C).emitter;break;case`Scene`:u=new be,e.background!==void 0&&(Number.isInteger(e.background)?u.background=new Ke(e.background):u.background=h(e.background)),e.environment!==void 0&&(u.environment=h(e.environment)),e.fog!==void 0&&(e.fog.type===`Fog`?u.fog=new We(e.fog.color,e.fog.near,e.fog.far):e.fog.type===`FogExp2`&&(u.fog=new x(e.fog.color,e.fog.density)),e.fog.name!==``&&(u.fog.name=e.fog.name)),e.backgroundBlurriness!==void 0&&(u.backgroundBlurriness=e.backgroundBlurriness),e.backgroundIntensity!==void 0&&(u.backgroundIntensity=e.backgroundIntensity),e.backgroundRotation!==void 0&&u.backgroundRotation.fromArray(e.backgroundRotation),e.environmentIntensity!==void 0&&(u.environmentIntensity=e.environmentIntensity),e.environmentRotation!==void 0&&u.environmentRotation.fromArray(e.environmentRotation);break;case`PerspectiveCamera`:u=new te(e.fov,e.aspect,e.near,e.far),e.focus!==void 0&&(u.focus=e.focus),e.zoom!==void 0&&(u.zoom=e.zoom),e.filmGauge!==void 0&&(u.filmGauge=e.filmGauge),e.filmOffset!==void 0&&(u.filmOffset=e.filmOffset),e.view!==void 0&&(u.view=Object.assign({},e.view));break;case`OrthographicCamera`:u=new T(e.left,e.right,e.top,e.bottom,e.near,e.far),e.zoom!==void 0&&(u.zoom=e.zoom),e.view!==void 0&&(u.view=Object.assign({},e.view));break;case`AmbientLight`:u=new Ie(e.color,e.intensity);break;case`DirectionalLight`:u=new b(e.color,e.intensity);break;case`PointLight`:u=new t(e.color,e.intensity,e.distance,e.decay);break;case`RectAreaLight`:u=new ze(e.color,e.intensity,e.width,e.height);break;case`SpotLight`:u=new Ve(e.color,e.intensity,e.distance,e.angle,e.penumbra,e.decay);break;case`HemisphereLight`:u=new a(e.color,e.groundColor,e.intensity);break;case`LightProbe`:u=new _,e.sh!==void 0&&(u.sh=new we().fromArray(e.sh));break;case`SkinnedMesh`:g=d(e.geometry),v=f(e.material),u=new Ae(g,v),e.bindMode!==void 0&&(u.bindMode=e.bindMode),e.bindMatrix!==void 0&&u.bindMatrix.fromArray(e.bindMatrix),e.skeleton!==void 0&&(u.skeleton=e.skeleton);break;case`Mesh`:g=d(e.geometry),v=f(e.material),u=new l(g,v);break;case`InstancedMesh`:{g=d(e.geometry),v=f(e.material);let t=e.count,n=e.instanceMatrix,r=e.instanceColor;u=new xe(g,v,t),u.instanceMatrix=new Se(new Float32Array(n.array),16),r!==void 0&&(u.instanceColor=new Se(new Float32Array(r.array),r.itemSize));break}case`BatchedMesh`:g=d(e.geometry),v=f(e.material),u=new Be(e.maxGeometryCount,e.maxVertexCount,e.maxIndexCount,v),u.geometry=g,u.perObjectFrustumCulled=e.perObjectFrustumCulled,u.sortObjects=e.sortObjects,u._drawRanges=e.drawRanges,u._reservedRanges=e.reservedRanges,u._visibility=e.visibility,u._active=e.active,u._bounds=e.bounds.map(e=>{let t=new pe;t.min.fromArray(e.boxMin),t.max.fromArray(e.boxMax);let n=new Le;return n.radius=e.sphereRadius,n.center.fromArray(e.sphereCenter),{boxInitialized:e.boxInitialized,box:t,sphereInitialized:e.sphereInitialized,sphere:n}}),u._maxGeometryCount=e.maxGeometryCount,u._maxVertexCount=e.maxVertexCount,u._maxIndexCount=e.maxIndexCount,u._geometryInitialized=e.geometryInitialized,u._geometryCount=e.geometryCount,u._matricesTexture=h(e.matricesTexture.uuid);break;case`LOD`:u=new m;break;case`Line`:u=new s(d(e.geometry),f(e.material));break;case`LineLoop`:u=new p(d(e.geometry),f(e.material));break;case`LineSegments`:u=new y(d(e.geometry),f(e.material));break;case`PointCloud`:case`Points`:u=new fe(d(e.geometry),f(e.material));break;case`Sprite`:u=new de(f(e.material));break;case`Group`:u=new o;break;case`Bone`:u=new ue;break;default:u=new Ne}if(u.uuid=e.uuid,e.name!==void 0&&(u.name=e.name),e.matrix===void 0?(e.position!==void 0&&u.position.fromArray(e.position),e.rotation!==void 0&&u.rotation.fromArray(e.rotation),e.quaternion!==void 0&&u.quaternion.fromArray(e.quaternion),e.scale!==void 0&&u.scale.fromArray(e.scale)):(u.matrix.fromArray(e.matrix),e.matrixAutoUpdate!==void 0&&(u.matrixAutoUpdate=e.matrixAutoUpdate),u.matrixAutoUpdate&&(u.matrix.decompose(u.position,u.quaternion,u.scale),isNaN(u.quaternion.x)&&u.quaternion.set(0,0,0,1))),e.up!==void 0&&u.up.fromArray(e.up),e.castShadow!==void 0&&(u.castShadow=e.castShadow),e.receiveShadow!==void 0&&(u.receiveShadow=e.receiveShadow),e.shadow&&(e.shadow.bias!==void 0&&(u.shadow.bias=e.shadow.bias),e.shadow.normalBias!==void 0&&(u.normalBias=e.shadow.normalBias),e.shadow.radius!==void 0&&(u.radius=e.shadow.radius),e.shadow.mapSize!==void 0&&u.mapSize.fromArray(e.shadow.mapSize),e.shadow.camera!==void 0&&(u.camera=this.parseObject(e.shadow.camera))),e.visible!==void 0&&(u.visible=e.visible),e.frustumCulled!==void 0&&(u.frustumCulled=e.frustumCulled),e.renderOrder!==void 0&&(u.renderOrder=e.renderOrder),e.userData!==void 0&&(u.userData=e.userData),e.layers!==void 0&&(u.layers.mask=e.layers),e.children!==void 0){let t=e.children;for(let e=0;e<t.length;e++)u.add(this.parseObject(t[e],n,r,i,c))}if(e.animations!==void 0){let t=e.animations;for(let e=0;e<t.length;e++){let n=t[e];u.animations.push(c[n])}}if(e.type===`LOD`){e.autoUpdate!==void 0&&(u.autoUpdate=e.autoUpdate);let t=e.levels;for(let e=0;e<t.length;e++){let n=t[e],r=u.getObjectByProperty(`uuid`,n.object);r!==void 0&&u.addLevel(r,n.distance)}}else e.type===`QuarksPrefab`&&u.resolveReferences(u);return u}},fi=class e{static runOnAllParticleEmitters(e,t){e.traverse(e=>{e.type===`ParticleEmitter`&&t(e)}),e.type===`ParticleEmitter`&&t(e)}static addToBatchRenderer(t,n){e.runOnAllParticleEmitters(t,e=>{n.addSystem(e.system)})}static play(t){e.runOnAllParticleEmitters(t,e=>{e.system.play()})}static stop(t){e.runOnAllParticleEmitters(t,e=>{e.system.stop()})}static setAutoDestroy(t,n){e.runOnAllParticleEmitters(t,e=>{e.system.autoDestroy=n})}static endEmit(t){e.runOnAllParticleEmitters(t,e=>{e.system.endEmit()})}static restart(t){e.runOnAllParticleEmitters(t,e=>{e.system.restart()})}static pause(t){e.runOnAllParticleEmitters(t,e=>{e.system.pause()})}};zr(),Tr(kr),console.log(`%c Particle system powered by three.quarks. https://quarks.art/`,`font-size: 14px; font-weight: bold;`);var pi;(function(e){e.Unimplemented=`UNIMPLEMENTED`,e.Unavailable=`UNAVAILABLE`})(pi||={});var mi=class extends Error{constructor(e,t,n){super(e),this.message=e,this.code=t,this.data=n}},hi=e=>e?.androidBridge?`android`:e?.webkit?.messageHandlers?.bridge?`ios`:`web`,gi=e=>{let t=e.CapacitorCustomPlatform||null,n=e.Capacitor||{},r=n.Plugins=n.Plugins||{},i=()=>t===null?hi(e):t.name,a=()=>i()!==`web`,o=e=>!!(l.get(e)?.platforms.has(i())||s(e)),s=e=>n.PluginHeaders?.find(t=>t.name===e),c=t=>e.console.error(t),l=new Map;return n.convertFileSrc||=e=>e,n.getPlatform=i,n.handleError=c,n.isNativePlatform=a,n.isPluginAvailable=o,n.registerPlugin=(e,a={})=>{let o=l.get(e);if(o)return console.warn(`Capacitor plugin "${e}" already registered. Cannot register plugins twice.`),o.proxy;let c=i(),u=s(e),d,f=async()=>(!d&&c in a?d=d=typeof a[c]==`function`?await a[c]():a[c]:t!==null&&!d&&`web`in a&&(d=d=typeof a.web==`function`?await a.web():a.web),d),p=(t,r)=>{if(u){let i=u?.methods.find(e=>r===e.name);if(i)return i.rtype===`promise`?t=>n.nativePromise(e,r.toString(),t):(t,i)=>n.nativeCallback(e,r.toString(),t,i);if(t)return t[r]?.bind(t)}else if(t)return t[r]?.bind(t);else throw new mi(`"${e}" plugin is not implemented on ${c}`,pi.Unimplemented)},m=t=>{let n,r=(...r)=>{let i=f().then(i=>{let a=p(i,t);if(a){let e=a(...r);return n=e?.remove,e}throw new mi(`"${e}.${t}()" is not implemented on ${c}`,pi.Unimplemented)});return t===`addListener`&&(i.remove=async()=>n()),i};return r.toString=()=>`${t.toString()}() { [capacitor code] }`,Object.defineProperty(r,"name",{value:t,writable:!1,configurable:!1}),r},h=m(`addListener`),g=m(`removeListener`),_=(e,t)=>{let n=h({eventName:e},t),r=async()=>{let r=await n;g({eventName:e,callbackId:r},t)},i=new Promise(e=>n.then(()=>e({remove:r})));return i.remove=async()=>{console.warn(`Using addListener() without 'await' is deprecated.`),await r()},i},v=new Proxy({},{get(e,t){switch(t){case`$$typeof`:return;case`toJSON`:return()=>({});case`addListener`:return u?_:h;case`removeListener`:return g;default:return m(t)}}});return r[e]=v,l.set(e,{name:e,proxy:v,platforms:new Set([...Object.keys(a),...u?[c]:[]])}),v},n.Exception=mi,n.DEBUG=!!n.DEBUG,n.isLoggingEnabled=!!n.isLoggingEnabled,n},_i=(e=>e.Capacitor=gi(e))(typeof globalThis<`u`?globalThis:typeof self<`u`?self:typeof window<`u`?window:typeof global<`u`?global:{}),vi=_i.registerPlugin,yi=class{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let n=!1;this.listeners[e]||(this.listeners[e]=[],n=!0),this.listeners[e].push(t);let r=this.windowListeners[e];return r&&!r.registered&&this.addWindowListener(r),n&&this.sendRetainedArgumentsForEvent(e),Promise.resolve({remove:async()=>this.removeListener(e,t)})}async removeAllListeners(){this.listeners={};for(let e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,n){let r=this.listeners[e];if(!r){if(n){let n=this.retainedEventArguments[e];n||=[],n.push(t),this.retainedEventArguments[e]=n}return}r.forEach(e=>e(t))}hasListeners(e){return!!this.listeners[e]?.length}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:e=>{this.notifyListeners(t,e)}}}unimplemented(e=`not implemented`){return new _i.Exception(e,pi.Unimplemented)}unavailable(e=`not available`){return new _i.Exception(e,pi.Unavailable)}async removeListener(e,t){let n=this.listeners[e];if(!n)return;let r=n.indexOf(t);r!==-1&&this.listeners[e].splice(r,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){let t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(t=>{this.notifyListeners(e,t)}))}},bi=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),xi=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent),Si=class extends yi{async getCookies(){let e=document.cookie,t={};return e.split(`;`).forEach(e=>{if(e.length<=0)return;let[n,r]=e.replace(/=/,`CAP_COOKIE`).split(`CAP_COOKIE`);n=xi(n).trim(),r=xi(r).trim(),t[n]=r}),t}async setCookie(e){try{let t=bi(e.key),n=bi(e.value),r=e.expires?`; expires=${e.expires.replace(`expires=`,``)}`:``,i=(e.path||`/`).replace(`path=`,``),a=e.url!=null&&e.url.length>0?`domain=${e.url}`:``;document.cookie=`${t}=${n||``}${r}; path=${i}; ${a};`}catch(e){return Promise.reject(e)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(e){return Promise.reject(e)}}async clearCookies(){try{let e=document.cookie.split(`;`)||[];for(let t of e)document.cookie=t.replace(/^ +/,``).replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}};vi(`CapacitorCookies`,{web:()=>new Si});var Ci=async e=>new Promise((t,n)=>{let r=new FileReader;r.onload=()=>{let e=r.result;t(e.indexOf(`,`)>=0?e.split(`,`)[1]:e)},r.onerror=e=>n(e),r.readAsDataURL(e)}),wi=(e={})=>{let t=Object.keys(e);return Object.keys(e).map(e=>e.toLocaleLowerCase()).reduce((n,r,i)=>(n[r]=e[t[i]],n),{})},Ti=(e,t=!0)=>e?Object.entries(e).reduce((e,n)=>{let[r,i]=n,a,o;return Array.isArray(i)?(o=``,i.forEach(e=>{a=t?encodeURIComponent(e):e,o+=`${r}=${a}&`}),o.slice(0,-1)):(a=t?encodeURIComponent(i):i,o=`${r}=${a}`),`${e}&${o}`},``).substr(1):null,Ei=(e,t={})=>{let n=Object.assign({method:e.method||`GET`,headers:e.headers},t),r=wi(e.headers)[`content-type`]||``;if(typeof e.data==`string`)n.body=e.data;else if(r.includes(`application/x-www-form-urlencoded`)){let t=new URLSearchParams;for(let[n,r]of Object.entries(e.data||{}))t.set(n,r);n.body=t.toString()}else if(r.includes(`multipart/form-data`)||e.data instanceof FormData){let t=new FormData;if(e.data instanceof FormData)e.data.forEach((e,n)=>{t.append(n,e)});else for(let n of Object.keys(e.data))t.append(n,e.data[n]);n.body=t;let r=new Headers(n.headers);r.delete(`content-type`),n.headers=r}else(r.includes(`application/json`)||typeof e.data==`object`)&&(n.body=JSON.stringify(e.data));return n},Di=class extends yi{async request(e){let t=Ei(e,e.webFetchExtra),n=Ti(e.params,e.shouldEncodeUrlParams),r=n?`${e.url}?${n}`:e.url,i=await fetch(r,t),a=i.headers.get(`content-type`)||``,{responseType:o=`text`}=i.ok?e:{};a.includes(`application/json`)&&(o=`json`);let s,c;switch(o){case`arraybuffer`:case`blob`:c=await i.blob(),s=await Ci(c);break;case`json`:s=await i.json();break;default:s=await i.text()}let l={};return i.headers.forEach((e,t)=>{l[t]=e}),{data:s,headers:l,status:i.status,url:i.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:`GET`}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:`POST`}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:`PUT`}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:`PATCH`}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:`DELETE`}))}};vi(`CapacitorHttp`,{web:()=>new Di});var Oi;(function(e){e.Dark=`DARK`,e.Light=`LIGHT`,e.Default=`DEFAULT`})(Oi||={});var ki;(function(e){e.StatusBar=`StatusBar`,e.NavigationBar=`NavigationBar`})(ki||={});var Ai=class extends yi{async setStyle(){this.unavailable(`not available for web`)}async setAnimation(){this.unavailable(`not available for web`)}async show(){this.unavailable(`not available for web`)}async hide(){this.unavailable(`not available for web`)}};vi(`SystemBars`,{web:()=>new Ai});var M={maxPixelRatio:2,difficultyPressureMultiplier:.88,obstacleSpawnCount:2,arenaSize:26,arenaLimit:12,playerSpeed:5,playerStartHeight:.75,playerRadius:1.05,cellPickupRadius:1.15,cellCashValue:1,baseCellCashValue:1,initialCellCount:5,initialObstacleTypes:[`regular`,`chaser`,`creeper`],cellSpawnInterval:5,cellMagnetRange:4,cellMagnetBaseSpeed:.8,boosterSpawnInterval:18,speedBoosterBaseDuration:5,thornShieldBaseDuration:4,freezerBaseDuration:3,pushbackBaseRange:3.5,pushbackBaseSpeed:.7,slowAuraBaseRange:4,slowAuraBaseEffect:.25,orbitalElectronOrbitRadius:3.5,orbitalElectronBaseSpeed:2.1,orbitalElectronBaseStunDuration:.65,orbitalElectronHitRadius:.28,cellMinDistance:3,chronoCellSpawnInterval:20,chronoCellLifetime:9,chronoCellMinDistance:4,chronoCellChronoshardValue:1,obstacleMinDistance:4,obstacleColliderRadius:.86,obstacleColliderIterations:2,creeperStaticCollisionSlowDuration:.35,creeperStaticCollisionSpeedMultiplier:.45,obstacleSpawnInterval:7.85,obstacleSpawnDecreasePerCell:.07,regularObstacleLifetime:32,regularObstacleLifetimeIncreasePerCell:.14,obstacleDespawnWarningDuration:2,obstacleDespawnWarningStartFrequency:1.2,obstacleDespawnWarningEndFrequency:10,obstacleSpawnWarningDuration:2,bangerExplosionVfxDuration:.65,bangerPulseStartInterval:.9,bangerPulseEndInterval:.1,bangerPulseVfxDuration:.55,fallingBlockStartHeight:16,obstacleGroundHeight:.86,fallingBlockGroundHeight:.86,fallingBlockDuration:1.8,fallingBlockLifetime:1.9,fallingBlockMinInterval:1.8,fallingBlockBaseInterval:24,fallingRockSpawnFrequencyMultiplier:.75,fallingBlockIntervalPerCell:.1,fallingRockImpactOffset:.8,fieryRockFireDuration:5,fieryRockFireRadius:1.7,poisonTrailDuration:5.5,fieryRockFlameCount:9,fieryRockEmberCount:12,splinterPieceCount:4,splinterPieceDistance:8,splinterPieceDuration:1,shockwaveBaseRadius:4.5,shockwaveBaseInterval:8,shockwavePushDistance:4.5,shockwaveVfxDuration:.65,shieldInvulnerabilityDuration:1,playerDeathVfxDuration:.9},ji={sector1:{extraArenaPadding:0,cellsRequiredToAdvance:30,cashValueMultiplier:1,availableObstacleTypes:[`regular`,`creeper`],maxActiveEnemies:10,maxActiveEnemiesIncrementPerCell:.03,obstacleSpawnCountOffset:0,obstacleSpawnCountIncreasePerCell:.035,obstacleSpawnIntervalOffset:1.8,obstacleSpawnDecreasePerCellOffset:.002,obstacleLifetimeOffset:-7,obstacleLifetimeIncreasePerCellOffset:-.03,regularSpawnWeight:.7,creeperSpawnWeight:.3,availableFallingRockTypes:[`stoneRock`],fallingRockSpawnIntervalOffset:1.5,fallingRockSpawnDecreasePerCellOffset:-.04,stoneRockSpawnWeight:1},sector2:{extraArenaPadding:1,cellsRequiredToAdvance:100,cashValueMultiplier:2,availableObstacleTypes:[`regular`,`chaser`,`creeper`],maxActiveEnemies:11,maxActiveEnemiesIncrementPerCell:.04,obstacleSpawnCountOffset:1,obstacleSpawnCountIncreasePerCell:.047,obstacleSpawnIntervalOffset:.6,obstacleSpawnDecreasePerCellOffset:.014,obstacleLifetimeOffset:-4.8,obstacleLifetimeIncreasePerCellOffset:.012,regularSpawnWeight:.6,chaserSpawnWeight:.2,creeperSpawnWeight:.2,availableFallingRockTypes:[`stoneRock`,`splinter`],fallingRockSpawnIntervalOffset:-5.8,fallingRockSpawnDecreasePerCellOffset:-.01,stoneRockSpawnWeight:.8,splinterSpawnWeight:.2},sector3:{extraArenaPadding:2,cellsRequiredToAdvance:200,cashValueMultiplier:4,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:13,maxActiveEnemiesIncrementPerCell:.05,obstacleSpawnCountOffset:2,obstacleSpawnCountIncreasePerCell:.06,obstacleSpawnIntervalOffset:-.4,obstacleSpawnDecreasePerCellOffset:.025,obstacleLifetimeOffset:-2.4,obstacleLifetimeIncreasePerCellOffset:.032,regularSpawnWeight:.6,chaserSpawnWeight:.1,creeperSpawnWeight:.1,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-11,fallingRockSpawnDecreasePerCellOffset:.015,stoneRockSpawnWeight:.6,fieryRockSpawnWeight:.2,splinterSpawnWeight:.2},sector4:{extraArenaPadding:3,cellsRequiredToAdvance:300,cashValueMultiplier:8,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:14,maxActiveEnemiesIncrementPerCell:.06,obstacleSpawnCountOffset:3,obstacleSpawnCountIncreasePerCell:.072,obstacleSpawnIntervalOffset:-.9,obstacleSpawnDecreasePerCellOffset:.03,obstacleLifetimeOffset:-.2,obstacleLifetimeIncreasePerCellOffset:.052,regularSpawnWeight:.5,chaserSpawnWeight:.16,creeperSpawnWeight:.14,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-16.2,fallingRockSpawnDecreasePerCellOffset:.065,stoneRockSpawnWeight:.4,fieryRockSpawnWeight:.35,splinterSpawnWeight:.25},sector5:{extraArenaPadding:4,cellsRequiredToAdvance:300,cashValueMultiplier:16,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`],maxActiveEnemies:16,maxActiveEnemiesIncrementPerCell:.07,obstacleSpawnCountOffset:5,obstacleSpawnCountIncreasePerCell:.085,obstacleSpawnIntervalOffset:-1.9,obstacleSpawnDecreasePerCellOffset:.042,obstacleLifetimeOffset:2,obstacleLifetimeIncreasePerCellOffset:.076,regularSpawnWeight:.42,chaserSpawnWeight:.2,creeperSpawnWeight:.15,bangerSpawnWeight:.12,shooterSpawnWeight:.11,porterSpawnWeight:.08,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-18.4,fallingRockSpawnDecreasePerCellOffset:.088,stoneRockSpawnWeight:.3,fieryRockSpawnWeight:.42,splinterSpawnWeight:.28},sector6:{extraArenaPadding:5,cellsRequiredToAdvance:300,cashValueMultiplier:32,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`],maxActiveEnemies:17,maxActiveEnemiesIncrementPerCell:.08,obstacleSpawnCountOffset:6,obstacleSpawnCountIncreasePerCell:.097,obstacleSpawnIntervalOffset:-2.8,obstacleSpawnDecreasePerCellOffset:.054,obstacleLifetimeOffset:4.2,obstacleLifetimeIncreasePerCellOffset:.1,regularSpawnWeight:.34,chaserSpawnWeight:.23,creeperSpawnWeight:.16,bangerSpawnWeight:.14,shooterSpawnWeight:.13,porterSpawnWeight:.1,magnetSpawnWeight:.09,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-20.6,fallingRockSpawnDecreasePerCellOffset:.112,stoneRockSpawnWeight:.24,fieryRockSpawnWeight:.47,splinterSpawnWeight:.29},sector7:{extraArenaPadding:6,cellsRequiredToAdvance:300,cashValueMultiplier:64,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:19,maxActiveEnemiesIncrementPerCell:.09,obstacleSpawnCountOffset:7,obstacleSpawnCountIncreasePerCell:.11,obstacleSpawnIntervalOffset:-3.7,obstacleSpawnDecreasePerCellOffset:.066,obstacleLifetimeOffset:6.6,obstacleLifetimeIncreasePerCellOffset:.124,regularSpawnWeight:.28,chaserSpawnWeight:.26,creeperSpawnWeight:.17,bangerSpawnWeight:.15,shooterSpawnWeight:.14,porterSpawnWeight:.11,magnetSpawnWeight:.11,sporeSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-22.7,fallingRockSpawnDecreasePerCellOffset:.136,stoneRockSpawnWeight:.18,fieryRockSpawnWeight:.51,splinterSpawnWeight:.31},sector8:{extraArenaPadding:7,cellsRequiredToAdvance:300,cashValueMultiplier:128,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:20,maxActiveEnemiesIncrementPerCell:.1,obstacleSpawnCountOffset:8,obstacleSpawnCountIncreasePerCell:.123,obstacleSpawnIntervalOffset:-4.6,obstacleSpawnDecreasePerCellOffset:.078,obstacleLifetimeOffset:9.2,obstacleLifetimeIncreasePerCellOffset:.148,regularSpawnWeight:.22,chaserSpawnWeight:.29,creeperSpawnWeight:.18,bangerSpawnWeight:.16,shooterSpawnWeight:.15,porterSpawnWeight:.12,magnetSpawnWeight:.13,sporeSpawnWeight:.12,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-24.5,fallingRockSpawnDecreasePerCellOffset:.16,stoneRockSpawnWeight:.14,fieryRockSpawnWeight:.54,splinterSpawnWeight:.32},sector9:{extraArenaPadding:8,cellsRequiredToAdvance:400,cashValueMultiplier:256,availableObstacleTypes:[`regular`,`chaser`,`poisonCreeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:22,maxActiveEnemiesIncrementPerCell:.11,obstacleSpawnCountOffset:9,obstacleSpawnCountIncreasePerCell:.14,obstacleSpawnIntervalOffset:-5.4,obstacleSpawnDecreasePerCellOffset:.09,obstacleLifetimeOffset:12,obstacleLifetimeIncreasePerCellOffset:.17,regularSpawnWeight:.18,chaserSpawnWeight:.3,poisonCreeperSpawnWeight:.2,bangerSpawnWeight:.17,shooterSpawnWeight:.16,porterSpawnWeight:.14,magnetSpawnWeight:.14,sporeSpawnWeight:.14,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-26,fallingRockSpawnDecreasePerCellOffset:.18,stoneRockSpawnWeight:.1,fieryRockSpawnWeight:.56,splinterSpawnWeight:.34}},N={background:`#101b25`,floor:`#1d3a46`,gridMajor:`#50e5bc`,gridMinor:`#244b59`,arenaBoundary:`#ff795f`,player:`#67d46e`,playerEmissive:`#1d7437`,playerWing:`#9af08f`,playerWingEmissive:`#2f8b42`,playerRing:`#d7ffb8`,cell:`#63f5cd`,cellEmissive:`#00b487`,chronoCell:`#b59aff`,chronoCellEmissive:`#5933c7`,slowAura:`#63f5cd`,obstacle:`#41687c`,obstacleEmissive:`#07141d`,chaser:`#c36b55`,chaserEmissive:`#70281d`,creeper:`#8d71c5`,creeperEmissive:`#38265c`,poisonCreeper:`#215c3a`,poisonCreeperEmissive:`#0b3d25`,poisonTrail:`#75df65`,banger:`#ffb347`,bangerEmissive:`#8f3100`,shooter:`#63f58a`,shooterEmissive:`#086b35`,porter:`#4ba3ff`,porterEmissive:`#124b9e`,magnet:`#050505`,magnetEmissive:`#171717`,spore:`#ff8fd0`,sporeEmissive:`#9b145f`,fallingObstacle:`#66869a`,fallingObstacleEmissive:`#152b3b`,fieryRock:`#ff6948`,fieryRockEmissive:`#b11d08`,splinter:`#d2c27e`,splinterEmissive:`#675b25`,fire:`#ff8a38`,targetShadow:`#020407`,targetRing:`#ff795f`},Mi={fov:52,near:.1,far:100,angle:53,landscapeDistance:8,portraitDistance:16,followStrength:.06},Ni={floorMetalness:.5,floorRoughness:.55,floorOpacity:.76,starCount:720,brightStarCount:70,starfieldRadius:70,starSize:1.55,brightStarSize:3.1},Pi={hemisphereSky:`#b8e8ff`,hemisphereGround:`#0a1016`,hemisphereIntensity:2.2,key:`#fff4cf`,keyIntensity:3},P={playerCoreRadius:.7,playerCoreDetail:1,playerCoreEmissiveIntensity:1.4,playerCoreMetalness:.35,playerCoreRoughness:.25,playerRingRadius:.92,playerRingTube:.07,playerRingRadialSegments:10,playerRingTubularSegments:32,cellRadius:.42,chronoCellRadius:.52,chronoCellEmissiveIntensity:2.4,obstacleRadius:.86,fallingRockDetail:1,obstacleCoreRadius:.48,obstacleSpikeRadius:.2,obstacleSpikeHeight:.68,obstacleSpikeSegments:5,cellEmissiveIntensity:1.8,cellMetalness:.08,cellRoughness:.48,obstacleMetalness:.6,obstacleRoughness:.3,fallingObstacleEmissiveIntensity:.8,fallingObstacleMetalness:.65,fallingObstacleRoughness:.25,chaserRangeIndicatorWidth:.08,chaserRangeIndicatorSegments:64,chaserRange:3.5,bangerRangeMultiplier:1.5,bangerFuseDuration:3,shooterRangeMultiplier:2,shooterProjectileRadius:.24,shooterProjectileSpeed:5.25,shooterProjectileLifetime:2.4,shooterProjectileCooldown:2,porterTeleportInterval:10,porterWarningDuration:2,porterTeleportMinDistance:3,porterTeleportMaxDistance:7,magnetPullSpeed:1.1,sporeFuseDuration:3,sporeFragmentCount:4,sporeFragmentChildCount:4,sporeFragmentDuration:1.35,sporeFragmentSpeed:4.6,sporeFragmentScale:.42,sporeFragmentChildScale:.18,poisonCreeperTrailInterval:.42,poisonCreeperTrailRadius:.9,spawnRingInnerRadius:.38,spawnRingOuterRadius:.5,spawnRingSegments:32,spawnCueGlowRadius:1.45,spawnCueBeamHeight:3.2,slowAuraRingWidth:.1,slowAuraRingSegments:64},F={playerTurnSpeed:1.4,playerCoreSpinSpeed:1.8,playerRingSpinSpeed:2.4,cellSpinSpeed:2.2,cellBobBaseHeight:.8,cellBobAmplitude:.16,cellBobSpeed:2.4,chronoCellSpinSpeed:3.6,chronoCellBobSpeed:3.2,chronoCellBobAmplitude:.24,obstacleBobBaseHeight:.72,obstacleBobAmplitude:.12,obstacleBobSpeed:1.8,fallingObstacleSpinXSpeed:3,fallingObstacleSpinZSpeed:2,targetShadowBaseScale:.38,targetShadowScaleGrowth:.9,targetShadowBaseOpacity:.32,targetShadowOpacityGrowth:.56,targetRingPulseSpeed:12,targetRingPulseAmount:.1,targetRingBaseScale:.82,targetRingScaleGrowth:.62,targetRingBaseOpacity:.95,targetRingOpacityFade:.4,chaserRangeIndicatorBaseOpacity:.24,chaserRangeIndicatorActiveOpacity:.7,chaserRangeIndicatorPulseSpeed:7,chaserRangeIndicatorPulseAmount:.1,bangerFusePulseSpeed:9,bangerFuseEmissiveBaseIntensity:.45,bangerFuseEmissivePulseAmount:.9,spawnRingBaseScale:.7,spawnRingScaleGrowth:1,spawnRingPulseSpeed:15,spawnRingPulseAmount:.12,spawnRingBaseOpacity:.9,spawnCueGlowBaseOpacity:.2,spawnCueGlowPulseAmount:.14,spawnCueBeamBaseOpacity:.26},Fi={masterVolume:.16,bangerPulseVolume:.32,fallingObstacleVolume:.82,cellCollectVolume:.26,obstacleSummonVolume:.17,buttonClickVolume:.2,spatialMaxDistance:24,spatialMinGain:.04,fallback:{bangerPulse:{startFrequency:180,endFrequency:860,duration:.055,type:`square`},fallingObstacle:{duration:M.fallingBlockDuration},cellCollect:{startFrequency:540,endFrequency:960,duration:.13,type:`triangle`},obstacleSummon:{startFrequency:130,endFrequency:310,duration:2,type:`sine`},buttonClick:{startFrequency:440,endFrequency:660,duration:.07,type:`square`}},assets:{bangerPulse:`./audio/banger-pulse.wav`,fallingObstacle:`./audio/falling-obstacle.wav`,cellCollect:`./audio/cell-collect.wav`,obstacleSummon:`./audio/obstacle-summon.wav`,buttonClick:`./audio/button-click.wav`}},Ii={regular:{color:N.obstacle,emissive:N.obstacleEmissive,speed:0,range:0},chaser:{color:N.chaser,emissive:N.chaserEmissive,speed:M.playerSpeed/2,range:P.chaserRange},creeper:{color:N.creeper,emissive:N.creeperEmissive,speed:M.playerSpeed/4,range:1/0},banger:{color:N.banger,emissive:N.bangerEmissive,speed:0,range:P.chaserRange*P.bangerRangeMultiplier},shooter:{color:N.shooter,emissive:N.shooterEmissive,speed:0,range:P.chaserRange*P.shooterRangeMultiplier},porter:{color:N.porter,emissive:N.porterEmissive,speed:0,range:0},magnet:{color:N.magnet,emissive:N.magnetEmissive,speed:0,range:P.chaserRange},spore:{color:N.spore,emissive:N.sporeEmissive,speed:0,range:0},poisonCreeper:{color:N.creeper,emissive:N.creeperEmissive,speed:M.playerSpeed/4,range:1/0}},Li={stoneRock:{name:`Stone Rock`,color:N.fallingObstacle,emissive:N.fallingObstacleEmissive,emissiveIntensity:P.fallingObstacleEmissiveIntensity},fieryRock:{name:`Fiery Rock`,color:N.fieryRock,emissive:N.fieryRockEmissive,emissiveIntensity:2.1},splinter:{name:`Splinter`,color:N.splinter,emissive:N.splinterEmissive,emissiveIntensity:1.2}},Ri={voidReaper:{name:`Void Reaper`,color:`#151021`,emissive:`#8d35ff`,eyeColor:`#d9ff6a`,telegraphDuration:3,speed:24,scale:2,sweepRadius:M.playerRadius*2,edgeOffset:3}},zi=`language.english: "English"\r
language.turkish: "Turkish"\r
language.spanish: "Spanish"\r
settings.language: "Language"\r
settings.language_help: "Choose the language used by the game interface."\r
save_slots.heading: "SELECT SAVE SLOT"\r
save_slots.archive: "COMMAND ARCHIVE"\r
save_slots.description: "Choose a pilot archive to continue your expedition."\r
save_slots.slot: "SLOT {slot}"\r
save_slots.new_expedition: "NEW EXPEDITION"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MAX CELLS"\r
save_slots.total_cash: "TOTAL CASH"\r
save_slots.total_chronoshards: "TOTAL CHRONOSHARDS"\r
research.category.player_enhancements: "Player Enhancements"\r
research.category.economy: "Economy"\r
research.category.boosters: "Boosters"\r
research.category.weapons: "Weapons"\r
research.category.building_system: "Building System"\r
research.category.enemy_debuff: "Enemy Debuff"\r
research.lucky-find.name: "Lucky Find"\r
research.lucky-find.description: "Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1."\r
research.weapon-recharge.name: "Weapon Recharge"\r
research.weapon-recharge.description: "Weapons are now capable of recharging over time."\r
research.weapon-recharge-rate.name: "Weapon Recharge Rate"\r
research.weapon-recharge-rate.description: "Reduces weapon recharge time."\r
research.weapon-charge-capacity.name: "Weapon Charge Capacity"\r
research.weapon-charge-capacity.description: "Increases the maximum stored charges for each equipped weapon by 1."\r
research.weapon-slots.name: "Weapon Slot"\r
research.weapon-slots.description: "Adds one weapon slot to your round loadout."\r
research.player-speed-multiplier.name: "Player Speed Multiplier"\r
research.player-speed-multiplier.description: "Increases player movement speed."\r
research.unlock-slow-aura.name: "Unlock Slow Aura"\r
research.unlock-slow-aura.description: "Unlocks the Slow Aura ability, which slows down nearby enemies within the range."\r
research.unlock-orbital-electron.name: "Unlock Orbital Electron"\r
research.unlock-orbital-electron.description: "Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc."\r
research.electron-stun-duration.name: "Electron Stun Duration"\r
research.electron-stun-duration.description: "Increases how long enemies hit by the Orbital Electron are stunned."\r
research.electron-speed.name: "Electron Speed"\r
research.electron-speed.description: "Increases Orbital Electron orbit speed."\r
research.slow-aura-effect.name: "Slow Aura Effect"\r
research.slow-aura-effect.description: "Increases the effect of the Slow Aura ability."\r
research.slow-aura-range.name: "Effect Range"\r
research.slow-aura-range.description: "Increases the range of every active range-based effect."\r
research.cell-spawn-rate.name: "Cell Spawn Rate"\r
research.cell-spawn-rate.description: "Increases the spawn rate of standard cells."\r
research.cell-increment-per-cell.name: "Cell Increment Per Cell"\r
research.cell-increment-per-cell.description: "Each collected Cell increases the standard Cell spawn rate."\r
research.cash-cell-multiplier.name: "Cash/Cell Multiplier"\r
research.cash-cell-multiplier.description: "Increases the Cash earned from every standard cell."\r
research.initial-cell-count.name: "Initial Cell"\r
research.initial-cell-count.description: "Adds one Cell to the arena at the start of every run."\r
research.cell-magnet.name: "Cell Magnet"\r
research.cell-magnet.description: "Pulls nearby Cells toward you. Each level increases pull speed."\r
research.chrono-spawn-rate.name: "Chrono Spawn Rate"\r
research.chrono-spawn-rate.description: "Makes Chrono Cells appear more frequently."\r
research.chrono-lifetime-multiplier.name: "Chrono Lifetime Multiplier"\r
research.chrono-lifetime-multiplier.description: "Increases the lifetime of Chrono Cells."\r
research.unlock-shockwave.name: "Unlock Shockwave"\r
research.unlock-shockwave.description: "Periodically emits a green shockwave that pushes enemies away."\r
research.shockwave-frequency.name: "Shockwave Frequency"\r
research.shockwave-frequency.description: "Makes Shockwaves trigger more frequently."\r
research.shield.name: "Shield"\r
research.shield.description: "Grants one death save per level at the start of every run."\r
research.building-slots.name: "Building Slots"\r
research.building-slots.description: "Increases the number of buildings you can place in the arena by 1."\r
research.unlock-speed-booster.name: "Unlock Speed Boosters"\r
research.unlock-speed-booster.description: "Unlocks Speed Booster pickups that double movement speed."\r
research.speed-booster-duration.name: "Speed Booster Duration"\r
research.speed-booster-duration.description: "Increases Speed Booster duration."\r
research.thorn-shield.name: "Thorn Shield"\r
research.thorn-shield.description: "Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact."\r
research.thorn-shield-duration.name: "Thorn Shield Duration"\r
research.thorn-shield-duration.description: "Increases Thorn Shield duration."\r
research.freezer.name: "Freezer"\r
research.freezer.description: "Unlocks Freezer pickups that freeze all enemies."\r
research.freezer-duration.name: "Freezer Duration"\r
research.freezer-duration.description: "Increases Freezer duration."\r
research.pushback.name: "Pushback"\r
research.pushback.description: "Pushes nearby stationary enemies away. Each level increases push speed."\r
research.shield-invulnerability-duration.name: "Shield Afterglow"\r
research.shield-invulnerability-duration.description: "Increases invulnerability time after the Shield breaks."\r
research.shield-break-explosion.name: "Shield Break Explosion"\r
research.shield-break-explosion.description: "Destroys all enemies within range when the Shield breaks. Each level increases the range."\r
research.regular-lifetime-debuff.name: "Regular Decay"\r
research.regular-lifetime-debuff.description: "Reduces Regular enemy lifetime."\r
research.chaser-range-debuff.name: "Chaser Range Dampener"\r
research.chaser-range-debuff.description: "Reduces Chaser detection range."\r
research.creeper-speed-debuff.name: "Creeper Slowdown"\r
research.creeper-speed-debuff.description: "Reduces Creeper movement speed."\r
research.banger-range-debuff.name: "Banger Range Dampener"\r
research.banger-range-debuff.description: "Reduces Banger blast range."\r
research.banger-enemy-destruction.name: "Banger Disruption"\r
research.banger-enemy-destruction.description: "Give the banger's blast a chance to destroy affected enemies."\r
research.shooter-range-debuff.name: "Shooter Range Dampener"\r
research.shooter-range-debuff.description: "Reduces Shooter firing range."\r
research.shooter-projectile-debuff.name: "Projectile Drag"\r
research.shooter-projectile-debuff.description: "Reduces Shooter projectile speed."\r
research.porter-interval-debuff.name: "Porter Delay Field"\r
research.porter-interval-debuff.description: "Increases the interval between Porter teleports."\r
research.magnet-strength-debuff.name: "Magnet Insulation"\r
research.magnet-strength-debuff.description: "Reduces Magnet pull strength."\r
research.spore-speed-debuff.name: "Spore Drag"\r
research.spore-speed-debuff.description: "Reduces Spore movement speed."\r
research.poison-creep-clean.name: "Poison Creep Clean"\r
research.poison-creep-clean.description: "Reduces how long Poison Creeper trails remain."\r
weapon.nuke.name: "Nuke"\r
weapon.nuke.description: "Destroys a percentage of enemies in the arena."\r
weapon.megaMagnet.name: "Mega Magnet"\r
weapon.megaMagnet.description: "Pulls every Cell rapidly toward your ship."\r
weapon.atmosphereShield.name: "Atmosphere Shield"\r
weapon.atmosphereShield.description: "Destroys and blocks falling meteors for a short time."\r
weapon.phaseDash.name: "Phase Dash"\r
weapon.phaseDash.description: "Dash through enemies and erase every enemy in your path."\r
weapon.chronoFreeze.name: "Chrono Freeze"\r
weapon.chronoFreeze.description: "Freezes every enemy and their lifetime for a short time."\r
weapon.plasmaOrbital.name: "Plasma Orbital"\r
weapon.plasmaOrbital.description: "Deploys plasma orbitals that destroy enemies on contact."\r
weapon.cellOverdrive.name: "Cell Overdrive"\r
weapon.cellOverdrive.description: "Doubles Cells collected for a short time."\r
weapon.demonMode.name: "Demon Mode"\r
weapon.demonMode.description: "Move faster and destroy enemies you pass through."\r
weapon.remove_loadout: "REMOVE FROM LOADOUT"\r
weapon.add_loadout: "ADD TO LOADOUT"\r
weapon.replace_with: "REPLACE WITH {weapon}"\r
weapon.replace_selected: "REPLACE SELECTED WEAPON"\r
weapon.buy: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.empty_slot: "EMPTY SLOT"\r
weapon.not_collected: "Not collected yet"\r
weapon.max_level: "MAX LEVEL"\r
weapon.claim: "CLAIM"\r
weapon.next: "NEXT"\r
weapon.unlocked: "UNLOCKED"\r
weapon.unlocked_level: "Unlocked at Level 1."\r
weapon.level_up: "LEVEL UP · LV. {level}"\r
weapon.upgraded_level: "Upgraded to Level {level}."\r
weapon.max_level_copy: "MAX LEVEL COPY"\r
weapon.max_level_detail: "This weapon is already at maximum level."\r
weapon.copy: "COPY · LV. {level}"\r
weapon.copy_progress: "{copies}/{required} copies toward Level {level}."\r
artifact.broken-radar.name: "Broken Radar"\r
artifact.broken-radar.buff: "+10% Cell spawn rate"\r
artifact.ftl-schematics.name: "FTL Schematics"\r
artifact.ftl-schematics.buff: "+10% player movement speed"\r
artifact.supply-depot.name: "Supply Depot"\r
artifact.supply-depot.buff: "+5 initial Cells"\r
artifact.broken-extractor.name: "Broken Extractor"\r
artifact.broken-extractor.buff: "+10% cash earned from Cells"\r
artifact.construction-bot.name: "Construction Bot"\r
artifact.construction-bot.buff: "-10% Building prices"\r
artifact.alientech-gizmo.name: "Alientech Gizmo"\r
artifact.alientech-gizmo.buff: "-20% Research cost"\r
artifact.broken-hard-drive.name: "Broken Hard-Drive"\r
artifact.broken-hard-drive.buff: "+1 Weapon Slot"\r
artifact.hubble-telescope.name: "Hubble Telescope"\r
artifact.hubble-telescope.buff: "+20% player effect range"\r
artifact.dark-core.name: "Dark Core"\r
artifact.dark-core.buff: "+1% Chronoshards earned"\r
artifact.map-to-earth.name: "Map To Earth"\r
artifact.map-to-earth.buff: "+20% arena size in every Sector"\r
building.chronoGenerator.name: "Chrono Generator"\r
building.autocannon.name: "Autocannon"\r
building.droneBay.name: "Drone Bay"\r
building.barrierNode.name: "Barrier Node"\r
building.overclockRelay.name: "Overclock Relay"\r
building.salvageExtractor.name: "Salvage Extractor"\r
building.upgrade.range: "Range"\r
building.upgrade.effectiveness: "Effectiveness"\r
building.upgrade.frequency: "Frequency"\r
building.upgrade.period: "Period"\r
building.upgrade.count: "Count"\r
building.upgrade.duration: "Duration"\r
building.upgrade.cash: "Cash"\r
encyclopedia.category.enemies: "Enemies"\r
encyclopedia.category.meteors: "Meteors"\r
encyclopedia.category.ultimate_enemy: "Ultimate Enemy"\r
enemy.regular.name: "Regular"\r
enemy.regular.description: "A stationary asteroid enemy. Keep clear of its body while collecting Cells."\r
enemy.chaser.name: "Chaser"\r
enemy.chaser.description: "Detects the ship within its range and pursues it."\r
enemy.creeper.name: "Creeper"\r
enemy.creeper.description: "Slowly closes in from any distance and becomes faster as it survives."\r
enemy.poisonCreeper.name: "Poison Creeper"\r
enemy.poisonCreeper.description: "A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind."\r
enemy.banger.name: "Banger"\r
enemy.banger.description: "Arms itself, pulses a warning, then detonates over a wide area."\r
enemy.shooter.name: "Shooter"\r
enemy.shooter.description: "Fires projectiles at the ship when it enters firing range."\r
enemy.porter.name: "Porter"\r
enemy.porter.description: "Occasionally teleports itself to random locations."\r
enemy.magnet.name: "Magnet"\r
enemy.magnet.description: "Pulls the ship toward itself while it is within range."\r
enemy.spore.name: "Spore"\r
enemy.spore.description: "Bursts into small pieces of itself, then bursts into even smaller pieces again."\r
enemy.voidReaper.name: "Void Reaper"\r
enemy.voidReaper.description: "A horrifying alien raider that marks a lethal path before tearing across the arena."\r
enemy.stoneRock.name: "Stone Rock"\r
enemy.stoneRock.description: "A standard falling meteor. Avoid its marked impact point."\r
enemy.fieryRock.name: "Fiery Rock"\r
enemy.fieryRock.description: "A burning meteor that leaves a damaging fire hazard after impact."\r
enemy.splinter.name: "Splinter"\r
enemy.splinter.description: "Shatters on impact and sends fragments outward."\r
status.fire: "Burning"\r
status.poison: "Poisoned"\r
anomaly.cell-scout.name: "Scout Rivalry"\r
anomaly.cell-scout.description: "A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you."\r
anomaly.tower-defense.name: "Tower Defense"\r
anomaly.tower-defense.description: "Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls."\r
anomaly.tower_health: "TOWER {current}/{maximum}"\r
anomaly.tower_defended: "TOWER DEFENDED"\r
anomaly.tower_defended_copy: "You destroyed {cells} enemies and secured the tower."\r
anomaly.tower_destroyed: "TOWER DESTROYED"\r
anomaly.tower_destroyed_copy: "The tower fell after {cells} enemies were destroyed."\r
anomaly.dark_core_stack: "ARTIFACT · {artifact} STACK"\r
anomaly.run: "ANOMALY RUN"\r
anomaly.weekly: "WEEKLY ANOMALY"\r
anomaly.start: "START ANOMALY RUN"\r
anomaly.verifying_title: "VERIFYING TIME"\r
anomaly.verifying_copy: "Checking the current Weekly Anomaly with the game server."\r
anomaly.reward: "{cells} CELLS · REWARD ✦ {reward}"\r
anomaly.reset: "(New Anomaly in {date})"\r
anomaly.reward_claimed: "This sector’s Weekly Anomaly reward has already been claimed."\r
anomaly.time_unverified_title: "TIME NOT VERIFIED"\r
anomaly.time_unverified_copy: "The current Weekly Anomaly could not be verified."\r
anomaly.time_unverified_error: "We could not verify the server time or check your internet connection. Please check your connection and try again."\r
menu.home: "HOME"\r
menu.research_lab: "RESEARCH LAB"\r
menu.weaponry: "WEAPONRY"\r
menu.buildings: "BUILDING SYSTEM"\r
menu.encyclopedia: "ENCYCLOPEDIA"\r
menu.settings: "SETTINGS"\r
menu.artifacts: "ARTIFACTS"\r
menu.exit_game: "EXIT GAME"\r
menu.start_run: "START RUN"\r
menu.continue: "CONTINUE"\r
menu.run_again: "RUN AGAIN"\r
menu.back: "BACK"\r
menu.pause: "PAUSE"\r
menu.round_paused: "ROUND PAUSED"\r
menu.reset: "RESET"\r
menu.surrender: "SURRENDER"\r
menu.return: "RETURN"\r
menu.main_menu: "MAIN MENU"\r
hud.cash: "CASH"\r
hud.chronoshards: "CHRONOSHARDS"\r
hud.cells: "CELLS"\r
hud.shields: "SHIELDS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SANDBOX SECTOR {sector}"\r
hud.anomaly_suffix: " · ANOMALY"\r
settings.preferences: "PREFERENCES"\r
settings.graphics: "GRAPHICS"\r
settings.gameplay: "GAMEPLAY"\r
settings.sound: "SOUND"\r
settings.quality: "Quality"\r
settings.quality_help: "Changes render resolution and shadows."\r
settings.low: "LOW"\r
settings.medium: "MEDIUM"\r
settings.high: "HIGH"\r
settings.shadows: "Shadows"\r
settings.shadows_help: "Show dynamic object shadows."\r
settings.hdr_emission: "HDR Emission"\r
settings.hdr_emission_help: "Controls how far bright effects bloom beyond their models."\r
settings.max_fps: "Maximum FPS"\r
settings.max_fps_help: "Limits rendering and simulation to reduce hardware load."\r
settings.unlimited: "UNLIMITED"\r
settings.auto_pause: "Auto Pause"\r
settings.auto_pause_help: "Pause the run when the game loses focus."\r
settings.high_contrast_hud: "High Contrast HUD"\r
settings.high_contrast_hud_help: "Improves HUD readability."\r
settings.master_volume: "Master Volume"\r
settings.master_volume_help: "Controls all game sound effects."\r
settings.mute_all: "Mute All"\r
settings.mute_all_help: "Instantly silence all sound effects."\r
settings.spatial_audio: "Spatial Audio"\r
settings.spatial_audio_help: "Pan sounds based on their world position."\r
settings.patch_notes: "PATCH NOTES"\r
settings.display: "DISPLAY"\r
settings.screen_mode: "Screen Mode"\r
settings.screen_mode_help: "Steam launches fullscreen by default."\r
settings.resolution: "Resolution"\r
settings.resolution_help: "Choosing a resolution switches to windowed mode."\r
settings.fullscreen: "FULLSCREEN"\r
settings.windowed: "WINDOWED"\r
milestone.ascension: "ASCENSION"\r
milestone.max_cells: "MAX CELLS"\r
milestone.cells: "{cells} CELLS"\r
milestone.next: "NEXT ASCENSION: {cells} CELLS"\r
milestone.ready: "ASCENSION REWARD READY TO CLAIM"\r
milestone.complete: "ASCENSION COMPLETE"\r
milestone.claim: "CLAIM REWARD"\r
milestone.claimed: "Claimed"\r
milestone.secured: "REWARD SECURED"\r
milestone.auto_claimed: "Claimed automatically"\r
milestone.best: "{best}/{target} best cells in Sector {sector}"\r
milestone.reward_claimed: "REWARD CLAIMED · {rewards}"\r
milestone.reward_cash: "+\${amount} cash"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshards"\r
milestone.unlock_sector: "Unlock Sector {sector}"\r
milestone.unlock_feature: "Unlock {feature}"\r
milestone.unlock_research: "Unlock: {researches}"\r
error.server_time_unconfigured: "Server time endpoint is not configured."\r
error.server_time_request: "Server time request failed with {status}."\r
error.server_time_invalid: "Server returned an invalid time."\r
message.round_saved: "Round saved. Continue when you are ready."\r
message.sandbox_closed: "Sandbox closed. No progress was saved."\r
message.run_surrendered: "Run surrendered. No progress was saved."\r
message.killed_by: "KILLED BY {cause}"\r
message.energy_secured: "You secured {count} energy {cellWord}."\r
message.cell_singular: "cell"\r
message.cell_plural: "cells"\r
message.tip: "TIP · {tip}"\r
message.anomaly_reward: "ANOMALY +✦{amount}"\r
artifact.acquired: "ARTIFACT ACQUIRED"\r
artifact.acquired_named: "ARTIFACT ACQUIRED · {artifact}"\r
artifact.locked: "ARTIFACT LOCKED"\r
artifact.unknown: "UNKNOWN ARTIFACT"\r
encyclopedia.unknown_enemy: "Unknown enemy"\r
research.slot: "SLOT {slot}"\r
research.available: "AVAILABLE"\r
research.locked: "LOCKED"\r
research.remaining: "{duration} remaining"\r
research.select_below: "Select a research below."\r
research.unlock_for: "Unlock for {cost}"\r
research.unlock_sector: "Unlock Sector {sector} research in Milestones"\r
research.max_level: "MAX LEVEL"\r
research.in_progress: "IN PROGRESS"\r
research.free_enabled: "FREE RESEARCH ENABLED"\r
research.cost: "Cost {cost}"\r
research.maxed: "MAXED"\r
research.start: "RESEARCH"\r
research.no_search_results: "No research names match your search."\r
research.started: "{research} research started in Slot {slot}."\r
research.upgraded: "{research} upgraded to Level {level}."\r
research.slot_unlocked: "Research Slot {slot} unlocked."\r
research.requires_sector_cells: "Requires {cells} Cells in Sector {sector}"\r
research.requires_banked_cells: "Requires {cells} banked cells"\r
research.requires_research: "Requires {research}"\r
research.requires_research_level: "Requires {research} Lv. {level}"\r
weapon.number: "WEAPON {current} / {total}"\r
weapon.cards: "WEAPON CARDS"\r
weapon.round_loadout: "ROUND LOADOUT"\r
weapon.buy_with_cost: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five_with_cost: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.level: "LV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copies to Lv. {level}"\r
weapon.lucky_find_double: "LUCKY FIND · 2 CARDS"\r
weapon.lucky_find_unlock: "Unlocked at Level 1 and received an extra copy."\r
weapon.lucky_find_received: "Received 2 cards. {detail}"\r
artifact.stacks: "{count} stacks"\r
artifact.stack: "{count} STACK"\r
artifact.stacks_label: "{count} STACKS"\r
artifact.dark_core_stack: "{count} DARK CORE STACK"\r
artifact.dark_core_stacks: "{count} DARK CORE STACKS"\r
artifact.to_acquire: "TO ACQUIRE"\r
artifact.permanent_buff: "PERMANENT BUFF"\r
artifact.buff_per_stack: "{buff} per stack · {count} stacks = +{percent}% Chronoshards earned"\r
artifact.requirement_score: "Reach {cells} Cells in Sector {sector}."\r
artifact.requirement_milestone: "Claim the Sector {sector} · {cells} Cells Ascension reward."\r
artifact.requirement_anomaly: "Complete each Anomaly in each Sector. Every unique Anomaly and Sector combination grants one stack."\r
artifact.requirement_hidden: "Hidden condition."\r
artifact.requirement_default: "Complete this artifact achievement."\r
building.choose_offer: "CHOOSE 1 OF {count} · NEXT UNLOCK ✦ {cost}"\r
building.all_unlocked: "ALL BUILDINGS UNLOCKED"\r
building.permanent_unlock: "Permanent building unlock"\r
building.unlock_cost: "UNLOCK · ✦ {cost}"\r
building.upgrade: "UPGRADE"\r
building.slot_limit: "SLOT LIMIT"\r
building.build_cost: "Build cost: \${cost}"\r
building.unlocked: "UNLOCKED"\r
building.none_unlocked: "NO BUILDINGS UNLOCKED YET"\r
building.build_mode_slots: "BUILD MODE · SLOTS {used}/{total}"\r
building.level: "LVL. {level}"\r
building.installed_defense: "INSTALLED DEFENSE"\r
building.choose_upgrade: "Choose an upgrade for this structure."\r
building.upgrade_level: "LV. {current} → {next}"\r
building.demolish_refund: "DEMOLISH · REFUND \${amount}"\r
building.demolish_confirm: "Demolish {building}? You will receive a \${refund} refund."\r
research.active_slots: "ACTIVE SLOTS"\r
research.available_research: "AVAILABLE RESEARCH"\r
research.search: "SEARCH"\r
research.search_placeholder: "Search research names"\r
research.hide_completed: "Hide Completed Researches"\r
research.hide_locked: "Hide Locked Researches"\r
artifact.permanent_achievements: "PERMANENT ACHIEVEMENTS"\r
artifact.intro: "Artifacts are permanent rewards earned by reaching achievement goals."\r
building.permanent_defenses: "PERMANENT DEFENSES"\r
building.system: "BUILDING SYSTEM"\r
building.build_mode: "BUILD MODE"\r
building.unlock_a_building: "UNLOCK A BUILDING"\r
building.unlocked_buildings: "UNLOCKED BUILDINGS"\r
building.draft: "BUILDING DRAFT"\r
weapon.active_arsenal: "ACTIVE ARSENAL"\r
menu.back: "BACK"\r
menu.done: "DONE"\r
encyclopedia.threat_database: "THREAT DATABASE"\r
accessibility.game_canvas: "Asteroid Belt game canvas"\r
accessibility.current_sector: "Current difficulty sector"\r
accessibility.pause_game: "Pause game"\r
accessibility.shield_charges: "Shield charges"\r
accessibility.game_controls: "Game controls"\r
accessibility.build_information: "Build information"\r
accessibility.build_locations: "Build locations"\r
accessibility.pause_menu: "Pause menu"\r
accessibility.debug_console: "Debug console"\r
accessibility.close_debug_console: "Close debug console"\r
accessibility.save_slots: "Save slot selection"\r
accessibility.defeating_enemy: "Defeating enemy 3D model"\r
accessibility.sector_selection: "Difficulty sector selection"\r
accessibility.previous_sector: "Select previous sector"\r
accessibility.next_sector: "Select next sector"\r
accessibility.previous_milestone_sector: "View previous milestone sector"\r
accessibility.next_milestone_sector: "View next milestone sector"\r
accessibility.enemy_model: "{enemy} model"\r
controls.move: "MOVE"\r
controls.navigate: "NAVIGATE"\r
controls.use_weapon: "USE WEAPON"\r
controls.select_weapon: "SELECT / USE WEAPON"\r
patch_notes.version_build: "VERSION {version} · BUILD {build}"\r
patch_notes.artifacts: "ARTIFACTS"\r
patch_notes.artifacts_1: "Introducing Artifact System - An achievements mechanic which rewards the player with permanent buffs and rewards when achieving certain things."\r
patch_notes.artifacts_2: "Artifacts are mostly earned by reaching 500 cells in Tier 2 and onwards."\r
patch_notes.artifacts_3: "There are 10 different artifact right now, more to come in upcoming update."\r
patch_notes.improvements: "IMPROVEMENTS"\r
patch_notes.improvements_1: "Certain UI improvements for better visibility especially in mobile devices."\r
patch_notes.improvements_2: "Small value tweaks regarding Research unlocks and Enemy strengths."\r
tip.1: "You will eventually be overwhelmed no matter what. Try unlocking new researches to push further."\r
tip.2: "Keep moving: standing still makes incoming hazards much harder to read."\r
tip.3: "The final seconds of an enemy lifetime are marked by a blink."\r
tip.4: "Research upgrades persist between runs, so a short run can still move you forward."\r
tip.5: "Use the arena edge to reduce the directions enemies can approach from."\r
tip.6: "Chronoshards are rare, valuable and short-lived. Make sure to grab them before they disappear."\r
tip.7: "Watch enemy range rings before committing to a path through the arena."\r
tip.8: "You can unlock boosters later in the game from Research Lab."\r
tip.9: "After reaching Sector IV, you can unlock the ability to build Buildings to help you in the arena."\r
tip.10: "Purple enemies are called creepers and they speed up gradually over time. They can be slowed down by static collisions with obstacles."\r
tip.11: "Red enemies are called chasers and they will pursue you when you are in their range."\r
tip.12: "Yellow enemies are called bangers and they explode after a few seconds."\r
tip.13: "More cells you collect, the more difficult the game becomes."\r
tip.14: "New enemies and obstacles are introduced as you progress through the game, so be prepared for new challenges."\r
tip.15: "Each sector introduces unique enemies and challenges, so adapt your strategy accordingly."\r
tip.16: "Asteroid Belt is designed to be an endless experience, so focus on improving your skills and strategies to achieve higher scores."\r
cheat.title: "DEBUG CONSOLE"\r
cheat.prompt: "Enter a command."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "You need to reach Sector {sector}."\r
cheat.feature_cells: "You need to collect {cells} Cells in Sector {sector}."\r
cheat.feature_chronoshards: "You need ✦ {amount} Chronoshards."\r
cheat.feature_unavailable: "This system is not available yet."\r
cheat.research_completed: "{research} research completed."\r
status.damage: "{status} DAMAGE"\r
cheat.sandbox_started: "Sandbox Sector I started. Use sandbox [sector], sandbox simulate [cell|enemies|all], or sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "Sandbox difficulty set to Sector {sector}. Spawn simulation remains unchanged."\r
cheat.sandbox_start_first: "Start Sandbox first with: sandbox"\r
cheat.sandbox_simulate_usage: "Usage: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simulation started for Sector {sector}."\r
cheat.sandbox_spawn_usage: "Usage: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Spawned {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Usage: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Usage: spawn <entity_id>. Available: {entities}"\r
cheat.spawn_requires_round: "Start a round before spawning an entity."\r
cheat.spawned: "Spawned {entity} near the player."\r
cheat.anomaly_usage: "Usage: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Unknown Anomaly: {id}. Available: {available}"\r
cheat.anomaly_started: "Anomaly {id} started in Sector {sector}."\r
cheat.cell_usage: "Usage: cell <positive amount>"\r
cheat.cell_requires_round: "Start a round before granting Cells."\r
cheat.cell_granted: "Added {amount} Cells without awarding Cash. Total: {total}."\r
cheat.cell_obtain_usage: "Usage: cell_obtain <whole number from 1 to 10,000>"\r
cheat.cell_obtain_set: "Cell obtain multiplier set to {amount} for this session."\r
cheat.god_usage: "Usage: god <on/off>"\r
cheat.god_state: "God mode {state}."\r
cheat.on: "ON"\r
cheat.off: "OFF"\r
cheat.artifact_usage: "Usage: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Unknown Artifact: {artifact}"\r
cheat.artifact_stack_range: "Stack must be a whole number from 1 to 10,000."\r
cheat.artifact_granted: "Granted {count} {artifact} {stackWord} ({total} total)."\r
cheat.artifact_unique: "{artifact} is a unique Artifact and is now unlocked."\r
cheat.amount_usage: "Usage: {command} [positive amount]"\r
cheat.amount_granted: "Granted {amount}."\r
cheat.free_research: "Free research enabled for this session."\r
cheat.sectors_unlocked: "All sectors and Ascension rewards unlocked.{rewards}"\r
cheat.clear_usage: "Usage: clear_save [{targets}]"\r
cheat.cleared: "Cleared {target} save data."\r
cheat.unknown_command: "Unknown command: {command}"\r
menu.patch_notes: "PATCH NOTES"\r
menu.unlock_feature: "UNLOCK {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
onboarding.drag_to_move: "DRAG TO MOVE"\r
`,Bi=`language.english: "İngilizce"\r
language.turkish: "Türkçe"\r
language.spanish: "İspanyolca"\r
settings.language: "Dil"\r
settings.language_help: "Oyun arayüzünde kullanılacak dili seçin."\r
save_slots.heading: "KAYIT YUVASI SEÇ"\r
save_slots.archive: "KOMUTA ARŞİVİ"\r
save_slots.description: "Seferinize devam etmek için bir pilot arşivi seçin."\r
save_slots.slot: "YUVA {slot}"\r
save_slots.new_expedition: "YENİ SEFER"\r
save_slots.sector: "SEKTÖR {sector}"\r
save_slots.max_cells: "AZAMİ HÜCRE"\r
save_slots.total_cash: "TOPLAM NAKİT"\r
save_slots.total_chronoshards: "TOPLAM CHRONOSHARD"\r
research.category.player_enhancements: "Oyuncu Geliştirmeleri"\r
research.category.economy: "Ekonomi"\r
research.category.boosters: "Güçlendiriciler"\r
research.category.weapons: "Silahlar"\r
research.category.building_system: "Yapı Sistemi"\r
research.category.enemy_debuff: "Düşman Zayıflatmaları"\r
research.lucky-find.name: "Şanslı Buluntu"\r
research.lucky-find.description: "Silah kartlarının Şanslı Buluntuya dönüşme ve 1 yerine 2 kart verme ihtimali vardır."\r
research.weapon-recharge.name: "Silah Yeniden Dolumu"\r
research.weapon-recharge.description: "Silahlar artık zaman içinde yeniden dolabilir."\r
research.weapon-recharge-rate.name: "Silah Dolum Hızı"\r
research.weapon-recharge-rate.description: "Silahların yeniden dolma süresini azaltır."\r
research.weapon-charge-capacity.name: "Silah Şarj Kapasitesi"\r
research.weapon-charge-capacity.description: "Kuşanılmış her silahın saklayabileceği azami şarj sayısını 1 artırır."\r
research.weapon-slots.name: "Silah Yuvası"\r
research.weapon-slots.description: "Tur donanımınıza bir silah yuvası ekler."\r
research.player-speed-multiplier.name: "Oyuncu Hız Çarpanı"\r
research.player-speed-multiplier.description: "Oyuncunun hareket hızını artırır."\r
research.unlock-slow-aura.name: "Yavaşlatma Aurasını Aç"\r
research.unlock-slow-aura.description: "Menzil içindeki yakındaki düşmanları yavaşlatan Yavaşlatma Aurası yeteneğini açar."\r
research.unlock-orbital-electron.name: "Yörünge Elektronunu Aç"\r
research.unlock-orbital-electron.description: "Etki menzilinizin çevresinde dönen ve elektrik arkının çarptığı düşmanları sersemleten bir Elektron konuşlandırır."\r
research.electron-stun-duration.name: "Elektron Sersemletme Süresi"\r
research.electron-stun-duration.description: "Yörünge Elektronunun vurduğu düşmanların sersemleme süresini artırır."\r
research.electron-speed.name: "Elektron Hızı"\r
research.electron-speed.description: "Yörünge Elektronunun yörünge hızını artırır."\r
research.slow-aura-effect.name: "Yavaşlatma Aurası Etkisi"\r
research.slow-aura-effect.description: "Yavaşlatma Aurası yeteneğinin etkisini artırır."\r
research.slow-aura-range.name: "Etki Menzili"\r
research.slow-aura-range.description: "Menzile dayalı tüm etkin etkilerin menzilini artırır."\r
research.cell-spawn-rate.name: "Hücre Belirme Hızı"\r
research.cell-spawn-rate.description: "Standart Hücrelerin belirme hızını artırır."\r
research.cell-increment-per-cell.name: "Hücre Başına Hücre Artışı"\r
research.cell-increment-per-cell.description: "Toplanan her Hücre, standart Hücrelerin belirme hızını artırır."\r
research.cash-cell-multiplier.name: "Nakit/Hücre Çarpanı"\r
research.cash-cell-multiplier.description: "Her standart Hücreden kazanılan Nakdi artırır."\r
research.initial-cell-count.name: "Başlangıç Hücresi"\r
research.initial-cell-count.description: "Her seferin başında arenaya bir Hücre ekler."\r
research.cell-magnet.name: "Hücre Mıknatısı"\r
research.cell-magnet.description: "Yakındaki Hücreleri size doğru çeker. Her seviye çekme hızını artırır."\r
research.chrono-spawn-rate.name: "Krono Belirme Hızı"\r
research.chrono-spawn-rate.description: "Krono Hücrelerinin daha sık belirmesini sağlar."\r
research.chrono-lifetime-multiplier.name: "Krono Ömür Çarpanı"\r
research.chrono-lifetime-multiplier.description: "Krono Hücrelerinin ömrünü artırır."\r
research.unlock-shockwave.name: "Şok Dalgasını Aç"\r
research.unlock-shockwave.description: "Belirli aralıklarla düşmanları uzağa iten yeşil bir şok dalgası yayar."\r
research.shockwave-frequency.name: "Şok Dalgası Sıklığı"\r
research.shockwave-frequency.description: "Şok Dalgalarının daha sık tetiklenmesini sağlar."\r
research.shield.name: "Kalkan"\r
research.shield.description: "Her seviye, her seferin başında ölümden bir kez kurtulma hakkı verir."\r
research.building-slots.name: "Yapı Yuvaları"\r
research.building-slots.description: "Arenaya yerleştirebileceğiniz yapı sayısını 1 artırır."\r
research.unlock-speed-booster.name: "Hız Güçlendiricilerini Aç"\r
research.unlock-speed-booster.description: "Hareket hızını iki katına çıkaran Hız Güçlendirici nesnelerini açar."\r
research.speed-booster-duration.name: "Hız Güçlendirici Süresi"\r
research.speed-booster-duration.description: "Hız Güçlendiricinin süresini artırır."\r
research.thorn-shield.name: "Diken Kalkan"\r
research.thorn-shield.description: "Dokunulmazlık sağlayan ve temas ettiği düşmanları yok eden Diken Kalkan nesnelerini açar."\r
research.thorn-shield-duration.name: "Diken Kalkan Süresi"\r
research.thorn-shield-duration.description: "Diken Kalkanın süresini artırır."\r
research.freezer.name: "Dondurucu"\r
research.freezer.description: "Tüm düşmanları donduran Dondurucu nesnelerini açar."\r
research.freezer-duration.name: "Dondurucu Süresi"\r
research.freezer-duration.description: "Dondurucunun süresini artırır."\r
research.pushback.name: "Geri İtme"\r
research.pushback.description: "Yakındaki hareketsiz düşmanları uzağa iter. Her seviye itme hızını artırır."\r
research.shield-invulnerability-duration.name: "Kalkan Art Etkisi"\r
research.shield-invulnerability-duration.description: "Kalkan kırıldıktan sonraki dokunulmazlık süresini artırır."\r
research.shield-break-explosion.name: "Kalkan Kırılma Patlaması"\r
research.shield-break-explosion.description: "Kalkan kırıldığında menzil içindeki tüm düşmanları yok eder. Her seviye menzili artırır."\r
research.regular-lifetime-debuff.name: "Sıradan Çürümesi"\r
research.regular-lifetime-debuff.description: "Sıradan düşmanların ömrünü azaltır."\r
research.chaser-range-debuff.name: "Takipçi Menzil Bastırıcı"\r
research.chaser-range-debuff.description: "Takipçilerin algılama menzilini azaltır."\r
research.creeper-speed-debuff.name: "Sinsici Yavaşlatma"\r
research.creeper-speed-debuff.description: "Sinsicilerin hareket hızını azaltır."\r
research.banger-range-debuff.name: "Patlayıcı Menzil Bastırıcı"\r
research.banger-range-debuff.description: "Patlayıcıların patlama menzilini azaltır."\r
research.banger-enemy-destruction.name: "Patlayıcı Bozucu"\r
research.banger-enemy-destruction.description: "Patlayıcının patlamasına, etkilenen düşmanları yok etme ihtimali verir."\r
research.shooter-range-debuff.name: "Atıcı Menzil Bastırıcı"\r
research.shooter-range-debuff.description: "Atıcıların ateş menzilini azaltır."\r
research.shooter-projectile-debuff.name: "Mermi Sürüklenmesi"\r
research.shooter-projectile-debuff.description: "Atıcıların mermi hızını azaltır."\r
research.porter-interval-debuff.name: "Işınlayıcı Gecikme Alanı"\r
research.porter-interval-debuff.description: "Işınlayıcıların ışınlanmaları arasındaki süreyi artırır."\r
research.magnet-strength-debuff.name: "Mıknatıs Yalıtımı"\r
research.magnet-strength-debuff.description: "Mıknatısların çekim gücünü azaltır."\r
research.spore-speed-debuff.name: "Spor Sürüklenmesi"\r
research.spore-speed-debuff.description: "Sporların hareket hızını azaltır."\r
research.poison-creep-clean.name: "Zehir İzi Temizliği"\r
research.poison-creep-clean.description: "Zehirli Sinsicilerin bıraktığı izlerin kalma süresini azaltır."\r
weapon.nuke.name: "Nükleer Bomba"\r
weapon.nuke.description: "Arenadaki düşmanların belirli bir yüzdesini yok eder."\r
weapon.megaMagnet.name: "Mega Mıknatıs"\r
weapon.megaMagnet.description: "Tüm Hücreleri hızla geminize doğru çeker."\r
weapon.atmosphereShield.name: "Atmosfer Kalkanı"\r
weapon.atmosphereShield.description: "Düşen meteorları kısa bir süre boyunca yok eder ve engeller."\r
weapon.phaseDash.name: "Faz Atılımı"\r
weapon.phaseDash.description: "Düşmanların içinden atılın ve yolunuzdaki her düşmanı silin."\r
weapon.chronoFreeze.name: "Krono Dondurma"\r
weapon.chronoFreeze.description: "Tüm düşmanları ve ömür sayaçlarını kısa bir süreliğine dondurur."\r
weapon.plasmaOrbital.name: "Plazma Yörüngesi"\r
weapon.plasmaOrbital.description: "Temas ettiği düşmanları yok eden plazma yörünge cisimleri konuşlandırır."\r
weapon.cellOverdrive.name: "Hücre Aşırı Yükü"\r
weapon.cellOverdrive.description: "Kısa bir süre boyunca toplanan Hücreleri iki katına çıkarır."\r
weapon.demonMode.name: "Şeytan Modu"\r
weapon.demonMode.description: "Daha hızlı hareket edin ve içinden geçtiğiniz düşmanları yok edin."\r
weapon.remove_loadout: "DONANIMDAN ÇIKAR"\r
weapon.add_loadout: "DONANIMA EKLE"\r
weapon.replace_with: "{weapon} İLE DEĞİŞTİR"\r
weapon.replace_selected: "SEÇİLİ SİLAHI DEĞİŞTİR"\r
weapon.buy: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.empty_slot: "BOŞ YUVA"\r
weapon.not_collected: "Henüz alınmadı"\r
weapon.max_level: "AZAMİ SEVİYE"\r
weapon.claim: "AL"\r
weapon.next: "SONRAKİ"\r
weapon.unlocked: "AÇILDI"\r
weapon.unlocked_level: "1. Seviyede açıldı."\r
weapon.level_up: "SEVİYE ATLA · SV. {level}"\r
weapon.upgraded_level: "{level}. Seviyeye yükseltildi."\r
weapon.max_level_copy: "AZAMİ SEVİYE KOPYASI"\r
weapon.max_level_detail: "Bu silah zaten azami seviyede."\r
weapon.copy: "KOPYA · SV. {level}"\r
weapon.copy_progress: "{level}. Seviye için {copies}/{required} kopya."\r
artifact.broken-radar.name: "Bozuk Radar"\r
artifact.broken-radar.buff: "+10% Hücre belirme hızı"\r
artifact.ftl-schematics.name: "FTL Şemaları"\r
artifact.ftl-schematics.buff: "+10% oyuncu hareket hızı"\r
artifact.supply-depot.name: "İkmal Deposu"\r
artifact.supply-depot.buff: "+5 başlangıç Hücresi"\r
artifact.broken-extractor.name: "Bozuk Çıkarıcı"\r
artifact.broken-extractor.buff: "+10% Hücrelerden kazanılan nakit"\r
artifact.construction-bot.name: "İnşaat Botu"\r
artifact.construction-bot.buff: "-10% Yapı fiyatları"\r
artifact.alientech-gizmo.name: "Uzaylı Teknolojisi Aygıtı"\r
artifact.alientech-gizmo.buff: "-20% Araştırma maliyeti"\r
artifact.broken-hard-drive.name: "Bozuk Sabit Disk"\r
artifact.broken-hard-drive.buff: "+1 Silah Yuvası"\r
artifact.hubble-telescope.name: "Hubble Teleskobu"\r
artifact.hubble-telescope.buff: "+20% oyuncu etki menzili"\r
artifact.dark-core.name: "Karanlık Çekirdek"\r
artifact.dark-core.buff: "+1% kazanılan Chronoshard"\r
artifact.map-to-earth.name: "Dünya'ya Giden Harita"\r
artifact.map-to-earth.buff: "+20% her Sektörde arena boyutu"\r
building.chronoGenerator.name: "Krono Jeneratörü"\r
building.autocannon.name: "Otomatik Top"\r
building.droneBay.name: "Drone Hangarı"\r
building.barrierNode.name: "Bariyer Düğümü"\r
building.overclockRelay.name: "Hız Aşırtma Rölesi"\r
building.salvageExtractor.name: "Hurda Çıkarıcı"\r
building.upgrade.range: "Menzil"\r
building.upgrade.effectiveness: "Etkinlik"\r
building.upgrade.frequency: "Sıklık"\r
building.upgrade.period: "Periyot"\r
building.upgrade.count: "Adet"\r
building.upgrade.duration: "Süre"\r
building.upgrade.cash: "Nakit"\r
encyclopedia.category.enemies: "Düşmanlar"\r
encyclopedia.category.meteors: "Meteorlar"\r
encyclopedia.category.ultimate_enemy: "Nihai Düşman"\r
enemy.regular.name: "Normal"\r
enemy.regular.description: "Hareketsiz bir düşman. Hücreleri toplarken gövdesinden uzak durun."\r
enemy.chaser.name: "Kovalayıcı"\r
enemy.chaser.description: "Menziline giren gemiyi algılar ve peşine düşer."\r
enemy.creeper.name: "Takipçi"\r
enemy.creeper.description: "Uzaktan yavaşça yaklaşır ve hayatta kaldıkça hızlanır."\r
enemy.poisonCreeper.name: "Zehirli Takipçi"\r
enemy.poisonCreeper.description: "Arkasında zehirli izler bırakırken mor ile koyu yeşil arasında renk değiştiren bir Sinsici türüdür."\r
enemy.banger.name: "Patlayıcı"\r
enemy.banger.description: "Kendini kurar, uyarı sinyalleri verir ve ardından geniş bir alanda patlar."\r
enemy.shooter.name: "Atıcı"\r
enemy.shooter.description: "Gemi ateş menziline girdiğinde ona mermiler fırlatır."\r
enemy.porter.name: "Işınlayıcı"\r
enemy.porter.description: "Ara sıra rastgele konumlara ışınlanır."\r
enemy.magnet.name: "Mıknatıs"\r
enemy.magnet.description: "Gemi menzilindeyken onu kendine doğru çeker."\r
enemy.spore.name: "Spor"\r
enemy.spore.description: "Kendisinin küçük parçalarına ayrılır, ardından bu parçalar daha da küçük parçalara ayrılır."\r
enemy.voidReaper.name: "Boşluk Biçici"\r
enemy.voidReaper.description: "Arena boyunca ilerlemeden önce ölümcül rotasını işaretleyen korkunç bir uzaylı akıncısı."\r
enemy.stoneRock.name: "Taş Meteor"\r
enemy.stoneRock.description: "Standart bir düşen meteor. İşaretlenmiş çarpma noktasından uzak durun."\r
enemy.fieryRock.name: "Alevli Meteor"\r
enemy.fieryRock.description: "Çarptıktan sonra hasar veren bir ateş alanı bırakan yanan meteor."\r
enemy.splinter.name: "Parçalayıcı"\r
enemy.splinter.description: "Çarpma anında parçalanır ve parçalarını çevreye saçar."\r
status.fire: "Yanma"\r
status.poison: "Zehirlenme"\r
anomaly.cell-scout.name: "Gözcü Rekabeti"\r
anomaly.cell-scout.description: "Uzaktaki kırmızı bir yapay zekâ gemisi sizinle birlikte Hücre toplar. Topladığı Hücreler seferinize sayılmaz ve size zarar veremez."\r
anomaly.tower-defense.name: "Kule Savunması"\r
anomaly.tower-defense.description: "Merkezdeki kuleyi düşman dalgalarına karşı savun. Kule düşmeden önce 1.000 düşman yok et."\r
anomaly.tower_health: "KULE {current}/{maximum}"\r
anomaly.tower_defended: "KULE SAVUNULDU"\r
anomaly.tower_defended_copy: "{cells} düşman yok ettin ve kuleyi güvenceye aldın."\r
anomaly.tower_destroyed: "KULE YIKILDI"\r
anomaly.tower_destroyed_copy: "{cells} düşman yok edildikten sonra kule düştü."\r
anomaly.dark_core_stack: "ARTIFACT · {artifact} YIĞINI"\r
anomaly.run: "ANOMALİ SEFERİ"\r
anomaly.weekly: "HAFTALIK ANOMALİ"\r
anomaly.start: "ANOMALİ SEFERİNİ BAŞLAT"\r
anomaly.verifying_title: "ZAMAN DOĞRULANIYOR"\r
anomaly.verifying_copy: "Mevcut Haftalık Anomali oyun sunucusuyla kontrol ediliyor."\r
anomaly.reward: "{cells} HÜCRE · ÖDÜL ✦ {reward}"\r
anomaly.reset: "(Yeni Anomali: {date})"\r
anomaly.reward_claimed: "Bu sektörün Haftalık Anomali ödülü zaten alındı."\r
anomaly.time_unverified_title: "ZAMAN DOĞRULANAMADI"\r
anomaly.time_unverified_copy: "Mevcut Haftalık Anomali doğrulanamadı."\r
anomaly.time_unverified_error: "Sunucu zamanı doğrulanamadı veya internet bağlantınız kontrol edilemedi. Lütfen bağlantınızı kontrol edip tekrar deneyin."\r
menu.home: "ANA SAYFA"\r
menu.research_lab: "ARAŞTIRMA LABORATUVARI"\r
menu.weaponry: "SİLAHLAR"\r
menu.buildings: "YAPI SİSTEMİ"\r
menu.encyclopedia: "ANSİKLOPEDİ"\r
menu.settings: "AYARLAR"\r
menu.artifacts: "KALINTILAR"\r
menu.exit_game: "OYUNDAN ÇIK"\r
menu.start_run: "SEFERİ BAŞLAT"\r
menu.continue: "DEVAM ET"\r
menu.run_again: "TEKRAR SEFERE ÇIK"\r
menu.back: "GERİ"\r
menu.pause: "DURAKLAT"\r
menu.round_paused: "TUR DURAKLATILDI"\r
menu.reset: "SIFIRLA"\r
menu.surrender: "TESLİM OL"\r
menu.return: "DÖN"\r
menu.main_menu: "ANA MENÜ"\r
hud.cash: "NAKİT"\r
hud.chronoshards: "KRONOPARÇALARI"\r
hud.cells: "HÜCRELER"\r
hud.shields: "KALKANLAR"\r
hud.sector: "SEKTÖR {sector}"\r
hud.sandbox_sector: "SANDBOX SEKTÖR {sector}"\r
hud.anomaly_suffix: " · ANOMALİ"\r
settings.preferences: "TERCİHLER"\r
settings.graphics: "GRAFİKLER"\r
settings.gameplay: "OYNANIŞ"\r
settings.sound: "SES"\r
settings.quality: "Kalite"\r
settings.quality_help: "Görüntü işleme çözünürlüğünü ve gölgeleri değiştirir."\r
settings.low: "DÜŞÜK"\r
settings.medium: "ORTA"\r
settings.high: "YÜKSEK"\r
settings.shadows: "Gölgeler"\r
settings.shadows_help: "Dinamik nesne gölgelerini gösterir."\r
settings.hdr_emission: "HDR Işıma"\r
settings.hdr_emission_help: "Parlak efektlerin modellerinin dışına ne kadar taşacağını belirler."\r
settings.max_fps: "Maksimum FPS"\r
settings.max_fps_help: "Donanım yükünü azaltmak için görüntüleme ve simülasyonu sınırlar."\r
settings.unlimited: "SINIRSIZ"\r
settings.auto_pause: "Otomatik Duraklatma"\r
settings.auto_pause_help: "Oyun odağı kaybettiğinde seferi duraklatır."\r
settings.high_contrast_hud: "Yüksek Kontrastlı HUD"\r
settings.high_contrast_hud_help: "HUD okunabilirliğini artırır."\r
settings.master_volume: "Ana Ses Düzeyi"\r
settings.master_volume_help: "Oyundaki tüm ses efektlerini kontrol eder."\r
settings.mute_all: "Tümünü Sessize Al"\r
settings.mute_all_help: "Tüm ses efektlerini anında sessize alır."\r
settings.spatial_audio: "Uzamsal Ses"\r
settings.spatial_audio_help: "Sesleri dünya konumlarına göre sağa veya sola yönlendirir."\r
settings.patch_notes: "YAMA NOTLARI"\r
settings.display: "EKRAN"\r
settings.screen_mode: "Ekran Modu"\r
settings.screen_mode_help: "Steam oyunu varsayılan olarak tam ekranda başlatır."\r
settings.resolution: "Çözünürlük"\r
settings.resolution_help: "Bir çözünürlük seçildiğinde pencere moduna geçilir."\r
settings.fullscreen: "TAM EKRAN"\r
settings.windowed: "PENCERE"\r
milestone.ascension: "YÜKSELİŞ"\r
milestone.max_cells: "AZAMİ HÜCRE"\r
milestone.cells: "{cells} HÜCRE"\r
milestone.next: "SONRAKİ YÜKSELİŞ: {cells} HÜCRE"\r
milestone.ready: "YÜKSELİŞ ÖDÜLÜ ALINMAYA HAZIR"\r
milestone.complete: "YÜKSELİŞ TAMAMLANDI"\r
milestone.claim: "ÖDÜLÜ AL"\r
milestone.claimed: "Alındı"\r
milestone.secured: "ÖDÜL GÜVENCEDE"\r
milestone.auto_claimed: "Otomatik olarak alındı"\r
milestone.best: "Sektör {sector}: en iyi {best}/{target} Hücre"\r
milestone.reward_claimed: "ÖDÜL ALINDI · {rewards}"\r
milestone.reward_cash: "+\${amount} nakit"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshard"\r
milestone.unlock_sector: "Sektör {sector} kilidini aç"\r
milestone.unlock_feature: "{feature} kilidini aç"\r
milestone.unlock_research: "Kilidi aç: {researches}"\r
error.server_time_unconfigured: "Sunucu zamanı uç noktası yapılandırılmamış."\r
error.server_time_request: "Sunucu zamanı isteği {status} durumuyla başarısız oldu."\r
error.server_time_invalid: "Sunucu geçersiz bir zaman döndürdü."\r
message.round_saved: "Tur kaydedildi. Hazır olduğunuzda devam edin."\r
message.sandbox_closed: "Sandbox kapatıldı. İlerleme kaydedilmedi."\r
message.run_surrendered: "Seferden vazgeçildi. İlerleme kaydedilmedi."\r
message.killed_by: "ÖLÜM NEDENİ: {cause}"\r
message.energy_secured: "{count} enerji {cellWord} güvenceye aldınız."\r
message.cell_singular: "hücresi"\r
message.cell_plural: "hücresi"\r
message.tip: "İPUCU · {tip}"\r
message.anomaly_reward: "ANOMALİ +✦{amount}"\r
artifact.acquired: "KALINTI EDİNİLDİ"\r
artifact.acquired_named: "KALINTI EDİNİLDİ · {artifact}"\r
artifact.locked: "KALINTI KİLİTLİ"\r
artifact.unknown: "BİLİNMEYEN KALINTI"\r
encyclopedia.unknown_enemy: "Bilinmeyen düşman"\r
research.slot: "YUVA {slot}"\r
research.available: "MEVCUT"\r
research.locked: "KİLİTLİ"\r
research.remaining: "{duration} kaldı"\r
research.select_below: "Aşağıdan bir araştırma seçin."\r
research.unlock_for: "{cost} karşılığında aç"\r
research.unlock_sector: "Sektör {sector} araştırmalarını Yükselişlerde aç"\r
research.max_level: "AZAMİ SEVİYE"\r
research.in_progress: "DEVAM EDİYOR"\r
research.free_enabled: "ÜCRETSİZ ARAŞTIRMA ETKİN"\r
research.cost: "Maliyet {cost}"\r
research.maxed: "AZAMİ SEVİYEDE"\r
research.start: "ARAŞTIR"\r
research.no_search_results: "Aramanızla eşleşen araştırma adı yok."\r
research.started: "{research} araştırması {slot}. Yuvada başlatıldı."\r
research.upgraded: "{research}, {level}. Seviyeye yükseltildi."\r
research.slot_unlocked: "Araştırma Yuvası {slot} açıldı."\r
research.requires_sector_cells: "Sektör {sector} içinde {cells} Hücre gerektirir"\r
research.requires_banked_cells: "Biriktirilmiş {cells} Hücre gerektirir"\r
research.requires_research: "{research} gerektirir"\r
research.requires_research_level: "{research} Sv. {level} gerektirir"\r
weapon.number: "SİLAH {current} / {total}"\r
weapon.cards: "SİLAH KARTLARI"\r
weapon.round_loadout: "TUR DONANIMI"\r
weapon.buy_with_cost: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five_with_cost: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find_cards: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.level: "SV. {level}"\r
weapon.copy_progress_short: "Sv. {level} için {copies}/{required} kopya"\r
weapon.lucky_find_double: "ŞANSLI BULUNTU · 2 KART"\r
weapon.lucky_find_unlock: "1. Seviyede açıldı ve fazladan bir kopya alındı."\r
weapon.lucky_find_received: "2 kart alındı. {detail}"\r
artifact.stacks: "{count} birikim"\r
artifact.stack: "{count} BİRİKİM"\r
artifact.stacks_label: "{count} BİRİKİM"\r
artifact.dark_core_stack: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.dark_core_stacks: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.to_acquire: "EDİNİLECEK"\r
artifact.permanent_buff: "KALICI GÜÇLENDİRME"\r
artifact.buff_per_stack: "Birikim başına {buff} · {count} birikim = +%{percent} kazanılan Chronoshard"\r
artifact.requirement_score: "Sektör {sector} içinde {cells} Hücreye ulaşın."\r
artifact.requirement_milestone: "Sektör {sector} · {cells} Hücre Yükseliş ödülünü alın."\r
artifact.requirement_anomaly: "Her Anomaliyi her Sektörde tamamlayın. Her benzersiz Anomali ve Sektör birleşimi bir birikim kazandırır."\r
artifact.requirement_hidden: "Gizli koşul."\r
artifact.requirement_default: "Bu kalıntı başarımını tamamlayın."\r
building.choose_offer: "{count} SEÇENEKTEN 1'İNİ SEÇ · SONRAKİ KİLİT ✦ {cost}"\r
building.all_unlocked: "TÜM YAPILAR AÇILDI"\r
building.permanent_unlock: "Kalıcı yapı kilidi açma"\r
building.unlock_cost: "KİLİDİ AÇ · ✦ {cost}"\r
building.upgrade: "YÜKSELT"\r
building.slot_limit: "YUVA SINIRI"\r
building.build_cost: "İnşa maliyeti: \${cost}"\r
building.unlocked: "AÇILDI"\r
building.none_unlocked: "HENÜZ HİÇBİR YAPI AÇILMADI"\r
building.build_mode_slots: "İNŞA MODU · YUVALAR {used}/{total}"\r
building.level: "SV. {level}"\r
building.installed_defense: "KURULU SAVUNMA"\r
building.choose_upgrade: "Bu yapı için bir yükseltme seçin."\r
building.upgrade_level: "SV. {current} → {next}"\r
building.demolish_refund: "YIK · İADE \${amount}"\r
building.demolish_confirm: "{building} yıkılsın mı? \${refund} iade alacaksınız."\r
research.active_slots: "ETKİN YUVALAR"\r
research.available_research: "MEVCUT ARAŞTIRMALAR"\r
research.search: "ARA"\r
research.search_placeholder: "Araştırma adlarında ara"\r
research.hide_completed: "Tamamlanan Araştırmaları Gizle"\r
research.hide_locked: "Kilitli Araştırmaları Gizle"\r
artifact.permanent_achievements: "KALICI BAŞARIMLAR"\r
artifact.intro: "Kalıntılar, başarım hedeflerine ulaşarak kazanılan kalıcı ödüllerdir."\r
building.permanent_defenses: "KALICI SAVUNMALAR"\r
building.system: "YAPI SİSTEMİ"\r
building.build_mode: "İNŞA MODU"\r
building.unlock_a_building: "BİR YAPI AÇ"\r
building.unlocked_buildings: "AÇILAN YAPILAR"\r
building.draft: "YAPI SEÇİMİ"\r
weapon.active_arsenal: "ETKİN CEPHANELİK"\r
menu.back: "GERİ"\r
menu.done: "BİTTİ"\r
encyclopedia.threat_database: "TEHDİT VERİTABANI"\r
accessibility.game_canvas: "Asteroid Belt oyun alanı"\r
accessibility.current_sector: "Mevcut zorluk sektörü"\r
accessibility.pause_game: "Oyunu duraklat"\r
accessibility.shield_charges: "Kalkan şarjları"\r
accessibility.game_controls: "Oyun kontrolleri"\r
accessibility.build_information: "Yapı bilgileri"\r
accessibility.build_locations: "Yapı konumları"\r
accessibility.pause_menu: "Duraklatma menüsü"\r
accessibility.debug_console: "Hata ayıklama konsolu"\r
accessibility.close_debug_console: "Hata ayıklama konsolunu kapat"\r
accessibility.save_slots: "Kayıt yuvası seçimi"\r
accessibility.defeating_enemy: "Yenilmekte olan düşmanın 3B modeli"\r
accessibility.sector_selection: "Zorluk sektörü seçimi"\r
accessibility.previous_sector: "Önceki sektörü seç"\r
accessibility.next_sector: "Sonraki sektörü seç"\r
accessibility.previous_milestone_sector: "Önceki Yükseliş sektörünü görüntüle"\r
accessibility.next_milestone_sector: "Sonraki Yükseliş sektörünü görüntüle"\r
accessibility.enemy_model: "{enemy} modeli"\r
controls.move: "HAREKET"\r
controls.navigate: "GEZİN"\r
controls.use_weapon: "SİLAH KULLAN"\r
controls.select_weapon: "SİLAH SEÇ / KULLAN"\r
patch_notes.version_build: "SÜRÜM {version} · DERLEME {build}"\r
patch_notes.artifacts: "KALINTILAR"\r
patch_notes.artifacts_1: "Kalıntı Sistemi eklendi: Belirli hedefleri tamamladığınızda oyuncuyu kalıcı güçlendirmeler ve ödüllerle ödüllendiren bir başarım mekaniği."\r
patch_notes.artifacts_2: "Kalıntılar çoğunlukla 2. Kademe ve sonrasında 500 Hücreye ulaşılarak kazanılır."\r
patch_notes.artifacts_3: "Şu anda 10 farklı Kalıntı bulunuyor; gelecek güncellemelerde yenileri eklenecek."\r
patch_notes.improvements: "İYİLEŞTİRMELER"\r
patch_notes.improvements_1: "Özellikle mobil cihazlarda görünürlüğü artırmak için çeşitli arayüz iyileştirmeleri yapıldı."\r
patch_notes.improvements_2: "Araştırma kilitleri ve düşman güçleriyle ilgili küçük değer ayarlamaları yapıldı."\r
tip.1: "Ne yaparsanız yapın, sonunda düşmanlar sizi bunaltacak. Daha ileri gidebilmek için yeni araştırmaların kilidini açmayı deneyin."\r
tip.2: "Hareket etmeye devam edin: Sabit durmak yaklaşan tehlikeleri okumayı çok daha zor hâle getirir."\r
tip.3: "Bir düşmanın ömrünün son saniyeleri yanıp sönmeyle belirtilir."\r
tip.4: "Araştırma yükseltmeleri seferler arasında kalıcıdır; bu yüzden kısa bir sefer bile ilerlemenizi sağlayabilir."\r
tip.5: "Düşmanların yaklaşabileceği yönleri azaltmak için arena kenarını kullanın."\r
tip.6: "Chronoshard nadir, değerli ve kısa ömürlüdür. Kaybolmadan önce topladığınızdan emin olun."\r
tip.7: "Arenada bir rota seçmeden önce düşmanların menzil halkalarını takip edin."\r
tip.8: "Oyunun ilerleyen bölümlerinde Araştırma Laboratuvarından güçlendiricilerin kilidini açabilirsiniz."\r
tip.9: "Sektör IV'e ulaştıktan sonra arenada size yardımcı olacak Yapılar inşa etme özelliğini açabilirsiniz."\r
tip.10: "Mor düşmanlara Sinsici denir ve zamanla giderek hızlanırlar. Engellere yaptıkları statik çarpışmalarla yavaşlatılabilirler."\r
tip.11: "Kırmızı düşmanlara Takipçi denir ve menzillerine girdiğinizde sizi kovalarlar."\r
tip.12: "Sarı düşmanlara Patlayıcı denir ve birkaç saniye sonra patlarlar."\r
tip.13: "Ne kadar çok Hücre toplarsanız oyun o kadar zorlaşır."\r
tip.14: "Oyunda ilerledikçe yeni düşmanlar ve engeller ortaya çıkar; yeni zorluklara hazırlıklı olun."\r
tip.15: "Her sektör benzersiz düşmanlar ve zorluklar sunar; stratejinizi buna göre uyarlayın."\r
tip.16: "Asteroid Belt sonsuz bir deneyim olacak şekilde tasarlanmıştır; daha yüksek puanlara ulaşmak için becerilerinizi ve stratejilerinizi geliştirmeye odaklanın."\r
cheat.title: "HATA AYIKLAMA KONSOLU"\r
cheat.prompt: "Bir komut girin."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Sektör {sector} seviyesine ulaşmanız gerekiyor."\r
cheat.feature_cells: "Sektör {sector} içinde {cells} Hücre toplamanız gerekiyor."\r
cheat.feature_chronoshards: "✦ {amount} Chronoshardna ihtiyacınız var."\r
cheat.feature_unavailable: "Bu sistem henüz kullanılamıyor."\r
cheat.research_completed: "{research} araştırması tamamlandı."\r
status.damage: "{status} HASARI"\r
cheat.sandbox_started: "Sandbox Sektör I başlatıldı. sandbox [sector], sandbox simulate [cell|enemies|all] veya sandbox spawn [enemy] [count] komutlarını kullanın."\r
cheat.sandbox_sector: "Sandbox zorluğu Sektör {sector} olarak ayarlandı. Doğma simülasyonu değiştirilmedi."\r
cheat.sandbox_start_first: "Önce şu komutla Sandbox'ı başlatın: sandbox"\r
cheat.sandbox_simulate_usage: "Kullanım: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simülasyonu Sektör {sector} için başlatıldı."\r
cheat.sandbox_spawn_usage: "Kullanım: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "{count} {enemy}{plural} oluşturuldu."\r
cheat.sandbox_usage: "Kullanım: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Kullanım: spawn <entity_id>. Kullanılabilir: {entities}"\r
cheat.spawn_requires_round: "Varlık oluşturmadan önce bir tur başlatın."\r
cheat.spawned: "{entity}, oyuncunun yakınında oluşturuldu."\r
cheat.anomaly_usage: "Kullanım: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Bilinmeyen Anomaly: {id}. Mevcut: {available}"\r
cheat.anomaly_started: "{id} Anomaly'si Sektör {sector} içinde başlatıldı."\r
cheat.cell_usage: "Kullanım: cell <pozitif miktar>"\r
cheat.cell_requires_round: "Hücre vermeden önce bir tur başlat."\r
cheat.cell_granted: "Nakit vermeden {amount} Hücre eklendi. Toplam: {total}."\r
cheat.cell_obtain_usage: "Kullanım: cell_obtain <1 ile 10.000 arasında tam sayı>"\r
cheat.cell_obtain_set: "Hücre alma çarpanı bu oturum için {amount} olarak ayarlandı."\r
cheat.god_usage: "Kullanım: god <on/off>"\r
cheat.god_state: "God mode {state}."\r
cheat.on: "AÇIK"\r
cheat.off: "KAPALI"\r
cheat.artifact_usage: "Kullanım: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Bilinmeyen Kalıntı: {artifact}"\r
cheat.artifact_stack_range: "Birikim 1 ile 10.000 arasında bir tam sayı olmalıdır."\r
cheat.artifact_granted: "{count} {artifact} {stackWord} verildi (toplam {total})."\r
cheat.artifact_unique: "{artifact} benzersiz bir Kalıntıdır ve artık açıldı."\r
cheat.amount_usage: "Kullanım: {command} [positive amount]"\r
cheat.amount_granted: "{amount} verildi."\r
cheat.free_research: "Bu oturum için ücretsiz araştırma etkinleştirildi."\r
cheat.sectors_unlocked: "Tüm sektörler ve Yükseliş ödülleri açıldı.{rewards}"\r
cheat.clear_usage: "Kullanım: clear_save [{targets}]"\r
cheat.cleared: "{target} kayıt verileri temizlendi."\r
cheat.unknown_command: "Bilinmeyen komut: {command}"\r
menu.patch_notes: "YAMA NOTLARI"\r
menu.unlock_feature: "{feature} KİLİDİNİ AÇ · ✦ {cost}"\r
menu.feature_sector: "{feature} · SEKTÖR {sector}"\r
onboarding.drag_to_move: "HAREKET ETMEK İÇİN SÜRÜKLE"\r
`,Vi=`language.english: "Inglés"\r
language.turkish: "Turco"\r
language.spanish: "Español"\r
settings.language: "Idioma"\r
settings.language_help: "Elige el idioma utilizado por la interfaz del juego."\r
save_slots.heading: "SELECCIONAR RANURA DE GUARDADO"\r
save_slots.archive: "ARCHIVO DE MANDO"\r
save_slots.description: "Elige un archivo de piloto para continuar tu expedición."\r
save_slots.slot: "RANURA {slot}"\r
save_slots.new_expedition: "NUEVA EXPEDICIÓN"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MÁX. CÉLULAS"\r
save_slots.total_cash: "DINERO TOTAL"\r
save_slots.total_chronoshards: "CRONOFRAGMENTOS TOTALES"\r
research.category.player_enhancements: "Mejoras del jugador"\r
research.category.economy: "Economía"\r
research.category.boosters: "Potenciadores"\r
research.category.weapons: "Armas"\r
research.category.building_system: "Sistema de construcción"\r
research.category.enemy_debuff: "Debilitamiento de enemigos"\r
research.lucky-find.name: "Hallazgo afortunado"\r
research.lucky-find.description: "Las cartas de arma tienen una probabilidad de convertirse en Hallazgos afortunados y otorgar 2 cartas en lugar de 1."\r
research.weapon-recharge.name: "Recarga de armas"\r
research.weapon-recharge.description: "Las armas ahora pueden recargarse con el tiempo."\r
research.weapon-recharge-rate.name: "Velocidad de recarga de armas"\r
research.weapon-recharge-rate.description: "Reduce el tiempo de recarga de las armas."\r
research.weapon-charge-capacity.name: "Capacidad de cargas del arma"\r
research.weapon-charge-capacity.description: "Aumenta en 1 el máximo de cargas almacenadas de cada arma equipada."\r
research.weapon-slots.name: "Ranura de arma"\r
research.weapon-slots.description: "Añade una ranura de arma a tu equipamiento de partida."\r
research.player-speed-multiplier.name: "Multiplicador de velocidad del jugador"\r
research.player-speed-multiplier.description: "Aumenta la velocidad de movimiento del jugador."\r
research.unlock-slow-aura.name: "Desbloquear Aura ralentizadora"\r
research.unlock-slow-aura.description: "Desbloquea la habilidad Aura ralentizadora, que ralentiza a los enemigos cercanos dentro de su alcance."\r
research.unlock-orbital-electron.name: "Desbloquear Electrón orbital"\r
research.unlock-orbital-electron.description: "Despliega un Electrón que orbita tu alcance efectivo y aturde a los enemigos alcanzados por su arco eléctrico."\r
research.electron-stun-duration.name: "Duración del aturdimiento del Electrón"\r
research.electron-stun-duration.description: "Aumenta el tiempo que permanecen aturdidos los enemigos alcanzados por el Electrón orbital."\r
research.electron-speed.name: "Velocidad del Electrón"\r
research.electron-speed.description: "Aumenta la velocidad orbital del Electrón orbital."\r
research.slow-aura-effect.name: "Efecto del Aura ralentizadora"\r
research.slow-aura-effect.description: "Aumenta el efecto de la habilidad Aura ralentizadora."\r
research.slow-aura-range.name: "Alcance del efecto"\r
research.slow-aura-range.description: "Aumenta el alcance de todos los efectos activos basados en alcance."\r
research.cell-spawn-rate.name: "Frecuencia de aparición de Células"\r
research.cell-spawn-rate.description: "Aumenta la frecuencia de aparición de Células estándar."\r
research.cell-increment-per-cell.name: "Incremento por Célula"\r
research.cell-increment-per-cell.description: "Cada Célula recogida aumenta la frecuencia de aparición de Células estándar."\r
research.cash-cell-multiplier.name: "Multiplicador Dinero/Célula"\r
research.cash-cell-multiplier.description: "Aumenta el Dinero obtenido por cada Célula estándar."\r
research.initial-cell-count.name: "Célula inicial"\r
research.initial-cell-count.description: "Añade una Célula a la arena al comienzo de cada partida."\r
research.cell-magnet.name: "Imán de Células"\r
research.cell-magnet.description: "Atrae hacia ti las Células cercanas. Cada nivel aumenta la velocidad de atracción."\r
research.chrono-spawn-rate.name: "Frecuencia de aparición crono"\r
research.chrono-spawn-rate.description: "Hace que las Células crono aparezcan con mayor frecuencia."\r
research.chrono-lifetime-multiplier.name: "Multiplicador de duración crono"\r
research.chrono-lifetime-multiplier.description: "Aumenta la duración de las Células crono."\r
research.unlock-shockwave.name: "Desbloquear Onda de choque"\r
research.unlock-shockwave.description: "Emite periódicamente una onda de choque verde que empuja a los enemigos."\r
research.shockwave-frequency.name: "Frecuencia de Onda de choque"\r
research.shockwave-frequency.description: "Hace que las Ondas de choque se activen con mayor frecuencia."\r
research.shield.name: "Escudo"\r
research.shield.description: "Otorga una salvación de muerte por nivel al comienzo de cada partida."\r
research.building-slots.name: "Ranuras de edificios"\r
research.building-slots.description: "Aumenta en 1 la cantidad de edificios que puedes colocar en la arena."\r
research.unlock-speed-booster.name: "Desbloquear Potenciadores de velocidad"\r
research.unlock-speed-booster.description: "Desbloquea objetos de Potenciador de velocidad que duplican la velocidad de movimiento."\r
research.speed-booster-duration.name: "Duración del Potenciador de velocidad"\r
research.speed-booster-duration.description: "Aumenta la duración del Potenciador de velocidad."\r
research.thorn-shield.name: "Escudo de espinas"\r
research.thorn-shield.description: "Desbloquea objetos de Escudo de espinas que otorgan inmunidad y destruyen enemigos al contacto."\r
research.thorn-shield-duration.name: "Duración del Escudo de espinas"\r
research.thorn-shield-duration.description: "Aumenta la duración del Escudo de espinas."\r
research.freezer.name: "Congelador"\r
research.freezer.description: "Desbloquea objetos de Congelador que congelan a todos los enemigos."\r
research.freezer-duration.name: "Duración del Congelador"\r
research.freezer-duration.description: "Aumenta la duración del Congelador."\r
research.pushback.name: "Repulsión"\r
research.pushback.description: "Empuja a los enemigos estacionarios cercanos. Cada nivel aumenta la velocidad de empuje."\r
research.shield-invulnerability-duration.name: "Resplandor del escudo"\r
research.shield-invulnerability-duration.description: "Aumenta el tiempo de invulnerabilidad después de que el Escudo se rompe."\r
research.shield-break-explosion.name: "Explosión al romperse el Escudo"\r
research.shield-break-explosion.description: "Destruye a todos los enemigos dentro del alcance cuando el Escudo se rompe. Cada nivel aumenta el alcance."\r
research.regular-lifetime-debuff.name: "Deterioro de Comunes"\r
research.regular-lifetime-debuff.description: "Reduce la duración de los enemigos Comunes."\r
research.chaser-range-debuff.name: "Amortiguador de alcance del Perseguidor"\r
research.chaser-range-debuff.description: "Reduce el alcance de detección del Perseguidor."\r
research.creeper-speed-debuff.name: "Ralentización del Reptante"\r
research.creeper-speed-debuff.description: "Reduce la velocidad de movimiento del Reptante."\r
research.banger-range-debuff.name: "Amortiguador de alcance del Explosivo"\r
research.banger-range-debuff.description: "Reduce el alcance de explosión del Explosivo."\r
research.banger-enemy-destruction.name: "Disrupción del Explosivo"\r
research.banger-enemy-destruction.description: "Otorga a la explosión del Explosivo una probabilidad de destruir a los enemigos afectados."\r
research.shooter-range-debuff.name: "Amortiguador de alcance del Tirador"\r
research.shooter-range-debuff.description: "Reduce el alcance de disparo del Tirador."\r
research.shooter-projectile-debuff.name: "Resistencia de proyectiles"\r
research.shooter-projectile-debuff.description: "Reduce la velocidad de los proyectiles del Tirador."\r
research.porter-interval-debuff.name: "Campo de retraso del Teletransportador"\r
research.porter-interval-debuff.description: "Aumenta el intervalo entre los teletransportes del Teletransportador."\r
research.magnet-strength-debuff.name: "Aislamiento magnético"\r
research.magnet-strength-debuff.description: "Reduce la fuerza de atracción del Imán."\r
research.spore-speed-debuff.name: "Resistencia de la Espora"\r
research.spore-speed-debuff.description: "Reduce la velocidad de movimiento de la Espora."\r
research.poison-creep-clean.name: "Limpieza de rastro venenoso"\r
research.poison-creep-clean.description: "Reduce el tiempo que permanecen los rastros del Reptante venenoso."\r
weapon.nuke.name: "Bomba nuclear"\r
weapon.nuke.description: "Destruye un porcentaje de los enemigos de la arena."\r
weapon.megaMagnet.name: "Megaimán"\r
weapon.megaMagnet.description: "Atrae rápidamente todas las Células hacia tu nave."\r
weapon.atmosphereShield.name: "Escudo atmosférico"\r
weapon.atmosphereShield.description: "Destruye y bloquea meteoros que caen durante un breve periodo."\r
weapon.phaseDash.name: "Impulso de fase"\r
weapon.phaseDash.description: "Atraviesa a los enemigos y elimina a todos los que haya en tu trayectoria."\r
weapon.chronoFreeze.name: "Cronocongelación"\r
weapon.chronoFreeze.description: "Congela a todos los enemigos y su tiempo de vida durante un breve periodo."\r
weapon.plasmaOrbital.name: "Plasma orbital"\r
weapon.plasmaOrbital.description: "Despliega plasmas orbitales que destruyen enemigos al contacto."\r
weapon.cellOverdrive.name: "Sobrecarga de Células"\r
weapon.cellOverdrive.description: "Duplica las Células recogidas durante un breve periodo."\r
weapon.demonMode.name: "Modo demonio"\r
weapon.demonMode.description: "Muévete más rápido y destruye a los enemigos que atravieses."\r
weapon.remove_loadout: "QUITAR DEL EQUIPAMIENTO"\r
weapon.add_loadout: "AÑADIR AL EQUIPAMIENTO"\r
weapon.replace_with: "REEMPLAZAR POR {weapon}"\r
weapon.replace_selected: "REEMPLAZAR ARMA SELECCIONADA"\r
weapon.buy: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.empty_slot: "RANURA VACÍA"\r
weapon.not_collected: "Aún no obtenida"\r
weapon.max_level: "NIVEL MÁXIMO"\r
weapon.claim: "RECLAMAR"\r
weapon.next: "SIGUIENTE"\r
weapon.unlocked: "DESBLOQUEADA"\r
weapon.unlocked_level: "Desbloqueada en el nivel 1."\r
weapon.level_up: "SUBIR DE NIVEL · NV. {level}"\r
weapon.upgraded_level: "Mejorada al nivel {level}."\r
weapon.max_level_copy: "COPIA DE NIVEL MÁXIMO"\r
weapon.max_level_detail: "Esta arma ya está en el nivel máximo."\r
weapon.copy: "COPIA · NV. {level}"\r
weapon.copy_progress: "{copies}/{required} copias para alcanzar el nivel {level}."\r
artifact.broken-radar.name: "Radar averiado"\r
artifact.broken-radar.buff: "+10% a la frecuencia de aparición de Células"\r
artifact.ftl-schematics.name: "Planos FTL"\r
artifact.ftl-schematics.buff: "+10% a la velocidad de movimiento del jugador"\r
artifact.supply-depot.name: "Depósito de suministros"\r
artifact.supply-depot.buff: "+5 Células iniciales"\r
artifact.broken-extractor.name: "Extractor averiado"\r
artifact.broken-extractor.buff: "+10% al Dinero obtenido de Células"\r
artifact.construction-bot.name: "Robot constructor"\r
artifact.construction-bot.buff: "-10% al precio de los Edificios"\r
artifact.alientech-gizmo.name: "Dispositivo de tecnología alienígena"\r
artifact.alientech-gizmo.buff: "-20% al coste de Investigación"\r
artifact.broken-hard-drive.name: "Disco duro averiado"\r
artifact.broken-hard-drive.buff: "+1 Ranura de arma"\r
artifact.hubble-telescope.name: "Telescopio Hubble"\r
artifact.hubble-telescope.buff: "+20% al alcance de efectos del jugador"\r
artifact.dark-core.name: "Núcleo oscuro"\r
artifact.dark-core.buff: "+1% a los Cronofragmentos obtenidos"\r
artifact.map-to-earth.name: "Mapa hacia la Tierra"\r
artifact.map-to-earth.buff: "+20% al tamaño de la arena en cada Sector"\r
building.chronoGenerator.name: "Generador crono"\r
building.autocannon.name: "Cañón automático"\r
building.droneBay.name: "Hangar de drones"\r
building.barrierNode.name: "Nodo de barrera"\r
building.overclockRelay.name: "Relé de overclock"\r
building.salvageExtractor.name: "Extractor de salvamento"\r
building.upgrade.range: "Alcance"\r
building.upgrade.effectiveness: "Eficacia"\r
building.upgrade.frequency: "Frecuencia"\r
building.upgrade.period: "Periodo"\r
building.upgrade.count: "Cantidad"\r
building.upgrade.duration: "Duración"\r
building.upgrade.cash: "Dinero"\r
encyclopedia.category.enemies: "Enemigos"\r
encyclopedia.category.meteors: "Meteoros"\r
encyclopedia.category.ultimate_enemy: "Enemigo definitivo"\r
enemy.regular.name: "Común"\r
enemy.regular.description: "Un enemigo asteroide estacionario. Mantente alejado de su cuerpo mientras recoges Células."\r
enemy.chaser.name: "Perseguidor"\r
enemy.chaser.description: "Detecta la nave dentro de su alcance y la persigue."\r
enemy.creeper.name: "Reptante"\r
enemy.creeper.description: "Se acerca lentamente desde cualquier distancia y se vuelve más rápido cuanto más tiempo sobrevive."\r
enemy.poisonCreeper.name: "Reptante venenoso"\r
enemy.poisonCreeper.description: "Una variante del Reptante que alterna entre púrpura y verde oscuro mientras deja rastros venenosos."\r
enemy.banger.name: "Explosivo"\r
enemy.banger.description: "Se arma, emite pulsos de advertencia y después detona en una amplia zona."\r
enemy.shooter.name: "Tirador"\r
enemy.shooter.description: "Dispara proyectiles contra la nave cuando entra en su alcance de disparo."\r
enemy.porter.name: "Teletransportador"\r
enemy.porter.description: "Se teletransporta ocasionalmente a ubicaciones aleatorias."\r
enemy.magnet.name: "Imán"\r
enemy.magnet.description: "Atrae la nave hacia sí mientras se encuentra dentro de su alcance."\r
enemy.spore.name: "Espora"\r
enemy.spore.description: "Explota en pequeños fragmentos de sí misma y luego vuelve a dividirse en fragmentos aún más pequeños."\r
enemy.voidReaper.name: "Segador del Vacío"\r
enemy.voidReaper.description: "Un aterrador invasor alienígena que marca una ruta letal antes de atravesar la arena."\r
enemy.stoneRock.name: "Roca pétrea"\r
enemy.stoneRock.description: "Un meteoro estándar en caída. Evita su punto de impacto marcado."\r
enemy.fieryRock.name: "Roca ígnea"\r
enemy.fieryRock.description: "Un meteoro en llamas que deja una zona de fuego dañina tras el impacto."\r
enemy.splinter.name: "Esquirla"\r
enemy.splinter.description: "Se hace añicos al impactar y lanza fragmentos hacia el exterior."\r
status.fire: "En llamas"\r
status.poison: "Envenenado"\r
anomaly.cell-scout.name: "Rivalidad de exploradores"\r
anomaly.cell-scout.description: "Una nave de IA roja y distante recoge Células junto a ti. Sus Células no cuentan para tu partida y no puede dañarte."\r
anomaly.tower-defense.name: "Defensa de la torre"\r
anomaly.tower-defense.description: "Defiende la torre central de las oleadas enemigas. Destruye 1.000 enemigos antes de que caiga la torre."\r
anomaly.tower_health: "TORRE {current}/{maximum}"\r
anomaly.tower_defended: "TORRE DEFENDIDA"\r
anomaly.tower_defended_copy: "Destruiste {cells} enemigos y aseguraste la torre."\r
anomaly.tower_destroyed: "TORRE DESTRUIDA"\r
anomaly.tower_destroyed_copy: "La torre cayó después de destruir {cells} enemigos."\r
anomaly.dark_core_stack: "ARTEFACTO · CARGA DE {artifact}"\r
anomaly.run: "PARTIDA DE ANOMALÍA"\r
anomaly.weekly: "ANOMALÍA SEMANAL"\r
anomaly.start: "INICIAR PARTIDA DE ANOMALÍA"\r
anomaly.verifying_title: "VERIFICANDO HORA"\r
anomaly.verifying_copy: "Comprobando la Anomalía semanal actual con el servidor del juego."\r
anomaly.reward: "{cells} CÉLULAS · RECOMPENSA ✦ {reward}"\r
anomaly.reset: "(Nueva Anomalía en {date})"\r
anomaly.reward_claimed: "La recompensa de la Anomalía semanal de este sector ya ha sido reclamada."\r
anomaly.time_unverified_title: "HORA NO VERIFICADA"\r
anomaly.time_unverified_copy: "No se pudo verificar la Anomalía semanal actual."\r
anomaly.time_unverified_error: "No pudimos verificar la hora del servidor ni comprobar tu conexión a Internet. Revisa tu conexión e inténtalo de nuevo."\r
menu.home: "INICIO"\r
menu.research_lab: "LABORATORIO DE INVESTIGACIÓN"\r
menu.weaponry: "ARMAMENTO"\r
menu.buildings: "SISTEMA DE CONSTRUCCIÓN"\r
menu.encyclopedia: "ENCICLOPEDIA"\r
menu.settings: "AJUSTES"\r
menu.artifacts: "ARTEFACTOS"\r
menu.exit_game: "SALIR DEL JUEGO"\r
menu.start_run: "INICIAR PARTIDA"\r
menu.continue: "CONTINUAR"\r
menu.run_again: "JUGAR DE NUEVO"\r
menu.back: "ATRÁS"\r
menu.pause: "PAUSA"\r
menu.round_paused: "PARTIDA EN PAUSA"\r
menu.reset: "REINICIAR"\r
menu.surrender: "RENDIRSE"\r
menu.return: "VOLVER"\r
menu.main_menu: "MENÚ PRINCIPAL"\r
hud.cash: "DINERO"\r
hud.chronoshards: "CRONOFRAGMENTOS"\r
hud.cells: "CÉLULAS"\r
hud.shields: "ESCUDOS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SECTOR DE PRUEBAS {sector}"\r
hud.anomaly_suffix: " · ANOMALÍA"\r
settings.preferences: "PREFERENCIAS"\r
settings.graphics: "GRÁFICOS"\r
settings.gameplay: "JUGABILIDAD"\r
settings.sound: "SONIDO"\r
settings.quality: "Calidad"\r
settings.quality_help: "Cambia la resolución de renderizado y las sombras."\r
settings.low: "BAJA"\r
settings.medium: "MEDIA"\r
settings.high: "ALTA"\r
settings.shadows: "Sombras"\r
settings.shadows_help: "Muestra sombras dinámicas de los objetos."\r
settings.hdr_emission: "Emisión HDR"\r
settings.hdr_emission_help: "Controla cuánto se extienden los efectos brillantes más allá de sus modelos."\r
settings.max_fps: "FPS máximos"\r
settings.max_fps_help: "Limita el renderizado y la simulación para reducir la carga de hardware."\r
settings.unlimited: "SIN LÍMITE"\r
settings.auto_pause: "Pausa automática"\r
settings.auto_pause_help: "Pausa la partida cuando el juego pierde el foco."\r
settings.high_contrast_hud: "HUD de alto contraste"\r
settings.high_contrast_hud_help: "Mejora la legibilidad del HUD."\r
settings.master_volume: "Volumen general"\r
settings.master_volume_help: "Controla todos los efectos de sonido del juego."\r
settings.mute_all: "Silenciar todo"\r
settings.mute_all_help: "Silencia instantáneamente todos los efectos de sonido."\r
settings.spatial_audio: "Audio espacial"\r
settings.spatial_audio_help: "Distribuye los sonidos según su posición en el mundo."\r
settings.patch_notes: "NOTAS DEL PARCHE"\r
settings.display: "PANTALLA"\r
settings.screen_mode: "Modo de pantalla"\r
settings.screen_mode_help: "Steam inicia el juego en pantalla completa de forma predeterminada."\r
settings.resolution: "Resolución"\r
settings.resolution_help: "Al elegir una resolución se cambia al modo ventana."\r
settings.fullscreen: "PANTALLA COMPLETA"\r
settings.windowed: "VENTANA"\r
milestone.ascension: "ASCENSIÓN"\r
milestone.max_cells: "MÁX. CÉLULAS"\r
milestone.cells: "{cells} CÉLULAS"\r
milestone.next: "SIGUIENTE ASCENSIÓN: {cells} CÉLULAS"\r
milestone.ready: "RECOMPENSA DE ASCENSIÓN LISTA PARA RECLAMAR"\r
milestone.complete: "ASCENSIÓN COMPLETADA"\r
milestone.claim: "RECLAMAR RECOMPENSA"\r
milestone.claimed: "Reclamada"\r
milestone.secured: "RECOMPENSA ASEGURADA"\r
milestone.auto_claimed: "Reclamada automáticamente"\r
milestone.best: "Mejor marca: {best}/{target} Células en el Sector {sector}"\r
milestone.reward_claimed: "RECOMPENSA RECLAMADA · {rewards}"\r
milestone.reward_cash: "+\${amount} de Dinero"\r
milestone.reward_chronoshards: "+✦ {amount} Cronofragmentos"\r
milestone.unlock_sector: "Desbloquear Sector {sector}"\r
milestone.unlock_feature: "Desbloquear {feature}"\r
milestone.unlock_research: "Desbloquear: {researches}"\r
error.server_time_unconfigured: "El endpoint de hora del servidor no está configurado."\r
error.server_time_request: "La solicitud de hora del servidor falló con {status}."\r
error.server_time_invalid: "El servidor devolvió una hora no válida."\r
message.round_saved: "Partida guardada. Continúa cuando quieras."\r
message.sandbox_closed: "Se cerró el modo de pruebas. No se guardó ningún progreso."\r
message.run_surrendered: "Te rendiste en la partida. No se guardó ningún progreso."\r
message.killed_by: "ELIMINADO POR {cause}"\r
message.energy_secured: "Has asegurado {count} {cellWord} de energía."\r
message.cell_singular: "célula"\r
message.cell_plural: "células"\r
message.tip: "CONSEJO · {tip}"\r
message.anomaly_reward: "ANOMALÍA +✦{amount}"\r
artifact.acquired: "ARTEFACTO OBTENIDO"\r
artifact.acquired_named: "ARTEFACTO OBTENIDO · {artifact}"\r
artifact.locked: "ARTEFACTO BLOQUEADO"\r
artifact.unknown: "ARTEFACTO DESCONOCIDO"\r
encyclopedia.unknown_enemy: "Enemigo desconocido"\r
research.slot: "RANURA {slot}"\r
research.available: "DISPONIBLE"\r
research.locked: "BLOQUEADA"\r
research.remaining: "Quedan {duration}"\r
research.select_below: "Selecciona una investigación abajo."\r
research.unlock_for: "Desbloquear por {cost}"\r
research.unlock_sector: "Desbloquea la investigación del Sector {sector} en Hitos"\r
research.max_level: "NIVEL MÁXIMO"\r
research.in_progress: "EN PROGRESO"\r
research.free_enabled: "INVESTIGACIÓN GRATUITA ACTIVADA"\r
research.cost: "Coste {cost}"\r
research.maxed: "AL MÁXIMO"\r
research.start: "INVESTIGAR"\r
research.no_search_results: "Ningún nombre de investigación coincide con tu búsqueda."\r
research.started: "La investigación {research} ha comenzado en la Ranura {slot}."\r
research.upgraded: "{research} mejorada al nivel {level}."\r
research.slot_unlocked: "Ranura de investigación {slot} desbloqueada."\r
research.requires_sector_cells: "Requiere {cells} Células en el Sector {sector}"\r
research.requires_banked_cells: "Requiere {cells} células almacenadas"\r
research.requires_research: "Requiere {research}"\r
research.requires_research_level: "Requiere {research} Nv. {level}"\r
weapon.number: "ARMA {current} / {total}"\r
weapon.cards: "CARTAS DE ARMA"\r
weapon.round_loadout: "EQUIPAMIENTO DE PARTIDA"\r
weapon.buy_with_cost: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five_with_cost: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.level: "NV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copias para Nv. {level}"\r
weapon.lucky_find_double: "HALLAZGO AFORTUNADO · 2 CARTAS"\r
weapon.lucky_find_unlock: "Desbloqueada en el nivel 1 y recibiste una copia adicional."\r
weapon.lucky_find_received: "Recibiste 2 cartas. {detail}"\r
artifact.stacks: "{count} acumulaciones"\r
artifact.stack: "{count} ACUMULACIÓN"\r
artifact.stacks_label: "{count} ACUMULACIONES"\r
artifact.dark_core_stack: "{count} ACUMULACIÓN DE NÚCLEO OSCURO"\r
artifact.dark_core_stacks: "{count} ACUMULACIONES DE NÚCLEO OSCURO"\r
artifact.to_acquire: "POR OBTENER"\r
artifact.permanent_buff: "BONIFICACIÓN PERMANENTE"\r
artifact.buff_per_stack: "{buff} por acumulación · {count} acumulaciones = +{percent}% de Cronofragmentos obtenidos"\r
artifact.requirement_score: "Alcanza {cells} Células en el Sector {sector}."\r
artifact.requirement_milestone: "Reclama la recompensa de Ascensión de {cells} Células del Sector {sector}."\r
artifact.requirement_anomaly: "Completa cada Anomalía en cada Sector. Cada combinación única de Anomalía y Sector otorga una acumulación."\r
artifact.requirement_hidden: "Condición oculta."\r
artifact.requirement_default: "Completa este logro de artefacto."\r
building.choose_offer: "ELIGE 1 DE {count} · SIGUIENTE DESBLOQUEO ✦ {cost}"\r
building.all_unlocked: "TODOS LOS EDIFICIOS DESBLOQUEADOS"\r
building.permanent_unlock: "Desbloqueo permanente de edificio"\r
building.unlock_cost: "DESBLOQUEAR · ✦ {cost}"\r
building.upgrade: "MEJORAR"\r
building.slot_limit: "LÍMITE DE RANURAS"\r
building.build_cost: "Coste de construcción: \${cost}"\r
building.unlocked: "DESBLOQUEADO"\r
building.none_unlocked: "AÚN NO HAY EDIFICIOS DESBLOQUEADOS"\r
building.build_mode_slots: "MODO CONSTRUCCIÓN · RANURAS {used}/{total}"\r
building.level: "NV. {level}"\r
building.installed_defense: "DEFENSA INSTALADA"\r
building.choose_upgrade: "Elige una mejora para esta estructura."\r
building.upgrade_level: "NV. {current} → {next}"\r
building.demolish_refund: "DEMOLER · REEMBOLSO \${amount}"\r
building.demolish_confirm: "¿Demoler {building}? Recibirás un reembolso de \${refund}."\r
research.active_slots: "RANURAS ACTIVAS"\r
research.available_research: "INVESTIGACIONES DISPONIBLES"\r
research.search: "BUSCAR"\r
research.search_placeholder: "Buscar nombres de investigaciones"\r
research.hide_completed: "Ocultar investigaciones completadas"\r
research.hide_locked: "Ocultar investigaciones bloqueadas"\r
artifact.permanent_achievements: "LOGROS PERMANENTES"\r
artifact.intro: "Los Artefactos son recompensas permanentes obtenidas al alcanzar objetivos de logros."\r
building.permanent_defenses: "DEFENSAS PERMANENTES"\r
building.system: "SISTEMA DE CONSTRUCCIÓN"\r
building.build_mode: "MODO CONSTRUCCIÓN"\r
building.unlock_a_building: "DESBLOQUEAR UN EDIFICIO"\r
building.unlocked_buildings: "EDIFICIOS DESBLOQUEADOS"\r
building.draft: "SELECCIÓN DE EDIFICIO"\r
weapon.active_arsenal: "ARSENAL ACTIVO"\r
menu.back: "ATRÁS"\r
menu.done: "HECHO"\r
encyclopedia.threat_database: "BASE DE DATOS DE AMENAZAS"\r
accessibility.game_canvas: "Lienzo del juego Asteroid Belt"\r
accessibility.current_sector: "Sector de dificultad actual"\r
accessibility.pause_game: "Pausar juego"\r
accessibility.shield_charges: "Cargas de escudo"\r
accessibility.game_controls: "Controles del juego"\r
accessibility.build_information: "Información de construcción"\r
accessibility.build_locations: "Ubicaciones de construcción"\r
accessibility.pause_menu: "Menú de pausa"\r
accessibility.debug_console: "Consola de depuración"\r
accessibility.close_debug_console: "Cerrar consola de depuración"\r
accessibility.save_slots: "Selección de ranura de guardado"\r
accessibility.defeating_enemy: "Modelo 3D de enemigo derrotado"\r
accessibility.sector_selection: "Selección de sector de dificultad"\r
accessibility.previous_sector: "Seleccionar sector anterior"\r
accessibility.next_sector: "Seleccionar sector siguiente"\r
accessibility.previous_milestone_sector: "Ver sector de hito anterior"\r
accessibility.next_milestone_sector: "Ver sector de hito siguiente"\r
accessibility.enemy_model: "Modelo de {enemy}"\r
controls.move: "MOVERSE"\r
controls.navigate: "NAVEGAR"\r
controls.use_weapon: "USAR ARMA"\r
controls.select_weapon: "SELECCIONAR / USAR ARMA"\r
patch_notes.version_build: "VERSIÓN {version} · COMPILACIÓN {build}"\r
patch_notes.artifacts: "ARTEFACTOS"\r
patch_notes.artifacts_1: "Presentamos el Sistema de Artefactos: una mecánica de logros que recompensa al jugador con bonificaciones y recompensas permanentes al cumplir ciertos objetivos."\r
patch_notes.artifacts_2: "Los Artefactos se obtienen principalmente al alcanzar 500 Células en el Nivel 2 y superiores."\r
patch_notes.artifacts_3: "Actualmente hay 10 Artefactos distintos; se añadirán más en próximas actualizaciones."\r
patch_notes.improvements: "MEJORAS"\r
patch_notes.improvements_1: "Diversas mejoras de la interfaz para aumentar la visibilidad, especialmente en dispositivos móviles."\r
patch_notes.improvements_2: "Pequeños ajustes de valores relacionados con los desbloqueos de Investigación y la fuerza de los Enemigos."\r
tip.1: "Tarde o temprano te verás superado, hagas lo que hagas. Intenta desbloquear nuevas investigaciones para llegar más lejos."\r
tip.2: "Sigue moviéndote: quedarte quieto hace que sea mucho más difícil anticipar los peligros entrantes."\r
tip.3: "Los últimos segundos de vida de un enemigo se indican con un parpadeo."\r
tip.4: "Las mejoras de Investigación se conservan entre partidas, así que incluso una partida corta puede hacerte avanzar."\r
tip.5: "Usa el borde de la arena para reducir las direcciones desde las que pueden acercarse los enemigos."\r
tip.6: "Los Cronofragmentos son raros, valiosos y duran poco. Asegúrate de recogerlos antes de que desaparezcan."\r
tip.7: "Observa los anillos de alcance de los enemigos antes de decidir una ruta por la arena."\r
tip.8: "Más adelante en el juego puedes desbloquear potenciadores desde el Laboratorio de Investigación."\r
tip.9: "Tras alcanzar el Sector IV, puedes desbloquear la capacidad de construir Edificios que te ayuden en la arena."\r
tip.10: "Los enemigos púrpura se llaman Reptantes y aumentan gradualmente su velocidad con el tiempo. Las colisiones estáticas con obstáculos pueden ralentizarlos."\r
tip.11: "Los enemigos rojos se llaman Perseguidores y te perseguirán cuando entres en su alcance."\r
tip.12: "Los enemigos amarillos se llaman Explosivos y explotan después de unos segundos."\r
tip.13: "Cuantas más Células recoges, más difícil se vuelve el juego."\r
tip.14: "A medida que avanzas por el juego aparecen nuevos enemigos y obstáculos, así que prepárate para nuevos desafíos."\r
tip.15: "Cada sector presenta enemigos y desafíos únicos, así que adapta tu estrategia en consecuencia."\r
tip.16: "Asteroid Belt está diseñado como una experiencia sin fin, así que céntrate en mejorar tus habilidades y estrategias para lograr puntuaciones más altas."\r
cheat.title: "CONSOLA DE DEPURACIÓN"\r
cheat.prompt: "Introduce un comando."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Debes alcanzar el Sector {sector}."\r
cheat.feature_cells: "Debes recoger {cells} Células en el Sector {sector}."\r
cheat.feature_chronoshards: "Necesitas ✦ {amount} Cronofragmentos."\r
cheat.feature_unavailable: "Este sistema aún no está disponible."\r
cheat.research_completed: "Investigación {research} completada."\r
status.damage: "DAÑO DE {status}"\r
cheat.sandbox_started: "Sector de pruebas I iniciado. Usa sandbox [sector], sandbox simulate [cell|enemies|all] o sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "La dificultad del modo de pruebas se ha establecido en el Sector {sector}. La simulación de aparición no ha cambiado."\r
cheat.sandbox_start_first: "Primero inicia el modo de pruebas con: sandbox"\r
cheat.sandbox_simulate_usage: "Uso: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Simulación de {type} del modo de pruebas iniciada para el Sector {sector}."\r
cheat.sandbox_spawn_usage: "Uso: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Se generaron {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Uso: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Uso: spawn <entity_id>. Disponibles: {entities}"\r
cheat.spawn_requires_round: "Inicia una partida antes de generar una entidad."\r
cheat.spawned: "Se generó {entity} cerca del jugador."\r
cheat.anomaly_usage: "Uso: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Anomalía desconocida: {id}. Disponibles: {available}"\r
cheat.anomaly_started: "Anomalía {id} iniciada en el Sector {sector}."\r
cheat.cell_usage: "Uso: cell <cantidad positiva>"\r
cheat.cell_requires_round: "Inicia una partida antes de añadir Células."\r
cheat.cell_granted: "Se añadieron {amount} Células sin otorgar dinero. Total: {total}."\r
cheat.cell_obtain_usage: "Uso: cell_obtain <número entero de 1 a 10.000>"\r
cheat.cell_obtain_set: "Multiplicador de obtención de células establecido en {amount} para esta sesión."\r
cheat.god_usage: "Uso: god <on/off>"\r
cheat.god_state: "Modo dios {state}."\r
cheat.on: "ACTIVADO"\r
cheat.off: "DESACTIVADO"\r
cheat.artifact_usage: "Uso: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Artefacto desconocido: {artifact}"\r
cheat.artifact_stack_range: "La acumulación debe ser un número entero entre 1 y 10.000."\r
cheat.artifact_granted: "Se otorgaron {count} {artifact} {stackWord} ({total} en total)."\r
cheat.artifact_unique: "{artifact} es un Artefacto único y ahora está desbloqueado."\r
cheat.amount_usage: "Uso: {command} [positive amount]"\r
cheat.amount_granted: "Se otorgaron {amount}."\r
cheat.free_research: "Investigación gratuita activada para esta sesión."\r
cheat.sectors_unlocked: "Todos los sectores y recompensas de Ascensión desbloqueados.{rewards}"\r
cheat.clear_usage: "Uso: clear_save [{targets}]"\r
cheat.cleared: "Se borraron los datos de guardado de {target}."\r
cheat.unknown_command: "Comando desconocido: {command}"\r
menu.patch_notes: "NOTAS DEL PARCHE"\r
menu.unlock_feature: "DESBLOQUEAR {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
onboarding.drag_to_move: "ARRASTRA PARA MOVERTE"\r
`;function Hi(e){return Object.fromEntries(e.split(/\r?\n/).map(e=>e.match(/^([\w.-]+):\s*"(.*)"\s*$/)).filter(Boolean).map(([,e,t])=>[e,t.replaceAll(`\\"`,`"`)]))}var Ui=Object.freeze({en:Hi(zi),tr:Hi(Bi),es:Hi(Vi)});function Wi(){return(typeof navigator>`u`?[]:navigator.languages?.length?navigator.languages:[navigator.language]).map(e=>e?.split(`-`)[0].toLowerCase()).find(e=>Ui[e])??`en`}function Gi(){try{let e=Math.max(1,Number.parseInt(localStorage.getItem(`asteroid-belt-active-save-slot`)??`1`,10)||1),t=JSON.parse(localStorage.getItem(`asteroid-belt-slot-${e}-settings`)??localStorage.getItem(`asteroid-belt-settings`)??`null`);return Ui[t?.language]?t.language:Wi()}catch{return Wi()}}var Ki=Gi();function qi(e){Ki=Ui[e]?e:`en`}function Ji(){return Object.keys(Ui)}function I(e,t={},n=e){return(Ui[Ki]?.[e]??Ui.en[e]??n).replace(/\{(\w+)\}/g,(e,n)=>String(t[n]??`{${n}}`))}var Yi={durationsEnabled:!1,categoryOrder:[`Player Enhancements`,`Economy`,`Boosters`],featureUnlocks:{researchLab:{minSector:1,chronoshardCost:0,requiredMilestone:`sector-1-10`},buildingSystem:{minSector:4,chronoshardCost:50},weaponry:{minSector:2,chronoshardCost:25}},maxSlots:3,slotUnlocks:[{slot:2,cost:{currency:`chronoshards`,amount:50},requirements:{minSector:2}},{slot:3,cost:{currency:`chronoshards`,amount:200},requirements:{minSector:3}},{slot:4,cost:{currency:`chronoshards`,amount:500},requirements:{minSector:4}},{slot:5,cost:{currency:`chronoshards`,amount:1500},requirements:{minSector:4}}],researches:[{id:`lucky-find`,category:`Weapons`,name:`Lucky Find`,description:`Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1.`,maxLevel:10,effect:{stat:`luckyFindChance`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:5e3,multiplier:1.3,jerk:1.001},duration:{baseMs:15e4,multiplier:1.16}},{id:`weapon-recharge`,category:`Weapons`,name:`Weapon Recharge`,description:`Weapons are now capable of recharging over time.`,maxLevel:1,cost:{currency:`cash`,base:6e3,multiplier:1,jerk:1},duration:{baseMs:18e4,multiplier:1}},{id:`weapon-recharge-rate`,category:`Weapons`,name:`Weapon Recharge Rate`,description:`Reduces weapon recharge time.`,maxLevel:10,effect:{stat:`weaponRechargeReductionSeconds`,perLevel:30,format:`flat`},cost:{currency:`cash`,base:3e3,multiplier:1.28,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18},requirements:{researchId:`weapon-recharge`}},{id:`weapon-charge-capacity`,category:`Weapons`,name:`Weapon Charge Capacity`,description:`Increases the maximum stored charges for each equipped weapon by 1.`,maxLevel:4,effect:{stat:`weaponChargeCapacity`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:7500,multiplier:1.42,jerk:1.002},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchId:`weapon-recharge`}},{id:`weapon-slots`,category:`Weapons`,name:`Weapon Slot`,description:`Adds one weapon slot to your round loadout.`,maxLevel:4,effect:{stat:`weaponSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:8e3,multiplier:1.8,jerk:1.01},duration:{baseMs:18e4,multiplier:1.25}},{id:`player-speed-multiplier`,category:`Player Enhancements`,name:`Player Speed Multiplier`,description:`Increases player movement speed.`,maxLevel:50,effect:{stat:`playerSpeedMultiplier`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:75,multiplier:1.14,jerk:1.0003},duration:{baseMs:9e4,multiplier:1.3}},{id:`unlock-slow-aura`,category:`Player Enhancements`,name:`Unlock Slow Aura`,description:`Unlocks the Slow Aura ability, which slows down nearby enemies within the range.`,maxLevel:1,cost:{currency:`cash`,base:600,multiplier:1,jerk:1},duration:{baseMs:9e4,multiplier:1}},{id:`unlock-orbital-electron`,category:`Player Enhancements`,name:`Unlock Orbital Electron`,description:`Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc.`,maxLevel:1,cost:{currency:`cash`,base:2e3,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`electron-stun-duration`,category:`Player Enhancements`,name:`Electron Stun Duration`,description:`Increases how long enemies hit by the Orbital Electron are stunned.`,maxLevel:20,effect:{stat:`electronStunDuration`,perLevel:.2,format:`flat`},cost:{currency:`cash`,base:2e3,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.18},requirements:{researchId:`unlock-orbital-electron`}},{id:`electron-speed`,category:`Player Enhancements`,name:`Electron Speed`,description:`Increases Orbital Electron orbit speed.`,maxLevel:20,effect:{stat:`electronSpeed`,perLevel:.35,format:`flat`},cost:{currency:`cash`,base:1500,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.16},requirements:{researchId:`unlock-orbital-electron`}},{id:`slow-aura-effect`,category:`Player Enhancements`,name:`Slow Aura Effect`,description:`Increases the effect of the Slow Aura ability.`,maxLevel:50,effect:{stat:`slowAuraEffect`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.14,jerk:1.0003},duration:{baseMs:12e7,multiplier:1.35},requirements:{researchId:`unlock-slow-aura`}},{id:`slow-aura-range`,category:`Player Enhancements`,name:`Effect Range`,description:`Increases the range of every active range-based effect.`,maxLevel:99,effect:{stat:`effectRange`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.09,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35},requirements:{anyResearch:[`unlock-slow-aura`,`cell-magnet`,`pushback`]}},{id:`cell-spawn-rate`,category:`Economy`,name:`Cell Spawn Rate`,description:`Increases the spawn rate of standard cells.`,maxLevel:99,effect:{stat:`cellSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.1,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`cell-increment-per-cell`,category:`Economy`,name:`Cell Increment Per Cell`,description:`Each collected Cell increases the standard Cell spawn rate.`,maxLevel:10,effect:{stat:`cellSpawnRatePerCell`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.35,jerk:1.003},duration:{baseMs:9e4,multiplier:1.2}},{id:`cash-cell-multiplier`,category:`Economy`,name:`Cash/Cell Multiplier`,description:`Increases the Cash earned from every standard cell.`,maxLevel:99,effect:{stat:`cashMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:60,multiplier:1.1,jerk:1.00015},duration:{baseMs:6e4,multiplier:1.25}},{id:`initial-cell-count`,category:`Economy`,name:`Initial Cell`,description:`Adds one Cell to the arena at the start of every run.`,maxLevel:99,effect:{stat:`initialCellCount`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:15,multiplier:1.08,jerk:1.00005},duration:{baseMs:3e4,multiplier:1.08}},{id:`cell-magnet`,category:`Economy`,name:`Cell Magnet`,description:`Pulls nearby Cells toward you. Each level increases pull speed.`,maxLevel:20,effect:{stat:`cellMagnetSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:500,multiplier:1.2,jerk:1.001},duration:{baseMs:9e4,multiplier:1.16}},{id:`chrono-spawn-rate`,category:`Economy`,name:`Chrono Spawn Rate`,description:`Makes Chrono Cells appear more frequently.`,maxLevel:99,effect:{stat:`chronoSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:400,multiplier:1.11,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`chrono-lifetime-multiplier`,category:`Economy`,name:`Chrono Lifetime Multiplier`,description:`Increases the lifetime of Chrono Cells.`,maxLevel:30,effect:{stat:`chronoLifetimeMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.14,jerk:1.0005},duration:{baseMs:12e7,multiplier:1.35}},{id:`unlock-shockwave`,category:`Player Enhancements`,name:`Unlock Shockwave`,description:`Periodically emits a green shockwave that pushes enemies away.`,maxLevel:1,cost:{currency:`cash`,base:900,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`shockwave-frequency`,category:`Player Enhancements`,name:`Shockwave Frequency`,description:`Makes Shockwaves trigger more frequently.`,maxLevel:20,effect:{stat:`shockwaveFrequency`,perLevel:.1,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.2},requirements:{researchId:`unlock-shockwave`}},{id:`shield`,category:`Player Enhancements`,name:`Shield`,description:`Grants one death save per level at the start of every run.`,maxLevel:10,effect:{stat:`shieldCharges`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:4e3,multiplier:1.38,jerk:1.002},duration:{baseMs:18e4,multiplier:1.25}},{id:`building-slots`,category:`Building System`,name:`Building Slots`,description:`Increases the number of buildings you can place in the arena by 1.`,maxLevel:7,effect:{stat:`buildingSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:5e3,multiplier:1.45,jerk:1.002},duration:{baseMs:12e4,multiplier:1.2}},...[[`unlock-speed-booster`,`Unlock Speed Boosters`,`Unlocks Speed Booster pickups that double movement speed.`,1,null],[`speed-booster-duration`,`Speed Booster Duration`,`Increases Speed Booster duration.`,20,`speedBoosterDuration`,`unlock-speed-booster`],[`thorn-shield`,`Thorn Shield`,`Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact.`,1,null],[`thorn-shield-duration`,`Thorn Shield Duration`,`Increases Thorn Shield duration.`,20,`thornShieldDuration`,`thorn-shield`],[`freezer`,`Freezer`,`Unlocks Freezer pickups that freeze all enemies.`,1,null],[`freezer-duration`,`Freezer Duration`,`Increases Freezer duration.`,20,`freezerDuration`,`freezer`]].map(([e,t,n,r,i,a])=>({id:e,category:`Boosters`,name:t,description:n,maxLevel:r,...i?{effect:{stat:i,perLevel:.25,format:`flat`}}:{},cost:{currency:`cash`,base:r===1?2500:1500,multiplier:r===1?1:1.18,jerk:r===1?1:1.001},duration:{baseMs:12e4,multiplier:1.18},...a?{requirements:{researchId:a}}:{}})),{id:`pushback`,category:`Player Enhancements`,name:`Pushback`,description:`Pushes nearby stationary enemies away. Each level increases push speed.`,maxLevel:20,effect:{stat:`pushbackSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:1e4,multiplier:1.18,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18}},{id:`shield-invulnerability-duration`,category:`Player Enhancements`,name:`Shield Afterglow`,description:`Increases invulnerability time after the Shield breaks.`,maxLevel:20,effect:{stat:`shieldInvulnerabilityDuration`,perLevel:.05,format:`flat`},cost:{currency:`cash`,base:12e3,multiplier:1.18,jerk:1.001},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchLevels:{shield:1}}},{id:`shield-break-explosion`,category:`Player Enhancements`,name:`Shield Break Explosion`,description:`Destroys all enemies within range when the Shield breaks. Each level increases the range.`,maxLevel:20,effect:{stat:`shieldBreakExplosionRadius`,perLevel:.3,format:`flat`},cost:{currency:`cash`,base:2e4,multiplier:1.18,jerk:1.001},duration:{baseMs:21e4,multiplier:1.22},requirements:{researchLevels:{shield:1}}},...[[`regular-lifetime-debuff`,`Regular Decay`,`Reduces Regular enemy lifetime.`,`regularLifetimeDebuff`],[`chaser-range-debuff`,`Chaser Range Dampener`,`Reduces Chaser detection range.`,`chaserRangeDebuff`],[`creeper-speed-debuff`,`Creeper Slowdown`,`Reduces Creeper movement speed.`,`creeperSpeedDebuff`],[`banger-range-debuff`,`Banger Range Dampener`,`Reduces Banger blast range.`,`bangerRangeDebuff`],[`banger-enemy-destruction`,`Banger Disruption`,`Give the banger's blast a chance to destroy affected enemies.`,`bangerEnemyDestroyChance`],[`shooter-range-debuff`,`Shooter Range Dampener`,`Reduces Shooter firing range.`,`shooterRangeDebuff`],[`shooter-projectile-debuff`,`Projectile Drag`,`Reduces Shooter projectile speed.`,`shooterProjectileSpeedDebuff`],[`porter-interval-debuff`,`Porter Delay Field`,`Increases the interval between Porter teleports.`,`porterIntervalBonus`],[`magnet-strength-debuff`,`Magnet Insulation`,`Reduces Magnet pull strength.`,`magnetStrengthDebuff`],[`spore-speed-debuff`,`Spore Drag`,`Reduces Spore movement speed.`,`sporeSpeedDebuff`],[`poison-creep-clean`,`Poison Creep Clean`,`Reduces how long Poison Creeper trails remain.`,`poisonTrailDurationReduction`]].map(([e,t,n,r])=>({id:e,category:`Enemy Debuff`,name:t,description:n,maxLevel:20,effect:{stat:r,perLevel:r===`porterIntervalBonus`||r===`poisonTrailDurationReduction`?.05:.025,format:`percent`},...r===`poisonTrailDurationReduction`?{maxLevel:15}:{},cost:{currency:`cash`,base:6e3,multiplier:1.18,jerk:1.001},duration:{baseMs:24e4,multiplier:1.22}}))]},Xi=e=>`research.category.${e.toLowerCase().replaceAll(` `,`_`)}`,Zi={...Yi,categoryOrder:Yi.categoryOrder.map(e=>I(Xi(e),{},e)),researches:Yi.researches.map(e=>({...e,category:I(Xi(e.category),{},e.category),name:I(`research.${e.id}.name`,{},e.name),description:I(`research.${e.id}.description`,{},e.description)}))},Qi={enabled:!0,hotkey:`"`,title:I(`cheat.title`),commands:{cash:`cash`,chrono:`chrono`,freeResearch:`free_research`,unlockSectors:`unlock_sectors`,gainArtifact:`gain_artifact`,clearSave:`clear_save`,sandbox:`sandbox`,spawn:`spawn`,anomaly:`anomaly`,cell:`cell`,cellObtain:`cell_obtain`,god:`god`},clearSaveTargets:[`currency`,`game_progress`,`milestones`,`research`,`buildings`,`weapons`,`artifacts`,`all`]},$i={version:`0.9.12`,number:`1164`,date:`September 19, 2026`,label:`EARLY ACCESS`},ea={unlockSector:2,weeklyAnchorDate:`2026-09-02`,rewardCellTarget:250,rewardBaseChronoshards:10,rewardChronoshardStepPerSector:2,challenges:[{id:`cell-scout`,name:`Scout Rivalry`,description:`A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you.`,type:`cell-scout`,rewardCellTarget:250},{id:`tower-defense`,name:`Tower Defense`,description:`Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls.`,type:`tower-defense`,rewardCellTarget:1e3,towerHitpoints:100,towerContactDamage:1,towerProjectileDamage:1,towerRadius:1.15,difficultyMultiplier:1,enemyTypes:[`regular`,`chaser`,`creeper`,`shooter`],enemySpawnWeights:{regular:.4,chaser:.25,creeper:.2,shooter:.15},enemyMovementSpeeds:{chaser:2.4,creeper:1.25,shooter:1.1}}]},ta={...ea,challenges:ea.challenges.map(e=>({...e,name:I(`anomaly.${e.id}.name`,{},e.name),description:I(`anomaly.${e.id}.description`,{},e.description)}))},na={endpoint:``},ra={endpoint:``,publicEndpoint:`https://utctime.app/api/now`},ia=`asteroid-belt-analytics-session-id`;function aa(){try{let e=sessionStorage.getItem(ia);if(e)return e;let t=crypto.randomUUID();return sessionStorage.setItem(ia,t),t}catch{return crypto.randomUUID()}}function oa({sector:e,buildVersion:t,platform:n}){na.endpoint&&fetch(na.endpoint,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({event:`sector_started`,sessionId:aa(),properties:{sector:e,buildVersion:t,platform:n}}),keepalive:!0}).catch(()=>{})}var sa={placementRadius:10,minimumSpacing:2.2,spawnClearance:2.5,types:{chronoGenerator:{name:`Chrono Generator`,baseCost:180,costMultiplier:1.35,color:`#63f5cd`,effect:{range:4,slow:.22},upgrades:{range:{base:180,step:.2},effectiveness:{base:240,step:.02}}},autocannon:{name:`Autocannon`,baseCost:350,costMultiplier:1.45,color:`#ff795f`,effect:{range:5,interval:2.6},upgrades:{range:{base:360,step:.2},frequency:{base:440,step:-.06}}},droneBay:{name:`Drone Bay`,baseCost:460,costMultiplier:1.48,color:`#79caff`,effect:{period:14,count:1,droneSpeed:5},upgrades:{period:{base:540,step:-.65},count:{base:880,step:1}}},barrierNode:{name:`Barrier Node`,baseCost:520,costMultiplier:1.5,color:`#76eaff`,effect:{range:4.3,period:12,duration:4.5},upgrades:{range:{base:560,step:.28},period:{base:640,step:-.55},duration:{base:700,step:.45}}},overclockRelay:{name:`Overclock Relay`,baseCost:580,costMultiplier:1.52,color:`#ffcf76`,effect:{range:5.2,effectiveness:.14},upgrades:{range:{base:620,step:.3},effectiveness:{base:760,step:.04}}},salvageExtractor:{name:`Salvage Extractor`,baseCost:640,costMultiplier:1.55,color:`#8dff9c`,effect:{range:4.8,period:18,count:1,cash:2},upgrades:{period:{base:720,step:-.7},cash:{base:820,step:1.5},count:{base:980,step:1}}}}},ca={...sa,types:Object.fromEntries(Object.entries(sa.types).map(([e,t])=>[e,{...t,name:I(`building.${e}.name`,{},t.name),upgrades:Object.fromEntries(Object.entries(t.upgrades).map(([e,t])=>[e,{...t,name:I(`building.upgrade.${e}`,{},e)}]))}]))};function la({THREE:e,COLORS:t,ENTITIES:n,GAME:r,opacity:i=1}){let a=new e.Group,o=new e.Mesh(new e.ConeGeometry(.58,1.45,6),new e.MeshStandardMaterial({color:t.player,emissive:`#000000`,emissiveIntensity:0,metalness:.2,roughness:.55}));o.rotation.x=Math.PI/2,o.position.y=.18,o.castShadow=!0,a.add(o);let s=new e.MeshStandardMaterial({color:t.playerWing??`#f6b05c`,emissive:`#000000`,emissiveIntensity:0,metalness:.18,roughness:.58});for(let t of[-1,1]){let n=new e.Mesh(new e.BoxGeometry(.82,.08,.58),s);n.position.set(t*.52,.12,-.08),n.rotation.z=t*-.16,n.castShadow=!0,a.add(n)}let c=new e.Mesh(new e.SphereGeometry(.29,12,8),new e.MeshStandardMaterial({color:`#76ddff`,emissive:`#000000`,emissiveIntensity:0,metalness:.25,roughness:.48}));c.scale.set(.82,.62,1.15),c.position.set(0,.38,.18),a.add(c);let l=new e.Mesh(new e.TorusGeometry(.3,n.playerRingTube*.72,n.playerRingRadialSegments,n.playerRingTubularSegments),new e.MeshBasicMaterial({color:t.playerRing,transparent:!0,opacity:.88}));l.position.set(0,.17,-.67),a.add(l);let u=new e.Group,d=new e.Mesh(new e.ConeGeometry(.27,.82,8),new e.MeshBasicMaterial({color:`#ff5c32`,transparent:!0,opacity:.74,depthWrite:!1})),f=new e.Mesh(new e.ConeGeometry(.14,.57,8),new e.MeshBasicMaterial({color:`#ffe781`,transparent:!0,opacity:.94,depthWrite:!1}));for(let e of[d,f])e.rotation.x=-Math.PI/2;f.position.z=-.08,u.add(d,f),u.position.set(0,.17,-.93),a.add(u);let p=new e.Mesh(new e.RingGeometry(1-n.slowAuraRingWidth,1,n.slowAuraRingSegments),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.35,side:e.DoubleSide,depthWrite:!1}));p.rotation.x=-Math.PI/2,p.position.y=-r.playerStartHeight+.04,p.visible=!1,a.add(p);let m=new e.Mesh(new e.SphereGeometry(r.playerRadius*1.15,20,14),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.18,wireframe:!0,depthWrite:!1}));return m.visible=!1,a.add(m),i<1&&a.traverse(e=>{e.material&&(e.material.transparent=!0,e.material.opacity*=i,e.material.depthWrite=!1)}),a.position.y=r.playerStartHeight,{player:a,playerCore:o,slowAuraRing:p,shieldBubble:m,updateVisuals(e,t,n){l.rotation.z+=e*n;let r=.9+Math.sin(t*20)*.12+Math.sin(t*33)*.06;u.scale.set(1,1,r),d.material.opacity=.62+Math.sin(t*17)*.12,f.material.opacity=.8+Math.sin(t*23)*.14}}}function ua({THREE:e,building:t,config:n,range:r}){let i=new e.Group,a=new e.MeshStandardMaterial({color:`#33465a`,emissive:n.color,emissiveIntensity:.24,metalness:.92,roughness:.14}),o={autocannon:`#ffd36f`,droneBay:`#79caff`,barrierNode:`#76eaff`,overclockRelay:`#ffcf76`,salvageExtractor:`#8dff9c`}[t.type]??`#a6a2ff`,s=new e.MeshStandardMaterial({color:o,emissive:o,emissiveIntensity:1.25,metalness:.78,roughness:.12}),c=new e.Mesh(new e.CylinderGeometry(.53,.64,.26,8),a);if(c.position.y=.13,i.add(c),t.type===`chronoGenerator`){let t=new e.Mesh(new e.IcosahedronGeometry(.32,1),s);t.position.y=.67;let n=new e.Mesh(new e.TorusGeometry(.46,.035,8,24),s);n.position.y=.68,n.rotation.x=Math.PI/2;let r=n.clone();r.rotation.set(Math.PI/3,0,Math.PI/5),i.add(t,n,r)}if(t.type===`autocannon`){let t=new e.Mesh(new e.BoxGeometry(.48,.26,.48),s);t.position.y=.42,i.add(t);for(let t of[-.14,.14]){let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.78,8),s);n.rotation.x=Math.PI/2,n.position.set(t,.51,.38),i.add(n)}}if(t.type===`droneBay`){let t=new e.Mesh(new e.BoxGeometry(.96,.42,.78),a);t.position.y=.47;let n=new e.Mesh(new e.BoxGeometry(.56,.22,.04),s);n.position.set(0,.5,.41),i.add(t,n);for(let t of[-.26,.26]){let n=new e.Mesh(new e.SphereGeometry(.09,8,6),s);n.position.set(t,.82,.08),i.add(n)}}if(t.type===`barrierNode`){let t=new e.Mesh(new e.OctahedronGeometry(.34,0),s);t.position.y=.72,i.add(t);for(let t=0;t<3;t+=1){let n=new e.Mesh(new e.ConeGeometry(.13,.8,6),s),r=t*Math.PI*2/3;n.position.set(Math.cos(r)*.42,.46,Math.sin(r)*.42),i.add(n)}let n=new e.Mesh(new e.SphereGeometry(.72,16,10,0,Math.PI*2,0,Math.PI/2),new e.MeshBasicMaterial({color:`#8ceaff`,transparent:!0,opacity:.15,depthWrite:!1}));n.position.y=.1,i.add(n)}if(t.type===`overclockRelay`){let t=new e.Mesh(new e.TorusGeometry(.34,.06,8,24),s);t.position.y=.62,t.rotation.x=Math.PI/2;let n=new e.Mesh(new e.CylinderGeometry(.035,.05,.72,8),s);n.position.y=.8;let r=new e.Mesh(new e.SphereGeometry(.1,10,8),s);r.position.y=1.18,i.add(t,n,r)}if(t.type===`salvageExtractor`){let t=new e.Mesh(new e.CylinderGeometry(.3,.42,.66,8),s);t.position.y=.55;let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.82,8),a);n.position.set(.36,.82,0),n.rotation.z=-Math.PI/3;let r=new e.Mesh(new e.ConeGeometry(.17,.34,5),s);r.position.set(.72,.55,0),r.rotation.z=-Math.PI/2,i.add(t,n,r)}let l=Number.isFinite(n.effect.range),u=new e.Mesh(new e.RingGeometry(.985,1.005,48),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.28,side:e.DoubleSide,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.y=.03,u.scale.setScalar(l?r:0),u.visible=l,i.add(u);let d=null;if(t.type===`barrierNode`){d=new e.Group;let t=new e.Mesh(new e.CylinderGeometry(1,1,1.6,40,1,!0),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.16,side:e.DoubleSide,depthWrite:!1}));t.position.y=.8;let r=new e.Mesh(new e.TorusGeometry(1,.035,6,40),new e.MeshBasicMaterial({color:`#d5ffff`,transparent:!0,opacity:.85,depthWrite:!1}));r.position.y=1.58,r.rotation.x=Math.PI/2,d.add(t,r),d.visible=!1,i.add(d)}return i.position.set(t.x,0,t.z),{group:i,effectRing:u,barrierField:d}}function da(e){let t=new e.Group,n=new e.MeshStandardMaterial({color:`#314c63`,emissive:`#79caff`,emissiveIntensity:.8,metalness:.9,roughness:.18}),r=new e.MeshBasicMaterial({color:`#baf8ff`,transparent:!0,opacity:.95,depthWrite:!1}),i=new e.Mesh(new e.SphereGeometry(.14,10,7),n);i.scale.set(1.25,.55,1.5),t.add(i);let a=[];for(let[i,o]of[[-.22,-.2],[.22,-.2],[-.22,.2],[.22,.2]]){let s=new e.Mesh(new e.BoxGeometry(.13,.035,.13),n);s.position.set(i,0,o);let c=new e.Mesh(new e.CylinderGeometry(.12,.12,.018,12),r);c.position.set(i,.045,o),t.add(s,c),a.push(c)}let o=new e.Mesh(new e.SphereGeometry(.055,8,6),r);return o.position.set(0,.015,.2),t.add(o),t.userData.rotors=a,t}function fa({THREE:e,ENTITIES:t}){let n=new e.IcosahedronGeometry(t.obstacleCoreRadius,1),r=new e.ConeGeometry(t.obstacleSpikeRadius,t.obstacleSpikeHeight,t.obstacleSpikeSegments),i=new e.ConeGeometry(t.obstacleSpikeRadius*.72,t.obstacleSpikeHeight*.7,t.obstacleSpikeSegments),a=new e.ConeGeometry(t.obstacleSpikeRadius*.27,t.obstacleSpikeHeight*.22,t.obstacleSpikeSegments),o=new e.ConeGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeHeight*.27,t.obstacleSpikeSegments),s=new e.CylinderGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeRadius,t.obstacleSpikeHeight*.82,t.obstacleSpikeSegments),c=new e.CircleGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeSegments),l=new e.MeshStandardMaterial({color:`#ff3b30`,emissive:`#8c0b06`,emissiveIntensity:1.7,metalness:.35,roughness:.28}),u=new e.MeshStandardMaterial({color:`#c88cff`,emissive:`#7a18ff`,emissiveIntensity:1.75,metalness:.2,roughness:.22}),d=new e.MeshBasicMaterial({color:`#050505`,side:e.DoubleSide}),f=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1],[0,1,2],[0,1,-2],[0,-1,2],[0,-1,-2],[1,2,0],[-1,2,0],[1,-2,0],[-1,-2,0],[2,0,1],[-2,0,1],[2,0,-1],[-2,0,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),p=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),m=new e.Vector3(0,1,0);return function(h,g=`regular`){let _=new e.Group,v=new e.Mesh(n,h);v.castShadow=!0,_.add(v);let y=[],b=[],x=g===`chaser`?f:p;for(let[n,f]of x.entries()){let p=g===`chaser`?t.obstacleSpikeHeight*.7:t.obstacleSpikeHeight,v=new e.Group;v.position.copy(f).multiplyScalar(t.obstacleCoreRadius+p*.28),v.quaternion.setFromUnitVectors(m,f);let x=v.quaternion.clone(),S=new e.Mesh(g===`chaser`?i:g===`shooter`?s:r,h);if(S.castShadow=!0,v.add(S),g===`chaser`){let t=new e.Mesh(a,l);t.position.y=p*.43,t.castShadow=!0,v.add(t)}if(g===`creeper`||g===`poisonCreeper`){let t=u.clone(),n=new e.Mesh(o,t);n.position.y=p*.47,n.castShadow=!0,v.add(n),b.push(t)}if(g===`shooter`){let t=new e.Mesh(c,d);t.rotation.x=-Math.PI/2,t.position.y=p*.41+.002,v.add(t)}y.push({root:v,baseQuaternion:x,phase:n*1.71}),_.add(v)}return _.userData.material=h,_.userData.spikes=y,_.userData.creeperTipMaterials=b,_}}function pa(e){let t=new e.Group,n=new e.MeshStandardMaterial({color:`#151021`,emissive:`#3b0d72`,emissiveIntensity:1.8,metalness:.82,roughness:.2}),r=new e.MeshStandardMaterial({color:`#372052`,emissive:`#6b1caa`,emissiveIntensity:1.3,metalness:.6,roughness:.26}),i=new e.MeshStandardMaterial({color:`#d9ff6a`,emissive:`#9dff15`,emissiveIntensity:3.8,metalness:.18,roughness:.18}),a=new e.MeshBasicMaterial({color:`#06030a`}),o=new e.Mesh(new e.SphereGeometry(.66,12,8),n);o.scale.set(1.5,.62,1.05),o.castShadow=!0,t.add(o);let s=new e.Mesh(new e.ConeGeometry(.72,.64,6),r);s.rotation.x=Math.PI/2,s.position.z=-.23,s.castShadow=!0,t.add(s);let c=new e.Mesh(new e.SphereGeometry(.26,10,7),a);c.scale.set(1.45,.72,.3),c.position.set(0,.04,.72),t.add(c);let l=new e.Mesh(new e.SphereGeometry(.14,10,8),i);l.scale.set(1.55,.7,.32),l.position.set(0,.04,.79),t.add(l);let u=[];for(let n of[-1,1]){let a=new e.Mesh(new e.ConeGeometry(.38,1.45,4),r);a.position.set(n*.93,-.04,-.08),a.rotation.set(0,n*Math.PI/2,n*.48),a.castShadow=!0,t.add(a);let o=new e.Mesh(new e.ConeGeometry(.11,.92,5),i);o.position.set(n*.5,-.16,.78),o.rotation.set(n*.42,0,n*.26),t.add(o),u.push(o)}for(let n=0;n<4;n+=1){let i=new e.Mesh(new e.ConeGeometry(.12,.58,5),r);i.position.set((n-1.5)*.3,.34,-.42),i.rotation.x=-Math.PI/2.9,t.add(i)}return t.userData.eyeMaterial=i,t.userData.mandibles=u,t}function ma({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.OctahedronGeometry(n.cellRadius),i=new e.IcosahedronGeometry(n.chronoCellRadius,1),a=new e.OctahedronGeometry(.42),o={speed:`#ffcf76`,thorn:`#ff795f`,freezer:`#7bdcff`};return{createCell(){return new e.Mesh(r,new e.MeshStandardMaterial({color:t.cell,emissive:t.cellEmissive,emissiveIntensity:n.cellEmissiveIntensity,metalness:n.cellMetalness,roughness:n.cellRoughness}))},createChronoCell(){return new e.Mesh(i,new e.MeshStandardMaterial({color:t.chronoCell,emissive:t.chronoCellEmissive,emissiveIntensity:n.chronoCellEmissiveIntensity,metalness:.12,roughness:.42,transparent:!0}))},createBooster(t){let n=o[t];return new e.Mesh(a,new e.MeshStandardMaterial({color:n,emissive:n,emissiveIntensity:1.7,metalness:.25,roughness:.2}))}}}function ha({THREE:e,SCENE:t,count:n,size:r,opacity:i}){let a=new Float32Array(n*3),o=new Float32Array(n*3);for(let r=0;r<n;r+=1){let n=e.MathUtils.randFloatSpread(2),i=Math.sqrt(1-n*n),s=Math.random()*Math.PI*2,c=r*3;a[c]=Math.cos(s)*i*t.starfieldRadius,a[c+1]=n*t.starfieldRadius,a[c+2]=Math.sin(s)*i*t.starfieldRadius;let l=Math.random();o[c]=.72+l*.28,o[c+1]=.82+l*.18,o[c+2]=1}let s=new e.BufferGeometry;s.setAttribute(`position`,new e.BufferAttribute(a,3)),s.setAttribute(`color`,new e.BufferAttribute(o,3));let c=new e.Points(s,new e.PointsMaterial({size:r,sizeAttenuation:!1,transparent:!0,opacity:i,vertexColors:!0,depthWrite:!1,fog:!1}));return c.frustumCulled=!1,c}function ga(e,t){let n=[];for(let r=2;r<t;r+=2)for(let t=0;t<80;t+=1){let i=t/80*Math.PI*2,a=(t+1)/80*Math.PI*2;n.push(new e.Vector3(Math.cos(i)*r,.01,Math.sin(i)*r),new e.Vector3(Math.cos(a)*r,.01,Math.sin(a)*r))}for(let r=0;r<12;r+=1){let i=r/12*Math.PI*2;n.push(new e.Vector3,new e.Vector3(Math.cos(i)*t,.01,Math.sin(i)*t))}return new e.BufferGeometry().setFromPoints(n)}function _a(e,t){return new e.BufferGeometry().setFromPoints(Array.from({length:96},(n,r)=>{let i=r/96*Math.PI*2;return new e.Vector3(Math.cos(i)*t,.04,Math.sin(i)*t)}))}function va({THREE:e,scene:t,COLORS:n,GAME:r,SCENE:i,LIGHTING:a,quality:o=`high`}){let s=new e.Group;function c(t){let n={low:.35,medium:.65,high:1}[t]??1;s.clear(),s.add(ha({THREE:e,SCENE:i,count:Math.round(i.starCount*n),size:i.starSize,opacity:.84})),s.add(ha({THREE:e,SCENE:i,count:Math.round(i.brightStarCount*n),size:i.brightStarSize,opacity:.96}))}c(o),t.add(s),t.add(new e.HemisphereLight(a.hemisphereSky,a.hemisphereGround,a.hemisphereIntensity));let l=new e.DirectionalLight(a.key,a.keyIntensity);l.position.set(-7,13,5),l.castShadow=!0,l.shadow.mapSize.set(1024,1024),t.add(l);let u=new e.Mesh(new e.CircleGeometry(r.arenaSize/2,96),new e.MeshStandardMaterial({color:n.floor,metalness:i.floorMetalness,roughness:i.floorRoughness,transparent:!0,opacity:i.floorOpacity,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.receiveShadow=!0,t.add(u);let d=new e.LineSegments(ga(e,r.arenaLimit),new e.LineBasicMaterial({color:n.gridMinor,transparent:!0,opacity:.8}));d.position.y=.01,t.add(d);let f=new e.LineLoop(_a(e,r.arenaLimit),new e.LineDashedMaterial({color:n.arenaBoundary,dashSize:.45,gapSize:.2}));return f.computeLineDistances(),t.add(f),{starfield:s,floor:u,grid:d,arenaBoundary:f,keyLight:l,setQuality:c,resize(t,n=1){let i=(r.arenaLimit+t)*n;u.geometry.dispose(),u.geometry=new e.CircleGeometry((r.arenaSize/2+t)*n,96),d.geometry.dispose(),d.geometry=ga(e,i),f.geometry.dispose(),f.geometry=_a(e,i),f.computeLineDistances()}}}function ya({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.IcosahedronGeometry(n.shooterProjectileRadius,1);return{createShooterProjectile(){return new e.Mesh(r,new e.MeshStandardMaterial({color:`#7dff9d`,emissive:`#00ff5a`,emissiveIntensity:4,metalness:.25,roughness:.16}))},createAutocannonProjectile(){return new e.Mesh(new e.SphereGeometry(.16,10,8),new e.MeshBasicMaterial({color:`#fff1a6`,transparent:!0,opacity:.95}))},createSplinter(){return new e.Mesh(new e.TetrahedronGeometry(.32),new e.MeshStandardMaterial({color:t.splinter,emissive:t.splinterEmissive,emissiveIntensity:1.3,metalness:.4,roughness:.3}))}}}function ba({THREE:e,Quarks:t,particleRenderer:n,COLORS:r,getQuality:i=()=>`high`}){let a=()=>({low:.45,medium:.7,high:1})[i()]??1,o=e=>Math.max(1,Math.round(e*a())),s=(n,r=1)=>{let i=new e.Color(n);return new t.Vector4(i.r,i.g,i.b,r)},c=n=>{let r=new e.Color(n);return new t.Vector3(r.r,r.g,r.b)},l=(()=>{let t=document.createElement(`canvas`);t.width=128,t.height=128;let n=t.getContext(`2d`),r=n.createRadialGradient(64,64,9,64,64,64);r.addColorStop(0,`rgba(255,255,255,0.9)`),r.addColorStop(.58,`rgba(255,255,255,0.68)`),r.addColorStop(1,`rgba(255,255,255,0)`),n.fillStyle=r,n.fillRect(0,0,128,128);let i=new e.CanvasTexture(t);return i.colorSpace=e.SRGBColorSpace,i})();function u({position:r,color:i,count:a,life:l,size:u,speed:d,radius:f=0,gravity:p=0,duration:m=.05,texture:h=null,renderMode:g=t.RenderMode.BillBoard,instancingGeometry:_,sizeOverLife:v,looping:y=!1,emissionRate:b=0,force:x=null}){let S=new e.MeshBasicMaterial({color:i,map:h,transparent:!0,opacity:1,blending:e.AdditiveBlending,depthWrite:!1,depthTest:!0}),C=new t.ParticleSystem({autoDestroy:!y,looping:y,duration:m,shape:new t.SphereEmitter({radius:f,thickness:1}),startLife:new t.IntervalValue(l*.72,l),startSpeed:new t.IntervalValue(d*.65,d),startSize:new t.IntervalValue(u*.55,u),startColor:new t.ColorRange(s(i,.95),s(`#ffffff`,.7)),emissionOverTime:b?new t.ConstantValue(o(b)):void 0,emissionBursts:b?[]:[{time:0,count:new t.ConstantValue(o(a)),cycle:1,interval:.01,probability:1}],behaviors:[new t.ColorOverLife(new t.Gradient([[c(i),0],[c(i),.55],[c(i),1]],[[.95,0],[.55,.55],[0,1]])),...p?[new t.ApplyForce(new t.Vector3(0,-1,0),new t.ConstantValue(p))]:[],...x?[new t.ApplyForce(x.direction,new t.ConstantValue(x.magnitude))]:[],...v?[new t.SizeOverLife(v)]:[]],material:S,renderMode:g,..._?{instancingGeometry:_}:{},worldSpace:!0});return C.emitter.position.copy(r),n.addSystem(C),C.emitter}function d(t,n,r,i){let a=new e.PointLight(n,r,i);return a.position.copy(t),a}return{createExplosion(n,i){let a=new t.PiecewiseBezier([[new t.Bezier(.05,i,i,i),0],[new t.Bezier(i,i,i,i),.18]]);return{emitters:[u({position:n,color:r.banger,count:1,life:.65,size:1,speed:0,instancingGeometry:new e.SphereGeometry(1,16,12),renderMode:t.RenderMode.Mesh,sizeOverLife:a})],light:d(n,r.banger,10,i*2)}},createBangerPulse(t){let n=new e.Mesh(new e.RingGeometry(.22,.42,48),new e.MeshBasicMaterial({color:r.banger,transparent:!0,opacity:.9,side:e.DoubleSide,depthWrite:!1}));return n.rotation.x=-Math.PI/2,n.position.set(t.x,.06,t.z),n},createShockwave(t){let n=new e.Mesh(new e.RingGeometry(.2,.42,64),new e.MeshBasicMaterial({color:r.slowAura,transparent:!0,opacity:.95,side:e.DoubleSide,depthWrite:!1}));return n.rotation.x=-Math.PI/2,n.position.set(t.x,.07,t.z),n},createShieldBreak(e){return{emitters:[u({position:e,color:`#8cfff0`,count:38,life:.55,size:.19,speed:5.4,radius:.22})],light:d(e,`#63f5cd`,12,10)}},createPoisonTrail(e,n,i){let a=e.clone();return a.y=.045,{emitters:[u({position:a,color:r.poisonTrail,count:7,life:i,size:n*1.35,speed:0,radius:n*.56,duration:.05,texture:l,renderMode:t.RenderMode.HorizontalBillBoard})]}},createPlayerDeath(e){return{emitters:[u({position:e,color:r.playerRing,count:64,life:.9,size:.22,speed:8.8,radius:.2,gravity:5}),u({position:e,color:`#fff4cf`,count:22,life:.32,size:.4,speed:3.2,radius:.05})],light:d(e,`#fff4cf`,22,18)}},createFieryRockFire(n,i){let a=n.clone();return a.y=.08,{emitters:[u({position:a,color:r.fire,count:0,life:.7,size:i*.55,speed:.28,radius:i*.55,duration:1,looping:!0,emissionRate:14,force:{direction:new t.Vector3(0,1,0),magnitude:1.25}}),u({position:a,color:`#ffe19a`,count:0,life:1.15,size:.075,speed:.62,radius:i*.48,duration:1,looping:!0,emissionRate:7,force:{direction:new t.Vector3(0,1,0),magnitude:.72}})],light:d(new e.Vector3(n.x,1.2,n.z),r.fire,5.5,i*3)}},createFallingRockImpact(n,r,i){let a=n.clone();return a.y=.08,{emitters:[u({position:a,color:`#d9c7a0`,count:26,life:.62,size:r*.42,speed:r*2.8,radius:r*.24,force:{direction:new t.Vector3(0,1,0),magnitude:.28}}),u({position:a,color:i,count:18,life:.48,size:r*.13,speed:r*5,radius:r*.12,gravity:7,instancingGeometry:new e.TetrahedronGeometry(1,0),renderMode:t.RenderMode.Mesh})]}}}}var xa=Object.freeze({cellBank:`asteroid-belt-banked-cells`,sector:`asteroid-belt-selected-sector`,sectorHighScores:`asteroid-belt-sector-high-scores`,cash:`asteroid-belt-cash`,chronoshards:`asteroid-belt-chronoshards`,aetherium:`asteroid-belt-aetherium`,researchLab:`asteroid-belt-research-lab`,savedRound:`asteroid-belt-saved-round`,buildings:`asteroid-belt-buildings`,featureUnlocks:`asteroid-belt-feature-unlocks`,milestones:`asteroid-belt-milestones`,settings:`asteroid-belt-settings`,weaponry:`asteroid-belt-weaponry`,anomalyRewards:`asteroid-belt-anomaly-rewards`,artifacts:`asteroid-belt-artifacts`}),Sa=[`t`,`i`,`e`,`r`].join(``),Ca=`asteroid-belt-selected-${Sa}`,wa=`asteroid-belt-${Sa}-high-scores`,Ta=[[`astroid-belt-banked-cells`,xa.cellBank],[Ca,xa.sector],[wa,xa.sectorHighScores],[`astroid-belt-selected-${Sa}`,xa.sector],[`astroid-belt-${Sa}-high-scores`,xa.sectorHighScores],[`astroid-belt-cash`,xa.cash],[`astroid-belt-chronoshards`,xa.chronoshards],[`astroid-belt-research-lab`,xa.researchLab],[`astroid-belt-saved-round`,xa.savedRound],[`astroid-belt-buildings`,xa.buildings],[`astroid-belt-feature-unlocks`,xa.featureUnlocks]];function Ea(e=window.localStorage){for(let[t,n]of Ta)try{e.getItem(n)===null&&e.getItem(t)!==null&&e.setItem(n,e.getItem(t))}catch{}try{let t=`${Sa}-`,n=JSON.parse(e.getItem(xa.sectorHighScores)??`null`);if(n&&typeof n==`object`){let t=Object.fromEntries(Object.entries(n).map(([e,t])=>[e.startsWith(Sa)?`sector${e.slice(Sa.length)}`:e,t]));e.setItem(xa.sectorHighScores,JSON.stringify(t))}let r=JSON.parse(e.getItem(xa.milestones)??`null`);r&&Array.isArray(r.claimed)&&(r.claimed=r.claimed.map(e=>typeof e==`string`&&e.startsWith(t)?`sector-${e.slice(t.length)}`:e),e.setItem(xa.milestones,JSON.stringify(r)));let i=JSON.parse(e.getItem(xa.savedRound)??`null`),a=`${Sa}Index`;i&&typeof i==`object`&&Number.isFinite(i[a])&&!Number.isFinite(i.sectorIndex)&&(i.sectorIndex=i[a],e.setItem(xa.savedRound,JSON.stringify(i)));let o=JSON.parse(e.getItem(xa.anomalyRewards)??`null`),s=`claimed${Sa[0].toUpperCase()}${Sa.slice(1)}s`;o?.[s]&&!o.claimedSectors&&(o.claimedSectors=o[s],e.setItem(xa.anomalyRewards,JSON.stringify(o)))}catch{}}function Da(e,t=0,n=window.localStorage){try{let r=Number(n.getItem(e));return Number.isFinite(r)&&r>=0?r:t}catch{return t}}function Oa(e,t,n=window.localStorage){try{n.setItem(e,String(t))}catch{}}function ka(e,t=null,n=window.localStorage){try{return JSON.parse(n.getItem(e))??t}catch{return t}}function Aa(e,t,n=window.localStorage){try{t==null?n.removeItem(e):n.setItem(e,JSON.stringify(t))}catch{}}function ja({THREE:e,SOUND:t,getSettings:n,getPlayer:r,getCamera:i}){let a,o,s=new Map,c;async function l(e,t){try{let n=await fetch(t);if(!n.ok)return;s.set(e,await a.decodeAudioData(await n.arrayBuffer()))}catch{}}function u(){if(!a){let e=window.AudioContext||window.webkitAudioContext;if(!e)return Promise.resolve();a=new e,o=a.createGain(),d(!0),o.connect(a.destination),c=Promise.all(Object.entries(t.assets).map(([e,t])=>l(e,t)))}let e=a.state===`suspended`?a.resume():Promise.resolve();return Promise.all([e,c])}function d(e=!1){if(!o||!a)return;let r=n(),i=t.masterVolume*(r.sound.muted?0:r.sound.masterVolume/100);e?o.gain.value=i:o.gain.setTargetAtTime(i,a.currentTime,.03)}function f(n){let a=n.clone().sub(r().position);a.y=0;let o=a.length(),s=e.MathUtils.lerp(t.spatialMinGain,1,(1-e.MathUtils.clamp(o/t.spatialMaxDistance,0,1))**2);if(o===0)return{attenuation:s,pan:0};let c=new e.Vector3(1,0,0).applyQuaternion(i().quaternion);return c.y=0,c.normalize(),{attenuation:s,pan:e.MathUtils.clamp(a.normalize().dot(c),-1,1)}}function p(e,t,r){let i=a.createGain(),s=a.createGain(),c=a.createStereoPanner?.(),l=a.currentTime,{attenuation:u,pan:d}=n().sound.spatialAudio?f(r):{attenuation:1,pan:0};i.gain.setValueAtTime(t,l),s.gain.setValueAtTime(u,l),e.connect(i),i.connect(s),c?(c.pan.setValueAtTime(d,l),s.connect(c),c.connect(o)):s.connect(o)}function m(e,t,n,r,i,o){if(!a||a.state!==`running`)return;let s=a.createOscillator(),c=a.currentTime;s.type=o,s.frequency.setValueAtTime(e,c),s.frequency.linearRampToValueAtTime(t,c+n),p(s,r,i),s.start(c),s.stop(c+n)}function h(e,t,n){if(!a||a.state!==`running`)return;let r=a.currentTime,i=a.createBuffer(1,Math.ceil(a.sampleRate*e),a.sampleRate),o=i.getChannelData(0);for(let e=0;e<o.length;e+=1)o[e]=Math.random()*2-1;let s=a.createBufferSource(),c=a.createBiquadFilter(),l=a.createGain();s.buffer=i,c.type=`bandpass`,c.Q.value=.65,c.frequency.setValueAtTime(180,r),c.frequency.exponentialRampToValueAtTime(720,r+e),l.gain.setValueAtTime(1e-4,r),l.gain.exponentialRampToValueAtTime(1,r+.18),l.gain.exponentialRampToValueAtTime(1e-4,r+e),s.connect(c),c.connect(l),p(l,t,n),s.start(r)}function g(e,t){if(!a||a.state!==`running`)return;let n=a.currentTime,r=a.createBuffer(1,Math.ceil(a.sampleRate*.24),a.sampleRate),i=r.getChannelData(0);for(let e=0;e<i.length;e+=1)i[e]=(Math.random()*2-1)*(1-e/i.length);let o=a.createBufferSource(),s=a.createBiquadFilter(),c=a.createGain();o.buffer=r,s.type=`lowpass`,s.Q.value=1.2,s.frequency.setValueAtTime(1500,n),s.frequency.exponentialRampToValueAtTime(110,n+.24),c.gain.setValueAtTime(1e-4,n),c.gain.exponentialRampToValueAtTime(1,n+.012),c.gain.exponentialRampToValueAtTime(1e-4,n+.24),o.connect(s),s.connect(c),p(c,e,t),o.start(n)}function _(e,t,n,r){if(!a||a.state!==`running`)return;let i=s.get(e);if(!i){r();return}let o=a.createBufferSource();o.buffer=i,p(o,t,n),o.start()}return{initialize:u,setMasterVolume:d,playBangerPulse(n,r){let i=t.fallback.bangerPulse,a=e.MathUtils.lerp(i.startFrequency,i.endFrequency,n);_(`bangerPulse`,t.bangerPulseVolume,r,()=>m(a,a,i.duration,t.bangerPulseVolume,r,i.type))},playFallingObstacle(e){let n=t.fallback.fallingObstacle;_(`fallingObstacle`,t.fallingObstacleVolume,e,()=>h(n.duration,t.fallingObstacleVolume,e))},playCellCollect(e){let n=t.fallback.cellCollect;_(`cellCollect`,t.cellCollectVolume,e,()=>m(n.startFrequency,n.endFrequency,n.duration,t.cellCollectVolume,e,n.type))},playBoosterPickup(e,t){let[n,r]={speed:[480,900],thorn:[220,620],freezer:[720,260]}[t];m(n,r,.22,.3,e,t===`freezer`?`sine`:`triangle`)},playShieldBreak(e){g(.52,e),m(180,58,.2,.24,e,`sawtooth`)},playBuildingEffect(e,t){let[n,r]={chronoGenerator:[280,360],autocannon:[220,90],droneBay:[520,760],barrierNode:[260,440],overclockRelay:[440,600],salvageExtractor:[180,300]}[t];m(n,r,.12,.16,e,`sine`)},playObstacleSummon(e){let n=t.fallback.obstacleSummon;_(`obstacleSummon`,t.obstacleSummonVolume,e,()=>m(n.startFrequency,n.endFrequency,n.duration,t.obstacleSummonVolume,e,n.type))},playButtonClick(){let e=t.fallback.buttonClick,n=r().position;_(`buttonClick`,t.buttonClickVolume,n,()=>m(e.startFrequency,e.endFrequency,e.duration,t.buttonClickVolume,n,e.type))}}}var Ma=[[1e3,`M`],[900,`CM`],[500,`D`],[400,`CD`],[100,`C`],[90,`XC`],[50,`L`],[40,`XL`],[10,`X`],[9,`IX`],[5,`V`],[4,`IV`],[1,`I`]];function Na(e){let t=Math.max(1,Math.floor(Number(e)||1)),n=``;for(let[e,r]of Ma)for(;t>=e;)n+=r,t-=e;return n}function Pa({config:e,milestones:t,getResearchState:n,getMilestoneState:r,getBankedCells:i}){let a=t=>e.researches.find(e=>e.id===t),o=e=>n().levels[e]??0,s=e=>t.find(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)));function c(e){let n=r();return n.researchUnlocks.includes(e)||t.some(t=>n.claimed.includes(t.id)&&t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))}function l(t){return e.researches.filter(e=>e.effect?.stat===t).reduce((e,t)=>e+o(t.id)*t.effect.perLevel,0)}function u(e,t){let n=e.cost.jerk??1,r=e.cost.base*e.cost.multiplier**t*n**(t*(t-1)/2);return e.cost.currency===`cash`?Math.round(r*100)/100:Math.ceil(r)}function d(e){let t=e.requirements??{},n=s(e.id);if(n&&!r().debugAscensionsGranted&&!c(e.id))return I(`research.requires_sector_cells`,{cells:n.cells,sector:Na(n.sector)});if(t.minBankedCells&&i()<t.minBankedCells)return I(`research.requires_banked_cells`,{cells:t.minBankedCells});if(t.researchId&&o(t.researchId)<1)return I(`research.requires_research`,{research:a(t.researchId).name});for(let[e,n]of Object.entries(t.researchLevels??{}))if(o(e)<n)return I(`research.requires_research_level`,{research:a(e).name,level:n});return``}function f(e,t=new Set){let n=s(e.id)?.sector??0;if(t.has(e.id))return{sector:n,depth:0};let r=e.requirements??{},i=[...r.researchId?[r.researchId]:[],...Object.keys(r.researchLevels??{})].map(a).filter(Boolean).map(n=>f(n,new Set(t).add(e.id)));return{sector:Math.max(n,...i.map(e=>e.sector)),depth:i.length?Math.max(...i.map(e=>e.depth))+1:0}}function p(e,t){let n=f(e),r=f(t);return n.sector-r.sector||n.depth-r.depth||e.name.localeCompare(t.name)}return{getResearchById:a,getResearchLevel:o,getResearchStatBonus:l,getResearchCost:u,getResearchDuration:(e,t)=>Math.round(e.duration.baseMs*e.duration.multiplier**t),getResearchLockReason:d,isResearchVisible:e=>!e.visibleWhen?.anyResearch||e.visibleWhen.anyResearch.some(e=>o(e)>0),compareResearchProgression:p}}var Fa=[{id:`regular`,category:`Enemies`,name:`Regular`,model:`spiked-enemy`,firstSector:1,description:`A stationary asteroid enemy. Keep clear of its body while collecting Cells.`},{id:`chaser`,category:`Enemies`,name:`Chaser`,model:`spiked-enemy`,firstSector:2,description:`Detects the ship within its range and pursues it.`},{id:`creeper`,category:`Enemies`,name:`Creeper`,model:`spiked-enemy`,firstSector:1,description:`Slowly closes in from any distance and becomes faster as it survives.`},{id:`poisonCreeper`,category:`Enemies`,name:`Poison Creeper`,model:`spiked-enemy`,firstSector:9,description:`A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind.`},{id:`banger`,category:`Enemies`,name:`Banger`,model:`spiked-enemy`,firstSector:3,description:`Arms itself, pulses a warning, then detonates over a wide area.`},{id:`shooter`,category:`Enemies`,name:`Shooter`,model:`spiked-enemy`,firstSector:3,description:`Fires projectiles at the ship when it enters firing range.`},{id:`porter`,category:`Enemies`,name:`Porter`,model:`spiked-enemy`,firstSector:5,description:`Occasionally teleports itself to random locations.`},{id:`magnet`,category:`Enemies`,name:`Magnet`,model:`spiked-enemy`,firstSector:6,description:`Pulls the ship toward itself while it is within range.`},{id:`spore`,category:`Enemies`,name:`Spore`,model:`spiked-enemy`,firstSector:7,description:`Bursts into small pieces of itself, then burst into even smaller pieces again.`},{id:`voidReaper`,category:`Ultimate Enemy`,categoryKey:`ultimate_enemy`,name:`Void Reaper`,model:`ultimate-enemy`,firstSector:1/0,description:`A horrifying alien raider that marks a lethal path before tearing across the arena.`},{id:`stoneRock`,category:`Meteors`,name:`Stone Rock`,model:`falling-rock`,firstSector:1,description:`A standard falling meteor. Avoid its marked impact point.`},{id:`fieryRock`,category:`Meteors`,name:`Fiery Rock`,model:`falling-rock`,firstSector:3,description:`A burning meteor that leaves a damaging fire hazard after impact.`},{id:`splinter`,category:`Meteors`,name:`Splinter`,model:`falling-rock`,firstSector:2,description:`Shatters on impact and sends fragments outward.`}].map(e=>({...e,category:I(`encyclopedia.category.${e.categoryKey??e.category.toLowerCase()}`,{},e.category),name:I(`enemy.${e.id}.name`,{},e.name),description:I(`enemy.${e.id}.description`,{},e.description)})),Ia=[{heading:I(`patch_notes.artifacts`),changes:[I(`patch_notes.artifacts_1`),I(`patch_notes.artifacts_2`),I(`patch_notes.artifacts_3`)]},{heading:I(`patch_notes.improvements`),changes:[I(`patch_notes.improvements_1`),I(`patch_notes.improvements_2`)]}];function La(e,t){if(!e.effect)return t>0?`UNLOCKED`:`LOCKED`;let n=t*e.effect.perLevel;return e.effect.format===`percent`?`+${(n*100).toFixed(n*100%1?1:0)}%`:String(n)}function Ra(e){let t=Math.max(0,Math.ceil(e/1e3)),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60;return n>0?`${n}h ${r}m`:r>0?`${r}m ${i}s`:`${i}s`}function za(e){let t=Math.abs(e),n=t>=0xe8d4a51000?[`T`,0xe8d4a51000]:t>=1e9?[`B`,1e9]:t>=1e6?[`M`,1e6]:t>=1e3?[`K`,1e3]:null;if(!n)return e.toLocaleString(void 0,{maximumFractionDigits:2});let r=e/n[1];return`${r.toFixed(Math.abs(r)<10?2:1)}${n[0]}`}function Ba(e,t){return e===`cash`?`$${za(t)}`:`✦ ${za(t)}`}var Va=Array.from({length:16},(e,t)=>I(`tip.${t+1}`)),Ha=[10,25,50,100,250,500],L=(e,t,n)=>({id:`sector-${e}-${Ha[t]}`,sector:e,cells:Ha[t],rewards:n}),R=e=>({type:`cash`,amount:e}),z=e=>({type:`chronoshards`,amount:e}),B=(...e)=>({type:`research`,researchIds:e}),Ua=e=>({type:`feature`,featureId:e}),Wa=e=>({type:`sector`,sector:e}),Ga=[L(1,0,[R(25),Ua(`researchLab`),B(`player-speed-multiplier`)]),L(1,1,[R(50),B(`cash-cell-multiplier`),Wa(2)]),L(1,2,[R(75),z(1)]),L(1,3,[R(100)]),L(1,4,[R(150)]),L(1,5,[R(250),z(3)]),L(2,0,[R(150),B(`cell-magnet`)]),L(2,1,[R(250),B(`unlock-speed-booster`),B(`unlock-shockwave`)]),L(2,2,[R(400),z(3),B(`speed-booster-duration`),Wa(3)]),L(2,3,[R(650)]),L(2,4,[R(900),z(6),B(`shockwave-frequency`)]),L(2,5,[R(1250),z(10)]),L(3,0,[R(500),B(`unlock-slow-aura`,`unlock-orbital-electron`,`weapon-slots`)]),L(3,1,[R(750),z(5),B(`slow-aura-effect`,`electron-speed`)]),L(3,2,[R(1e3),B(`cell-increment-per-cell`),Wa(4)]),L(3,3,[R(1500),z(10),B(`electron-stun-duration`)]),L(3,4,[R(2e3),B(`slow-aura-range`)]),L(3,5,[R(3e3),z(15)]),L(4,0,[R(1e3),B(`chrono-lifetime-multiplier`)]),L(4,1,[R(1500),z(10),B(`building-slots`)]),L(4,2,[R(2e3),B(`shield`)]),L(4,3,[R(3e3),z(15),B(`thorn-shield`),Wa(5)]),L(4,4,[R(4500),B(`thorn-shield-duration`,`pushback`)]),L(4,5,[R(6e3),z(25),B(`shield-invulnerability-duration`,`shield-break-explosion`)]),L(5,0,[R(2e3),B(`freezer`,`weapon-recharge`,`lucky-find`)]),L(5,1,[R(3e3),z(15),B(`freezer-duration`,`weapon-recharge-rate`)]),L(5,2,[R(4e3),B(`regular-lifetime-debuff`,`weapon-charge-capacity`)]),L(5,3,[R(6e3),z(20),B(`chaser-range-debuff`),Wa(6)]),L(5,4,[R(8e3),B(`creeper-speed-debuff`)]),L(5,5,[R(1e4),z(30)]),L(6,0,[R(4e3),B(`banger-range-debuff`)]),L(6,1,[R(6e3),z(20),B(`banger-enemy-destruction`)]),L(6,2,[R(8e3),B(`shooter-range-debuff`)]),L(6,3,[R(12e3),z(30),B(`shooter-projectile-debuff`),Wa(7)]),L(6,4,[R(16e3),z(40)]),L(6,5,[R(2e4),z(50)]),L(7,0,[R(8e3),B(`porter-interval-debuff`)]),L(7,1,[R(12e3),z(30),B(`magnet-strength-debuff`)]),L(7,2,[R(16e3),B(`spore-speed-debuff`)]),L(7,3,[R(24e3),z(45),Wa(8)]),L(7,4,[R(32e3),z(60)]),L(7,5,[R(4e4),z(80)]),L(8,0,[R(16e3),z(25)]),L(8,1,[R(24e3),z(40)]),L(8,2,[R(32e3),z(60)]),L(8,3,[R(48e3),z(80),Wa(9)]),L(8,4,[R(64e3),z(120)]),L(8,5,[R(1e5),z(200)]),L(9,0,[R(32e3),B(`poison-creep-clean`)]),L(9,1,[R(48e3),z(50)]),L(9,2,[R(64e3),z(75)]),L(9,3,[R(96e3),z(100)]),L(9,4,[R(128e3),z(150)]),L(9,5,[R(2e5),z(250)])],Ka={purchaseCost:15,levelCopyRequirements:[3,5,10,25],weapons:{nuke:{name:`Nuke`,key:`1`,color:`#ff795f`,description:`Destroys a percentage of enemies in the arena.`,baseEffect:.3,effectPerLevel:.1},megaMagnet:{name:`Mega Magnet`,key:`2`,color:`#63f5cd`,description:`Pulls every Cell rapidly toward your ship.`,baseEffect:2.5,effectPerLevel:.8,duration:!0},atmosphereShield:{name:`Atmosphere Shield`,key:`3`,color:`#b59aff`,description:`Destroys and blocks falling meteors for a short time.`,baseEffect:4,effectPerLevel:1.2,duration:!0},phaseDash:{name:`Phase Dash`,key:`4`,color:`#78eaff`,description:`Dash through enemies and erase every enemy in your path.`,baseEffect:6.5,effectPerLevel:1.1},chronoFreeze:{name:`Chrono Freeze`,key:`5`,color:`#74bfff`,description:`Freezes every enemy and their lifetime for a short time.`,baseEffect:2.5,effectPerLevel:.65,duration:!0},plasmaOrbital:{name:`Plasma Orbital`,key:`6`,color:`#ff8cff`,description:`Deploys plasma orbitals that destroy enemies on contact.`,baseEffect:4,effectPerLevel:.8,duration:!0},cellOverdrive:{name:`Cell Overdrive`,key:`7`,color:`#ffd36f`,description:`Doubles Cells collected for a short time.`,baseEffect:4,effectPerLevel:.8,duration:!0},demonMode:{name:`Demon Mode`,key:`8`,color:`#ff465d`,description:`Move faster and destroy enemies you pass through.`,baseEffect:4,effectPerLevel:.8,duration:!0}}},qa={...Ka,weapons:Object.fromEntries(Object.entries(Ka.weapons).map(([e,t])=>[e,{...t,name:I(`weapon.${e}.name`,{},t.name),description:I(`weapon.${e}.description`,{},t.description)}]))},Ja={artifacts:[{id:`broken-radar`,name:`Broken Radar`,icon:`broken-radar.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-2-500`,sector:2,cells:500},buff:{stat:`cellSpawnRate`,amount:.1,label:`+10% Cell spawn rate`}},{id:`ftl-schematics`,name:`FTL Schematics`,icon:`ftl-schematics.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-3-500`,sector:3,cells:500},buff:{stat:`playerSpeedMultiplier`,amount:.1,label:`+10% player movement speed`}},{id:`supply-depot`,name:`Supply Depot`,icon:`supply-depot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-4-500`,sector:4,cells:500},buff:{stat:`initialCellCount`,amount:5,label:`+5 initial Cells`}},{id:`broken-extractor`,name:`Broken Extractor`,icon:`broken-extractor.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-5-500`,sector:5,cells:500},buff:{stat:`cashMultiplier`,amount:.1,label:`+10% cash earned from Cells`}},{id:`construction-bot`,name:`Construction Bot`,icon:`construction-bot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-6-500`,sector:6,cells:500},buff:{stat:`buildingCostReduction`,amount:.1,label:`-10% Building prices`}},{id:`alientech-gizmo`,name:`Alientech Gizmo`,icon:`alientech-gizmo.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-7-500`,sector:7,cells:500},buff:{stat:`researchCostReduction`,amount:.2,label:`-20% Research cost`}},{id:`broken-hard-drive`,name:`Broken Hard-Drive`,icon:`broken-hard-drive.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-8-500`,sector:8,cells:500},buff:{stat:`weaponSlotCount`,amount:1,label:`+1 Weapon Slot`}},{id:`hubble-telescope`,name:`Hubble Telescope`,icon:`hubble-telescope.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-9-500`,sector:9,cells:500},buff:{stat:`effectRange`,amount:.2,label:`+20% player effect range`}},{id:`dark-core`,name:`Dark Core`,icon:`dark-core.svg`,repeatable:!0,requirement:{type:`anomaly-run-success`,cells:250},buff:{stat:`chronoshardGainMultiplier`,amount:.01,label:`+1% Chronoshards earned`}},{id:`map-to-earth`,name:`Map To Earth`,icon:`map-to-earth.svg`,requirement:{type:`hidden-world-map`,minSector:6,chance:.01},buff:{stat:`arenaSizeMultiplier`,amount:.2,label:`+20% arena size in every Sector`}}]},Ya={...Ja,artifacts:Ja.artifacts.map(e=>({...e,name:I(`artifact.${e.id}.name`,{},e.name),buff:{...e.buff,label:I(`artifact.${e.id}.buff`,{},e.buff.label)}}))},Xa=Object.freeze({"broken-radar":`ARTIFACT_BROKEN_RADAR`,"ftl-schematics":`ARTIFACT_FTL_SCHEMATICS`,"supply-depot":`ARTIFACT_SUPPLY_DEPOT`,"broken-extractor":`ARTIFACT_BROKEN_EXTRACTOR`,"construction-bot":`ARTIFACT_CONSTRUCTION_BOT`,"alientech-gizmo":`ARTIFACT_ALIENTECH_GIZMO`,"broken-hard-drive":`ARTIFACT_BROKEN_HARD_DRIVE`,"hubble-telescope":`ARTIFACT_HUBBLE_TELESCOPE`,"dark-core":`ARTIFACT_DARK_CORE`,"map-to-earth":`ARTIFACT_MAP_TO_EARTH`});function Za(e){let t=Xa[e];!t||!window.steamShell?.unlockAchievement||window.steamShell.unlockAchievement(t).catch(e=>console.warn(`[Steamworks] achievement unlock failed:`,e))}async function Qa(){if(!window.steamShell?.getAchievementStates)return{};try{return await window.steamShell.getAchievementStates(Object.values(Xa))}catch(e){return console.warn(`[Steamworks] achievement sync failed:`,e),{}}}var $a=e=>`./assets/${e}`,eo={chronoGenerator:$a(`buildings/chrono-generator.svg`),autocannon:$a(`buildings/autocannon.svg`),droneBay:$a(`buildings/drone-bay.svg`),barrierNode:$a(`buildings/barrier-node.svg`),overclockRelay:$a(`buildings/overclock-relay.svg`),salvageExtractor:$a(`buildings/salvage-extractor.svg`)},to={nuke:$a(`weapons/nuke.svg`),megaMagnet:$a(`weapons/mega-magnet.svg`),atmosphereShield:$a(`weapons/atmosphere-shield.svg`),phaseDash:$a(`weapons/phase-dash.svg`),chronoFreeze:$a(`weapons/chrono-freeze.svg`),plasmaOrbital:$a(`weapons/plasma-orbital.svg`),cellOverdrive:$a(`weapons/cell-overdrive.svg`),demonMode:$a(`weapons/demon-mode.svg`)},no={researchLab:$a(`ui/research-lab.svg`),buildingSystem:$a(`ui/building-system.svg`),weaponry:$a(`ui/weaponry.svg`),home:$a(`ui/home.svg`),encyclopedia:$a(`ui/encyclopedia.svg`),settings:$a(`ui/settings.svg`),artifacts:$a(`ui/artifacts.svg`),shield:$a(`ui/shield-charge.svg`),pause:$a(`ui/pause.svg`),aetherium:$a(`ui/aetherium.svg`),adReward:$a(`ui/ad-reward.svg`)};function ro(e){return $a(`artifacts/${e}`)}function io(e){return eo[e]??``}function ao(e){return to[e]??``}function oo(e){return no[e]??``}var so={fire:{label:I(`status.fire`,{},`Burning`),duration:1.5,color:`#ff4f3e`,immunityResearchId:`fire-immunity`,requiresExposure:!0,refreshOnReapply:!1},poison:{label:I(`status.poison`,{},`Poisoned`),duration:3,color:`#91e85a`,immunityResearchId:`poison-immunity`,requiresExposure:!0,refreshOnReapply:!0}},co;(function(e){e.General=`General`,e.ParentalGuidance=`ParentalGuidance`,e.Teen=`Teen`,e.MatureAudience=`MatureAudience`})(co||={});var lo;(function(e){e.SizeChanged=`bannerAdSizeChanged`,e.Loaded=`bannerAdLoaded`,e.FailedToLoad=`bannerAdFailedToLoad`,e.Opened=`bannerAdOpened`,e.Closed=`bannerAdClosed`,e.AdImpression=`bannerAdImpression`,e.AdPaid=`bannerAdPaid`})(lo||={});var uo;(function(e){e.TOP_CENTER=`TOP_CENTER`,e.CENTER=`CENTER`,e.BOTTOM_CENTER=`BOTTOM_CENTER`})(uo||={});var fo;(function(e){e.BANNER=`BANNER`,e.FULL_BANNER=`FULL_BANNER`,e.LARGE_BANNER=`LARGE_BANNER`,e.MEDIUM_RECTANGLE=`MEDIUM_RECTANGLE`,e.LEADERBOARD=`LEADERBOARD`,e.ADAPTIVE_BANNER=`ADAPTIVE_BANNER`,e.SMART_BANNER=`SMART_BANNER`})(fo||={});var po;(function(e){e.Loaded=`interstitialAdLoaded`,e.FailedToLoad=`interstitialAdFailedToLoad`,e.Showed=`interstitialAdShowed`,e.FailedToShow=`interstitialAdFailedToShow`,e.Dismissed=`interstitialAdDismissed`,e.AdImpression=`interstitialAdImpression`})(po||={});var mo;(function(e){e.Loaded=`onRewardedInterstitialAdLoaded`,e.FailedToLoad=`onRewardedInterstitialAdFailedToLoad`,e.Showed=`onRewardedInterstitialAdShowed`,e.FailedToShow=`onRewardedInterstitialAdFailedToShow`,e.Dismissed=`onRewardedInterstitialAdDismissed`,e.Rewarded=`onRewardedInterstitialAdReward`,e.AdImpression=`onRewardedInterstitialAdImpression`})(mo||={});var ho;(function(e){e.Loaded=`onRewardedVideoAdLoaded`,e.FailedToLoad=`onRewardedVideoAdFailedToLoad`,e.Showed=`onRewardedVideoAdShowed`,e.FailedToShow=`onRewardedVideoAdFailedToShow`,e.Dismissed=`onRewardedVideoAdDismissed`,e.Rewarded=`onRewardedVideoAdReward`,e.AdImpression=`onRewardedVideoAdImpression`})(ho||={});var go;(function(e){e.NOT_REQUIRED=`NOT_REQUIRED`,e.OBTAINED=`OBTAINED`,e.REQUIRED=`REQUIRED`,e.UNKNOWN=`UNKNOWN`})(go||={});var _o;(function(e){e[e.DISABLED=0]=`DISABLED`,e[e.EEA=1]=`EEA`,e[e.NOT_EEA=2]=`NOT_EEA`,e[e.US=3]=`US`,e[e.OTHER=4]=`OTHER`})(_o||={});var vo;(function(e){e[e.Unknown=0]=`Unknown`,e[e.Estimated=1]=`Estimated`,e[e.PublisherProvided=2]=`PublisherProvided`,e[e.Precise=3]=`Precise`})(vo||={});var yo;(function(e){e.Loaded=`appOpenAdLoaded`,e.FailedToLoad=`appOpenAdFailedToLoad`,e.Opened=`appOpenAdOpened`,e.Closed=`appOpenAdClosed`,e.FailedToShow=`appOpenAdFailedToShow`,e.AdImpression=`appOpenAdImpression`})(yo||={});var bo=`modulepreload`,xo=function(e,t){return new URL(e,t).href},So={},Co=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=xo(t,n),t=s(t),t in So)return;So[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:bo,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},wo=vi(`AdMob`,{web:()=>Co(()=>import(`./web-DS9-TC-3.js`).then(e=>new e.AdMobWeb),[],import.meta.url)}),To=`ca-app-pub-3940256099942544/1033173712`,Eo=`ca-app-pub-3940256099942544/5224354917`,Do=!1,Oo=!1,ko=!1,Ao=!1,jo=!1;async function Mo(){if(!Do||!Oo||ko||Ao||jo)return!1;ko=!0;try{return await wo.prepareInterstitial({adId:To}),Ao=!0,!0}catch{return!1}finally{ko=!1}}async function No(){if(Do=_i.isNativePlatform()&&[`android`,`ios`].includes(_i.getPlatform()),!Do)return!1;try{await wo.initialize();let e=await wo.requestConsentInfo();return!e.canRequestAds&&e.isConsentFormAvailable&&(e=await wo.showConsentForm()),e.canRequestAds?(Oo=!0,Mo()):!1}catch{return!1}}async function Po(){if(!Do||!Oo||!Ao||jo)return!1;jo=!0,Ao=!1;try{return await wo.showInterstitial({adId:To}),!0}catch{return!1}finally{jo=!1,Mo()}}async function Fo({debug:e=!1}={}){if(!Do)return e;if(!Oo||jo)return!1;jo=!0;try{return await wo.prepareRewardVideoAd({adId:Eo}),!!await wo.showRewardVideoAd()}catch{return!1}finally{jo=!1}}var Io=`asteroid-belt-onboarding-progress`,Lo=Object.freeze([{id:`quick-start`,trigger:`launch`,shouldRun:({isSteamBuild:e})=>!e,run:async({startTutorialRun:e})=>e()},{id:`first-loss-guidance`,trigger:`first-loss`,shouldRun:({isSteamBuild:e})=>!e,run:async({startFirstLossGuidance:e})=>e()},{id:`sector-2-guidance`,trigger:`sector-2-unlocked`,shouldRun:({isSteamBuild:e})=>!e,run:async({startSecondSectorGuidance:e})=>e()},{id:`first-research-guidance`,trigger:`research-first-loss`,shouldRun:({isSteamBuild:e})=>!e,run:async({startFirstResearchGuidance:e})=>e()}]);function Ro(e){try{let t=JSON.parse(e.getItem(Io)??`null`);return{completed:new Set(Array.isArray(t?.completed)?t.completed.filter(e=>typeof e==`string`):[])}}catch{return{completed:new Set}}}function zo(e,t){try{e.setItem(Io,JSON.stringify({completed:[...t.completed]}))}catch{}}function Bo(e=window.localStorage){try{e.removeItem(Io)}catch{}}function Vo({isSteamBuild:e,startTutorialRun:t,startFirstLossGuidance:n,startSecondSectorGuidance:r,startFirstResearchGuidance:i,onStepStarted:a,onStepCompleted:o,storage:s=window.localStorage}){let c=Ro(s),l=null;return{async start(o=`launch`){if(l)return!1;for(let s of Lo)if(!(s.trigger!==o||c.completed.has(s.id)||!s.shouldRun({isSteamBuild:e})))return l=s,await s.run({startTutorialRun:t,startFirstLossGuidance:n,startSecondSectorGuidance:r,startFirstResearchGuidance:i}),a?.(s),!0;return!1},completeActiveStep(){if(!l)return!1;let e=l;return l=null,c.completed.add(e.id),zo(s,c),o?.(e),!0},isActiveStep(e){return l?.id===e}}}var Ho=!1,Uo=_i.isNativePlatform()&&_i.getPlatform()===`android`;No();function Wo(e,t){return`<span class="menu-button-icon" aria-hidden="true"><img data-menu-icon src="${oo(e)}" alt=""><span class="menu-icon-fallback" hidden>${t}</span></span>`}function Go({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button${e===`home-button`?` menu-home-button`:``}" id="${e}" type="button" aria-label="${r}" title="${r}">${Wo(t,n)}<span class="menu-button-label">${r}</span><span class="menu-button-lock" hidden></span></button>`}function Ko({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button menu-utility-button" id="${e}" type="button" aria-label="${r}" title="${r}">${Wo(t,n)}<span class="menu-button-label">${r}</span></button>`}var qo=oo(`shield`),Jo=oo(`pause`);document.querySelector(`#app`).innerHTML=`
  <main class="game-shell">
    <canvas id="game" aria-label="Asteroid Belt game canvas"></canvas>
    <header class="hud">
      <div class="hud-left">
        <div class="cash-balance"><span class="currency-label">CASH</span><span id="cash">$000</span></div>
        <div class="chronoshard-balance"><span class="currency-label">CHRONOSHARDS</span><span id="chronoshards">✦ 0</span></div>
        <div class="aetherium-balance"><span id="aetherium"><img src="${oo(`aetherium`)}" alt="Aetherium">0</span></div>
      </div>
      <div class="hud-sector" id="hud-sector" aria-label="Current difficulty sector"></div>
      <dl class="run-cell-counter"><div><dt>CELLS</dt><dd id="score">000</dd></div></dl>
      <button class="pause-button" id="pause-button" type="button" aria-label="Pause game"><img src="${Jo}" alt=""></button>
    </header>
    <div class="shield-indicators" id="shield-indicators" aria-label="Shield charges"></div>
    <div class="tower-health-hud hidden" id="tower-health-hud" role="status" aria-live="polite"><strong id="tower-health-label"></strong><div class="tower-health-track"><i id="tower-health-fill"></i></div></div>
    <div class="weapon-hud hidden" id="weapon-hud"></div>
    <aside class="instructions" aria-label="Game controls"><span class="controls-desktop"><span><b>MOVE</b> WASD</span><span><b>NAVIGATE</b> ↑↓</span><span><b>USE WEAPON</b> SPACE</span></span><span class="controls-mobile"><span><b>MOVE</b> JOYSTICK</span><span><b>SELECT / USE WEAPON</b> TAP A CARD</span></span></aside>
    <p class="onboarding-directive hidden" id="onboarding-directive" role="status"><span aria-hidden="true">↔</span>${I(`onboarding.drag_to_move`)}</p>
    <footer class="build-footer" aria-label="Build information">
      <span>v${$i.version}</span><span>BUILD ${$i.number}</span>
    </footer>
    <div class="virtual-joystick" id="virtual-joystick" aria-hidden="true">
      <div class="virtual-joystick-knob"></div>
    </div>
    <div class="cash-indicators" id="cash-indicators" aria-live="polite"></div>
    <button class="aetherium-ad-claim${Uo?``:` hidden`}" id="aetherium-ad-claim" type="button" aria-label="Watch an ad to claim 5 Aetherium"><img class="ad-badge" src="${oo(`adReward`)}" alt=""><span>CLAIM 5</span><img src="${oo(`aetherium`)}" alt="Aetherium"></button>
    <div class="build-grid-ui hidden" id="build-grid-ui" aria-label="Build locations"></div>
    <div class="milestone-claim-toast hidden" id="milestone-claim-toast" role="status" aria-live="polite"></div>
    <div class="feature-lock-toast hidden" id="feature-lock-toast" role="status" aria-live="polite"></div>
    <div class="artifact-unlock-toast hidden" id="artifact-unlock-toast" role="status" aria-live="polite"></div>
    <section class="pause-menu hidden" id="pause-menu" aria-label="Pause menu">
      <p class="eyebrow">ROUND PAUSED</p>
      <h2>PAUSE</h2>
      <div class="pause-actions">
        <button id="reset-round-button" type="button">RESET</button>
        <button id="surrender-button" type="button">SURRENDER</button>
        <button class="secondary-button" id="resume-game-button" type="button">RETURN</button>
        <button id="return-menu-button" type="button">MAIN MENU</button>
      </div>
    </section>
    <section class="cheat-console hidden" id="cheat-console" aria-label="Debug console">
      <header><strong>${Qi.title}</strong><button id="close-cheat-console" type="button" aria-label="Close debug console">×</button></header>
      <p id="cheat-output">Enter a command.</p>
      <label><span>›</span><input id="cheat-input" type="text" autocomplete="off" spellcheck="false" placeholder="cash 1000"></label>
    </section>
    <section class="overlay" id="overlay" aria-live="polite">
      
      <div class="menu-content" id="menu-content">
        <div class="death-killer-heading">
          <h1 id="overlay-title">ASTEROID BELT</h1>
          <div class="death-killer-preview" id="death-killer-preview" hidden>
            <canvas id="death-killer-canvas" aria-label="Defeating enemy 3D model"></canvas>
          </div>
        </div>
        <p id="overlay-copy"></p>
        <p class="game-over-tip" id="game-over-tip" hidden></p>
        <div class="sector-selection" aria-label="Difficulty sector selection">
          <div class="sector-heading">Difficulty</div>
          <div class="sector-carousel">
            <button class="sector-nav" id="previous-sector" type="button" aria-label="Select previous sector">‹</button>
            <span class="sector-options" id="sector-options" aria-live="polite"></span>
            <button class="sector-nav" id="next-sector" type="button" aria-label="Select next sector">›</button>
          </div>
          <p class="highest-cell">HIGHEST CELL: <span id="highest-cells">000</span></p>
          <p class="sector-requirement" id="sector-requirement"></p>
          <button class="milestone-button" id="open-milestones-button" type="button">VIEW ASCENSION <span class="milestone-claim-count" id="milestone-claim-count" hidden>0</span></button>
        </div>
      </div>
      <div class="menu-actions">
          <button class="menu-start-button" id="start-button" type="button">START RUN</button>
          <button class="menu-start-button anomaly-run-button" id="anomaly-run-button" type="button">ANOMALY RUN</button>
          ${Go({id:`home-button`,iconId:`home`,fallback:`H`,label:I(`menu.home`)})}
          ${Go({id:`open-lab-button`,iconId:`researchLab`,fallback:`RL`,label:I(`menu.research_lab`)})}
          ${Go({id:`open-weaponry-button`,iconId:`weaponry`,fallback:`W`,label:I(`menu.weaponry`)})}
          ${Go({id:`open-building-button`,iconId:`buildingSystem`,fallback:`BS`,label:I(`menu.buildings`)})}
          ${Ko({id:`open-encyclopedia-button`,iconId:`encyclopedia`,fallback:`E`,label:I(`menu.encyclopedia`)})}
          ${Ko({id:`open-settings-button`,iconId:`settings`,fallback:`S`,label:I(`menu.settings`)})}
          ${Ko({id:`open-artifacts-button`,iconId:`artifacts`,fallback:`A`,label:I(`menu.artifacts`)})}
          
      </div>
      <section class="milestones-panel hidden" id="milestones-panel" aria-label="Ascension">
        <div class="milestones-header"><div><p class="eyebrow">BEST SINGLE RUN</p><h2>ASCENSION</h2><p>MAX CELLS <strong id="milestone-max-cells">000</strong></p></div><button class="secondary-button" id="close-milestones-button" type="button">BACK</button></div>
        <div class="milestone-sector-nav"><button id="previous-milestone-sector" type="button" aria-label="View previous milestone sector">‹</button><strong id="milestone-sector-label">SECTOR I</strong><button id="next-milestone-sector" type="button" aria-label="View next milestone sector">›</button></div>
        <div class="milestone-track" id="milestone-track"></div>
      </section>
      <section class="lab-panel hidden" id="lab-panel" aria-label="Research Lab">
        <div class="lab-header"><div><p class="eyebrow">PERMANENT UPGRADES</p><h2>RESEARCH LAB</h2></div><button class="secondary-button" id="close-lab-button" type="button">BACK</button></div>
        <p class="lab-balance">CASH <span id="lab-cash">$0</span><span id="lab-chronoshard-balance"> · CHRONOSHARDS <span id="lab-chronoshards">✦ 0</span></span></p>
        <p class="lab-message" id="lab-message" aria-live="polite"></p>
        <h3 id="research-slots-heading">ACTIVE SLOTS</h3><div class="research-slots" id="research-slots"></div>
        <h3>AVAILABLE RESEARCH</h3><label class="research-search"><span>SEARCH</span><input id="research-search" type="search" placeholder="Search research names" autocomplete="off"></label><div class="research-filters"><label><input id="hide-completed-researches" type="checkbox"> <span>Hide Completed Researches</span></label><label><input id="hide-locked-researches" type="checkbox"> <span>Hide Locked Researches</span></label></div><div class="research-list" id="research-list"></div>
      </section>
      <section class="encyclopedia-panel hidden" id="encyclopedia-panel" aria-label="Encyclopedia"><div class="lab-header"><div><p class="eyebrow">THREAT DATABASE</p><h2>ENCYCLOPEDIA</h2></div><button class="secondary-button" id="close-encyclopedia-button" type="button">BACK</button></div><div class="encyclopedia-list" id="encyclopedia-list"></div></section>
      <section class="artifact-panel hidden" id="artifact-panel" aria-label="Artifacts"><div class="lab-header"><div><p class="eyebrow">PERMANENT ACHIEVEMENTS</p><h2>ARTIFACTS</h2></div><button class="secondary-button" id="close-artifacts-button" type="button">BACK</button></div><p class="artifact-intro">Artifacts are permanent rewards earned by reaching achievement goals.</p><div class="artifact-grid" id="artifact-grid"></div></section>
      <section class="artifact-detail-modal hidden" id="artifact-detail-modal" aria-label="Artifact detail"><div id="artifact-detail-content"></div><button class="secondary-button" id="close-artifact-detail-button" type="button">BACK</button></section>
      <section class="building-panel hidden" id="building-panel"><div class="lab-header"><div><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING SYSTEM</h2></div><button class="secondary-button" id="close-building-button" type="button">BACK</button></div><p class="lab-balance">CASH <span id="building-cash"></span> · CHRONOSHARDS <span id="building-chronoshards"></span> · SLOTS <span id="building-slots"></span></p><div class="building-actions"><button id="enter-build-mode" type="button">BUILD MODE</button><button id="open-building-draft" type="button">UNLOCK A BUILDING</button></div><h3>UNLOCKED BUILDINGS</h3><div class="building-list" id="building-list"></div></section>
      <section class="building-draft-modal hidden" id="building-draft-modal" aria-label="Building Draft"><button class="upgrade-close" id="close-building-draft" type="button" aria-label="Close building draft">×</button><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING DRAFT</h2><p class="building-draft-balance">CHRONOSHARDS <span id="building-draft-chronoshards"></span></p><div class="building-list" id="building-draft-list"></div></section>
      <section class="weaponry-panel hidden" id="weaponry-panel" aria-label="Weaponry"><div class="lab-header"><div><p class="eyebrow">ACTIVE ARSENAL</p><h2>WEAPONRY</h2></div><button class="secondary-button" id="close-weaponry-button" type="button">BACK</button></div><p class="lab-balance">CHRONOSHARDS <span id="weaponry-chronoshards"></span></p><div class="weapon-buy-actions"><button class="weapon-buy-button" id="buy-weapon-button" type="button">BUY WEAPON · ✦ 35</button><button class="weapon-buy-button" id="buy-weapons-five-button" type="button">BUY WEAPON x5 · ✦ 175</button></div><p class="weapon-lucky-find-chance" id="weapon-lucky-find-chance" hidden>LUCKY FIND · 0% · 2 CARDS</p><h3>ROUND LOADOUT <span id="weapon-slot-count"></span></h3><div class="weapon-loadout" id="weapon-loadout"></div><h3>WEAPON CARDS</h3><div class="weapon-card-list" id="weapon-card-list"></div></section>
      <section class="weapon-reveal-modal hidden" id="weapon-reveal-modal" aria-label="Weapon purchase result" aria-live="polite"><div class="weapon-reveal-card"><p class="eyebrow" id="weapon-reveal-count"></p><p class="weapon-lucky-find-badge" aria-hidden="true">✦ LUCKY FIND · DOUBLE CARD ✦</p><p class="weapon-reveal-status" id="weapon-reveal-status"></p><img class="asset-card-art" id="weapon-reveal-art" alt=""><h2 id="weapon-reveal-name"></h2><p id="weapon-reveal-detail"></p><button id="weapon-reveal-continue" type="button">CLAIM</button></div></section>
      <section class="settings-panel hidden" id="settings-panel" aria-label="Settings"><div class="lab-header"><div><p class="eyebrow">PREFERENCES</p><h2>SETTINGS</h2></div><button class="secondary-button" id="close-settings-button" type="button">BACK</button></div><div class="settings-section"><h3>GRAPHICS</h3><div class="settings-row"><div><strong>Quality</strong><small>Changes render resolution and shadows.</small></div><div class="settings-options" id="graphics-quality-options"></div></div><label class="settings-row settings-toggle"><span><strong>Shadows</strong><small>Show dynamic object shadows.</small></span><input id="setting-shadows" type="checkbox"></label><label class="settings-row"><span><strong>HDR Emission</strong><small>Controls how far bright effects bloom beyond their models.</small></span><output id="hdr-emission-value"></output><input id="setting-hdr-emission" type="range" min="0" max="100" step="1"></label><label class="settings-row"><span><strong>Maximum FPS</strong><small>Limits rendering and simulation to reduce hardware load.</small></span><output id="max-fps-value"></output><input id="setting-max-fps" type="range" min="0" max="240" step="30"></label></div><div class="settings-section"><h3>GAMEPLAY</h3><label class="settings-row settings-toggle"><span><strong>Auto Pause</strong><small>Pause the run when the game loses focus.</small></span><input id="setting-auto-pause" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>High Contrast HUD</strong><small>Improves HUD readability.</small></span><input id="setting-high-contrast" type="checkbox"></label></div><div class="settings-section"><h3>SOUND</h3><label class="settings-row"><span><strong>Master Volume</strong><small>Controls all game sound effects.</small></span><output id="master-volume-value"></output><input id="setting-master-volume" type="range" min="0" max="100" step="1"></label><label class="settings-row settings-toggle"><span><strong>Mute All</strong><small>Instantly silence all sound effects.</small></span><input id="setting-muted" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>Spatial Audio</strong><small>Pan sounds based on their world position.</small></span><input id="setting-spatial-audio" type="checkbox"></label></div><div class="settings-section settings-actions"><button id="open-patch-notes-button" type="button">PATCH NOTES</button></div></section>
      <section class="patch-notes-panel hidden" id="patch-notes-panel" aria-label="Patch notes"><div class="lab-header"><div><p class="eyebrow">VERSION ${$i.version} · BUILD ${$i.number}</p><h2>PATCH NOTES</h2></div><button class="secondary-button" id="close-patch-notes-button" type="button">BACK</button></div>${Ia.map(e=>`<article class="patch-notes-entry"><h3>${e.heading}</h3><ul>${e.changes.map(e=>`<li>${e}</li>`).join(``)}</ul></article>`).join(``)}</section>
    </section>
    <section class="anomaly-run-modal hidden" id="anomaly-run-modal" aria-label="Anomaly Run challenge"><div class="anomaly-run-card"><p class="eyebrow">WEEKLY ANOMALY</p><h2 id="anomaly-challenge-name"></h2><p id="anomaly-challenge-description"></p><p class="anomaly-reward" id="anomaly-reward"></p><p class="anomaly-reset" id="anomaly-reset"></p><p class="anomaly-time-warning hidden" id="anomaly-time-warning" role="alert"></p><div><button class="secondary-button" id="cancel-anomaly-run" type="button">BACK</button><button id="confirm-anomaly-run" type="button">START ANOMALY RUN</button></div></div></section>
    <div class="build-bar hidden" id="build-bar"><span id="build-status">SELECT A BUILDING</span><div id="build-options"></div><button id="exit-build-mode" type="button">DONE</button></div>
    <section class="building-upgrade hidden" id="building-upgrade"></section>
  </main>
`;var Yo=document.querySelector(`#game`);for(let e of document.querySelectorAll(`[data-menu-icon]`))e.addEventListener(`error`,()=>{e.hidden=!0;let t=e.nextElementSibling;t&&(t.hidden=!1)});var Xo=document.querySelector(`#score`),Zo=document.querySelector(`#hud-sector`),Qo=document.querySelector(`#shield-indicators`),$o=document.querySelector(`#tower-health-hud`),es=document.querySelector(`#tower-health-label`),ts=document.querySelector(`#tower-health-fill`),ns=document.querySelector(`#pause-button`),rs=document.querySelector(`#overlay`),is=document.querySelector(`#save-slot-select`),as=document.querySelector(`#save-slot-grid`),os=document.querySelector(`#overlay-title`),ss=document.querySelector(`#death-killer-preview`),cs=document.querySelector(`#death-killer-canvas`),ls=document.querySelector(`#overlay-copy`),us=document.querySelector(`#game-over-tip`),ds=document.querySelector(`#start-button`),fs=document.querySelector(`#anomaly-run-button`),ps=document.querySelector(`#anomaly-run-modal`),ms=document.querySelector(`#anomaly-challenge-name`),hs=document.querySelector(`#anomaly-challenge-description`),gs=document.querySelector(`#anomaly-reward`),_s=document.querySelector(`#anomaly-reset`),vs=document.querySelector(`#anomaly-time-warning`),ys=document.querySelector(`#confirm-anomaly-run`),bs=document.querySelector(`#cancel-anomaly-run`),xs=document.querySelector(`#menu-content`),Ss=document.querySelector(`#open-milestones-button`),Cs=document.querySelector(`#milestones-panel`),ws=document.querySelector(`#close-milestones-button`),Ts=document.querySelector(`#milestone-max-cells`),Es=document.querySelector(`#milestone-track`),Ds=document.querySelector(`#milestone-claim-count`),Os=document.querySelector(`#milestone-claim-toast`),ks=document.querySelector(`#feature-lock-toast`),As=document.querySelector(`#artifact-unlock-toast`),js=document.querySelector(`#previous-milestone-sector`),Ms=document.querySelector(`#next-milestone-sector`),Ns=document.querySelector(`#milestone-sector-label`),Ps=document.querySelector(`#lab-panel`),Fs=document.querySelector(`#open-lab-button`),Is=document.querySelector(`#home-button`),Ls=document.querySelector(`#open-building-button`),Rs=document.querySelector(`#open-weaponry-button`),zs=document.querySelector(`#open-encyclopedia-button`),Bs=document.querySelector(`#encyclopedia-panel`),Vs=document.querySelector(`#close-encyclopedia-button`),Hs=document.querySelector(`#encyclopedia-list`),Us=document.querySelector(`#open-artifacts-button`),Ws=document.querySelector(`#artifact-panel`),Gs=document.querySelector(`#close-artifacts-button`),Ks=document.querySelector(`#artifact-grid`),qs=document.querySelector(`#artifact-detail-modal`),Js=document.querySelector(`#artifact-detail-content`),Ys=document.querySelector(`#close-artifact-detail-button`),Xs=document.querySelector(`#weaponry-panel`),Zs=document.querySelector(`#close-weaponry-button`),Qs=document.querySelector(`#weaponry-chronoshards`),$s=document.querySelector(`#buy-weapon-button`),ec=document.querySelector(`#buy-weapons-five-button`),tc=document.querySelector(`#weapon-lucky-find-chance`),nc=document.querySelector(`#weapon-reveal-modal`),rc=document.querySelector(`#weapon-reveal-count`),ic=document.querySelector(`#weapon-reveal-status`),ac=document.querySelector(`#weapon-reveal-art`),oc=document.querySelector(`#weapon-reveal-name`),sc=document.querySelector(`#weapon-reveal-detail`),cc=document.querySelector(`#weapon-reveal-continue`),lc=document.querySelector(`#weapon-slot-count`),uc=document.querySelector(`#weapon-loadout`),dc=document.querySelector(`#weapon-card-list`),fc=document.querySelector(`#weapon-hud`),pc=document.querySelector(`#open-settings-button`),mc=document.querySelector(`#exit-game-button`),hc=document.querySelector(`#settings-panel`),gc=document.createElement(`div`);gc.className=`settings-section`,gc.innerHTML=`<h3>${I(`settings.language`)}</h3><div class="settings-row"><div><strong>${I(`settings.language`)}</strong><small>${I(`settings.language_help`)}</small></div><select id="language-select" class="language-select" aria-label="${I(`settings.language`)}"></select></div>`,hc.querySelector(`.lab-header`)?.after(gc);var _c=document.querySelector(`#language-select`),vc=document.querySelector(`#display-mode-options`),yc=document.querySelector(`#display-resolution-options`),bc=document.querySelector(`#close-settings-button`),xc=document.querySelector(`#open-patch-notes-button`),Sc=document.querySelector(`#patch-notes-panel`),Cc=document.querySelector(`#close-patch-notes-button`),wc=document.querySelector(`#graphics-quality-options`),Tc=document.querySelector(`#setting-shadows`),Ec=document.querySelector(`#setting-hdr-emission`),Dc=document.querySelector(`#hdr-emission-value`),Oc=document.querySelector(`#setting-max-fps`),kc=document.querySelector(`#max-fps-value`),Ac=document.querySelector(`#setting-auto-pause`),jc=document.querySelector(`#setting-high-contrast`),Mc=document.querySelector(`#setting-master-volume`),Nc=document.querySelector(`#master-volume-value`),Pc=document.querySelector(`#setting-muted`),Fc=document.querySelector(`#setting-spatial-audio`),Ic=document.querySelector(`#building-panel`),Lc=document.querySelector(`#close-building-button`),Rc=document.querySelector(`#building-list`),zc=document.querySelector(`#building-cash`),Bc=document.querySelector(`#building-chronoshards`),Vc=document.querySelector(`#building-slots`),Hc=document.querySelector(`#enter-build-mode`),Uc=document.querySelector(`#open-building-draft`),Wc=document.querySelector(`#building-draft-modal`),Gc=document.querySelector(`#close-building-draft`),Kc=document.querySelector(`#building-draft-chronoshards`),qc=document.querySelector(`#building-draft-list`),Jc=document.querySelector(`#build-bar`),Yc=document.querySelector(`#build-status`),Xc=document.querySelector(`#build-options`),Zc=document.querySelector(`#build-grid-ui`),Qc=document.querySelector(`#exit-build-mode`),$c=document.querySelector(`#building-upgrade`),el=document.querySelector(`#close-lab-button`),tl=document.querySelector(`#lab-cash`),nl=document.querySelector(`#lab-chronoshard-balance`),rl=document.querySelector(`#lab-chronoshards`),il=document.querySelector(`#lab-message`);function al(){let e=(e,t)=>{let n=document.querySelector(e);n&&(n.textContent=I(t))};e(`.cash-balance .currency-label`,`hud.cash`),e(`.chronoshard-balance .currency-label`,`hud.chronoshards`),e(`.run-cell-counter dt`,`hud.cells`),e(`#pause-menu .eyebrow`,`menu.round_paused`),e(`#pause-menu h2`,`menu.pause`),e(`#reset-round-button`,`menu.reset`),e(`#surrender-button`,`menu.surrender`),e(`#resume-game-button`,`menu.return`),e(`#return-menu-button`,`menu.main_menu`),e(`#start-button`,`menu.start_run`),e(`#anomaly-run-button`,`anomaly.run`),e(`#cancel-anomaly-run`,`menu.back`),e(`#confirm-anomaly-run`,`anomaly.start`),e(`#close-settings-button`,`menu.back`),e(`#open-patch-notes-button`,`settings.patch_notes`),e(`#close-milestones-button`,`menu.back`),e(`#close-lab-button`,`menu.back`),e(`#close-encyclopedia-button`,`menu.back`),e(`#encyclopedia-panel .eyebrow`,`encyclopedia.threat_database`),e(`#encyclopedia-panel h2`,`menu.encyclopedia`),e(`#close-artifacts-button`,`menu.back`),e(`#close-artifact-detail-button`,`menu.back`),e(`#close-building-button`,`menu.back`),e(`#close-weaponry-button`,`menu.back`),e(`#close-patch-notes-button`,`menu.back`),e(`#patch-notes-panel h2`,`menu.patch_notes`);let t=document.querySelector(`#patch-notes-panel .eyebrow`);t&&(t.textContent=I(`patch_notes.version_build`,{version:$i.version,build:$i.number})),e(`#research-slots-heading`,`research.active_slots`),e(`#lab-panel h3:not(#research-slots-heading)`,`research.available_research`),e(`.research-search > span`,`research.search`);let n=document.querySelector(`#research-search`);n&&(n.placeholder=I(`research.search_placeholder`)),e(`#hide-completed-researches + span`,`research.hide_completed`),e(`#hide-locked-researches + span`,`research.hide_locked`),e(`#artifact-panel .eyebrow`,`artifact.permanent_achievements`),e(`#artifact-panel .artifact-intro`,`artifact.intro`),e(`#building-panel .eyebrow`,`building.permanent_defenses`),e(`#building-panel h2`,`building.system`),e(`#enter-build-mode`,`building.build_mode`),e(`#open-building-draft`,`building.unlock_a_building`),e(`#building-panel h3`,`building.unlocked_buildings`),e(`#building-draft-modal .eyebrow`,`building.permanent_defenses`),e(`#building-draft-modal h2`,`building.draft`),e(`#weaponry-panel .eyebrow`,`weapon.active_arsenal`),e(`#weaponry-panel h2`,`menu.weaponry`);let r=document.querySelectorAll(`#weaponry-panel h3`);r[0]&&(r[0].childNodes[0].textContent=`${I(`weapon.round_loadout`)} `),r[1]&&(r[1].textContent=I(`weapon.cards`)),e(`.controls-desktop span:nth-child(1) b`,`controls.move`),e(`.controls-desktop span:nth-child(2) b`,`controls.navigate`),e(`.controls-desktop span:nth-child(3) b`,`controls.use_weapon`),e(`.controls-mobile span:nth-child(1) b`,`controls.move`),e(`.controls-mobile span:nth-child(2) b`,`controls.select_weapon`);let i=(e,t)=>{let n=document.querySelector(e);n&&n.setAttribute(`aria-label`,I(t))};i(`#game`,`accessibility.game_canvas`),i(`#hud-sector`,`accessibility.current_sector`),i(`#pause-button`,`accessibility.pause_game`),i(`#shield-indicators`,`accessibility.shield_charges`),i(`.instructions`,`accessibility.game_controls`),i(`.build-footer`,`accessibility.build_information`),i(`#build-grid-ui`,`accessibility.build_locations`),i(`#pause-menu`,`accessibility.pause_menu`),i(`#cheat-console`,`accessibility.debug_console`),i(`#close-cheat-console`,`accessibility.close_debug_console`),i(`#save-slot-select`,`accessibility.save_slots`),i(`#death-killer-canvas`,`accessibility.defeating_enemy`),i(`.sector-selection`,`accessibility.sector_selection`),i(`#previous-sector`,`accessibility.previous_sector`),i(`#next-sector`,`accessibility.next_sector`),i(`#previous-milestone-sector`,`accessibility.previous_milestone_sector`),i(`#next-milestone-sector`,`accessibility.next_milestone_sector`);let a=document.querySelector(`#cheat-output`);a&&(a.textContent=I(`cheat.prompt`));let o=document.querySelector(`#cheat-input`);o&&(o.placeholder=I(`cheat.placeholder`)),[[`#graphics-quality-options`,`settings.graphics`],[`#setting-max-fps`,`settings.graphics`],[`#setting-master-volume`,`settings.sound`]].forEach(([e,t])=>{let n=document.querySelector(e)?.closest(`.settings-section`);n&&(n.querySelector(`h3`).textContent=I(t))}),[[`#graphics-quality-options`,`settings.quality`,`settings.quality_help`],[`#setting-shadows`,`settings.shadows`,`settings.shadows_help`],[`#setting-hdr-emission`,`settings.hdr_emission`,`settings.hdr_emission_help`],[`#setting-max-fps`,`settings.max_fps`,`settings.max_fps_help`],[`#setting-auto-pause`,`settings.auto_pause`,`settings.auto_pause_help`],[`#setting-high-contrast`,`settings.high_contrast_hud`,`settings.high_contrast_hud_help`],[`#setting-master-volume`,`settings.master_volume`,`settings.master_volume_help`],[`#setting-muted`,`settings.mute_all`,`settings.mute_all_help`],[`#setting-spatial-audio`,`settings.spatial_audio`,`settings.spatial_audio_help`]].forEach(([e,t,n])=>{let r=document.querySelector(e)?.closest(`.settings-row`);if(!r)return;let i=r.querySelector(`strong`),a=r.querySelector(`small`);i&&(i.textContent=I(t)),a&&(a.textContent=I(n))})}al();var ol=document.querySelector(`#research-slots`),sl=document.querySelector(`#research-slots-heading`),cl=document.querySelector(`#research-list`),ll=document.querySelector(`#research-search`),ul=document.querySelector(`#hide-completed-researches`),dl=document.querySelector(`#hide-locked-researches`),fl=document.querySelector(`#cheat-console`),pl=document.querySelector(`#cheat-input`),ml=document.querySelector(`#cheat-output`),hl=document.querySelector(`#close-cheat-console`),gl=document.querySelector(`#pause-menu`),_l=document.querySelector(`#reset-round-button`),vl=document.querySelector(`#surrender-button`),yl=document.querySelector(`#resume-game-button`),bl=document.querySelector(`#return-menu-button`),xl=document.querySelector(`#cash`),Sl=document.querySelector(`#chronoshards`),Cl=document.querySelector(`#aetherium`),wl=document.querySelector(`#aetherium-ad-claim`),Tl=document.querySelector(`#cash-indicators`),El=document.querySelector(`#highest-cells`),Dl=document.querySelector(`#sector-requirement`),Ol=document.querySelector(`#sector-options`),kl=document.querySelector(`#previous-sector`),Al=document.querySelector(`#next-sector`),jl=document.querySelector(`#virtual-joystick`),Ml=document.querySelector(`#onboarding-directive`),Nl=null,Pl=null,Fl=null,Il=null,Ll=new Map;function Rl(){Ml.classList.remove(`hidden`),requestAnimationFrame(()=>Ml.classList.add(`is-visible`))}function zl(){Ml.classList.remove(`is-visible`),window.setTimeout(()=>Ml.classList.add(`hidden`),260)}function Bl(){document.querySelectorAll(`.onboarding-highlight`).forEach(e=>e.classList.remove(`onboarding-highlight`));for(let[e,t]of Ll)e.disabled=t,e.classList.remove(`onboarding-disabled`);Ll.clear()}function Vl(e){e&&e.classList.add(`onboarding-highlight`)}function Hl(){return Ga.filter(e=>!H.claimed.includes(e.id)&&(Ou[vu[e.sector-1]]??0)>=e.cells).map(e=>e.id)}function Ul(){let e=Pl??Fl??Il;if(!e)return;let t=t=>e.mode===`run-again`||e.mode===`start-run`?t===ds:e.mode===`next-sector`?t===Al:e.mode===`research-entry`?t===Fs:e.mode===`research-category`?t.matches(`[data-toggle-research-category="Player Enhancements"]`):e.mode===`research-upgrade`?t.matches(`[data-start-research="player-speed-multiplier"]`):e.mode===`ascension-entry`?t===Ss:t.matches(`[data-claim-milestone]`);document.querySelectorAll(`button`).forEach(e=>{t(e)||(Ll.has(e)||Ll.set(e,e.disabled),e.disabled=!0,e.classList.add(`onboarding-disabled`))})}function Wl(){if(Pl?.mode!==`ascension-claims`)return;Bl();let e=[...Es.querySelectorAll(`[data-claim-milestone]`)];e.forEach(e=>e.classList.add(`onboarding-highlight`)),Vl(e[0]),Ul()}function Gl(){let e=Hl();Pl=e.length>0?{mode:`ascension-entry`,claimableMilestoneIds:e}:{mode:`run-again`},Bl(),Vl(Pl.mode===`run-again`?ds:Ss),Ul()}function Kl(){Pl=null,Bl(),Nl?.completeActiveStep(),Tu()>=1&&(Cs.classList.add(`hidden`),xs.classList.remove(`hidden`),Nl?.start(`sector-2-unlocked`))}function ql(){Fl={mode:`next-sector`},Bl(),Al.disabled=!1,Vl(Al),Ul()}function Jl(){Fl=null,Bl(),Nl?.completeActiveStep()}function Yl(){Il={mode:`research-entry`},Bl(),Vl(Fs),Ul()}function Xl(e,t){Il&&(Il.mode=e,Bl(),Vl(t),Ul())}function Zl(){Il=null,Bl(),Ps.classList.add(`hidden`),xs.classList.remove(`hidden`),z_(),Nl?.completeActiveStep()}document.addEventListener(`click`,e=>{let t=Pl??Fl??Il;if(!t)return;let n=e.target.closest(`button`);(t.mode===`run-again`||t.mode===`start-run`?n===ds:t.mode===`next-sector`?n===Al:t.mode===`research-entry`?n===Fs:t.mode===`research-category`?n?.matches(`[data-toggle-research-category="Player Enhancements"]`):t.mode===`research-upgrade`?n?.matches(`[data-start-research="player-speed-multiplier"]`):t.mode===`ascension-entry`?n===Ss:n?.matches(`[data-claim-milestone]`))||(e.preventDefault(),e.stopImmediatePropagation())},!0);var Ql=``;function $l(){let e=Va.filter(e=>e!==Ql),t=e[Math.floor(Math.random()*e.length)]??Va[0];return Ql=t,t}var eu=`asteroid-belt-active-save-slot`,tu=`asteroid-belt-save-slot-session`,nu=3;Ea();var{cellBank:ru,sector:iu,sectorHighScores:au,cash:ou,chronoshards:su,aetherium:cu,researchLab:lu,savedRound:uu,buildings:du,featureUnlocks:fu,milestones:pu,settings:mu,weaponry:hu,anomalyRewards:gu,artifacts:_u}=xa,vu=Object.keys(ji);function yu(){let e=ka(uu);return e&&typeof e==`object`?e:null}function bu(e){Aa(uu,e)}function xu(){let e=ka(au,{});return!e||typeof e!=`object`?{}:Object.fromEntries(vu.map(t=>[t,Number.isFinite(e[t])&&e[t]>=0?e[t]:0]))}function Su(){Aa(au,Ou)}function Cu(){try{let e=JSON.parse(window.localStorage.getItem(pu));return!e||typeof e!=`object`?{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}:{version:Number(e.version)||0,claimed:Array.isArray(e.claimed)?e.claimed.filter(e=>Ga.some(t=>t.id===e)):[],researchUnlocks:Array.isArray(e.researchUnlocks)?e.researchUnlocks.filter(e=>Ga.some(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))):[],debugAscensionsGranted:!!e.debugAscensionsGranted}}catch{return{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}}}function wu(){Aa(pu,H)}function Tu(){return Ga.filter(e=>H.claimed.includes(e.id)).flatMap(e=>e.rewards.filter(e=>e.type===`sector`).map(e=>e.sector-1)).reduce((e,t)=>Math.max(e,t),0)}function Eu(e){return Tu()+1>=e}var Du=Da(ru),Ou=xu(),V=(()=>{let e=ka(_u,{}),t=new Set(Ya.artifacts.map(e=>e.id));return{unlocked:Array.isArray(e?.unlocked)?e.unlocked.filter(e=>t.has(e)):[],resetAtScores:e?.resetAtScores&&typeof e.resetAtScores==`object`?e.resetAtScores:{},stackCounts:e?.stackCounts&&typeof e.stackCounts==`object`?e.stackCounts:null}})(),H=Cu();H.version!==3&&(H.claimed=Ga.filter(e=>(Ou[vu[e.sector-1]]??0)>=e.cells).map(e=>e.id),H.version=3,wu());var U=Math.min(Da(iu),Tu()),ku=U,Au=Da(ou),ju=Da(su),Mu=Da(cu),W=yu(),Nu=null,Pu=(()=>{let e=ka(gu,{}),t=e&&typeof e.claimedSectors==`object`?e.claimedSectors:{},n=Object.entries(t).flatMap(([e,t])=>(Array.isArray(t)?t:[]).map(t=>`${ta.challenges[Number(e)%ta.challenges.length]?.id??`cell-scout`}:sector${Number(t)+1}`));return{claimedSectors:t,darkCoreClaims:Array.isArray(e?.darkCoreClaims)?e.darkCoreClaims:[...new Set(n)]}})();if(!V.stackCounts){let e=Object.values(Pu.claimedSectors).reduce((e,t)=>e+(Array.isArray(t)?new Set(t).size:0),0);V.stackCounts={"dark-core":e},e>0&&!V.unlocked.includes(`dark-core`)&&V.unlocked.push(`dark-core`),Aa(_u,V)}var Fu=null,Iu=!1,Lu=0;function Ru(){return ta.challenges.find(e=>e.id===Fu?.challengeId)??null}function zu(){return Ru()?.type===`tower-defense`}var Bu=(()=>{try{let e=JSON.parse(localStorage.getItem(fu));return{researchLab:!!e?.researchLab,buildingSystem:!!e?.buildingSystem,weaponry:!!e?.weaponry}}catch{return{researchLab:!1,buildingSystem:!1,weaponry:!1}}})();H.claimed.includes(`sector-1-10`)&&!Bu.researchLab&&(Bu.researchLab=!0,Od());var G=(()=>{try{let e=JSON.parse(localStorage.getItem(hu));return{cards:e?.cards??{},loadout:Array.isArray(e?.loadout)?e.loadout:[],selected:e?.selected??0}}catch{return{cards:{},loadout:[],selected:0}}})(),Vu=[],Hu=0,K=(()=>{try{let e=JSON.parse(localStorage.getItem(du));return e?.unlocked?e:{unlocked:[],placed:[]}}catch{return{unlocked:[],placed:[]}}})(),Uu=K.placed.filter(e=>e.type===`gapGenerator`);if(Uu.length){Au+=Uu.reduce((e,t)=>e+(t.spent??260),0),K.placed=K.placed.filter(e=>e.type!==`gapGenerator`),K.unlocked=K.unlocked.filter(e=>e!==`gapGenerator`);try{localStorage.setItem(ou,String(Au)),localStorage.setItem(du,JSON.stringify(K))}catch{}}function Wu(){let e={language:Wi(),graphics:{quality:`high`,shadows:!0,hdrEmissionIntensity:.5},gameplay:{maxFps:120,autoPause:!0,highContrastHud:!1},sound:{masterVolume:100,muted:!1,spatialAudio:!0}};try{let t=JSON.parse(localStorage.getItem(mu)),n=t?.graphics??{},r=t?.gameplay??{},i=Number.isFinite(n.hdrEmissionIntensity)?C.clamp(n.hdrEmissionIntensity,0,1):n.hdrEmission===!1?0:.5,a=Number.isFinite(r.maxFps)?C.clamp(r.maxFps,0,240):e.gameplay.maxFps;return{language:Ji().includes(t?.language)?t.language:e.language,graphics:{...e.graphics,...n,hdrEmissionIntensity:i},gameplay:{...e.gameplay,...r,maxFps:a},sound:{...e.sound,...t?.sound}}}catch{return e}}var q=Wu();qi(q.language);function Gu(){Aa(mu,q)}var Ku=Object.keys(ca.types);K.unlocked=[...new Set(K.unlocked.filter(e=>Ku.includes(e)))],K.placed=K.placed.filter(e=>Ku.includes(e.type)),K.unlockCount=Number.isFinite(K.unlockCount)?K.unlockCount:K.unlocked.length,K.unlockOffers=Array.isArray(K.unlockOffers)?K.unlockOffers.filter(e=>Ku.includes(e)&&!K.unlocked.includes(e)):[];var qu=new Map,Ju=new Map,Yu=!1,Xu=null,Zu=``,Qu=!1,$u=!1,ed=new Set;function td(){return{unlockedSlots:1,levels:{},slots:Array(Zi.maxSlots).fill(null)}}function nd(){try{let e=JSON.parse(window.localStorage.getItem(lu));return!e||typeof e!=`object`?td():{unlockedSlots:C.clamp(Number.parseInt(e.unlockedSlots,10)||1,1,Zi.maxSlots),levels:e.levels&&typeof e.levels==`object`?e.levels:{},slots:Array.from({length:Zi.maxSlots},(t,n)=>e.slots?.[n]??null)}}catch{return td()}}var rd=nd(),id=!1;function ad(){Aa(lu,rd)}var{getResearchById:od,getResearchLevel:sd,getResearchStatBonus:cd,getResearchCost:ld,getResearchDuration:ud,getResearchLockReason:dd,isResearchVisible:fd,compareResearchProgression:pd}=Pa({config:Zi,milestones:Ga,getResearchState:()=>rd,getMilestoneState:()=>H,getBankedCells:()=>Du});function md(e){return Ya.artifacts.filter(t=>V.unlocked.includes(t.id)&&t.buff.stat===e).reduce((e,t)=>e+t.buff.amount*hd(t),0)}function hd(e){return e.repeatable?Math.max(0,Number(V.stackCounts?.[e.id])||0):1}function J(e){return cd(e)+md(e)}function gd(e,t){if(e.id===`player-speed-multiplier`&&t===0)return 0;let n=ld(e,t)*Math.max(0,1-md(`researchCostReduction`));return e.cost.currency===`cash`?Math.round(n*100)/100:Math.ceil(n)}function _d(e,t){let n={chaser:`chaserRangeDebuff`,banger:`bangerRangeDebuff`,shooter:`shooterRangeDebuff`}[e];return n?t*Math.max(.5,1-J(n)):t}function vd(){let e=Date.now(),t=!1,n=[];for(let r=0;r<rd.unlockedSlots;r+=1){let i=rd.slots[r];if(!i||Zi.durationsEnabled&&i.completesAt>e)continue;let a=od(i.researchId);rd.levels[i.researchId]=Math.min(sd(i.researchId)+1,a.maxLevel),rd.slots[r]=null,n.push(a.name),t=!0}return t&&ad(),n.length&&yd(n.map(e=>I(`cheat.research_completed`,{research:e})).join(` `)),t}function yd(e=``){il.textContent=e}function bd(){vd(),tl.textContent=`$${za(Au)}`,rl.textContent=`✦ ${za(ju)}`,nl.hidden=!Zi.durationsEnabled;let e=Date.now();sl.hidden=!Zi.durationsEnabled,ol.hidden=!Zi.durationsEnabled,ol.innerHTML=Zi.durationsEnabled?rd.slots.map((t,n)=>{let r=n+1;if(t){let n=od(t.researchId),i=ud(n,t.level),a=Math.max(0,t.completesAt-e),o=C.clamp(1-a/i,0,1)*100;return`<article class="research-slot active"><span>${I(`research.slot`,{slot:r})}</span><strong>${n.name} · ${I(`weapon.level`,{level:t.level+1})}</strong><div class="research-progress"><i style="width:${o}%"></i></div><small>${I(`research.remaining`,{duration:Ra(a)})}</small></article>`}if(r<=rd.unlockedSlots)return`<article class="research-slot"><span>${I(`research.slot`,{slot:r})}</span><strong>${I(`research.available`)}</strong><small>${I(`research.select_below`)}</small></article>`;let i=Zi.slotUnlocks.find(e=>e.slot===r),a=!i.requirements?.minSector||Eu(i.requirements.minSector),o=i.cost.currency===`cash`?Au>=i.cost.amount:ju>=i.cost.amount,s=a&&o?``:`disabled`,c=a?I(`research.unlock_for`,{cost:Ba(i.cost.currency,i.cost.amount)}):I(`research.unlock_sector`,{sector:Na(i.requirements.minSector)});return`<article class="research-slot locked"><span>${I(`research.slot`,{slot:r})}</span><strong>${I(`research.locked`)}</strong><button data-unlock-slot="${r}" type="button" ${s}>${c}</button></article>`}).join(``):``;let t=new Map;for(let e of Zi.researches.filter(fd)){let n=e.category??`General`;t.set(n,[...t.get(n)??[],e])}let n=Zu.trim().toLocaleLowerCase(),r=[...t.entries()].sort(([e],[t])=>{let n=Zi.categoryOrder.indexOf(e),r=Zi.categoryOrder.indexOf(t);return(n<0?1e3:n)-(r<0?1e3:r)}).map(([e,t])=>[e,t.filter(e=>`${e.name} ${e.description}`.toLocaleLowerCase().includes(n)).filter(e=>!Qu||sd(e.id)<e.maxLevel).filter(e=>!$u||!dd(e)).sort(pd)]).filter(([,e])=>e.length);cl.innerHTML=r.length?r.map(([e,t])=>{let r=n||ed.has(e);return`<section class="research-category ${r?`open`:``}"><button class="research-category-toggle" data-toggle-research-category="${e}" type="button" aria-expanded="${r}"><span>${e}</span><i aria-hidden="true">›</i></button><div class="research-grid">${t.map(e=>{let t=sd(e.id),n=dd(e),r=Zi.durationsEnabled&&rd.slots.some(t=>t?.researchId===e.id),i=t>=e.maxLevel,a=gd(e,t),o=ud(e,t),s=id||(e.cost.currency===`cash`?Au>=a:ju>=a),c=Zi.durationsEnabled&&!rd.slots.slice(0,rd.unlockedSlots).some(e=>!e),l=n||r||i||!s||c,u=n||r||i||c?`research-locked`:s?`research-affordable`:`research-unaffordable`,d=e.id===`player-speed-multiplier`&&t===0,f=i?I(`research.max_level`):r?I(`research.in_progress`):n||(id||d?I(`research.free_enabled`):I(`research.cost`,{cost:`${Ba(e.cost.currency,a)}${Zi.durationsEnabled?` · ${Ra(o)}`:``}`}));return`<article class="research-card"><div><span class="research-level">${I(`weapon.level`,{level:t})}/${e.maxLevel}</span><h4>${e.name}</h4><p>${e.description}</p><p class="research-effect">${La(e,t)} → ${La(e,Math.min(t+1,e.maxLevel))}</p><small>${f}</small></div><button class="${u}" data-start-research="${e.id}" type="button" ${l?`disabled`:``}>${I(i?`research.maxed`:`research.start`)}</button></article>`}).join(``)}</div></section>`}).join(``):`<p class="research-empty">${I(`research.no_search_results`)}</p>`}function xd(e){vd();let t=od(e),n=sd(e),r=dd(t),i=rd.slots.slice(0,rd.unlockedSlots).findIndex(e=>!e),a=gd(t,n),o=t.cost.currency===`cash`?Au:ju,s=Zi.durationsEnabled&&rd.slots.some(t=>t?.researchId===e);return r||n>=t.maxLevel||Zi.durationsEnabled&&i<0||s||!id&&o<a?!1:(id||(t.cost.currency===`cash`?qd(-a):Jd(-a)),Zi.durationsEnabled?rd.slots[i]={researchId:e,level:n,completesAt:Date.now()+ud(t,n)}:(rd.levels[e]=Math.min(n+1,t.maxLevel),e===`shield`&&$&&(Im+=1,xp.visible=!0)),ad(),yd(Zi.durationsEnabled?I(`research.started`,{research:t.name,slot:i+1}):I(`research.upgraded`,{research:t.name,level:n+1})),bd(),!0)}function Sd(e){let t=Zi.slotUnlocks.find(t=>t.slot===e);!t||e!==rd.unlockedSlots+1||t.requirements?.minSector&&!Eu(t.requirements.minSector)||(t.cost.currency===`cash`?Au:ju)<t.cost.amount||(t.cost.currency===`cash`?qd(-t.cost.amount):Jd(-t.cost.amount),rd.unlockedSlots=e,ad(),yd(I(`research.slot_unlocked`,{slot:e})),bd())}function Y(e){ml.textContent=e}function Cd(e){if(!Qi.enabled)return;let t=e??fl.classList.contains(`hidden`);fl.classList.toggle(`hidden`,!t),t&&(Vp.clear(),pl.focus(),pl.select())}function wd(){Au=0,ju=0,qd(),Jd()}function Td(){Du=0,U=0,H.claimed=[],H.researchUnlocks=[],H.debugAscensionsGranted=!1;for(let e of vu)Ou[e]=0;Oa(ru,Du),Oa(iu,U),Su(),wu(),hp(),ff(),_f(),p_()}function Ed(){H.claimed=[],H.researchUnlocks=[],H.debugAscensionsGranted=!1,H.version=3;for(let e of vu)Ou[e]=0;U=0,Oa(iu,U),Su(),wu(),hp(),ff(),_f(),bd(),p_()}function Dd(){rd.unlockedSlots=1,rd.levels={},rd.slots=Array(Zi.maxSlots).fill(null),id=!1,ad(),bd()}function Od(){Aa(fu,Bu)}function kd(){Bu={researchLab:!1,buildingSystem:!1,weaponry:!1},Od(),Fd()}function Ad(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches&&window.innerHeight>=window.innerWidth}var jd;function Md(e,t){ks.textContent=t;let n=ds.getBoundingClientRect(),r=fs.getBoundingClientRect();ks.style.left=`${window.innerWidth/2}px`,ks.style.top=`${Math.min(window.innerHeight-12,Math.max(n.bottom,r.bottom)+12)}px`,ks.classList.remove(`hidden`),window.clearTimeout(jd),jd=window.setTimeout(()=>ks.classList.add(`hidden`),4e3)}function Nd(e){let t=Zi.featureUnlocks[e];if(Tu()+1<t.minSector)return I(`cheat.feature_sector`,{sector:Na(t.minSector)});if(t.requiredMilestone&&!H.claimed.includes(t.requiredMilestone)){let e=Ga.find(e=>e.id===t.requiredMilestone);if(e)return I(`cheat.feature_cells`,{cells:e.cells,sector:Na(e.sector)})}return ju<t.chronoshardCost?I(`cheat.feature_chronoshards`,{amount:t.chronoshardCost}):I(`cheat.feature_unavailable`)}function Pd(e,t){return Bu[e]||Id(e)?!0:(Md(t,Nd(e)),!1)}function Fd(){for(let[e,t]of[[`researchLab`,Fs],[`buildingSystem`,Ls],[`weaponry`,Rs]]){let n=Zi.featureUnlocks[e],r=Bu[e],i=Tu()+1>=n.minSector&&(!n.requiredMilestone||H.claimed.includes(n.requiredMilestone)),a=I(e===`researchLab`?`menu.research_lab`:e===`buildingSystem`?`menu.buildings`:`menu.weaponry`);t.className=`menu-system-button ${r?`is-unlocked`:i?`is-unlockable`:`is-locked`}${t.classList.contains(`is-active`)?` is-active`:``}`,t.disabled=!1,t.querySelector(`.menu-button-label`).textContent=r?a:i?I(`menu.unlock_feature`,{feature:a,cost:n.chronoshardCost}):I(`menu.feature_sector`,{feature:a,sector:Na(n.minSector)});let o=t.querySelector(`.menu-button-lock`);o.hidden=r||!Ad(),o.innerHTML=i?`<span class="chronoshard-symbol" aria-hidden="true">✦</span><span>${n.chronoshardCost}</span>`:`<span>SECTOR ${Na(n.minSector)}</span>`}}function Id(e){let t=Zi.featureUnlocks[e];return Bu[e]||Tu()+1<t.minSector||t.requiredMilestone&&!H.claimed.includes(t.requiredMilestone)||ju<t.chronoshardCost?!1:(Jd(-t.chronoshardCost),Bu[e]=!0,Od(),Fd(),!0)}function Ld(){K={unlocked:[],placed:[],unlockCount:0,unlockOffers:[]},Xu=null,Kh(),ig(),dg()}function Rd(e=0){Nu={sectorIndex:C.clamp(e,0,vu.length-1),simulation:new Set},Fu=null,g_(),hp(),p_(!1),$=!0,Cm=!1,Sm=!1,Z.visible=!0,xs.classList.remove(`hidden`),rs.classList.add(`hidden`),gl.classList.add(`hidden`),Gf(),w_()}function zd(e){let t=ta.challenges.find(t=>t.id===e);return t?(Nu=null,g_(),Fu={challengeId:t.id,weekId:`debug-${t.id}`},hp(),p_(),$=!0,Cm=!1,Sm=!1,Z.visible=!0,rs.classList.add(`hidden`),gl.classList.add(`hidden`),Gf(),w_(),!0):!1}function Bd(e){let[t,n]=e;if(!t){Rd(),Y(I(`cheat.sandbox_started`));return}let r=Number(t);if(Number.isInteger(r)){Nu?(Nu.sectorIndex=C.clamp(r-1,0,vu.length-1),hp(),w_()):Rd(r-1),Y(I(`cheat.sandbox_sector`,{sector:Na(Nu.sectorIndex+1)}));return}if(!Nu){Y(I(`cheat.sandbox_start_first`));return}if(t===`simulate`){if(![`cell`,`enemies`,`all`].includes(n)){Y(I(`cheat.sandbox_simulate_usage`));return}Nu.simulation=n===`all`?new Set([`cell`,`enemies`,`boosters`]):new Set([n]),Y(I(`cheat.sandbox_simulation`,{type:n,sector:Na(Nu.sectorIndex+1)}));return}if(t===`spawn`){let t=Object.keys(Ii).find(e=>e.toLocaleLowerCase()===n?.toLocaleLowerCase()),r=Number(e[2]??1),i=Number.isInteger(r)?C.clamp(r,1,100):0;if(!t||!i){Y(I(`cheat.sandbox_spawn_usage`,{enemies:Object.keys(Ii).join(`, `)}));return}for(let e=0;e<i;e+=1)jg(Gh(M.obstacleMinDistance),t);Y(I(`cheat.sandbox_spawned`,{count:i,enemy:t,plural:i===1?``:` enemies`}));return}Y(I(`cheat.sandbox_usage`))}function Vd(e){if(e.length<2){Y(I(`cheat.artifact_usage`));return}let t=Number(e.at(-1)),n=e.slice(0,-1).join(`-`).replaceAll(`_`,`-`).toLowerCase(),r=Ya.artifacts.find(e=>e.id.toLowerCase()===n||e.name.replaceAll(` `,`-`).toLowerCase()===n);if(!r){Y(I(`cheat.artifact_unknown`,{artifact:e.slice(0,-1).join(` `)}));return}if(!Number.isInteger(t)||t<=0||t>1e4){Y(I(`cheat.artifact_stack_range`));return}if(r.repeatable){V.stackCounts[r.id]=hd(r)+t,V.unlocked.includes(r.id)||(V.unlocked=[...V.unlocked,r.id]),$d(),uf(),Y(I(`cheat.artifact_granted`,{count:t,artifact:r.name,stackWord:t===1?`stack`:`stacks`,total:hd(r)}));return}V.unlocked.includes(r.id)||af(r),Y(I(`cheat.artifact_unique`,{artifact:r.name}))}function Hd(e){if(!$||Cm){Y(I(`cheat.spawn_requires_round`));return}let t=bm.get(e[0]?.toLocaleLowerCase());if(!t||e.length!==1){Y(I(`cheat.spawn_usage`,{entities:[...bm.values()].map(e=>e.id).join(`, `)}));return}t.spawn(),Y(I(`cheat.spawned`,{entity:t.id}))}function Ud(e){let[t,...n]=e.trim().toLowerCase().split(/\s+/),r=n[0];if(!t)return;if(t===Qi.commands.sandbox){Bd(n);return}if(t===Qi.commands.gainArtifact){Vd(n);return}if(t===Qi.commands.spawn){Hd(n);return}if(t===Qi.commands.anomaly){let e=n.join(`-`);if(!e){Y(I(`cheat.anomaly_usage`));return}if(!zd(e)){Y(I(`cheat.anomaly_unknown`,{id:e,available:ta.challenges.map(e=>e.id).join(`, `)}));return}Y(I(`cheat.anomaly_started`,{id:e,sector:Na(U+1)})),Cd(!1);return}if(t===Qi.commands.cell){let e=Number(n[0]);if(!Number.isInteger(e)||e<=0){Y(I(`cheat.cell_usage`));return}if(!$||Cm){Y(I(`cheat.cell_requires_round`));return}Em+=e,w_(),Mh(),zu()&&Em>=(Ru()?.rewardCellTarget??1e3)&&C_(!0),Y(I(`cheat.cell_granted`,{amount:e,total:Em}));return}if(t===Qi.commands.cellObtain){let e=Number(n[0]);if(!Number.isInteger(e)||e<=0||e>1e4){Y(I(`cheat.cell_obtain_usage`));return}Dm=e,Y(I(`cheat.cell_obtain_set`,{amount:e}));return}if(t===Qi.commands.god){let e=n[0];if(![`on`,`off`].includes(e)){Y(I(`cheat.god_usage`));return}Iu=e===`on`,Y(I(`cheat.god_state`,{state:I(Iu?`cheat.on`:`cheat.off`)}));return}let i=Number(r);if(t===Qi.commands.cash||t===Qi.commands.chrono){if(!Number.isFinite(i)||i<=0){Y(I(`cheat.amount_usage`,{command:t}));return}t===Qi.commands.cash?qd(i):Jd(i),Y(I(`cheat.amount_granted`,{amount:`${t===Qi.commands.cash?`$`:`✦ `}${i.toLocaleString()}`}));return}if(t===Qi.commands.freeResearch){id=!0,bd(),Y(I(`cheat.free_research`));return}if(t===Qi.commands.unlockSectors){let e=Ga.filter(e=>!H.claimed.includes(e.id)),t=H.debugAscensionsGranted?e:Ga;H.claimed=Ga.map(e=>e.id),H.researchUnlocks=[...new Set(Ga.flatMap(e=>e.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)))],H.debugAscensionsGranted=!0;let n=t.flatMap(e=>e.rewards).filter(e=>e.type===`cash`).reduce((e,t)=>e+t.amount,0),r=t.flatMap(e=>e.rewards).filter(e=>e.type===`chronoshards`).reduce((e,t)=>e+t.amount,0);n&&qd(n),r&&Jd(r),wu(),ff(),bd(),_f(),Y(I(`cheat.sectors_unlocked`,{rewards:n||r?` +$${za(n)} · +✦ ${za(r)}`:``}));return}if(t===Qi.commands.clearSave){if(!Qi.clearSaveTargets.includes(r)){Y(I(`cheat.clear_usage`,{targets:Qi.clearSaveTargets.join(`, `)}));return}(r===`currency`||r===`all`)&&wd(),(r===`game_progress`||r===`all`)&&Td(),(r===`milestones`||r===`all`)&&Ed(),(r===`research`||r===`all`)&&Dd(),(r===`buildings`||r===`all`)&&Ld(),(r===`weapons`||r===`all`)&&Zh(),(r===`artifacts`||r===`all`)&&ef(),r===`all`&&(kd(),Bo()),window.location.reload();return}Y(I(`cheat.unknown_command`,{command:t}))}function Wd(){return ji[vu[Nu?.sectorIndex??U]]}function Gd(){let e=Wd();if(e.maxActiveEnemies===void 0)return 1/0;let t=Math.max(0,Math.floor(e.maxActiveEnemies+Em*(e.maxActiveEnemiesIncrementPerCell??0)));return zu()?Math.max(1,Math.floor(t*(Ru()?.difficultyMultiplier??1))):t}function Kd(e=0){Du+=e,Oa(ru,Du),ff()}function qd(e=0){Au=Math.round((Au+e)*100)/100,Oa(ou,Au),xl.textContent=`$${za(Au)}`,bd()}function Jd(e=0){let t=e>0?e*(1+md(`chronoshardGainMultiplier`)):e;return ju+=t,Oa(su,ju),Sl.textContent=`✦ ${za(ju)}`,bd(),t}function Yd(e=0){return Mu=Math.max(0,Mu+e),Oa(cu,Mu),Cl.innerHTML=`<img src="${oo(`aetherium`)}" alt="">${za(Mu)}`,e}wl.addEventListener(`click`,async()=>{!Uo||wl.disabled||(wl.disabled=!0,await Fo({debug:!1})&&Yd(5),wl.disabled=!1)});function Xd(e,t){Zd(e,`+$${t}`,`cash-indicator`)}function Zd(e,t,n){let r=e.clone().project(ip),i=document.createElement(`span`);i.className=n,i.textContent=t,i.style.left=`${(r.x*.5+.5)*window.innerWidth}px`,i.style.top=`${(-r.y*.5+.5)*window.innerHeight}px`,i.addEventListener(`animationend`,()=>i.remove()),Tl.append(i)}function Qd(){if(Nu)return;let e=vu[U];Em>(Ou[e]??0)&&(Ou[e]=Em,Su()),rf(),wu(),ff(),bd(),_f()}function $d(){Aa(_u,V)}function ef(){V={unlocked:[],resetAtScores:Object.fromEntries(Ya.artifacts.map(e=>[e.id,e.requirement.type===`sector-high-score`?Ou[vu[e.requirement.sector-1]]??0:0])),stackCounts:{}},$d(),uf()}function tf(e){let{requirement:t}=e;return t.type===`sector-high-score`?I(`artifact.requirement_score`,{cells:t.cells,sector:Na(t.sector)}):t.type===`milestone-claimed`?I(`artifact.requirement_milestone`,{sector:Na(t.sector),cells:t.cells}):t.type===`anomaly-run-success`?I(`artifact.requirement_anomaly`,{cells:t.cells}):t.type===`hidden-world-map`?I(`artifact.requirement_hidden`):I(`artifact.requirement_default`)}function nf(e){let{requirement:t}=e;if(t.type===`sector-high-score`){let n=Ou[vu[t.sector-1]]??0;return n>=t.cells&&n>(V.resetAtScores[e.id]??-1)}return t.type===`milestone-claimed`&&H.claimed.includes(t.milestoneId)}function rf(){return Ya.artifacts.filter(e=>nf(e)).reduce((e,t)=>af(t)||e,!1)}function af(e){return!e||V.unlocked.includes(e.id)?!1:(V.unlocked=[...V.unlocked,e.id],$d(),uf(),lf(e),Za(e.id),e.buff.stat===`arenaSizeMultiplier`&&hp(),!0)}function of(e){return e?.repeatable?(V.stackCounts[e.id]=hd(e)+1,V.unlocked.includes(e.id)||(V.unlocked=[...V.unlocked,e.id]),$d(),uf(),lf(e),Za(e.id),!0):!1}async function sf(){let e=await Qa();for(let t of Ya.artifacts)e[Xa[t.id]]&&!V.unlocked.includes(t.id)&&af(t);for(let e of V.unlocked)Za(e)}var cf;function lf(e){As.textContent=I(`artifact.acquired_named`,{artifact:e.name.toUpperCase()}),As.classList.remove(`hidden`),window.clearTimeout(cf),cf=window.setTimeout(()=>As.classList.add(`hidden`),4e3)}function uf(){Ks.innerHTML=Ya.artifacts.map(e=>{let t=V.unlocked.includes(e.id),n=hd(e),r=t&&e.repeatable?`<b class="artifact-stack-count" aria-label="${I(`artifact.stacks`,{count:n})}">${n}</b>`:``,i=I(n===1?`artifact.stack`:`artifact.stacks_label`,{count:n});return`<button class="artifact-card ${t?`is-unlocked`:`is-locked`}" data-artifact-id="${e.id}" type="button"><span class="artifact-icon-wrap"><img src="${ro(e.icon)}" alt="">${r}</span><span>${t?e.name:I(`artifact.unknown`)}</span><small>${t?e.repeatable?i:I(`weapon.unlocked`):I(`artifact.locked`)}</small></button>`}).join(``)}function df(e){let t=Ya.artifacts.find(t=>t.id===e);if(!t)return;let n=V.unlocked.includes(t.id),r=hd(t),i=t.repeatable&&n?I(`artifact.buff_per_stack`,{buff:t.buff.label,count:r,percent:Math.round(t.buff.amount*r*100)}):t.buff.label,a=I(r===1?`artifact.dark_core_stack`:`artifact.dark_core_stacks`,{count:r});Js.innerHTML=`<img class="artifact-detail-icon ${n?``:`is-locked`}" src="${ro(t.icon)}" alt=""><p class="eyebrow">${n?t.repeatable?a:I(`artifact.acquired`):I(`artifact.locked`)}</p><h2>${n?t.name:I(`artifact.unknown`)}</h2><div class="artifact-detail-section"><strong>${I(`artifact.to_acquire`)}</strong><p>${tf(t)}</p></div><div class="artifact-detail-section"><strong>${I(`artifact.permanent_buff`)}</strong><p>${i}</p></div>`,qs.classList.remove(`hidden`)}function ff(){let e=Tu();U>e&&(U=e),Ol.textContent=I(`hud.sector`,{sector:Na(U+1)}),El.textContent=String(Ou[vu[U]]??0).padStart(3,`0`);let t=Ga.find(e=>e.sector===U+1&&!H.claimed.includes(e.id)),n=Ou[vu[U]]??0;Dl.textContent=t?n>=t.cells?I(`milestone.ready`):I(`milestone.next`,{cells:t.cells}):I(`milestone.complete`),kl.disabled=U===0,Al.disabled=U>=e;let r=Ga.filter(e=>!H.claimed.includes(e.id)&&(Ou[vu[e.sector-1]]??0)>=e.cells).length;Ds.textContent=String(r),Ds.hidden=r===0,Fd(),v_()}function pf(e){e<0||e>Tu()||(U=e,Oa(iu,U),hp(),ff())}kl.addEventListener(`click`,()=>pf(U-1)),Al.addEventListener(`click`,()=>{pf(U+1),Fl?.mode===`next-sector`&&U>=1&&(Fl.mode=`start-run`,Bl(),Vl(ds),Ul())}),Ss.addEventListener(`click`,()=>{ku=U,V_(Cs,_f),Pl?.mode===`ascension-entry`&&(Pl.mode=`ascension-claims`,Wl())}),ws.addEventListener(`click`,()=>{Cs.classList.add(`hidden`),xs.classList.remove(`hidden`)}),js.addEventListener(`click`,()=>{ku=Math.max(0,ku-1),_f()}),Ms.addEventListener(`click`,()=>{ku=Math.min(Tu(),ku+1),_f()}),Es.addEventListener(`click`,e=>{let t=e.target.closest(`[data-claim-milestone]`);t&&gf(t.dataset.claimMilestone)});function mf(e){return e.type===`cash`?I(`milestone.reward_cash`,{amount:e.amount.toLocaleString()}):e.type===`chronoshards`?I(`milestone.reward_chronoshards`,{amount:e.amount}):e.type===`sector`?I(`milestone.unlock_sector`,{sector:Na(e.sector)}):e.type===`feature`?I(`milestone.unlock_feature`,{feature:e.featureId===`researchLab`?I(`menu.research_lab`):e.featureId}):e.type===`research`?I(`milestone.unlock_research`,{researches:e.researchIds.map(e=>od(e)?.name??e).join(`, `)}):I(`milestone.reward`,{},`Reward`)}var hf;function gf(e){let t=Ga.find(t=>t.id===e),n=t?Ou[vu[t.sector-1]]??0:0;if(!(!t||H.claimed.includes(t.id)||n<t.cells)){H.claimed.push(t.id),H.researchUnlocks=[...new Set([...H.researchUnlocks,...t.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)])];for(let e of t.rewards)e.type===`cash`&&qd(e.amount),e.type===`chronoshards`&&Jd(e.amount),e.type===`feature`&&e.featureId in Bu&&(Bu[e.featureId]=!0);if(Od(),rf(),wu(),Os.textContent=I(`milestone.reward_claimed`,{rewards:t.rewards.map(mf).join(` · `)}),Os.classList.remove(`hidden`),clearTimeout(hf),hf=setTimeout(()=>Os.classList.add(`hidden`),3600),ff(),bd(),_f(),Pl?.mode===`ascension-claims`){let e=Hl();if(e.length===0)Kl();else{let t=Ga.find(t=>t.id===e[0]);t&&(ku=t.sector-1),_f(),Wl()}}}}function _f(){let e=ku+1,t=Ou[vu[ku]]??0;Ts.textContent=String(t).padStart(3,`0`),Ns.textContent=I(`hud.sector`,{sector:Na(e)}),js.disabled=ku===0,Ms.disabled=ku>=Tu(),Es.innerHTML=Ga.filter(t=>t.sector===e).map(n=>{let r=H.claimed.includes(n.id),i=t>=n.cells,a=Math.min(100,t/n.cells*100);return`<article class="milestone-card ${r?`claimed`:i?`reached`:``}"><div class="milestone-node">${r?`✓`:n.cells}</div><div><strong>${r?I(`milestone.secured`):I(`milestone.cells`,{cells:n.cells})}</strong><p>${n.rewards.map(mf).join(` · `)}</p><div class="milestone-progress"><i style="width:${a}%"></i></div><small>${r?I(`milestone.auto_claimed`):I(`milestone.best`,{best:t,target:n.cells,sector:Na(e)})}</small></div></article>`}).join(``);let n=Ga.filter(t=>t.sector===e);for(let[e,r]of n.entries()){let n=H.claimed.includes(r.id),i=t>=r.cells,a=Es.children[e];if(a&&(n&&(a.querySelector(`small`).textContent=I(`milestone.claimed`)),i&&!n)){let e=document.createElement(`button`);e.className=`claim-milestone-button`,e.dataset.claimMilestone=r.id,e.type=`button`,e.textContent=I(`milestone.claim`),a.lastElementChild.append(e)}}}var vf=ja({THREE:ke,SOUND:Fi,getSettings:()=>q,getPlayer:()=>Z,getCamera:()=>ip}),yf=new ie({canvas:Yo,antialias:q.graphics.quality!==`low`}),bf,xf,Sf=null,Cf=null,wf=null,Tf={low:{pixelRatioCap:1,textureFilter:f},medium:{pixelRatioCap:1.5,textureFilter:qe},high:{pixelRatioCap:M.maxPixelRatio,textureFilter:qe}};function Ef(){return Tf[q.graphics.quality]??Tf.high}function Df(){let e=Ef(),t=q.graphics.quality!==`low`;bf&&yf.getContext().getContextAttributes().antialias!==t&&ap(t);let n=C.clamp(q.graphics.hdrEmissionIntensity??.5,0,1)*.5;yf.setPixelRatio(Math.min(window.devicePixelRatio,e.pixelRatioCap)),bf?.setPixelRatio(yf.getPixelRatio());let r=q.graphics.shadows&&q.graphics.quality!==`low`;Sf&&(Sf.castShadow=r),yf.shadowMap.enabled=r,yf.shadowMap.needsUpdate=r,Cf&&(Cf.magFilter=e.textureFilter,Cf.minFilter=e.textureFilter,Cf.needsUpdate=!0),wf?.(q.graphics.quality),yf.toneMapping=n>0?4:0,yf.toneMappingExposure=.9+n*.2,xf&&(xf.enabled=n>0,xf.strength=1.35*n)}function Of(){Aa(hu,G)}function kf(){return 1+sd(`weapon-slots`)+md(`weaponSlotCount`)}function Af(e){return G.cards[e]}var jf=480,Mf=30,Nf=180;function Pf(){return sd(`weapon-recharge`)>0}function Ff(){return Pf()?1+sd(`weapon-charge-capacity`):1}function If(){return Math.max(Nf,jf-sd(`weapon-recharge-rate`)*Mf)}function Lf(e){return Qm.get(e)??1}function Rf(){Qm.clear(),$m.clear();for(let e of G.loadout.filter(e=>Af(e)))Qm.set(e,1),$m.set(e,0)}function zf(e){if(!Pf())return;let t=Ff(),n=If(),r=!1;for(let i of G.loadout.filter(e=>Af(e))){let a=Lf(i);if(a>=t){$m.set(i,0);continue}let o=($m.get(i)??0)+e,s=a;for(;o>=n&&s<t;)o-=n,s+=1,r=!0;Qm.set(i,s),$m.set(i,s>=t?0:o)}r&&Gf()}function Bf(e){if(G.loadout.includes(e))return I(`weapon.remove_loadout`);if(G.loadout.length<kf())return I(`weapon.add_loadout`);let t=G.loadout[G.selected],n=qa.weapons[t];return n?I(`weapon.replace_with`,{weapon:n.name.toUpperCase()}):I(`weapon.replace_selected`)}function Vf(e){return qa.levelCopyRequirements[e-1]??1/0}function Hf(e){let t=Af(e),n=qa.weapons[e];return t&&n?n.baseEffect+n.effectPerLevel*(t.level-1):0}function Uf(e){return{megaMagnet:Wm,atmosphereShield:Gm,chronoFreeze:Km,plasmaOrbital:qm,cellOverdrive:Jm,demonMode:Ym}[e]??0}function Wf(){for(let e of fc.querySelectorAll(`[data-weapon-duration]`)){let t=e.dataset.weaponDuration,n=Hf(t);e.style.setProperty(`--weapon-progress`,String(n>0?C.clamp(Uf(t)/n,0,1):0))}}function Gf(){let e=G.loadout.filter(e=>Af(e));fc.classList.toggle(`hidden`,!$||!e.length),fc.innerHTML=e.map((e,t)=>{let n=Lf(e),r=Ff(),i=String(n);return`<button class="${t===G.selected?`selected`:``} ${n===0?`spent`:``} ${n>=r?`is-charge-full`:``}" data-use-weapon="${e}" type="button" ${n===0?`disabled`:``}><span class="weapon-hud-icon ${qa.weapons[e].duration?`has-duration`:``}" data-weapon-duration="${qa.weapons[e].duration?e:``}"><img class="weapon-hud-art" src="${ao(e)}" alt=""></span><b>${t+1}</b><span class="weapon-hud-name">${qa.weapons[e].name}</span><i>${i}</i></button>`}).join(``),Wf()}function Kf(){Qs.textContent=`✦ ${za(ju)}`,$s.textContent=I(`weapon.buy_with_cost`,{cost:za(qa.purchaseCost)}),ec.textContent=I(`weapon.buy_five_with_cost`,{cost:za(qa.purchaseCost*5)}),$s.disabled=ju<qa.purchaseCost,ec.disabled=ju<qa.purchaseCost*5;let e=Yf();tc.hidden=e<=0,tc.textContent=I(`weapon.lucky_find_cards`,{chance:Math.round(e*100)});let t=kf();lc.textContent=String(G.loadout.length),lc.classList.toggle(`is-full`,G.loadout.length>=t),uc.innerHTML=Array.from({length:kf()},(e,t)=>{let n=G.loadout[t];return`<button data-select-weapon-slot="${t}" type="button" class="${t===G.selected?`selected`:``}">${n?qa.weapons[n].name:I(`weapon.empty_slot`)}</button>`}).join(``),dc.innerHTML=Object.entries(qa.weapons).map(([e,t])=>{let n=Af(e),r=`<img class="asset-card-art" src="${ao(e)}" alt="">`;if(!n)return`<article class="weapon-card locked">${r}<strong>${t.name}</strong><small>${I(`weapon.not_collected`)}</small></article>`;let i=Vf(n.level);return`<article class="weapon-card ${G.loadout.includes(e)?`selected`:``}">${r}<strong>${t.name} · ${I(`weapon.level`,{level:n.level})}</strong><small>${t.description}</small><em>${n.level>=5?I(`weapon.max_level`):I(`weapon.copy_progress_short`,{copies:n.copies,required:i,level:n.level+1})}</em><button data-toggle-weapon="${e}" type="button">${Bf(e)}</button></article>`}).join(``),Gf()}function qf(){let e=Vu[Hu];e&&(nc.dataset.revealType=e.type,rc.textContent=I(`weapon.number`,{current:Hu+1,total:Vu.length}),ic.textContent=e.status,ac.src=ao(e.id),ac.alt=e.name,oc.textContent=e.name,sc.textContent=e.detail,cc.textContent=Hu===Vu.length-1?I(`weapon.claim`):I(`weapon.next`),nc.classList.remove(`hidden`),nc.classList.remove(`is-revealing`),nc.offsetWidth,nc.classList.add(`is-revealing`))}function Jf(e){let t=qa.weapons[e],n=Af(e);if(!n)return n={level:1,copies:0},G.cards[e]=n,{id:e,name:t.name,type:`unlock`,status:I(`weapon.unlocked`),detail:I(`weapon.unlocked_level`)};n.copies+=1;let r=Vf(n.level);return n.copies>=r&&n.level<5?(n.copies-=r,n.level+=1,{id:e,name:t.name,type:`level-up`,status:I(`weapon.level_up`,{level:n.level}),detail:I(`weapon.upgraded_level`,{level:n.level})}):n.level>=5?{id:e,name:t.name,type:`max-copy`,status:I(`weapon.max_level_copy`),detail:I(`weapon.max_level_detail`)}:{id:e,name:t.name,type:`copy`,status:I(`weapon.copy`,{level:n.level}),detail:I(`weapon.copy_progress`,{copies:n.copies,required:r,level:n.level+1})}}function Yf(){return C.clamp(J(`luckyFindChance`),0,1)}function Xf(e){let t=qa.purchaseCost*e;if(ju<t)return;Jd(-t);let n=[],r=Object.keys(qa.weapons);for(let t=0;t<e;t+=1){let e=r[Math.floor(Math.random()*r.length)],t=Math.random()<Yf(),i=Jf(e);if(!t){n.push(i);continue}let a=Jf(e);n.push({...a,type:`lucky-find`,status:I(`weapon.lucky_find_double`),detail:i.type===`unlock`?I(`weapon.lucky_find_unlock`):I(`weapon.lucky_find_received`,{detail:a.detail})})}Vu=n,Hu=0,Of(),Kf(),qf()}function Zf(){if(Hu<Vu.length-1){Hu+=1,qf();return}Vu=[],Hu=0,delete nc.dataset.revealType,nc.classList.remove(`is-revealing`),nc.classList.add(`hidden`),Kf()}function Qf(e){if($||!Af(e))return;let t=G.loadout.indexOf(e);t>=0?G.loadout.splice(t,1):G.loadout.length<kf()?(G.loadout.push(e),G.selected=G.loadout.length-1):G.loadout[G.selected]=e,G.selected=Math.min(G.selected,Math.max(G.loadout.length-1,0)),Of(),Kf()}function $f(e=G.loadout[G.selected]){let t=Af(e);if(!$||Sm||!t||!G.loadout.includes(e))return;let n=Lf(e);if(n<=0)return;qa.weapons[e];let r=Hf(e);if(e===`nuke`){let e=[...Q].sort(()=>Math.random()-.5).slice(0,Math.ceil(Q.length*Math.min(r,.9)));j_(Z.position,e)}if(e===`megaMagnet`&&(Wm=r),e===`atmosphereShield`){Gm=r;for(let e of nm)X.remove(e.obstacle,e.shadow,e.targetRing);nm.length=0}e===`phaseDash`&&ep(r),e===`chronoFreeze`&&(Km=r),e===`plasmaOrbital`&&(qm=r),e===`cellOverdrive`&&(Jm=r),e===`demonMode`&&(Ym=r),Qm.set(e,n-1),$m.has(e)||$m.set(e,0),Gf(),vf.playBuildingEffect(Z.position,`overclockRelay`)}function ep(e){let t=new E(Hp.x,0,Hp.y);t.lengthSq()===0?t.set(Math.sin(Z.rotation.y),0,Math.cos(Z.rotation.y)):t.normalize();let n=Z.position.clone(),r=mp(n.clone().addScaledVector(t,e),M.playerRadius);for(let e of[...Q])n_(e.position,n,r)>e.userData.colliderRadius+.8||(i_(e.position,.5),vg(e));let i=new s(new _e().setFromPoints([n.clone().setY(.25),r.clone().setY(.25)]),new u({color:`#78eaff`,transparent:!0,opacity:.95,depthWrite:!1}));X.add(i),Xm.push({trail:i,age:0}),Z.position.copy(r),_p=Math.atan2(t.x,t.z)}yf.setSize(window.innerWidth,window.innerHeight),yf.outputColorSpace=Fe;var X=new be;X.background=new Ke(N.background);var tp=new ci;X.add(tp);function np(){let e=new o,n=new c({color:`#29375c`,emissive:`#101936`,emissiveIntensity:.45,metalness:.78,roughness:.28}),r=new c({color:`#ffcf76`,emissive:`#ff9f43`,emissiveIntensity:1,metalness:.52,roughness:.2}),i=new l(new Ge(1.15,1.4,.65,10),n);i.position.y=.33;let a=new l(new Ge(.56,.82,5.8,10),n);a.position.y=3.45;let s=new l(new Ge(.88,.58,1.05,10),r);s.position.y=6.55;let u=new t(`#ffcf76`,.8,6,2);return u.position.y=7.15,e.add(i,a,s,u),e.traverse(e=>{e.isMesh&&(e.castShadow=!0,e.receiveShadow=!0)}),e.visible=!1,e}var rp=np();X.add(rp);var ip=new te(Mi.fov,window.innerWidth/window.innerHeight,Mi.near,Mi.far);ip.position.set(0,J_(),q_()),ip.lookAt(0,0,0),bf=new Pe(yf),bf.addPass(new De(X,ip)),xf=new Re(new Ue(window.innerWidth,window.innerHeight),.675,.48,1.1),bf.addPass(xf),bf.setSize(window.innerWidth,window.innerHeight);function ap(e){yf.dispose(),yf=new ie({canvas:Yo,antialias:e}),yf.setSize(window.innerWidth,window.innerHeight),yf.outputColorSpace=Fe,bf=new Pe(yf),bf.addPass(new De(X,ip)),xf=new Re(new Ue(window.innerWidth,window.innerHeight),.675,.48,1.1),bf.addPass(xf),bf.setSize(window.innerWidth,window.innerHeight)}var{starfield:op,floor:sp,grid:cp,arenaBoundary:lp,keyLight:up,setQuality:dp,resize:fp}=va({THREE:ke,scene:X,COLORS:N,GAME:M,SCENE:Ni,LIGHTING:Pi,quality:q.graphics.quality});Sf=up,wf=dp,Df();function pp(){return(M.arenaLimit+Wd().extraArenaPadding)*(1+md(`arenaSizeMultiplier`))}function mp(e,t=0){let n=Math.max(0,pp()-t),r=Math.hypot(e.x,e.z);if(r>n){let t=n/r;e.x*=t,e.z*=t}return e}function hp(){fp(Wd().extraArenaPadding,1+md(`arenaSizeMultiplier`))}var gp=new Ke(N.slowAura),_p=0,vp=la({THREE:ke,COLORS:N,ENTITIES:P,GAME:M}),{player:Z,playerCore:yp,slowAuraRing:bp,shieldBubble:xp}=vp;X.add(Z);var Sp={...la({THREE:ke,COLORS:{...N,player:`#ff4d4d`,playerEmissive:`#9d1010`,playerWing:`#ff6767`,playerWingEmissive:`#9d1010`,playerRing:`#ffaaa0`,slowAura:`#ff4d4d`},ENTITIES:P,GAME:M,opacity:.72}),active:!1};Sp.player.visible=!1;var Cp=new o,wp=new l(new ve(1.3,.055,10,48),new S({color:`#b59aff`,transparent:!0,opacity:.9,depthWrite:!1}));wp.rotation.x=Math.PI/2;var Tp=new l(new Oe(.95,1.28,48),new S({color:`#d5c9ff`,transparent:!0,opacity:.18,side:2,depthWrite:!1}));Tp.rotation.x=-Math.PI/2;var Ep=new l(new le(1.42,32,16,0,Math.PI*2,0,Math.PI/2),new S({color:`#a998ff`,transparent:!0,opacity:.15,wireframe:!0,depthWrite:!1}));Cp.position.y=.92,Cp.add(wp,Tp,Ep),Cp.visible=!1,Z.add(Cp);var Dp=Array.from({length:3},()=>{let e=new l(new le(.2,14,10),new c({color:`#ffb5ff`,emissive:`#ff45e9`,emissiveIntensity:3,metalness:.2,roughness:.15}));return e.visible=!1,Z.add(e),e}),Op=new l(new ve(1.25,.07,8,40),new S({color:`#ff465d`,transparent:!0,opacity:.8,depthWrite:!1}));Op.rotation.x=Math.PI/2,Op.position.y=.1,Op.visible=!1,Z.add(Op);var kp=new o;for(let e=0;e<12;e+=1){let t=e*Math.PI*2/12,n=new l(new oe(.12,1.05+e%3*.16,5),new S({color:`#ff465d`,transparent:!0,opacity:.46,depthWrite:!1})),r=new E(Math.cos(t),.1+e%2*.12,Math.sin(t));n.position.copy(r.clone().multiplyScalar(.95)),n.quaternion.setFromUnitVectors(new E(0,1,0),r.normalize()),kp.add(n)}kp.visible=!1,Z.add(kp);var Ap=document.createElement(`canvas`);Ap.width=128,Ap.height=128;var jp=Ap.getContext(`2d`);jp.font=`900 108px Arial`,jp.textAlign=`center`,jp.textBaseline=`middle`,jp.lineWidth=8,jp.strokeStyle=`#6b4710`,jp.strokeText(`$`,64,65),jp.fillStyle=`#ffd36f`,jp.fillText(`$`,64,65),Cf=new he(Ap),Cf.magFilter=Ef().textureFilter,Cf.minFilter=Ef().textureFilter,Cf.needsUpdate=!0;var Mp=new de(new me({map:Cf,transparent:!0,depthWrite:!1}));Mp.position.set(0,2.2,0),Mp.scale.set(.7,.7,1),Mp.visible=!1,Z.add(Mp);var Np=new Map;for(let[e,[t,n]]of Object.entries(qa.weapons).filter(([,e])=>e.duration).entries()){let r=new l(new Oe(1.42+e*.11,1.49+e*.11,96),new S({color:n.color,transparent:!0,opacity:.9,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.userData.height=.2+e*.025,r.position.y=r.userData.height,r.visible=!1,r.geometry.setDrawRange(0,0),X.add(r),Np.set(t,r)}var Pp=new l(new le(.19,16,12),new c({color:`#d9ffff`,emissive:`#42eaff`,emissiveIntensity:3.2,metalness:.2,roughness:.12})),Fp=new l(new le(.33,14,10),new S({color:`#4eeeff`,transparent:!0,opacity:.24,depthWrite:!1}));Pp.add(Fp);var Ip=new _e;Ip.setAttribute(`position`,new Te(new Float32Array(27),3).setUsage(i));var Lp=new s(Ip,new u({color:`#a9ffff`,transparent:!0,opacity:.8,depthWrite:!1}));Lp.frustumCulled=!1,Pp.visible=!1,Lp.visible=!1,X.add(Pp,Lp);var Rp=0,zp=new E,Bp=new E,Vp=new Set,Hp=new Ue,Up=null,Wp=null,Gp=58,Kp=12,qp=36,Jp=new Ue,Yp=28,Xp=new Map,Zp=null,Qp=!1,$p=[],em=[],tm=[],Q=[],nm=[],rm=[],im=[],am=[],om=[],sm=[],cm=[],lm=[],um=[],dm=[],fm=[],pm=[],mm=[],hm=[],gm=[],_m=[],vm=[],ym=[],bm=new Map,xm=new Ee,$=!1,Sm=!1,Cm=!1,wm=!1,Tm=!1,Em=0,Dm=1,Om=0,km=0,Am=0,jm=0,Mm=0,Nm=0,Pm=0,Fm=null,Im=0,Lm=0,Rm=.5,zm=0,Bm=0,Vm=0,Hm=0,Um=0,Wm=0,Gm=0,Km=0,qm=0,Jm=0,Ym=0,Xm=[],Zm=new Map,Qm=new Map,$m=new Map,eh=new g(P.obstacleRadius,P.fallingRockDetail),{createShooterProjectile:th,createAutocannonProjectile:nh,createSplinter:rh}=ya({THREE:ke,COLORS:N,ENTITIES:P}),{createCell:ih,createChronoCell:ah,createBooster:oh}=ma({THREE:ke,COLORS:N,ENTITIES:P}),sh=fa({THREE:ke,ENTITIES:P}),{createExplosion:ch,createBangerPulse:lh,createShockwave:uh,createShieldBreak:dh,createPoisonTrail:fh,createPlayerDeath:ph,createFieryRockFire:mh,createFallingRockImpact:hh}=ba({THREE:ke,Quarks:Dr,particleRenderer:tp,COLORS:N,getQuality:()=>q.graphics.quality}),gh=new Ke(N.creeper),_h=new Ke(N.poisonCreeper),vh=new Ke(N.creeperEmissive),yh=new Ke(N.poisonCreeperEmissive);function bh(e,t){let n=new ie({canvas:t,alpha:!0,antialias:!0});n.setPixelRatio(Math.min(window.devicePixelRatio,2)),n.setSize(210,150,!1);let r=new be,i=new te(32,210/150,.1,20);i.position.set(0,1.3,4.8),i.lookAt(0,0,0),r.add(new a(`#d9f9ff`,`#07141d`,2.6));let o=new b(`#fff4cf`,2.8);o.position.set(2,3,4),r.add(o);let s=e.model===`spiked-enemy`?Ii[e.id]:e.model===`ultimate-enemy`?Ri[e.id]:Li[e.id],u=new c({color:s.color,emissive:s.emissive,emissiveIntensity:s.emissiveIntensity??1.35,metalness:P.obstacleMetalness,roughness:P.obstacleRoughness}),d=e.model===`spiked-enemy`?sh(u,e.id):e.model===`ultimate-enemy`?pa(ke):new l(eh,u);e.model===`ultimate-enemy`&&d.scale.setScalar(s.scale),d.rotation.set(.28,-.55,.14),r.add(d),n.render(r,i),u.dispose(),n.dispose()}var xh=null,Sh=!1;function Ch(){if(ra.endpoint)return ra.endpoint;if(na.endpoint)try{return new URL(`/time`,na.endpoint).toString()}catch{}return ra.publicEndpoint}async function wh(){let e=Ch();if(!e)throw Error(I(`error.server_time_unconfigured`));let t=new AbortController,n=window.setTimeout(()=>t.abort(),8e3),r=performance.now();try{let n=await fetch(e,{cache:`no-store`,signal:t.signal});if(!n.ok)throw Error(I(`error.server_time_request`,{status:n.status}));let i=await n.json(),a=Date.parse(i?.now??i?.utc_iso);if(!Number.isFinite(a))throw Error(I(`error.server_time_invalid`));return new Date(a+(performance.now()-r)/2)}finally{window.clearTimeout(n)}}function Th(e=xh??new Date){let t=new Date(`${ta.weeklyAnchorDate}T00:00:00Z`),n=Date.UTC(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate());return Math.max(0,Math.floor((n-t.getTime())/6048e5))}function Eh(e=xh??new Date){return String(Th(e))}function Dh(e=xh??new Date){let t=new Date(`${ta.weeklyAnchorDate}T00:00:00Z`);return t.setUTCDate(t.getUTCDate()+(Th(e)+1)*7),t}function Oh(e){return`${String(e.getUTCDate()).padStart(2,`0`)}.${String(e.getUTCMonth()+1).padStart(2,`0`)}.${e.getUTCFullYear()}`}function kh(e=Eh()){return ta.challenges[Number(e)%ta.challenges.length]}function Ah(e){return ta.rewardBaseChronoshards+e*ta.rewardChronoshardStepPerSector}function jh(e=Eh(),t=U){return(Pu.claimedSectors[e]??[]).includes(String(t))}function Mh(){let e=Ru(),t=e?.rewardCellTarget??ta.rewardCellTarget;if(!Fu||!e||Em<t)return;let n=String(U),r=`${e.id}:sector${U+1}`;if(!Pu.darkCoreClaims.includes(r)){Pu.darkCoreClaims.push(r);let e=Ya.artifacts.find(e=>e.requirement.type===`anomaly-run-success`);e&&(of(e),Zd(Z.position,I(`anomaly.dark_core_stack`,{artifact:e.name.toUpperCase()}),`chronoshard-indicator`))}let i=Pu.claimedSectors[Fu.weekId]??[];if(!i.includes(n)){Pu.claimedSectors[Fu.weekId]=[...i,n];let e=Jd(Ah(U));Zd(Z.position,I(`message.anomaly_reward`,{amount:za(e)}),`chronoshard-indicator`)}Aa(gu,Pu),v_()}function Nh(e){!zu()||!$||Cm||(Ru(),Lu=Math.max(0,Lu-e),w_(),Lu===0&&C_(!1))}function Ph(){if(!zu()||!$||Cm)return;Em+=1,Mh();let e=Ru()?.rewardCellTarget??1e3;Em>=e&&C_(!0)}function Fh(){let e=Tu()+1,t=e=>[...e].map(e=>e===` `?` `:`?`).join(``),n=n=>{let r=n.firstSector<=e,i=r?`<canvas data-encyclopedia-model="${n.id}" width="210" height="150" aria-label="${n.name} model"></canvas>`:`<div class="encyclopedia-unknown-icon" role="img" aria-label="${I(`encyclopedia.unknown_enemy`)}">?</div>`;return`<article class="encyclopedia-entry ${r?``:`locked`}"><h3>${n.name}</h3>${i}<p>${r?n.description:t(n.description)}</p></article>`},r=new Map;for(let e of Fa)r.set(e.category,[...r.get(e.category)??[],e]);Hs.innerHTML=[...r.entries()].map(([e,t])=>`<section class="encyclopedia-category"><h3>${e}</h3><div class="encyclopedia-category-grid">${t.map(n).join(``)}</div></section>`).join(``);for(let e of Hs.querySelectorAll(`[data-encyclopedia-model]`)){let t=Fa.find(t=>t.id===e.dataset.encyclopediaModel);t&&bh(t,e)}}var Ih=new be,Lh=new te(34,1,.1,20);Lh.position.set(0,.1,3.25);var Rh=new ie({canvas:cs,alpha:!0,antialias:!0});Rh.setPixelRatio(Math.min(window.devicePixelRatio,2)),Rh.setSize(76,60,!1),Ih.add(new a(`#d9f9ff`,`#07141d`,2.5));var zh=new b(`#fff4cf`,3);zh.position.set(2,3,4),Ih.add(zh);var Bh=null;function Vh(e){let t=e.toLowerCase();return Object.keys(Ii).find(e=>t.includes(e))??null}function Hh(){Bh&&=(Ih.remove(Bh),Bh.userData.material?.dispose(),null),ss.hidden=!0,xs.classList.remove(`is-death-screen`)}function Uh(e){let t=Vh(e);if(!t)return Hh(),!1;Hh();let n=Ii[t];return Bh=sh(new c({color:n.color,emissive:n.emissive,emissiveIntensity:1.35,metalness:P.obstacleMetalness,roughness:P.obstacleRoughness}),t),Bh.rotation.set(.25,0,-.16),Ih.add(Bh),cs.setAttribute(`aria-label`,I(`accessibility.enemy_model`,{enemy:t})),ss.hidden=!1,xs.classList.add(`is-death-screen`),!0}function Wh(e){!Bh||ss.hidden||(Bh.rotation.y+=e*1.8,Bh.rotation.x+=e*.24,Rh.render(Ih,Lh))}function Gh(e=0){let t=pp(),n;do{let e=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*t;n=new E(Math.cos(e)*r,0,Math.sin(e)*r)}while(n.distanceTo(Z.position)<e);return n}function Kh(){Aa(du,K)}function qh(e,t=Math.ceil){return t(e*Math.max(0,1-md(`buildingCostReduction`)))}function Jh(){return qh(60+K.unlockCount*30)}function Yh(){let e=Object.keys(ca.types).filter(e=>!K.unlocked.includes(e)),t=K.unlockOffers.filter(t=>e.includes(t));return t.length?t:(K.unlockOffers=[...e].sort(()=>Math.random()-.5).slice(0,3),Kh(),K.unlockOffers)}function Xh(e){let t=Yh(),n=Jh();!t.includes(e)||ju<n||(Jd(-n),K.unlocked.push(e),K.unlockCount+=1,K.unlockOffers=[],Kh(),dg())}function Zh(){G={cards:{},loadout:[],selected:0},Vu=[],Hu=0,nc.classList.add(`hidden`),Of(),Kf()}function Qh(){let e=Yh(),t=Jh(),n=ju>=t;Kc.textContent=`✦ ${za(ju)}`,qc.innerHTML=e.length?`<p class="building-draft-copy">${I(`building.choose_offer`,{count:e.length,cost:za(t)})}</p>${e.map(e=>{let r=ca.types[e];return`<article class="building-card building-offer"><img class="asset-card-art" src="${io(e)}" alt=""><strong>${r.name}</strong><small>${I(`building.permanent_unlock`)}</small><button data-building-offer="${e}" ${n?``:`disabled`}>${I(`building.unlock_cost`,{cost:za(t)})}</button></article>`}).join(``)}`:`<p class="building-draft-copy">${I(`building.all_unlocked`)}</p>`}function $h(){return 3+sd(`building-slots`)}function eg(e){return 1+K.placed.filter(t=>t.type===e).reduce((e,t)=>e+Object.values(t.upgrades).reduce((e,t)=>e+t,0),0)}function tg(e,t){let n=ca.types[e.type].upgrades[t],r=e.upgrades[t]??0;return qh(n.base*1.65**r)}function ng(e){return Math.round((e.spent??ca.types[e.type].baseCost)*100)/100}function rg(e){let t=ca.types[e.type],{group:n,effectRing:r,barrierField:i}=ua({THREE:ke,building:e,config:t,range:_g(e,`range`)});n.userData.buildingId=e.id,X.add(n),qu.set(e.id,n),Ju.set(e.id,{timer:0,active:0,effectRing:r,barrierField:i})}function ig(){for(let e of qu.values())X.remove(e);qu.clear(),Ju.clear();for(let e of K.placed)rg(e)}function ag(e){let t=ca.types[e];return qh(t.baseCost*t.costMultiplier**K.placed.filter(t=>t.type===e).length)}function og(){let e=[];for(let t=-10;t<=10;t+=2)for(let n=-10;n<=10;n+=2)Math.hypot(t,n)<=ca.placementRadius&&Math.hypot(t,n)>=ca.spawnClearance&&e.push({x:t,z:n});return e}function sg(){if(!Yu){Zc.replaceChildren(),Zc.classList.add(`hidden`);return}let e=Xu?ag(Xu):0,t=K.placed.length>=$h();Zc.innerHTML=og().map(({x:n,z:r})=>{let i=K.placed.find(e=>e.x===n&&e.z===r),a=i?`<span class="build-name" data-build-x="${n}" data-build-z="${r}">${ca.types[i.type].name}</span>`:``;return`<button class="build-site ${i?`occupied`:``}" data-build-x="${n}" data-build-z="${r}" type="button" ${!i&&!t||i?``:`disabled`}>${i?I(`building.upgrade`):t?I(`building.slot_limit`):`$${e}`}</button>${a}`}).join(``),Zc.classList.remove(`hidden`),requestAnimationFrame(cg)}function cg(){if(Yu)for(let e of Zc.querySelectorAll(`[data-build-x]`)){let t=e.classList.contains(`build-name`),n=new E(Number(e.dataset.buildX),t?1.25:.08,Number(e.dataset.buildZ)).project(ip);e.style.left=`${(n.x*.5+.5)*window.innerWidth}px`;let r=e.classList.contains(`occupied`)?38:0;e.style.top=`${(-n.y*.5+.5)*window.innerHeight+r}px`}}function lg(e){Z.visible=!e&&!Cm,Pp.visible=!e&&sd(`unlock-orbital-electron`)>0&&!Cm,Lp.visible=!e&&sd(`unlock-orbital-electron`)>0&&!Cm;for(let t of $p)t.visible=!e;for(let t of em)t.visible=!e;for(let t of pm)t.visible=!e;for(let t of Q)t.visible=!e,t.userData.rangeIndicator&&(t.userData.rangeIndicator.visible=!e),t.userData.magnetPulse&&(t.userData.magnetPulse.visible=!e);for(let t of fm)t.spore.visible=!e;for(let t of um)t.projectile.visible=!e;for(let t of _m)t.mesh.visible=!e;for(let t of nm)t.obstacle.visible=!e,t.shadow.visible=!e,t.targetRing.visible=!e;for(let t of ym)t.ring.visible=!e,t.glow.visible=!e,t.beam.visible=!e;for(let t of sm){for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of vm){for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of tm)t.visible=!e;for(let t of im){t.ground.visible=!e;for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of am)for(let n of t.emitters)n.visible=!e;for(let t of om)t.piece.visible=!e;for(let t of lm)t.pulse.visible=!e;for(let t of mm)t.shockwave.visible=!e;for(let t of gm)t.ring.visible=!e,t.glow.visible=!e;for(let t of Np.values())e&&(t.visible=!1)}function ug(e,t){let n=K.placed.find(n=>n.x===e&&n.z===t);if(n){mg(n);return}let r=ag(Xu);if(K.placed.length>=$h()||Au<r)return;qd(-r);let i={id:crypto.randomUUID(),type:Xu,x:e,z:t,upgrades:{},spent:r};K.placed.push(i),Kh(),rg(i),dg()}function dg(){Hc.disabled=$,zc.textContent=`$${za(Au)}`,Bc.textContent=`✦ ${za(ju)}`,Vc.textContent=`${K.placed.length}/${$h()}`,Rc.innerHTML=K.unlocked.length?K.unlocked.map(e=>`<article class="building-card"><img class="asset-card-art" src="${io(e)}" alt=""><strong>${ca.types[e].name}</strong><small>${I(`building.build_cost`,{cost:za(ag(e))})}</small><span class="building-unlocked-state">${I(`building.unlocked`)}</span></article>`).join(``):`<p class="building-draft-copy">${I(`building.none_unlocked`)}</p>`,Qh(),Xc.innerHTML=K.unlocked.map(e=>`<button data-select-building="${e}" class="${Xu===e?`selected`:``}" type="button" aria-label="${ca.types[e].name} · ${I(`building.level`,{level:eg(e)})}"><img src="${io(e)}" alt=""><small>${I(`building.level`,{level:eg(e)})}</small></button>`).join(``),Yc.textContent=H_()?`${K.placed.length}/${$h()}`:I(`building.build_mode_slots`,{used:K.placed.length,total:$h()}),sg()}function fg(){$||!K.unlocked.length||(Jp.set(0,0),Yp=28,Yu=!0,Xu=K.unlocked[0],lg(!0),rs.classList.add(`hidden`),Jc.classList.remove(`hidden`),dg())}function pg(){Yu=!1,Xp.clear(),Zp=null,Xu=null,lg(!1),Zc.classList.add(`hidden`),Jc.classList.add(`hidden`),rs.classList.remove(`hidden`),$c.classList.add(`hidden`)}function mg(e){let t=ca.types[e.type];$c.innerHTML=`<button class="upgrade-close" data-close-building-upgrade="1" type="button" aria-label="${I(`building.upgrade`)}">×</button><p class="eyebrow">${I(`building.installed_defense`)}</p><h3>${t.name}</h3><p class="building-upgrade-summary">${I(`building.choose_upgrade`)}</p><div class="upgrade-grid">${Object.entries(t.upgrades).map(([t,n])=>{let r=e.upgrades[t]??0,i=tg(e,t);return`<button data-upgrade-building="${e.id}" data-upgrade-key="${t}" type="button"><span>${n.name}</span><strong>${I(`building.upgrade_level`,{current:r,next:r+1})}</strong><small>$${za(i)}</small></button>`}).join(``)}</div><button data-destroy-building="${e.id}" class="demolish-button" type="button">${I(`building.demolish_refund`,{amount:za(ng(e))})}</button>`,$c.classList.remove(`hidden`)}function hg(e,t){let n=ca.types[e.type],r=t===`interval`?`frequency`:t,i=(n.upgrades[r]?.step??0)*(e.upgrades[r]??0),a=t===`slow`?(n.upgrades.effectiveness?.step??0)*(e.upgrades.effectiveness??0):0;return(n.effect[t]??0)+i+a}function gg(e,t){return e.type===`overclockRelay`||t===`count`?1:1+K.placed.filter(t=>t.type===`overclockRelay`&&t.id!==e.id&&t_(e,t)<=hg(t,`range`)).reduce((e,t)=>e+hg(t,`effectiveness`),0)}function _g(e,t){let n=hg(e,t),r=gg(e,t);return t===`interval`||t===`period`?n/r:n*r}function vg(e,t=!0){X.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Pg(e);let n=Q.indexOf(e);n>=0&&Q.splice(n,1),n>=0&&t&&Ph()}function yg(){let e=Math.random()*Math.PI*2,t=Math.max(1,pp()-M.obstacleColliderRadius);return new E(Math.cos(e)*t,M.obstacleGroundHeight,Math.sin(e)*t)}function bg(){return da(ke)}function xg(e,t,n){let r=bg(),i=new E(e.x,1.4,e.z),a=t.position.clone().setY(.48),o=a.clone().sub(i).setY(0).normalize(),s=new E(-o.z,0,o.x).multiplyScalar((Math.random()-.5)*2.2),c=i.clone().lerp(a,.48).add(s);c.y=3.2+Math.random()*1.1,r.position.copy(i),X.add(r),_m.push({mesh:r,target:t,start:i,control:c,speed:n,age:0,duration:Math.max(1.35,Math.min(4.5,i.distanceTo(a)/Math.max(n,1)))})}function Sg(e){for(let t of K.placed){if(t.type!==`barrierNode`||Ju.get(t.id)?.active<=0)continue;let n=_g(t,`range`)+e.userData.colliderRadius+.08,r=e.position.x-t.x,i=e.position.z-t.z,a=Math.hypot(r,i);if(a>=n)continue;let o=a>.001?r/a:1,s=a>.001?i/a:0;e.position.x=t.x+o*n,e.position.z=t.z+s*n,mp(e.position)}}function Cg(e,t){for(let t=_m.length-1;t>=0;--t){let n=_m[t];if(n.age+=e,!Q.includes(n.target)){X.remove(n.mesh),_m.splice(t,1);continue}let r=n.target.position.clone().setY(.48),i=Math.min(n.age/n.duration,1),a=1-i,o=n.start.clone().multiplyScalar(a*a).addScaledVector(n.control,2*a*i).addScaledVector(r,i*i),s=Math.min(i+.025,1),c=1-s,l=n.start.clone().multiplyScalar(c*c).addScaledVector(n.control,2*c*s).addScaledVector(r,s*s);n.mesh.position.copy(o),n.mesh.lookAt(l);for(let t of n.mesh.userData.rotors)t.rotation.y+=e*38;i>=1&&(Q.includes(n.target)&&(i_(n.target.position,.52),vg(n.target)),X.remove(n.mesh),_m.splice(t,1))}for(let t=dm.length-1;t>=0;--t){let n=dm[t];if(n.age+=e,!Q.includes(n.target)){X.remove(n.mesh),dm.splice(t,1);continue}let r=n.target.position.clone().sub(n.mesh.position);r.y=0;let i=r.length();i>.001&&n.direction.lerp(r.multiplyScalar(1/i),1-Math.exp(-12*e)).normalize(),n.mesh.position.addScaledVector(n.direction,14*e),n.mesh.rotation.x+=e*12,n.mesh.scale.setScalar(.85+Math.sin(n.age*28)*.12),i<=M.obstacleColliderRadius+.24?(X.remove(n.mesh),Q.indexOf(n.target)>=0&&(i_(n.target.position,.58),vg(n.target)),dm.splice(t,1)):n.age>2.5&&(X.remove(n.mesh),dm.splice(t,1))}for(let n of K.placed){let r=Ju.get(n.id);if(!r)continue;let i=qu.get(n.id),a=ca.types[n.type];r.timer+=e,r.effectRing.rotation.z+=e*1.4;let o=a.effect.range?_g(n,`range`):0;if(r.effectRing.scale.setScalar(o),r.effectRing.material.opacity=.12+Math.sin(t*3)*.06,n.type===`overclockRelay`&&(r.effectRing.material.opacity=.3+Math.sin(t*6)*.12,i.rotation.y+=e*.7),n.type===`droneBay`&&r.timer>=Math.max(2,_g(n,`period`))){r.timer=0;let e=[...Q].sort(()=>Math.random()-.5).slice(0,Math.floor(_g(n,`count`)));for(let t of e)xg(n,t,_g(n,`droneSpeed`));e.length&&vf.playBuildingEffect(i.position,n.type)}if(n.type===`barrierNode`){let a=Math.max(2,_g(n,`period`));r.timer>=a&&(r.timer=0,r.active=_g(n,`duration`),vf.playBuildingEffect(i.position,n.type)),r.active=Math.max(0,r.active-e),r.barrierField&&(r.barrierField.visible=r.active>0,r.barrierField.scale.set(o,1,o),r.barrierField.rotation.y+=e*1.8,r.barrierField.children[0].material.opacity=r.active>0?.14+Math.sin(t*10)*.05:0),r.effectRing.material.opacity=r.active>0?.58:.12}if(n.type===`salvageExtractor`&&r.timer>=Math.max(3,_g(n,`period`))){r.timer=0;let e=Q.filter(e=>t_(e.position,n)<=o).sort(()=>Math.random()-.5).slice(0,Math.floor(_g(n,`count`)));for(let t of e){let e=M.cellCashValue*Wd().cashValueMultiplier*(1+J(`cashMultiplier`))+_g(n,`cash`);zu()||wg({position:{x:t.position.x,y:M.playerStartHeight,z:t.position.z},cashValue:e}),i_(t.position,.42),vg(t)}e.length&&vf.playBuildingEffect(i.position,n.type)}if(n.type===`autocannon`&&r.timer>=Math.max(.35,_g(n,`interval`))){r.timer=0;let e=Q.filter(e=>t_(e.position,n)<=o).sort((e,t)=>t_(e.position,n)-t_(t.position,n))[0];if(e){let t=e.position.clone().sub(i.position);t.y=0,t.normalize(),i.rotation.y=Math.atan2(t.x,t.z);let r=nh();r.position.copy(i.position).addScaledVector(t,.95),r.position.y=.7,X.add(r),dm.push({mesh:r,direction:t,destination:e.position.clone().setY(.7),target:e,age:0}),vf.playBuildingEffect(i.position,n.type)}}}}function wg(e){let t=ih();e?t.position.set(e.position.x,e.position.y,e.position.z):t.position.copy(Gh(M.cellMinDistance)),e||(t.position.y=M.playerStartHeight),t.userData.phase=e?.phase??Math.random()*Math.PI*2,t.userData.cashValue=e?.cashValue??M.cellCashValue*Wd().cashValueMultiplier*(1+J(`cashMultiplier`)),X.add(t),$p.push(t)}function Tg(e){if(em.length>0)return;let t=Ya.artifacts.find(e=>e.requirement.type===`hidden-world-map`),n=!!e?.isMapToEarth||!!(!e&&t&&U+1>=t.requirement.minSector&&!V.unlocked.includes(t.id)&&Math.random()<t.requirement.chance),r=n?Eg():ah();e?r.position.set(e.position.x,e.position.y,e.position.z):r.position.copy(Gh(M.chronoCellMinDistance)),e||(r.position.y=M.playerStartHeight),r.userData.phase=e?.phase??Math.random()*Math.PI*2,r.userData.age=e?.age??0,r.userData.isMapToEarth=n,X.add(r),em.push(r)}function Eg(){let e=new l(new le(P.chronoCellRadius*1.18,20,14),new c({color:`#378ac3`,emissive:`#0b385d`,emissiveIntensity:2.4,metalness:.28,roughness:.48,transparent:!0}));return e.add(new y(new se(new le(P.chronoCellRadius*1.21,10,7)),new u({color:`#83e9cf`,transparent:!0,opacity:.72}))),e}function Dg(e,t){let n=oh(e);t?n.position.set(t.position.x,t.position.y,t.position.z):(n.position.copy(Gh(M.cellMinDistance)),n.position.y=M.playerStartHeight),n.userData.type=e,X.add(n),pm.push(n)}function Og(e,t){e===`speed`&&(Vm=M.speedBoosterBaseDuration+J(`speedBoosterDuration`)),e===`thorn`&&(Hm=M.thornShieldBaseDuration+J(`thornShieldDuration`)),e===`freezer`&&(Um=M.freezerBaseDuration+J(`freezerDuration`)),vf.playBoosterPickup(t,e)}function kg(e){jg(Gh(M.obstacleMinDistance),e)}function Ag(e){let t=zu()?Ru():null,n=Wd(),r=(t?.enemyTypes??n.availableObstacleTypes).map(e=>({type:e,weight:t?.enemySpawnWeights?.[e]??n[`${e}SpawnWeight`]??0})),i=r.reduce((e,t)=>e+t.weight,0),a=Math.random()*i,o=e?.type??r[r.length-1].type;for(let t of e?[]:r)if(a-=t.weight,a<=0){o=t.type;break}for(let e of rm)e.mesh.visible=!hidden,e.arrow.visible=!hidden&&e.phase===`telegraph`,e.trail.visible=!hidden;let s=e?.position??(t&&o!==`regular`?yg():Gh(M.obstacleMinDistance)),c=Ii[o],u=new l(new Oe(P.spawnRingInnerRadius,P.spawnRingOuterRadius,P.spawnRingSegments),new S({color:c.color,transparent:!0,opacity:F.spawnRingBaseOpacity,side:2,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.set(s.x,.03,s.z);let d=new l(new ne(P.spawnCueGlowRadius,P.spawnRingSegments),new S({color:c.color,transparent:!0,opacity:F.spawnCueGlowBaseOpacity,depthWrite:!1}));d.rotation.x=-Math.PI/2,d.position.set(s.x,.02,s.z);let f=new l(new Ge(.42,1.12,P.spawnCueBeamHeight,P.spawnRingSegments,1,!0),new S({color:c.color,transparent:!0,opacity:F.spawnCueBeamBaseOpacity,side:2,depthWrite:!1}));f.position.set(s.x,P.spawnCueBeamHeight/2,s.z),X.add(u,d,f),ym.push({ring:u,glow:d,beam:f,position:s,type:o,age:e?.age??0}),e||vf.playObstacleSummon(s)}function jg(e,t,n){let r=Ii[t],i=sh(new c({color:r.color,emissive:r.emissive,emissiveIntensity:t===`spore`?2.3:1,metalness:P.obstacleMetalness,roughness:P.obstacleRoughness}),t);i.position.copy(e),i.position.y=M.obstacleGroundHeight,i.userData.type=t,i.userData.id=n?.id??crypto.randomUUID(),i.userData.age=n?.age??0,i.userData.lifetimeAge=n?.lifetimeAge??0,i.userData.speed=n?.speed??C.randFloat(.8,1.45),i.userData.pulseTimer=n?.pulseTimer??0,i.userData.bangerFlash=0,i.userData.shotCooldown=n?.shotCooldown??0,i.userData.teleportTimer=n?.teleportTimer??0,i.userData.poisonTrailTimer=n?.poisonTrailTimer??0,i.userData.teleportTarget=n?.teleportTarget?new E(n.teleportTarget.x,n.teleportTarget.y,n.teleportTarget.z):null,i.userData.colliderRadius=M.obstacleColliderRadius,i.userData.electronStunnedOnce=!!n?.electronStunnedOnce;let a=new o,s=new S({color:`#fff3a6`,transparent:!0,opacity:.9,depthWrite:!1});for(let e=0;e<3;e+=1){let t=new l(new Me(.13,0),s.clone()),n=e*Math.PI*2/3;t.position.set(Math.cos(n)*.42,Math.sin(e*2.2)*.09,Math.sin(n)*.42),t.rotation.set(Math.PI/4,n,Math.PI/4),a.add(t)}a.position.y=1.08,a.visible=!1,i.add(a),i.userData.stunStars=a;let u=new o,d=new S({color:`#c59cff`,transparent:!0,opacity:.76,depthWrite:!1}),f=new l(new ve(.28,.028,6,18),d);f.rotation.x=Math.PI/2,u.add(f);for(let e of[Math.PI/4,-Math.PI/4]){let t=new l(new je(.48,.04,.035),d.clone());t.rotation.y=e,u.add(t)}if(u.position.y=1.08,u.visible=i.userData.electronStunnedOnce,i.add(u),i.userData.electronImmunityMarker=u,t===`chaser`||t===`banger`||t===`shooter`||t===`magnet`){let t=new l(new Oe(r.range-P.chaserRangeIndicatorWidth,r.range,P.chaserRangeIndicatorSegments),new S({color:r.color,transparent:!0,opacity:F.chaserRangeIndicatorBaseOpacity,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.025,e.z),i.userData.rangeIndicator=t,X.add(t)}if(t===`magnet`){let t=new l(new Oe(.18,.3,P.chaserRangeIndicatorSegments),new S({color:N.slowAura,transparent:!0,opacity:.5,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.035,e.z),i.userData.magnetPulse=t,i.userData.magnetPulsePhase=n?.magnetPulsePhase??Math.random(),X.add(t)}X.add(i),Q.push(i),t===`porter`&&i.userData.teleportTarget&&Ng(i)}function Mg(){let e=Math.random()*Math.PI*2,t=C.randFloat(P.porterTeleportMinDistance,P.porterTeleportMaxDistance);return mp(new E(Z.position.x+Math.cos(e)*t,M.obstacleGroundHeight,Z.position.z+Math.sin(e)*t))}function Ng(e){let t=e.userData.teleportTarget,n=new l(new Oe(.4,.65,32),new S({color:N.porter,transparent:!0,opacity:.8,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(t.x,.04,t.z);let r=new l(new Ge(.18,.7,2.8,20,1,!0),new S({color:N.porter,transparent:!0,opacity:.25,side:2,depthWrite:!1}));r.position.set(t.x,1.4,t.z),e.userData.teleportEffect={ring:n,beam:r},X.add(n,r)}function Pg(e){let t=e.userData.teleportEffect;t&&X.remove(t.ring,t.beam),e.userData.teleportEffect=null}function Fg(e,t,n=1,r={}){let i=n===1?.6:.4,a=sh(new c({color:N.spore,emissive:N.sporeEmissive,emissiveIntensity:3*i,metalness:P.obstacleMetalness,roughness:P.obstacleRoughness}),`spore`);a.userData.hdrEmissionScale=i,a.scale.setScalar(n===1?P.sporeFragmentScale:P.sporeFragmentChildScale),a.position.copy(e),X.add(a),fm.push({spore:a,direction:t.clone(),generation:n,age:r.age??0})}function Ig(e,t=1){let n=t===1?P.sporeFragmentCount:P.sporeFragmentChildCount,r=Math.random()*Math.PI*2;for(let i=0;i<n;i+=1){let a=r+i*(Math.PI*2/n);Fg(new E(e.x,M.playerStartHeight,e.z),new E(Math.cos(a),0,Math.sin(a)),t)}}function Lg(e){let t=e.position.clone();X.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Pg(e);let n=Q.indexOf(e);n>=0&&Q.splice(n,1),Ig(t)}function Rg(e){let t=th();t.position.set(e.position.x,M.playerStartHeight,e.position.z);let n=zu(),r=(n?rp.position:Z.position).clone().sub(t.position);r.y=0,r.lengthSq()===0?r.set(0,0,1):r.normalize(),t.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),X.add(t),um.push({projectile:t,direction:r,age:0,distanceTravelled:0,maxRange:_d(`shooter`,Ii.shooter.range),targetTower:n})}function zg(){for(let e=0;e<M.obstacleColliderIterations;e+=1)for(let e=0;e<Q.length-1;e+=1){let t=Q[e];for(let n=e+1;n<Q.length;n+=1){let r=Q[n],i=t.userData.colliderRadius+r.userData.colliderRadius,a=r.position.x-t.position.x,o=r.position.z-t.position.z,s=a*a+o*o;if(s>=i*i)continue;let c=Ii[t.userData.type],l=Ii[r.userData.type];t.userData.type===`creeper`&&l.speed===0&&(t.userData.staticCollisionSlow=M.creeperStaticCollisionSlowDuration),r.userData.type===`creeper`&&c.speed===0&&(r.userData.staticCollisionSlow=M.creeperStaticCollisionSlowDuration);let u=Math.sqrt(s),d=u>.001?a/u:(e+n)%2?1:-1,f=u>.001?o/u:0,p=(i-u)/2;t.position.x-=d*p,t.position.z-=f*p,r.position.x+=d*p,r.position.z+=f*p,mp(t.position),mp(r.position)}}}function Bg(){if(Gm>0)return;let e=Wd(),t=e.availableFallingRockTypes.map(t=>({type:t,weight:e[`${t}SpawnWeight`]??0})),n=t.reduce((e,t)=>e+t.weight,0),r=Math.random()*n,i=t[t.length-1].type;for(let e of t)if(r-=e.weight,r<=0){i=e.type;break}let a=Z.position.clone();a.x+=C.randFloatSpread(M.fallingRockImpactOffset*2),a.z+=C.randFloatSpread(M.fallingRockImpactOffset*2),mp(a),Vg(a,void 0,i)}function Vg(e,t,n=t?.type??`stoneRock`){let r=Li[n],i=new l(eh,new c({color:r.color,emissive:r.emissive,emissiveIntensity:r.emissiveIntensity,metalness:P.fallingObstacleMetalness,roughness:P.fallingObstacleRoughness}));i.position.set(e.x,M.fallingBlockStartHeight,e.z),i.castShadow=!0;let a=new l(new ne(1.15,32),new S({color:N.targetShadow,transparent:!0,opacity:.7,depthWrite:!1}));a.rotation.x=-Math.PI/2,a.position.set(e.x,.025,e.z);let o=new l(new Oe(1.18,1.3,32),new S({color:N.targetRing,transparent:!0,opacity:.95,side:2,depthWrite:!1}));o.rotation.x=-Math.PI/2,o.position.set(e.x,.03,e.z),X.add(i,a,o),nm.push({obstacle:i,shadow:a,targetRing:o,target:e.clone(),type:n,age:t?.age??0,landed:t?.landed??!1,impactTriggered:t?.impactTriggered??!1}),t||vf.playFallingObstacle(e)}function Hg(e){let t=Ri[e];if(!t)return;let n=Math.random()*Math.PI*2,r=new E(Math.cos(n),0,Math.sin(n)),i=pp()+t.edgeOffset,a=r.clone().multiplyScalar(-i).setY(M.playerStartHeight),o=r.clone().multiplyScalar(i).setY(M.playerStartHeight),s=o.clone().sub(a).normalize(),c=a.distanceTo(o),u=pa(ke);u.scale.setScalar(t.scale),u.position.copy(a),u.rotation.y=Math.atan2(s.x,s.z);let d=new Ce(s,new E(a.x,.08,a.z),c,t.eyeColor,1.1,.54);d.line.material.transparent=!0,d.line.material.opacity=.82,d.cone.material.transparent=!0,d.cone.material.opacity=.94;let f=new l(new Ge(t.sweepRadius,t.sweepRadius,c,12,1,!0),new S({color:t.emissive,transparent:!0,opacity:.05,depthWrite:!1}));f.position.copy(a).add(o).multiplyScalar(.5),f.position.y=.13,f.quaternion.setFromUnitVectors(new E(0,1,0),s),X.add(u,d,f),rm.push({type:e,config:t,mesh:u,arrow:d,trail:f,start:a,end:o,direction:s,phase:`telegraph`,age:0,draggingPlayer:!1})}function Ug(e){X.remove(e.mesh,e.arrow,e.trail);let t=rm.indexOf(e);t>=0&&rm.splice(t,1)}function Wg(e,t,n){for(let r=$p.length-1;r>=0;--r)n_($p[r].position,e,t)>n||(X.remove($p[r]),$p.splice(r,1));for(let r=em.length-1;r>=0;--r)n_(em[r].position,e,t)>n||(X.remove(em[r]),em.splice(r,1));for(let e=tm.length-1;e>=0;--e){let t=tm[e];t.rotation.y+=delta*1.7,t.position.y=M.playerStartHeight+Math.sin(total*3.4+t.userData.phase)*.18,t.userData.ring.rotation.z+=delta*2.5,t.position.distanceTo(Z.position)<M.cellPickupRadius&&(Yd(1),Zd(t.position,`+1 AETHERIUM`,`aetherium-indicator`),X.remove(t),tm.splice(e,1))}}function Gg(e,t){for(let n of[...rm]){if(n.age+=e,n.phase===`telegraph`){let e=.65+(Math.sin(t*11)+1)*.18;n.arrow.line.material.opacity=e,n.arrow.cone.material.opacity=Math.min(1,e+.2),n.trail.material.opacity=.04+(Math.sin(t*8)+1)*.025,n.age>=n.config.telegraphDuration&&(n.phase=`charge`,n.arrow.visible=!1,n.trail.material.opacity=.48);continue}let r=n.mesh.position.clone();n.mesh.position.addScaledVector(n.direction,n.config.speed*e),n.mesh.rotation.z=Math.sin(t*18)*.1;let i=n.mesh.userData.eyeMaterial;i&&(i.emissiveIntensity=3.2+Math.sin(t*24)*1.4);for(let r of n.mesh.userData.mandibles??[])r.rotation.z+=Math.sin(t*16+r.position.x)*e*.7;if(Wg(r,n.mesh.position,n.config.sweepRadius),$&&n_(Z.position,r,n.mesh.position)<=n.config.sweepRadius+M.playerRadius*.4){let e=Im>0||Lm>0;S_(`VOID REAPER`),n.draggingPlayer||=e&&$}n.draggingPlayer&&$&&(Z.position.copy(n.mesh.position).addScaledVector(n.direction,-n.config.sweepRadius*.4),Z.position.y=M.playerStartHeight,mp(Z.position)),n.mesh.position.clone().sub(n.end).dot(n.direction)>=0&&Ug(n)}}function Kg(e,t){bm.set(e.toLocaleLowerCase(),{id:e,spawn:t})}function qg(){for(let e of Object.keys(Ii))Kg(e,()=>jg(Mg(),e));for(let e of Object.keys(Li))Kg(e,()=>Vg(Mg(),void 0,e));for(let e of Object.keys(Ri))Kg(e,()=>Hg(e))}qg();function Jg(e,t){let n=new l(new Ge(M.fieryRockFireRadius,M.fieryRockFireRadius*.82,.06,32),new S({color:N.fire,transparent:!0,opacity:.34,depthWrite:!1}));n.position.set(e.x,.05,e.z);let r=mh(e,M.fieryRockFireRadius);X.add(n,...r.emitters,r.light),im.push({ground:n,...r,position:e.clone(),age:t?.age??0})}function Yg(){let e=new o,n=new l(new ee(.38,1),new c({color:`#9af8ff`,emissive:`#4f5dff`,emissiveIntensity:2.8,metalness:.5,roughness:.14})),r=new l(new ee(.52,1),new S({color:`#b9faff`,transparent:!0,opacity:.24,wireframe:!0,depthWrite:!1})),i=new l(new ve(.58,.025,8,28),new S({color:`#c8ffff`,transparent:!0,opacity:.9,depthWrite:!1}));i.rotation.x=Math.PI/2;let a=new t(`#74eaff`,3.5,5);return e.add(n,r,i,a),e.userData.ring=i,e}function Xg(e){let t=Yg();t.position.set(e?.position?.x??0,M.playerStartHeight,e?.position?.z??0),t.userData.phase=e?.phase??Math.random()*Math.PI*2,X.add(t),tm.push(t)}function Zg(e,t){let n=M.poisonTrailDuration*(1-J(`poisonTrailDurationReduction`)),r=fh(e,P.poisonCreeperTrailRadius,n);X.add(...r.emitters),am.push({...r,position:e.clone(),age:t?.age??0})}function Qg(e,t,n=0){let r=rh();r.position.copy(e),X.add(r),om.push({piece:r,direction:t,age:n})}function $g(e){let t=Math.random()*Math.PI*2;for(let n=0;n<M.splinterPieceCount;n+=1){let r=t+n*(Math.PI*2/M.splinterPieceCount)+C.randFloatSpread(.35);Qg(new E(e.x,.72,e.z),new E(Math.cos(r),0,Math.sin(r)))}}function e_(e){for(let t of e)X.remove(t);e.length=0}function t_(e,t){return Math.hypot(e.x-t.x,e.z-t.z)}function n_(e,t,n){let r=n.x-t.x,i=n.z-t.z,a=r*r+i*i;if(a===0)return Math.hypot(e.x-t.x,e.z-t.z);let o=C.clamp(((e.x-t.x)*r+(e.z-t.z)*i)/a,0,1);return Math.hypot(e.x-(t.x+r*o),e.z-(t.z+i*o))}function r_(e,t,n){let r=sd(`unlock-orbital-electron`)>0&&!Yu&&!Cm;if(Pp.visible=r,Lp.visible=r,!r)return!1;Rp+=e*(M.orbitalElectronBaseSpeed+J(`electronSpeed`));let i=M.orbitalElectronOrbitRadius*n;Pp.position.set(Z.position.x+Math.cos(Rp)*i,Z.position.y+.12+Math.sin(t*9)*.08,Z.position.z+Math.sin(Rp)*i),Pp.rotation.y+=e*8,Fp.scale.setScalar(.9+Math.sin(t*12)*.18);let a=Ip.attributes.position.array;for(let e=0;e<=8;e+=1){let n=e/8,r=e===0||e===8?0:Math.sin(t*34+e*4.7)*.12;a[e*3]=C.lerp(Z.position.x,Pp.position.x,n)+Math.sin(Rp)*r,a[e*3+1]=C.lerp(Z.position.y,Pp.position.y,n)+(e%2?.08:-.06)+r*.3,a[e*3+2]=C.lerp(Z.position.z,Pp.position.z,n)-Math.cos(Rp)*r}return Ip.attributes.position.needsUpdate=!0,Lp.material.opacity=.55+Math.sin(t*18)*.22,zp.copy(Pp.position),!0}function i_(e,t){let n=ch(e,t);X.add(...n.emitters,n.light),sm.push({...n,radius:t,age:0})}function a_(e,t,n){let r=lh(e);X.add(r),lm.push({pulse:r,radius:t,age:0}),vf.playBangerPulse(n,e)}function o_(e,t,n=0,r=[]){let i=uh(e);X.add(i),mm.push({shockwave:i,origin:e.clone(),radius:t,age:n,affected:new Set(Q.filter(e=>r.includes(e.userData.id)))})}function s_(){let e=M.shockwaveBaseRadius*(1+J(`effectRange`));o_(Z.position,e)}function c_(e){let t=ph(e);X.add(...t.emitters,t.light),vm.push({...t,age:0})}function l_(e){for(let t=vm.length-1;t>=0;--t){let n=vm[t];n.age+=e;let r=Math.min(n.age/M.playerDeathVfxDuration,1);n.light.intensity=22*(1-r),r===1&&(X.remove(...n.emitters,n.light),vm.splice(t,1))}}function u_(e){let t=e.position.clone(),n=_d(`banger`,Ii.banger.range),r=J(`bangerEnemyDestroyChance`),i=t_(Z.position,t)<=n;for(let i=Q.length-1;i>=0;--i){let a=Q[i];(a===e||t_(a.position,t)<=n&&Math.random()<r)&&(X.remove(a,a.userData.rangeIndicator,a.userData.magnetPulse),Q.splice(i,1))}i_(t,n),i&&S_(`BANGER DETONATION`)}function d_(e){let t=ta.challenges.find(e=>e.id===Fu?.challengeId);if(!t||t.type!==`cell-scout`)return;let n=e?new E(e.x,e.y,e.z):new E().setFromCylindricalCoords(Math.min(pp()-1.2,7.5),Math.random()*Math.PI*2,M.playerStartHeight);Sp.player.position.copy(n),Sp.player.rotation.y=e?.heading??0,Sp.player.visible=!0,Sp.slowAuraRing.visible=!1,Sp.shieldBubble.visible=!1,Sp.active=!0,X.add(Sp.player)}function f_(e,t){if(!Sp.active)return;let n=$p.reduce((e,t)=>!e||t_(t.position,Sp.player.position)<t_(e.position,Sp.player.position)?t:e,null);if(n){let t=n.position.clone().sub(Sp.player.position);if(t.y=0,t.lengthSq()>0&&(t.normalize(),Sp.player.position.addScaledVector(t,E_()*.65*e),Sp.player.rotation.y=Math.atan2(t.x,t.z)),Sp.player.position.distanceTo(n.position)<M.cellPickupRadius){let e=$p.indexOf(n);e>=0&&(X.remove(n),$p.splice(e,1))}}Sp.updateVisuals(e,t,F.playerRingSpinSpeed)}function p_(e=!0){e_($p),e_(em),e_(tm),e_(pm);for(let e of Q)X.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),Pg(e);Q.length=0;for(let e of fm)X.remove(e.spore);fm.length=0;for(let e of nm)X.remove(e.obstacle,e.shadow,e.targetRing);nm.length=0;for(let e of rm)X.remove(e.mesh,e.arrow,e.trail);rm.length=0;for(let e of im)X.remove(e.ground,...e.emitters,e.light);im.length=0;for(let e of am)X.remove(...e.emitters);am.length=0;for(let e of om)X.remove(e.piece);om.length=0;for(let e of sm)X.remove(...e.emitters,e.light);sm.length=0;for(let e of cm)X.remove(...e.emitters,e.light);cm.length=0;for(let e of lm)X.remove(e.pulse);lm.length=0;for(let e of um)X.remove(e.projectile);um.length=0;for(let e of dm)X.remove(e.mesh);dm.length=0;for(let e of _m)X.remove(e.mesh);_m.length=0;for(let e of mm)X.remove(e.shockwave);mm.length=0;for(let e of gm)X.remove(e.ring,e.glow);gm.length=0,hm.length=0;for(let e of vm)X.remove(...e.emitters,e.light);vm.length=0;for(let e of ym)X.remove(e.ring,e.glow,e.beam);ym.length=0,X.remove(Sp.player),Sp.player.visible=!1,Sp.active=!1,Z.position.set(0,M.playerStartHeight,zu()?3:0),Z.rotation.y=0,_p=0,Z.visible=!0,Rp=0,Pp.visible=!1,Lp.visible=!1,Em=0,Om=0,km=0,Am=0,jm=0,Mm=0,Nm=0,Pm=0,Im=sd(`shield`),Lm=0,Bm=0,Vm=0,Hm=0,Um=0,Wm=0,Gm=0,Km=0,qm=0,Jm=0,Ym=0,Cp.visible=!1,Op.visible=!1,kp.visible=!1,Mp.visible=!1;for(let e of Np.values())e.visible=!1,e.geometry.setDrawRange(0,0);for(let e of Dp)e.visible=!1;for(let e of Xm)X.remove(e.trail);Xm.length=0,Zm.clear();let t=zu()?Ru():null;if(Lu=t?.towerHitpoints??0,rp.visible=!!t,$o.classList.toggle(`hidden`,!t),Rf(),xp.visible=Im>0,Xo.textContent=`000`,e){if(!t){for(let e=0;e<M.initialCellCount+J(`initialCellCount`);e+=1)wg();for(let e of M.initialObstacleTypes)Wd().availableObstacleTypes.includes(e)&&kg(e)}d_()}}function m_(e){return{x:e.x,y:e.y,z:e.z}}function h_(){W={sectorIndex:U,anomalyRun:Fu,anomalyScout:Sp.active?{...m_(Sp.player.position),heading:Sp.player.rotation.y}:null,player:m_(Z.position),playerHeading:Z.rotation.y,score:Em,elapsed:Om,spawnTimer:km,chronoCellTimer:Am,aetheriumSpawnTimer:jm,obstacleSpawnTimer:Mm,hazardTimer:Nm,shockwaveTimer:Pm,shieldCharges:Im,shieldInvulnerability:Lm,towerHealth:Lu,boosterTimer:Bm,speedBoosterTime:Vm,thornShieldTime:Hm,freezerTime:Um,weaponCharges:Object.fromEntries(Qm),weaponRechargeTimers:Object.fromEntries($m),cells:$p.map(e=>({position:m_(e.position),phase:e.userData.phase,cashValue:e.userData.cashValue})),chronoCells:em.map(e=>({position:m_(e.position),phase:e.userData.phase,age:e.userData.age,isMapToEarth:!!e.userData.isMapToEarth})),aetheriumPickups:tm.map(e=>({position:m_(e.position),phase:e.userData.phase})),boosters:pm.map(e=>({type:e.userData.type,position:m_(e.position)})),obstacles:Q.map(e=>({id:e.userData.id,position:m_(e.position),type:e.userData.type,age:e.userData.age,lifetimeAge:e.userData.lifetimeAge,speed:e.userData.speed,pulseTimer:e.userData.pulseTimer,shotCooldown:e.userData.shotCooldown,teleportTimer:e.userData.teleportTimer,poisonTrailTimer:e.userData.poisonTrailTimer,teleportTarget:e.userData.teleportTarget&&m_(e.userData.teleportTarget),magnetPulsePhase:e.userData.magnetPulsePhase,electronStunnedOnce:e.userData.electronStunnedOnce})),spores:fm.map(e=>({position:m_(e.spore.position),direction:m_(e.direction),generation:e.generation,age:e.age})),shooterProjectiles:um.map(e=>({position:m_(e.projectile.position),direction:m_(e.direction),age:e.age,distanceTravelled:e.distanceTravelled,maxRange:e.maxRange,targetTower:!!e.targetTower})),fallingObstacles:nm.map(e=>({target:m_(e.target),type:e.type,age:e.age,landed:e.landed,impactTriggered:e.impactTriggered})),fireHazards:im.map(e=>({position:m_(e.position),age:e.age})),poisonTrails:am.map(e=>({position:m_(e.position),age:e.age})),splinterPieces:om.map(e=>({position:m_(e.piece.position),direction:m_(e.direction),age:e.age})),buildingRuntime:K.placed.map(e=>({id:e.id,timer:Ju.get(e.id)?.timer??0,active:Ju.get(e.id)?.active??0})),autocannonProjectiles:dm.map(e=>({position:m_(e.mesh.position),direction:m_(e.direction),destination:m_(e.destination),targetId:e.target.userData.id,age:e.age})),shockwaves:mm.map(e=>({origin:m_(e.origin),radius:e.radius,age:e.age,affectedIds:[...e.affected].map(e=>e.userData.id)})),shockwavePushes:hm.map(e=>({obstacleId:e.obstacle.userData.id,direction:m_(e.direction),distance:e.distance,remaining:e.remaining})),warnings:ym.map(e=>({position:m_(e.position),type:e.type,age:e.age}))},bu(W),v_()}function g_(){W=null,bu(null),v_()}function __(){if(!W)return!1;U=Math.min(W.sectorIndex??0,Tu()),Fu=ta.challenges.some(e=>e.id===W.anomalyRun?.challengeId)?W.anomalyRun:null,hp(),p_(!1),Z.position.set(W.player.x,W.player.y,W.player.z),Z.rotation.y=W.playerHeading??0,_p=Z.rotation.y,Em=W.score??0,Om=W.elapsed??0,km=W.spawnTimer??0,Am=W.chronoCellTimer??0,jm=W.aetheriumSpawnTimer??0,Mm=W.obstacleSpawnTimer??0,Nm=W.hazardTimer??0,Pm=W.shockwaveTimer??0,Im=W.shieldCharges??sd(`shield`),Lm=W.shieldInvulnerability??0,Lu=W.towerHealth??Ru()?.towerHitpoints??0,rp.visible=zu(),Bm=W.boosterTimer??0,Vm=W.speedBoosterTime??0,Hm=W.thornShieldTime??0,Um=W.freezerTime??0;for(let e of G.loadout.filter(e=>Af(e))){let t=Number(W.weaponCharges?.[e]);Qm.set(e,C.clamp(Number.isFinite(t)?t:1,0,Ff()));let n=Number(W.weaponRechargeTimers?.[e]);$m.set(e,Number.isFinite(n)?Math.max(0,n):0)}xp.visible=Im>0,d_(W.anomalyScout);for(let e of W.cells??[])wg(e);for(let e of W.chronoCells??[])Tg(e);for(let e of W.aetheriumPickups??[])Xg(e);for(let e of W.obstacles??[])jg(new E(e.position.x,e.position.y,e.position.z),e.type,e);for(let e of W.boosters??[])Dg(e.type,e);for(let e of W.spores??[])Fg(new E(e.position.x,e.position.y,e.position.z),new E(e.direction.x,e.direction.y,e.direction.z),e.generation??1,e);for(let e of W.shooterProjectiles??[]){let t=th();t.position.set(e.position.x,e.position.y,e.position.z),X.add(t),um.push({projectile:t,direction:new E(e.direction.x,e.direction.y,e.direction.z),age:e.age??0,distanceTravelled:e.distanceTravelled??0,maxRange:e.maxRange??_d(`shooter`,Ii.shooter.range),targetTower:!!e.targetTower})}for(let e of W.fallingObstacles??[])Vg(new E(e.target.x,e.target.y,e.target.z),e);for(let e of W.fireHazards??[])Jg(new E(e.position.x,e.position.y,e.position.z),e);for(let e of W.poisonTrails??[])Zg(new E(e.position.x,e.position.y,e.position.z),e);for(let e of W.splinterPieces??[])Qg(new E(e.position.x,e.position.y,e.position.z),new E(e.direction.x,e.direction.y,e.direction.z),e.age);for(let e of W.buildingRuntime??[]){let t=Ju.get(e.id);t&&(t.timer=e.timer??0,t.active=e.active??0)}for(let e of W.autocannonProjectiles??[]){let t=Q.find(t=>t.userData.id===e.targetId);if(!t)continue;let n=nh();n.position.set(e.position.x,e.position.y,e.position.z),X.add(n),dm.push({mesh:n,direction:new E(e.direction.x,e.direction.y,e.direction.z),destination:new E(e.destination.x,e.destination.y,e.destination.z),target:t,age:e.age??0})}for(let e of W.shockwaves??[])o_(new E(e.origin.x,e.origin.y,e.origin.z),e.radius,e.age??0,e.affectedIds??[]);for(let e of W.shockwavePushes??[]){let t=Q.find(t=>t.userData.id===e.obstacleId);t&&hm.push({obstacle:t,direction:new E(e.direction.x,e.direction.y,e.direction.z),distance:e.distance,remaining:e.remaining})}for(let e of W.warnings??[])Ag({...e,position:new E(e.position.x,e.position.y,e.position.z)});return w_(),!0}function v_(){ds.textContent=I(W?`menu.continue`:`menu.start_run`);let e=jh(),t=Eu(ta.unlockSector);fs.textContent=t?e?`${I(`anomaly.run`)} (${I(`anomaly.reward_claimed`)})`:I(`anomaly.run`):`${I(`anomaly.run`)} · ${I(`hud.sector`,{sector:Na(ta.unlockSector)})}`,fs.title=t?I(e?`anomaly.reward_claimed`:`anomaly.weekly`):I(`milestone.unlock_sector`,{sector:Na(ta.unlockSector)}),fs.disabled=!!W||e||!t||Sh}async function y_(){if(!Sh){Sh=!0,xh=null,ms.textContent=I(`anomaly.verifying_title`),hs.textContent=I(`anomaly.verifying_copy`),gs.hidden=!0,_s.hidden=!0,vs.hidden=!0,ys.hidden=!0,ps.classList.remove(`hidden`),v_();try{xh=await wh();let e=Eh(xh),t=kh(e);ms.textContent=`${t.name} (${I(`hud.sector`,{sector:Na(U+1)})})`,hs.textContent=t.description,gs.textContent=I(`anomaly.reward`,{cells:t.rewardCellTarget??ta.rewardCellTarget,reward:Ah(U)}),_s.textContent=I(`anomaly.reset`,{date:Oh(Dh(xh))}),gs.hidden=!1,_s.hidden=!1,jh(e)?(vs.textContent=I(`anomaly.reward_claimed`),vs.hidden=!1):ys.hidden=!1}catch{ms.textContent=I(`anomaly.time_unverified_title`),hs.textContent=I(`anomaly.time_unverified_copy`),vs.textContent=I(`anomaly.time_unverified_error`),vs.hidden=!1}finally{Sh=!1,v_()}}}function b_(){if(wm=!1,Tm=!1,Nu){g_(),Sm=!1,$=!1,gl.classList.add(`hidden`),os.textContent=`ASTEROID BELT`,os.classList.remove(`death-title`),Hh(),ls.textContent=I(`message.sandbox_closed`),us.hidden=!0,xs.classList.remove(`hidden`),Ps.classList.add(`hidden`),rs.classList.remove(`hidden`);return}h_(),Sm=!1,$=!1,gl.classList.add(`hidden`),os.textContent=`ASTEROID BELT`,os.classList.remove(`death-title`),Hh(),ls.textContent=I(`message.round_saved`),us.hidden=!0,xs.classList.remove(`hidden`),Ps.classList.add(`hidden`),rs.classList.remove(`hidden`)}function x_(){let e=Z.position.clone(),t=dh(e);X.add(...t.emitters,t.light),cm.push({...t,age:0}),vf.playShieldBreak(e),zm=Rm;let n=J(`shieldBreakExplosionRadius`);if(n<=0)return;let r=3+n;i_(e,r);for(let t=Q.length-1;t>=0;--t){let n=Q[t];t_(n.position,e)>r||vg(n)}}function S_(e=`SIGNAL LOST`){if(!$||Cm||Iu||Lm>0)return;if(Im>0){--Im,Lm=M.shieldInvulnerabilityDuration+J(`shieldInvulnerabilityDuration`),x_(),xp.visible=Im>0,xp.scale.setScalar(1.7);return}$=!1,wm=!1,Tm=!1,Cm=!0,Sm=!1,xp.visible=!1,c_(Z.position),Z.visible=!1,Pp.visible=!1,Lp.visible=!1,fc.classList.add(`hidden`),gl.classList.add(`hidden`),g_(),Qd();let t=Uh(e),n=e.toLocaleLowerCase().replace(/\s+(collision|detonation|projectile|impact|damage)$/,``);os.textContent=t?I(`message.killed_by`,{cause:``}).trim():I(`message.killed_by`,{cause:n.toUpperCase()}),os.classList.add(`death-title`),ls.textContent=I(`message.energy_secured`,{count:Em,cellWord:I(Em===1?`message.cell_singular`:`message.cell_plural`)}),us.textContent=I(`message.tip`,{tip:$l()}),us.hidden=!1,ds.textContent=I(`menu.run_again`),rs.classList.remove(`hidden`),Nl?.start(`first-loss`),Bu.researchLab&&sd(`player-speed-multiplier`)===0&&Nl?.start(`research-first-loss`),Po()}function C_(e){!zu()||!$||Cm||(e&&Mh(),$=!1,wm=!1,Tm=!1,Cm=!0,Sm=!1,g_(),Qd(),fc.classList.add(`hidden`),$o.classList.add(`hidden`),gl.classList.add(`hidden`),os.textContent=I(e?`anomaly.tower_defended`:`anomaly.tower_destroyed`),os.classList.toggle(`death-title`,!e),ls.textContent=I(e?`anomaly.tower_defended_copy`:`anomaly.tower_destroyed_copy`,{cells:Em}),us.hidden=!0,ds.textContent=I(`menu.run_again`),rs.classList.remove(`hidden`))}function w_(){Xo.textContent=String(Em).padStart(3,`0`),Zo.textContent=Nu?I(`hud.sandbox_sector`,{sector:Na(Nu.sectorIndex+1)}):`${I(`hud.sector`,{sector:Na(U+1)})}${Fu?I(`hud.anomaly_suffix`):``}`,Qo.innerHTML=`<span class="shield-indicators-label">${I(`hud.shields`)}</span>${Array.from({length:Im},()=>`<img src="${qo}" alt="">`).join(``)}`,Qo.hidden=Im===0,Qo.setAttribute(`aria-label`,`${Im} shield ${Im===1?`charge`:`charges`} remaining`);let e=zu()?Ru():null;$o.classList.toggle(`hidden`,!$||!e),e&&(es.textContent=I(`anomaly.tower_health`,{current:Lu,maximum:e.towerHitpoints}),ts.style.transform=`scaleX(${C.clamp(Lu/e.towerHitpoints,0,1)})`)}function T_(){return Ym>0||zu()}function E_(){return M.playerSpeed*(1+J(`playerSpeedMultiplier`))*(Vm>0?2:1)*(T_()?1.8:1)}function D_(e,t){for(let e of Zm.values())e.exposed=!1;let n=Wd(),r=zu()?Ru()?.difficultyMultiplier??1:1,i=C.lerp(.16,.03,U/Math.max(vu.length-1,1)),a=(M.regularObstacleLifetime+n.obstacleLifetimeOffset+Em*(M.regularObstacleLifetimeIncreasePerCell+n.obstacleLifetimeIncreasePerCellOffset))*Math.max(.5,1-J(`regularLifetimeDebuff`)),o=Math.max(1,a-Q.length*.1),s=Math.max(M.obstacleSpawnWarningDuration,(M.obstacleSpawnInterval+n.obstacleSpawnIntervalOffset-Em*(M.obstacleSpawnDecreasePerCell+n.obstacleSpawnDecreasePerCellOffset))*(1-i)/r),c=Math.max(1,Math.floor((M.obstacleSpawnCount+n.obstacleSpawnCountOffset+Em*n.obstacleSpawnCountIncreasePerCell)*M.difficultyPressureMultiplier*r)),l=new E(!!Vp.has(`KeyD`)-+!!Vp.has(`KeyA`)+Hp.x,0,!!Vp.has(`KeyS`)-+!!Vp.has(`KeyW`)+Hp.y);l.lengthSq()>0&&(l.normalize(),Z.position.addScaledVector(l,E_()*e),_p=Math.atan2(l.x,l.z));let u=Math.atan2(Math.sin(_p-Z.rotation.y),Math.cos(_p-Z.rotation.y));Z.rotation.y+=u*(1-Math.exp(-10*e)),mp(Z.position),vp.updateVisuals(e,t,F.playerRingSpinSpeed);let d=sd(`unlock-slow-aura`)>0,f=1+J(`effectRange`),p=M.slowAuraBaseRange*f,m=C.clamp(M.slowAuraBaseEffect+J(`slowAuraEffect`),0,.9);bp.visible=d,d&&(bp.scale.setScalar(p),bp.material.opacity=.22+Math.sin(t*3.5)*.08,bp.rotation.z+=e*.35);let h=r_(e,t,f);Lm>0&&(Lm=Math.max(0,Lm-e)),Vm=Math.max(0,Vm-e),Hm=Math.max(0,Hm-e),Um=Math.max(0,Um-e),Wm=Math.max(0,Wm-e),Gm=Math.max(0,Gm-e),Km=Math.max(0,Km-e),qm=Math.max(0,qm-e),Jm=Math.max(0,Jm-e),Ym=Math.max(0,Ym-e),zf(e);let g=Hf(`atmosphereShield`);if(Cp.visible=Gm>0,Gm>0){let n=g>0?Gm/g:0;wp.rotation.z+=e*2.7,Tp.rotation.z-=e*1.5,Cp.scale.setScalar(1+Math.sin(t*9)*.08),wp.material.opacity=.52+n*.38,Tp.material.opacity=.08+n*.18,Ep.material.opacity=.06+n*.18}if(Op.visible=T_(),kp.visible=T_(),T_()){Op.rotation.z+=e*5,Op.scale.setScalar(1+Math.sin(t*14)*.12),Op.material.opacity=.55+Math.sin(t*18)*.2,kp.rotation.y-=e*1.7,kp.scale.setScalar(1+Math.sin(t*16)*.14);for(let e of kp.children)e.material.opacity=.26+Math.sin(t*12+e.position.x*4)*.16}Mp.visible=Jm>0,Jm>0&&(Mp.material.rotation+=e*2.8,Mp.position.y=2.2+Math.sin(t*5)*.15,Mp.scale.setScalar(.65+Math.sin(t*7)*.08));for(let[e,n]of Dp.entries()){if(n.visible=qm>0,!n.visible)continue;let r=t*5+e*Math.PI*2/Dp.length;n.position.set(Math.cos(r)*2.2,.55+Math.sin(r*2)*.18,Math.sin(r)*2.2),n.scale.setScalar(.9+Math.sin(t*12+e)*.18),n.getWorldPosition(Bp);for(let e of[...Q])e.position.distanceTo(Bp)<=e.userData.colliderRadius+.3&&(i_(e.position,.42),vg(e))}for(let t=Xm.length-1;t>=0;--t){let n=Xm[t];n.age+=e,n.trail.material.opacity=Math.max(0,.95-n.age*2.5),n.age>=.4&&(X.remove(n.trail),Xm.splice(t,1))}for(let[t,n]of Np){let r=Hf(t),i=Uf(t),a=r>0?C.clamp(i/r,0,1):0;if(n.visible=a>0,!n.visible){n.geometry.setDrawRange(0,0);continue}n.position.set(Z.position.x,n.userData.height,Z.position.z);let o=n.geometry.index?.count??0;n.geometry.setDrawRange(0,Math.max(3,Math.floor(o*a/3)*3)),n.rotation.z-=e*(1.1+a),n.material.opacity=.28+a*.65}if(Wf(),yp.material.emissive.set(`#000000`),yp.material.emissiveIntensity=0,Im>0||Lm>0||Hm>0?(xp.visible=!0,xp.scale.setScalar(1+Math.sin(t*12)*.08+(Lm>0?.2:0)),xp.material.color.set(Hm>0?`#ff795f`:N.slowAura),xp.material.opacity=Hm>0||Lm>0?.65:.18):xp.visible=!1,sd(`unlock-shockwave`)>0){Pm+=e;let t=M.shockwaveBaseInterval/(1+J(`shockwaveFrequency`));Pm>=t&&(s_(),Pm=0)}Cg(e,t),f_(e,t);for(let n=$p.length-1;n>=0;--n){let r=$p[n];r.rotation.y+=e*F.cellSpinSpeed,r.position.y=F.cellBobBaseHeight+Math.sin(t*F.cellBobSpeed+r.userData.phase)*F.cellBobAmplitude;let i=J(`cellMagnetSpeed`),a=Z.position.clone().sub(r.position);if(a.y=0,Wm>0?a.lengthSq()>0&&r.position.addScaledVector(a.normalize(),22*e):i>0&&a.length()<=M.cellMagnetRange*f&&r.position.addScaledVector(a.normalize(),(M.cellMagnetBaseSpeed+i)*e),r.position.distanceTo(Z.position)<M.cellPickupRadius){vf.playCellCollect(r.position),X.remove(r),$p.splice(n,1);let e=(Jm>0?2:1)*Dm;Em+=e,Nu||(Kd(e),qd(r.userData.cashValue*e),Xd(r.position,r.userData.cashValue*e)),Mh()}}for(let n=pm.length-1;n>=0;--n){let r=pm[n];r.rotation.y+=e*3,r.position.y=M.playerStartHeight+Math.sin(t*4+n)*.16,r.position.distanceTo(Z.position)<M.cellPickupRadius&&(Og(r.userData.type,r.position),X.remove(r),pm.splice(n,1))}for(let n=em.length-1;n>=0;--n){let r=em[n];r.userData.age+=e;let i=M.chronoCellLifetime*(1+J(`chronoLifetimeMultiplier`)),a=r.userData.age/i;if(r.rotation.x+=e*F.chronoCellSpinSpeed,r.rotation.y+=e*F.chronoCellSpinSpeed*.7,r.position.y=F.cellBobBaseHeight+Math.sin(t*F.chronoCellBobSpeed+r.userData.phase)*F.chronoCellBobAmplitude,r.material.emissiveIntensity=P.chronoCellEmissiveIntensity+Math.sin(t*8)*.8,r.material.opacity=a>.7?1-(a-.7)/.3:1,r.userData.isMapToEarth)for(let e of r.children)e.material.opacity=r.material.opacity*.72;if(r.position.distanceTo(Z.position)<M.cellPickupRadius){if(vf.playCellCollect(r.position),r.userData.isMapToEarth){af(Ya.artifacts.find(e=>e.requirement.type===`hidden-world-map`))&&Zd(r.position,I(`artifact.acquired`),`chronoshard-indicator`),X.remove(r),em.splice(n,1);continue}let e=Jd(M.chronoCellChronoshardValue);Zd(r.position,`+✦${za(e)}`,`chronoshard-indicator`),X.remove(r),em.splice(n,1);continue}a>=1&&(X.remove(r),em.splice(n,1))}Gg(e,t);let _=[],v=[];for(let n=Q.length-1;n>=0;--n){let r=Q[n],i=Ii[r.userData.type],a=_d(r.userData.type,i.range);if(Km>0){r.userData.material.emissive.set(`#77c8ff`),r.userData.material.emissiveIntensity=2+Math.sin(t*12)*.5,r.rotation.y+=e*.35;continue}if(r.userData.lifetimeAge+=e,r.userData.lifetimeAge>o){vg(r,!1);continue}let s=o-r.userData.lifetimeAge;if(s<=M.obstacleDespawnWarningDuration){let e=1-s/M.obstacleDespawnWarningDuration,t=C.lerp(M.obstacleDespawnWarningStartFrequency,M.obstacleDespawnWarningEndFrequency,e);r.visible=Math.sin(r.userData.lifetimeAge*t*Math.PI*2)>-.1}else r.visible=!0;let c=Z.position.clone().sub(r.position);c.y=0;let l=zu()?Ru():null,u=rp.position.clone().sub(r.position);u.y=0;let g=l?u:c,y=r.userData.type===`creeper`||r.userData.type===`poisonCreeper`;y&&(r.userData.staticCollisionSlow=Math.max(0,(r.userData.staticCollisionSlow??0)-e));let b=K.placed.filter(e=>e.type===`chronoGenerator`&&t_(r.position,e)<=_g(e,`range`)).reduce((e,t)=>Math.max(e,_g(t,`slow`)),0);if(r.userData.material.emissive.set(i.emissive),r.userData.type===`poisonCreeper`){let e=(Math.sin(t*2.7+r.userData.speed)+1)/2;r.userData.material.color.lerpColors(gh,_h,e),r.userData.material.emissive.lerpColors(vh,yh,e),r.userData.material.emissiveIntensity=1.2+e*.75}if(b>0&&r.userData.material.emissive.lerp(gp,C.clamp(b*1.6,0,.82)),Hm>0&&c.length()<M.playerRadius){vg(r);continue}if(T_()&&c.length()<M.playerRadius+.3){i_(r.position,.5),vg(r);continue}r.userData.electronStun=Math.max(0,(r.userData.electronStun??0)-e),r.userData.electronHitCooldown=Math.max(0,(r.userData.electronHitCooldown??0)-e),h&&!r.userData.electronStunnedOnce&&r.userData.electronHitCooldown===0&&n_(r.position,Z.position,zp)<=M.orbitalElectronHitRadius+r.userData.colliderRadius&&(r.userData.electronStun=M.orbitalElectronBaseStunDuration+J(`electronStunDuration`),r.userData.electronStunMax=r.userData.electronStun,r.userData.electronHitCooldown=.18,r.userData.electronStunnedOnce=!0);let x=r.userData.electronImmunityMarker;if(x.visible=r.userData.electronStunnedOnce,x.visible&&(x.rotation.y+=e*1.8),r.userData.electronStun>0){let n=C.clamp(r.userData.electronStun/(r.userData.electronStunMax||1),0,1),i=r.userData.stunStars;i.visible=!0,i.rotation.y+=e*(5+n*7),i.scale.setScalar(.55+n*.45);for(let t of i.children)t.rotation.x+=e*8,t.rotation.z+=e*5,t.material.opacity=.08+n*.32;r.userData.material.emissive.set(`#5eeeff`),r.userData.material.emissiveIntensity=.8+Math.sin(t*26)*.3,r.rotation.y+=e*1.5;continue}if(r.userData.stunStars.visible=!1,r.userData.material.emissiveIntensity=1,Um>0)continue;let S=(d&&c.length()<=p?1-m:1)*(1-b),w=J(`pushbackSpeed`);if(w>0&&i.speed===0&&c.length()<=M.pushbackBaseRange*f){let t=r.position.clone().sub(Z.position);t.y=0,t.lengthSq()>0&&r.position.addScaledVector(t.normalize(),(M.pushbackBaseSpeed+w)*e)}let T=l&&r.userData.type===`regular`;if(!T&&(l||g.length()<=a)&&(i.speed>0||l)){let t=y?Math.max(.5,1-J(`creeperSpeedDebuff`)):1,n=y?Math.min(r.userData.lifetimeAge/o,1):0,a=l?.enemyMovementSpeeds?.[r.userData.type],s=l?a??Math.max(i.speed,1):y?C.lerp(i.speed,M.playerSpeed*.9,n):i.speed,c=y&&r.userData.staticCollisionSlow>0?M.creeperStaticCollisionSpeedMultiplier:1;r.position.addScaledVector(g.clone().normalize(),s*t*S*c*e)}if(r.userData.rangeIndicator){let e=r.userData.rangeIndicator,n=l||c.length()<=a,i=1+Math.sin(t*F.chaserRangeIndicatorPulseSpeed)*F.chaserRangeIndicatorPulseAmount;e.position.set(r.position.x,.025,r.position.z),e.scale.setScalar(n?i:1),e.material.opacity=n?F.chaserRangeIndicatorActiveOpacity:F.chaserRangeIndicatorBaseOpacity}if(r.userData.magnetPulse){let e=r.userData.magnetPulse,n=(t*.85+r.userData.magnetPulsePhase)%1;e.position.set(r.position.x,.035,r.position.z),e.scale.setScalar(a*(1.1-n*.9)),e.material.opacity=.5*(1-n)}let ee=r.userData.type;if(ee===`creeper`||ee===`poisonCreeper`)for(let e of r.userData.spikes??[])e.root.quaternion.copy(e.baseQuaternion),e.root.rotateX(Math.sin(t*4.6+e.phase)*.1),e.root.rotateZ(Math.cos(t*3.8+e.phase)*.075);if(ee===`porter`)for(let e of r.userData.spikes??[]){let n=.86+(Math.sin(t*4.4+e.phase)+1)*.12;e.root.scale.set(1,n,1)}if(r.rotation.y+=e*(ee===`chaser`?4.2:r.userData.speed*S),r.position.y=F.obstacleBobBaseHeight+Math.sin(t*F.obstacleBobSpeed+r.position.x)*F.obstacleBobAmplitude,r.userData.type===`poisonCreeper`&&(r.userData.poisonTrailTimer+=e,r.userData.poisonTrailTimer>=P.poisonCreeperTrailInterval&&(r.userData.poisonTrailTimer=0,Zg(r.position))),r.userData.type===`creeper`||r.userData.type===`poisonCreeper`){let e=1.7+(Math.sin(t*5.4+r.userData.id.length)+1)*1.4;for(let t of r.userData.creeperTipMaterials??[])t.emissiveIntensity=e}if(r.userData.type===`banger`){r.userData.age+=e*S;let t=Math.min(r.userData.age/P.bangerFuseDuration,1),n=(Math.sin(r.userData.age*F.bangerFusePulseSpeed)+1)/2;r.userData.bangerFlash=Math.max(0,(r.userData.bangerFlash??0)-e*4.8),r.userData.material.emissive.set(`#ff160d`),r.userData.material.emissiveIntensity=F.bangerFuseEmissiveBaseIntensity+n*F.bangerFuseEmissivePulseAmount+r.userData.bangerFlash*4,r.userData.pulseTimer=(r.userData.pulseTimer??0)+e*S;let i=C.lerp(M.bangerPulseStartInterval,M.bangerPulseEndInterval,t);r.userData.pulseTimer>=i&&(a_(r.position,a,t),r.userData.bangerFlash=1,r.userData.pulseTimer=0),r.userData.age>=P.bangerFuseDuration&&_.push(r);continue}if(r.userData.type===`shooter`&&(r.userData.shotCooldown=Math.max(0,r.userData.shotCooldown-e),(l?u.length():c.length())<=a&&r.userData.shotCooldown===0&&(Rg(r),r.userData.shotCooldown=P.shooterProjectileCooldown)),r.userData.type===`magnet`&&c.length()<=a){let t=r.position.clone().sub(Z.position);t.y=0,t.lengthSq()>0&&Z.position.addScaledVector(t.normalize(),P.magnetPullSpeed*Math.max(.5,1-J(`magnetStrengthDebuff`))*e)}if(r.userData.type===`porter`){r.userData.teleportTimer+=e;let n=P.porterTeleportInterval*(1+J(`porterIntervalBonus`)),i=n-P.porterWarningDuration;if(r.userData.teleportTimer>=i&&!r.userData.teleportTarget&&(r.userData.teleportTarget=Mg(),Ng(r)),r.userData.teleportTarget){let e=(Math.sin(t*22)+1)/2;r.userData.material.emissiveIntensity=.8+e*3,r.userData.teleportEffect.ring.scale.setScalar(1+e*.35),r.userData.teleportEffect.ring.material.opacity=.45+e*.5,r.userData.teleportEffect.beam.material.opacity=.14+e*.3}r.userData.teleportTimer>=n&&(r.position.copy(r.userData.teleportTarget),Pg(r),r.userData.teleportTarget=null,r.userData.teleportTimer=0,r.userData.material.emissiveIntensity=1)}if(r.userData.type===`spore`){r.userData.age+=e;let t=r.userData.hdrEmissionScale??.5;r.userData.material.emissiveIntensity=(2.2+(Math.sin(r.userData.age*10)+1)*1.5)*t,r.userData.age>=P.sporeFuseDuration&&v.push(r)}if(!T&&l&&u.length()<=l.towerRadius+r.userData.colliderRadius){Nh(l.towerContactDamage),vg(r,!1);continue}Sg(r),r.position.distanceTo(Z.position)<M.playerRadius&&(T_()?(i_(r.position,.5),vg(r)):S_(`${r.userData.type.toUpperCase()} COLLISION`))}zg();for(let e of _)Q.includes(e)&&u_(e);for(let e of v)Q.includes(e)&&Lg(e);for(let t=fm.length-1;t>=0;--t){let n=fm[t];n.age+=e;let r=Math.min(n.age/P.sporeFragmentDuration,1),i=P.sporeFragmentSpeed*(1-r)*Math.max(.5,1-J(`sporeSpeedDebuff`));if(n.spore.position.addScaledVector(n.direction,i*e),n.spore.rotation.x+=e*7,n.spore.rotation.z+=e*5,r>=1){n.generation===1&&Ig(n.spore.position,2),X.remove(n.spore),n.spore.userData.material?.dispose(),fm.splice(t,1);continue}Math.hypot(n.spore.position.x,n.spore.position.z)>pp()&&(X.remove(n.spore),n.spore.userData.material?.dispose(),fm.splice(t,1))}for(let t=um.length-1;t>=0;--t){let n=um[t];n.age+=e;let r=P.shooterProjectileSpeed*Math.max(.5,1-J(`shooterProjectileSpeedDebuff`))*e;n.projectile.position.addScaledVector(n.direction,r),n.distanceTravelled+=r,n.projectile.rotation.x+=e*9,n.projectile.rotation.y+=e*12;let i=n.targetTower?rp.position:Z.position,a=n.targetTower?Ru()?.towerRadius??1.15:M.playerRadius;if(n.projectile.position.distanceTo(i)<a+P.shooterProjectileRadius){X.remove(n.projectile),um.splice(t,1),n.targetTower?Nh(Ru()?.towerProjectileDamage??1):S_(`SHOOTER PROJECTILE`);continue}n.distanceTravelled>=n.maxRange&&(X.remove(n.projectile),um.splice(t,1))}for(let t=sm.length-1;t>=0;--t){let n=sm[t];n.age+=e;let r=Math.min(n.age/M.bangerExplosionVfxDuration,1);n.light.intensity=10*(1-r),r===1&&(X.remove(...n.emitters,n.light),sm.splice(t,1))}for(let t=cm.length-1;t>=0;--t){let n=cm[t];n.age+=e;let r=Math.min(n.age/.42,1);n.light.intensity=12*(1-r),r===1&&(X.remove(...n.emitters,n.light),cm.splice(t,1))}for(let t=lm.length-1;t>=0;--t){let n=lm[t];n.age+=e;let r=Math.min(n.age/M.bangerPulseVfxDuration,1);n.pulse.scale.setScalar(C.lerp(.2,n.radius/.42,r)),n.pulse.material.opacity=.9*(1-r),r===1&&(X.remove(n.pulse),lm.splice(t,1))}for(let t=mm.length-1;t>=0;--t){let n=mm[t];n.age+=e;let r=Math.min(n.age/M.shockwaveVfxDuration,1);n.shockwave.scale.setScalar(C.lerp(.25,n.radius/.42,r)),n.shockwave.material.opacity=.95*(1-r);let i=n.radius*r;for(let e of Q){if(n.affected.has(e))continue;let t=e.position.clone().sub(n.origin);t.y=0;let r=t.length();r>i||(n.affected.add(e),r<.01?t.set(Math.random()-.5,0,Math.random()-.5).normalize():t.normalize(),hm.push({obstacle:e,direction:t,distance:M.shockwavePushDistance*(1-r/n.radius),remaining:.28}))}r===1&&(X.remove(n.shockwave),mm.splice(t,1))}for(let t=gm.length-1;t>=0;--t){let n=gm[t];n.age+=e;let r=Math.min(n.age/n.duration,1),i=n.radius*r;n.ring.scale.setScalar(C.lerp(.2,n.radius/.58,r)),n.glow.scale.setScalar(C.lerp(.08,n.radius,r)),n.ring.material.opacity=.98*(1-r*.38),n.glow.material.opacity=.24*(1-r);for(let e of n.targets)n.hit.has(e)||!Q.includes(e)||Math.hypot(e.position.x-n.origin.x,e.position.z-n.origin.z)>i||(n.hit.add(e),i_(e.position,.82),vg(e));r===1&&(X.remove(n.ring,n.glow),gm.splice(t,1))}for(let t=hm.length-1;t>=0;--t){let n=hm[t];if(!Q.includes(n.obstacle)){hm.splice(t,1);continue}let r=Math.min(e/n.remaining,1);n.obstacle.position.addScaledVector(n.direction,n.distance*r),mp(n.obstacle.position),n.distance*=1-r,n.remaining-=e,n.remaining<=0&&hm.splice(t,1)}for(let t=nm.length-1;t>=0;--t){let n=nm[t];n.age+=e;let r=Math.min(n.age/M.fallingBlockDuration,1),i=1-(1-r)**3;n.obstacle.position.y=C.lerp(M.fallingBlockStartHeight,M.fallingBlockGroundHeight,i),n.obstacle.rotation.x+=e*F.fallingObstacleSpinXSpeed,n.obstacle.rotation.z+=e*F.fallingObstacleSpinZSpeed,n.shadow.scale.setScalar(F.targetShadowBaseScale+r*F.targetShadowScaleGrowth),n.shadow.material.opacity=F.targetShadowBaseOpacity+r*F.targetShadowOpacityGrowth;let a=1+Math.sin(n.age*F.targetRingPulseSpeed)*F.targetRingPulseAmount;n.targetRing.scale.setScalar((F.targetRingBaseScale+r*F.targetRingScaleGrowth)*a),n.targetRing.material.opacity=F.targetRingBaseOpacity-r*F.targetRingOpacityFade;let o=Z.position.distanceTo(n.target);if(!n.landed&&r>.82&&o<M.playerRadius&&(n.type===`fieryRock`?k_(`fire`,`fiery-rock-impact`):S_(`METEOR IMPACT`)),r===1){if(n.landed=!0,!n.impactTriggered){n.impactTriggered=!0;let e=hh(n.target,.9,Li[n.type].color);X.add(...e.emitters),n.type===`fieryRock`&&Jg(n.target),n.type===`splinter`&&$g(n.target)}n.obstacle.position.y=M.fallingBlockGroundHeight,n.shadow.material.opacity=Math.max(0,.88-(n.age-M.fallingBlockDuration)*1.8),n.targetRing.material.opacity=Math.max(0,.55-(n.age-M.fallingBlockDuration)*1.5),n.age>M.fallingBlockLifetime&&(X.remove(n.obstacle,n.shadow,n.targetRing),nm.splice(t,1))}}for(let t=im.length-1;t>=0;--t){let n=im[t];n.age+=e;let r=n.age/M.fieryRockFireDuration,i=1+Math.sin(n.age*9)*.1,a=Math.max(0,1-r);n.ground.scale.setScalar(i*(.9+r*.2)),n.ground.material.opacity=.34*a,n.light.intensity=Math.max(0,(5.5+Math.sin(n.age*14))*a),t_(Z.position,n.position)<M.fieryRockFireRadius&&k_(`fire`,`fiery-rock`),r>=1&&(X.remove(n.ground,...n.emitters,n.light),im.splice(t,1))}for(let t=am.length-1;t>=0;--t){let n=am[t];n.age+=e;let r=M.poisonTrailDuration*(1-J(`poisonTrailDurationReduction`)),i=n.age/r;Math.max(0,1-i),t_(Z.position,n.position)<P.poisonCreeperTrailRadius&&k_(`poison`,`poison-creeper-trail`),i>=1&&(X.remove(...n.emitters),am.splice(t,1))}let y=A_(e,t);if(y){let e=.3+(Math.sin(t*18)+1)*.2;yp.material.emissive.set(y.color),yp.material.emissiveIntensity=e}for(let t=om.length-1;t>=0;--t){let n=om[t];n.age+=e;let r=M.splinterPieceDistance/M.splinterPieceDuration;n.piece.position.addScaledVector(n.direction,r*e),n.piece.rotation.x+=e*8,n.piece.rotation.z+=e*6,n.piece.position.distanceTo(Z.position)<M.playerRadius*.7&&S_(`SPLINTER IMPACT`),n.age>=M.splinterPieceDuration&&(X.remove(n.piece),om.splice(t,1))}for(let t=ym.length-1;t>=0;--t){let n=ym[t];n.age+=e;let r=n.age/M.obstacleSpawnWarningDuration,i=1+Math.sin(n.age*F.spawnRingPulseSpeed)*F.spawnRingPulseAmount;n.ring.scale.setScalar((F.spawnRingBaseScale+r*F.spawnRingScaleGrowth)*i),n.ring.material.opacity=F.spawnRingBaseOpacity*(1-r),n.ring.rotation.z-=e*2;let a=1+Math.sin(n.age*F.spawnRingPulseSpeed*.55)*F.spawnCueGlowPulseAmount;n.glow.scale.setScalar(a*(.85+r*.25)),n.glow.material.opacity=F.spawnCueGlowBaseOpacity*(1-r*.3),n.beam.scale.set(.8+r*.2,1,.8+r*.2),n.beam.material.opacity=F.spawnCueBeamBaseOpacity*(1-r*.45),n.beam.rotation.y+=e*1.6,r>=1&&(Q.length<Gd()&&jg(n.position,n.type),X.remove(n.ring,n.glow,n.beam),ym.splice(t,1))}km+=e,Bm+=e,Am+=e,jm+=e,Mm+=e,Nm+=e;let b=J(`cellSpawnRate`)+Em*J(`cellSpawnRatePerCell`),x=!zu()&&(!Nu||Nu.simulation.has(`cell`)),S=!Nu||Nu.simulation.has(`enemies`),w=!Nu||Nu.simulation.has(`boosters`);if(x&&km>M.cellSpawnInterval/(1+b)&&(wg(),km=0),w&&Bm>M.boosterSpawnInterval){let e=[sd(`unlock-speed-booster`)>0&&`speed`,sd(`thorn-shield`)>0&&`thorn`,sd(`freezer`)>0&&`freezer`].filter(Boolean);e.length&&Dg(e[Math.floor(Math.random()*e.length)]),Bm=0}if(x&&Am>M.chronoCellSpawnInterval/(1+J(`chronoSpawnRate`))&&(Tg(),Am=0),jm>=120&&(Xg(),jm=0),S&&Mm>s){let e=Math.max(0,Gd()-Q.length-ym.length);for(let t=0;t<Math.min(c,e);t+=1)Ag();Mm=0}let T=Math.max(M.fallingBlockMinInterval/M.fallingRockSpawnFrequencyMultiplier,(M.fallingBlockBaseInterval+n.fallingRockSpawnIntervalOffset-Em*(M.fallingBlockIntervalPerCell+n.fallingRockSpawnDecreasePerCellOffset))*(1-i)/M.fallingRockSpawnFrequencyMultiplier);!zu()&&S&&Nm>T&&(Bg(),Nm=0),Om+=e,w_()}function O_(e){requestAnimationFrame(O_);let t=q.gameplay.maxFps;if(t>0){let n=1e3/t;if(Fm!==null&&e<Fm)return;let r=Fm??e;Fm=r+(Math.floor(Math.max(0,e-r)/n)+1)*n}else Fm=null;xm.update(e);let n=Math.min(xm.getDelta(),.05),r=xm.getElapsed();if($&&!Sm&&!wm&&D_(n,r),l_(n),tp.update(n),Yu)ip.position.set(Jp.x,Yp,Jp.y+.01),ip.lookAt(Jp.x,0,Jp.y);else{if(ip.position.set(Z.position.x,J_(),Z.position.z+q_()),zm>0){let e=(zm/Rm)**1.5;ip.position.x+=C.randFloatSpread(.22)*e,ip.position.y+=C.randFloatSpread(.14)*e,ip.position.z+=C.randFloatSpread(.22)*e,zm=Math.max(0,zm-n)}ip.lookAt(Z.position.x,0,Z.position.z)}Yu&&cg(),op.position.copy(ip.position),q.graphics.hdrEmissionIntensity>0?bf.render():yf.render(X,ip),Wh(n)}function k_(e,t=`unknown`){let n=so[e];if(!n||!$||Cm||Lm>0||n.immunityResearchId&&sd(n.immunityResearchId)>0)return!1;if(Im>0)return S_(),!1;let r=Zm.get(e);return r?(r.exposed=!0,!n.requiresExposure&&n.refreshOnReapply&&(r.remaining=n.duration),!0):(Zm.set(e,{type:e,source:t,remaining:n.duration,maxDuration:n.duration,exposed:!0}),!0)}function A_(e,t){let n=null;for(let[t,r]of Zm){let i=so[t];if(i.requiresExposure&&!r.exposed){Zm.delete(t);continue}if(r.remaining-=e,r.remaining<=0){Zm.delete(t),S_(I(`status.damage`,{status:i.label.toUpperCase()}));continue}(!n||r.remaining/r.maxDuration>n.remaining/n.maxDuration)&&(n=r)}return n?so[n.type]:null}function j_(e,t){let n=new l(new Oe(.2,.58,96),new S({color:`#ff795f`,transparent:!0,opacity:1,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(e.x,.1,e.z);let r=new l(new Oe(.01,1,96),new S({color:`#ffbe75`,transparent:!0,opacity:.22,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.position.set(e.x,.075,e.z),X.add(n,r),gm.push({origin:e.clone(),ring:n,glow:r,radius:pp()*1.1,age:0,duration:2.2,targets:new Set(t),hit:new Set}),i_(e,2.1)}function M_(){al();let e={en:`language.english`,tr:`language.turkish`,es:`language.spanish`};_c.innerHTML=Ji().map(t=>`<option value="${t}">${I(e[t]??`language.${t}`,{},t)}</option>`).join(``),_c.value=q.language,wc.innerHTML=[`low`,`medium`,`high`].map(e=>`<button data-graphics-quality="${e}" class="${q.graphics.quality===e?`selected`:``}" type="button">${I(`settings.${e}`)}</button>`).join(``),Tc.checked=q.graphics.shadows;let t=Math.round(q.graphics.hdrEmissionIntensity*100);Ec.value=String(t),Dc.value=`${t}%`,Oc.value=q.gameplay.maxFps,kc.value=q.gameplay.maxFps===0?I(`settings.unlimited`):`${q.gameplay.maxFps} FPS`,Ac.checked=q.gameplay.autoPause,jc.checked=q.gameplay.highContrastHud,Mc.value=q.sound.masterVolume,Nc.value=`${q.sound.masterVolume}%`,Pc.checked=q.sound.muted,Fc.checked=q.sound.spatialAudio,document.querySelector(`.game-shell`).classList.toggle(`high-contrast-hud`,q.gameplay.highContrastHud),N_()}async function N_(){if(!vc||!yc||!window.steamShell?.getDisplaySettings)return;let e=await window.steamShell.getDisplaySettings();vc.innerHTML=`<button data-display-mode="fullscreen" class="${e.fullscreen?`selected`:``}" type="button">${I(`settings.fullscreen`)}</button><button data-display-mode="windowed" class="${e.fullscreen?``:`selected`}" type="button">${I(`settings.windowed`)}</button>`,yc.innerHTML=[[1280,720],[1600,900],[1920,1080],[2560,1440]].filter(([t,n])=>t<=e.maxWidth&&n<=e.maxHeight).map(([t,n])=>`<button data-display-resolution="${t}x${n}" class="${!e.fullscreen&&e.width===t&&e.height===n?`selected`:``}" type="button">${t}×${n}</button>`).join(``)}function P_(){Gu(),vf.setMasterVolume(),M_()}function F_(){return wm?(Tm&&p_(),wm=!1,Tm=!1,Nl?.completeActiveStep(),$=!0,Sm=!1,vf.initialize(),W||oa({sector:U+1,buildVersion:$i.version,platform:window.steamShell?`steam`:`web`}),!0):!1}function I_(e=!1,{waitForFirstInput:t=!0}={}){if(e&&!xh)return;vf.initialize().catch(()=>{}),vf.playButtonClick();let n=!!W,r=t;n?__():(Nu=null,Fu=e?{challengeId:kh().id,weekId:Eh()}:null,p_(!r)),$=!r,wm=r,Tm=r&&!n,Cm=!1,Sm=!1,os.classList.remove(`death-title`),Hh(),Ps.classList.add(`hidden`),xs.classList.remove(`hidden`),rs.classList.add(`hidden`),ps.classList.add(`hidden`),Gf(),!n&&!r&&oa({sector:U+1,buildVersion:$i.version,platform:window.steamShell?`steam`:`web`})}ds.addEventListener(`click`,()=>{Pl?.mode===`run-again`&&Kl(),Fl?.mode===`start-run`&&Jl(),I_()}),fs.addEventListener(`click`,y_),bs.addEventListener(`click`,()=>ps.classList.add(`hidden`)),ys.addEventListener(`click`,()=>I_(!0));function L_(){Ps.classList.add(`hidden`),Ic.classList.add(`hidden`),Wc.classList.add(`hidden`),$c.classList.add(`hidden`),Xs.classList.add(`hidden`),nc.classList.add(`hidden`),Bs.classList.add(`hidden`),Ws.classList.add(`hidden`),qs.classList.add(`hidden`),hc.classList.add(`hidden`),Sc.classList.add(`hidden`),Cs.classList.add(`hidden`),ps.classList.add(`hidden`),ks.classList.add(`hidden`)}var R_=new Map([[Ps,Fs],[Ic,Ls],[Xs,Rs],[Bs,zs],[Ws,Us],[hc,pc]]);function z_(e=Is){document.querySelectorAll(`.menu-system-button`).forEach(t=>t.classList.toggle(`is-active`,t===e))}function B_(){L_(),xs.classList.remove(`hidden`),z_()}function V_(e,t){L_(),xs.classList.add(`hidden`),e.classList.remove(`hidden`),z_(R_.get(e)),t?.()}Is.addEventListener(`click`,e=>{e.stopPropagation(),B_()}),Fs.addEventListener(`click`,e=>{e.stopPropagation(),Pd(`researchLab`,Fs)&&(yd(),V_(Ps,bd),Il?.mode===`research-entry`&&Xl(`research-category`,cl.querySelector(`[data-toggle-research-category="Player Enhancements"]`)))}),pc.addEventListener(`click`,e=>{e.stopPropagation(),V_(hc,M_)}),xc.addEventListener(`click`,()=>V_(Sc)),mc?.addEventListener(`click`,()=>{if(window.dispatchEvent(new Event(`asteroid-belt:exit-requested`)),window.steamShell?.quit){window.steamShell.quit();return}window.close()}),bc.addEventListener(`click`,()=>{hc.classList.add(`hidden`),xs.classList.remove(`hidden`)}),Cc.addEventListener(`click`,()=>{Sc.classList.add(`hidden`),hc.classList.remove(`hidden`)}),hc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-graphics-quality]`);t&&(q.graphics.quality=t.dataset.graphicsQuality,Df(),P_())}),_c.addEventListener(`change`,()=>{q.language=_c.value,qi(q.language),Gu(),window.location.reload()}),hc.addEventListener(`click`,async e=>{let t=e.target.closest(`[data-display-mode]`)?.dataset.displayMode,n=e.target.closest(`[data-display-resolution]`)?.dataset.displayResolution;if(t&&window.steamShell?.setFullscreen&&await window.steamShell.setFullscreen(t===`fullscreen`),n&&window.steamShell?.setResolution){let[e,t]=n.split(`x`).map(Number);await window.steamShell.setResolution(e,t)}(t||n)&&N_()}),Tc.addEventListener(`change`,()=>{q.graphics.shadows=Tc.checked,Df(),P_()}),Ec.addEventListener(`input`,()=>{q.graphics.hdrEmissionIntensity=Number(Ec.value)/100,Df(),P_()}),Oc.addEventListener(`input`,()=>{q.gameplay.maxFps=Number(Oc.value),P_()}),Ac.addEventListener(`change`,()=>{q.gameplay.autoPause=Ac.checked,P_()}),jc.addEventListener(`change`,()=>{q.gameplay.highContrastHud=jc.checked,P_()}),Mc.addEventListener(`input`,()=>{q.sound.masterVolume=Number(Mc.value),P_()}),Pc.addEventListener(`change`,()=>{q.sound.muted=Pc.checked,P_()}),Fc.addEventListener(`change`,()=>{q.sound.spatialAudio=Fc.checked,P_()}),el.addEventListener(`click`,()=>{Ps.classList.add(`hidden`),xs.classList.remove(`hidden`)}),rs.addEventListener(`click`,e=>{let t=e.composedPath();!Ps.classList.contains(`hidden`)&&!t.includes(Ps)&&(Ps.classList.add(`hidden`),xs.classList.remove(`hidden`)),!hc.classList.contains(`hidden`)&&!t.includes(hc)&&(hc.classList.add(`hidden`),xs.classList.remove(`hidden`)),!Ic.classList.contains(`hidden`)&&!t.includes(Ic)&&!t.includes(Wc)&&(Wc.classList.add(`hidden`),Ic.classList.add(`hidden`),xs.classList.remove(`hidden`)),!Xs.classList.contains(`hidden`)&&nc.classList.contains(`hidden`)&&!t.includes(Xs)&&(Xs.classList.add(`hidden`),xs.classList.remove(`hidden`)),!Bs.classList.contains(`hidden`)&&!t.includes(Bs)&&(Bs.classList.add(`hidden`),xs.classList.remove(`hidden`)),!Ws.classList.contains(`hidden`)&&!t.includes(Ws)&&!t.includes(qs)&&(qs.classList.add(`hidden`),Ws.classList.add(`hidden`),xs.classList.remove(`hidden`),z_())}),Ls.addEventListener(`click`,e=>{e.stopPropagation(),Pd(`buildingSystem`,Ls)&&V_(Ic,dg)}),Rs.addEventListener(`click`,e=>{e.stopPropagation(),!($||!Pd(`weaponry`,Rs))&&V_(Xs,Kf)}),zs.addEventListener(`click`,e=>{e.stopPropagation(),V_(Bs,Fh)}),Us.addEventListener(`click`,e=>{e.stopPropagation(),V_(Ws,uf)}),Vs.addEventListener(`click`,()=>{Bs.classList.add(`hidden`),xs.classList.remove(`hidden`)}),Gs.addEventListener(`click`,()=>{qs.classList.add(`hidden`),Ws.classList.add(`hidden`),xs.classList.remove(`hidden`),z_()}),Ks.addEventListener(`click`,e=>{let t=e.target.closest(`[data-artifact-id]`);t&&df(t.dataset.artifactId)}),Ys.addEventListener(`click`,()=>qs.classList.add(`hidden`)),Zs.addEventListener(`click`,()=>{Xs.classList.add(`hidden`),xs.classList.remove(`hidden`)}),$s.addEventListener(`click`,()=>Xf(1)),ec.addEventListener(`click`,()=>Xf(5)),cc.addEventListener(`click`,Zf),dc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-weapon]`);t&&Qf(t.dataset.toggleWeapon)}),uc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-weapon-slot]`);$||!t||(G.selected=Number(t.dataset.selectWeaponSlot),Of(),Kf())}),fc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-use-weapon]`);t&&$f(t.dataset.useWeapon)}),Lc.addEventListener(`click`,()=>{Wc.classList.add(`hidden`),Ic.classList.add(`hidden`),xs.classList.remove(`hidden`)}),Uc.addEventListener(`click`,()=>{Qh(),Wc.classList.remove(`hidden`)}),Gc.addEventListener(`click`,()=>Wc.classList.add(`hidden`)),Hc.addEventListener(`click`,fg),Qc.addEventListener(`click`,pg),Wc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-building-offer]`);t&&Xh(t.dataset.buildingOffer)}),Jc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-building]`);t&&(Xu=t.dataset.selectBuilding,dg())}),Zc.addEventListener(`click`,e=>{if(Qp){Qp=!1;return}let t=e.target.closest(`[data-build-x]`);t&&ug(Number(t.dataset.buildX),Number(t.dataset.buildZ))}),$c.addEventListener(`click`,e=>{let t=e.target.closest(`[data-upgrade-building]`),n=e.target.closest(`[data-destroy-building]`);if(e.target.closest(`[data-close-building-upgrade]`)){$c.classList.add(`hidden`);return}if(n){let e=K.placed.find(e=>e.id===n.dataset.destroyBuilding);if(!e||!window.confirm(I(`building.demolish_confirm`,{building:ca.types[e.type].name,refund:za(ng(e))})))return;qd(ng(e)),K.placed=K.placed.filter(t=>t.id!==e.id),Kh(),ig(),dg(),$c.classList.add(`hidden`);return}if(t){let e=K.placed.find(e=>e.id===t.dataset.upgradeBuilding);if(!e)return;let n=tg(e,t.dataset.upgradeKey);if(Au<n)return;qd(-n),e.upgrades[t.dataset.upgradeKey]=(e.upgrades[t.dataset.upgradeKey]??0)+1,e.spent=(e.spent??ca.types[e.type].baseCost)+n,Kh(),ig(),mg(e)}}),Ps.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-research-category]`),n=e.target.closest(`[data-start-research]`),r=e.target.closest(`[data-unlock-slot]`);if(t){let e=t.dataset.toggleResearchCategory;ed.has(e)?ed.delete(e):ed.add(e),bd(),Il?.mode===`research-category`&&e===`Player Enhancements`&&Xl(`research-upgrade`,cl.querySelector(`[data-start-research="player-speed-multiplier"]`));return}n&&xd(n.dataset.startResearch)&&Il?.mode===`research-upgrade`&&n.dataset.startResearch===`player-speed-multiplier`&&Zl(),r&&Sd(Number.parseInt(r.dataset.unlockSlot,10))}),ll.addEventListener(`input`,()=>{Zu=ll.value,bd()}),ul.addEventListener(`change`,()=>{Qu=ul.checked,bd()}),dl.addEventListener(`change`,()=>{$u=dl.checked,bd()}),_l.addEventListener(`click`,()=>{g_(),p_(!1),wm=!0,Tm=!0,Sm=!1,$=!1,gl.classList.add(`hidden`)}),vl.addEventListener(`click`,()=>{Yu&&pg(),g_(),Nu=null,Fu=null,p_(!0),wm=!1,Tm=!1,Sm=!1,$=!1,Cm=!1,gl.classList.add(`hidden`),fc.classList.add(`hidden`),os.textContent=`ASTEROID BELT`,os.classList.remove(`death-title`),Hh(),ls.textContent=I(`message.run_surrendered`),us.hidden=!0,B_(),rs.classList.remove(`hidden`)}),yl.addEventListener(`click`,()=>{Sm=!1,gl.classList.add(`hidden`)}),bl.addEventListener(`click`,b_),ns.addEventListener(`click`,()=>{Nl?.isActiveStep(`quick-start`)||$&&(Sm=!Sm,gl.classList.toggle(`hidden`,!Sm))}),document.addEventListener(`click`,e=>{if(gl.classList.contains(`hidden`))return;let t=e.composedPath();t.includes(gl)||t.includes(ns)||(Sm=!1,gl.classList.add(`hidden`))}),hl.addEventListener(`click`,()=>Cd(!1)),pl.addEventListener(`keydown`,e=>{e.key===`Enter`&&(e.preventDefault(),Ud(pl.value),pl.value=``),e.key===`Escape`&&(e.preventDefault(),Cd(!1)),e.stopPropagation()}),window.addEventListener(`keydown`,e=>{if(fl.classList.contains(`hidden`)){if(e.key===`Escape`&&$&&!Nl?.isActiveStep(`quick-start`)){e.preventDefault(),Sm=!Sm,gl.classList.toggle(`hidden`,!Sm);return}if(Qi.enabled&&e.key===Qi.hotkey){e.preventDefault(),Cd();return}if(F_(),$&&!Sm&&e.code===`ArrowUp`){e.preventDefault(),G.selected=(G.selected-1+Math.max(G.loadout.length,1))%Math.max(G.loadout.length,1),Gf();return}if($&&!Sm&&e.code===`ArrowDown`){e.preventDefault(),G.selected=(G.selected+1)%Math.max(G.loadout.length,1),Gf();return}if($&&!Sm&&e.code===`Space`){e.preventDefault(),$f();return}[`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`].includes(e.code)&&e.preventDefault(),Vp.add(e.code)}}),window.addEventListener(`keyup`,e=>Vp.delete(e.code));function H_(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches}function U_(){let[e,t]=Xp.values();return Math.hypot(e.x-t.x,e.y-t.y)}function W_(e){return!Yu||!H_()||e.button!==0?!1:(e.preventDefault(),Xp.set(e.pointerId,{x:e.clientX,y:e.clientY}),Xp.size===2&&(Zp={distance:U_(),height:Yp}),!0)}function G_(e){let t=Xp.get(e.pointerId);if(!t||!Yu)return;e.preventDefault();let n={x:e.clientX,y:e.clientY};if(Xp.set(e.pointerId,n),Xp.size===1){let e=n.x-t.x,r=n.y-t.y;if(Math.hypot(e,r)<.5)return;let i=2*Yp*Math.tan(C.degToRad(Mi.fov/2));Jp.x-=e/window.innerWidth*i*ip.aspect,Jp.y-=r/window.innerHeight*i,Qp=!0}else if(Xp.size===2&&Zp){let e=U_();e>0&&(Yp=C.clamp(Zp.height*Zp.distance/e,Kp,qp)),Qp=!0}}function K_(e){Xp.delete(e.pointerId)&&(Xp.size<2&&(Zp=null),Qp&&window.setTimeout(()=>{Qp=!1},250))}function q_(){return window.matchMedia(`(orientation: portrait)`).matches?Mi.portraitDistance:Mi.landscapeDistance}function J_(){return q_()*Math.tan(C.degToRad(Mi.angle))}function Y_(e){if(!Wp)return;let t=e.clientX-Wp.x,n=e.clientY-Wp.y,r=Math.hypot(t,n),i=Math.min(r,Gp),a=r?i/r:0,o=t*a,s=n*a,c=r<8?0:i/Gp;Hp.set(o/Gp*c,s/Gp*c),jl.querySelector(`.virtual-joystick-knob`).style.transform=`translate(${o}px, ${s}px)`}function X_(e){e&&e.pointerId!==Up||(Up=null,Wp=null,Hp.set(0,0),jl.classList.remove(`active`),jl.querySelector(`.virtual-joystick-knob`).style.transform=``)}Yo.addEventListener(`pointerdown`,e=>{if(Yu){W_(e);return}e.button===0&&F_(),!(!H_()||!$||Sm||e.button!==0||Up!==null)&&(e.preventDefault(),Up=e.pointerId,Wp={x:e.clientX,y:e.clientY},jl.style.left=`${e.clientX}px`,jl.style.top=`${e.clientY}px`,jl.classList.add(`active`),Yo.setPointerCapture(e.pointerId),Y_(e))}),Yo.addEventListener(`pointermove`,e=>{e.pointerId===Up&&(e.preventDefault(),Y_(e))}),Yo.addEventListener(`pointerup`,X_),Yo.addEventListener(`pointercancel`,X_),Yo.addEventListener(`lostpointercapture`,X_),Zc.addEventListener(`pointerdown`,W_),window.addEventListener(`pointermove`,G_,{passive:!1}),window.addEventListener(`pointerup`,K_),window.addEventListener(`pointercancel`,K_),window.addEventListener(`blur`,()=>{Vp.clear(),X_()}),document.addEventListener(`visibilitychange`,()=>{!document.hidden||!q.gameplay.autoPause||!$||Sm||(Sm=!0,gl.classList.remove(`hidden`))}),window.addEventListener(`resize`,()=>{Fd(),ip.aspect=window.innerWidth/window.innerHeight,ip.updateProjectionMatrix(),yf.setSize(window.innerWidth,window.innerHeight),bf.setSize(window.innerWidth,window.innerHeight),Yu&&cg()}),as?.addEventListener(`click`,e=>{let t=Number(e.target.closest(`[data-save-slot]`)?.dataset.saveSlot);!Number.isInteger(t)||t<1||t>nu||(localStorage.setItem(eu,String(t)),sessionStorage.setItem(tu,String(t)),window.location.reload())});async function Z_(){}hp(),ig(),vd(),Kd(),qd(),Jd(),Yd(),_f(),bd(),M_(),rf(),uf(),sf(),v_(),z_(),p_(),is&&(is.hidden=!0),Z_(),O_(),Nl=Vo({isSteamBuild:Ho,startTutorialRun:()=>I_(),startFirstLossGuidance:Gl,startSecondSectorGuidance:ql,startFirstResearchGuidance:Yl,onStepStarted:e=>{e.id===`quick-start`&&Rl(),e.id===`first-loss-guidance`&&(us.hidden=!0)},onStepCompleted:e=>{e.id===`quick-start`&&zl()}}),Nl.start(),setInterval(()=>{(vd()||!Ps.classList.contains(`hidden`))&&bd()},1e3);export{yi as n,go as t};