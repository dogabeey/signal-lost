import{t as e}from"./rolldown-runtime-DK3Fl9T5.js";import{$ as t,A as n,B as r,C as i,D as a,E as o,F as s,G as c,H as l,I as u,J as d,K as f,L as p,M as m,N as h,O as g,P as _,Q as v,R as y,S as b,T as x,U as S,V as C,W as ee,X as te,Y as ne,Z as re,_ as ie,_t as ae,a as oe,at as se,b as ce,bt as le,c as ue,ct as de,d as fe,dt as pe,et as me,f as he,ft as ge,g as _e,gt as ve,h as ye,ht as be,i as xe,it as Se,j as Ce,k as we,l as Te,lt as Ee,m as De,mt as Oe,n as ke,nt as Ae,o as je,ot as Me,p as Ne,pt as Pe,q as Fe,r as Ie,rt as Le,s as Re,st as ze,t as Be,tt as Ve,u as He,ut as Ue,v as We,vt as Ge,w as Ke,x as qe,y as Je,yt as w,z as Ye}from"./three--l62wOBY.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var Xe=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),Ze=1234567,Qe=Math.PI/180,$e=180/Math.PI;function et(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(Xe[e&255]+Xe[e>>8&255]+Xe[e>>16&255]+Xe[e>>24&255]+`-`+Xe[t&255]+Xe[t>>8&255]+`-`+Xe[t>>16&15|64]+Xe[t>>24&255]+`-`+Xe[n&63|128]+Xe[n>>8&255]+`-`+Xe[n>>16&255]+Xe[n>>24&255]+Xe[r&255]+Xe[r>>8&255]+Xe[r>>16&255]+Xe[r>>24&255]).toLowerCase()}function tt(e,t,n){return Math.max(t,Math.min(n,e))}function nt(e,t){return(e%t+t)%t}function rt(e,t,n,r,i){return r+(e-t)*(i-r)/(n-t)}function it(e,t,n){return e===t?0:(n-e)/(t-e)}function at(e,t,n){return(1-n)*e+n*t}function ot(e,t,n,r){return at(e,t,1-Math.exp(-n*r))}function st(e,t=1){return t-Math.abs(nt(e,t*2)-t)}function ct(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*(3-2*e))}function lt(e,t,n){return e<=t?0:e>=n?1:(e=(e-t)/(n-t),e*e*e*(e*(e*6-15)+10))}function ut(e,t){return e+Math.floor(Math.random()*(t-e+1))}function dt(e,t){return e+Math.random()*(t-e)}function ft(e){return e*(.5-Math.random())}function pt(e){e!==void 0&&(Ze=e);let t=Ze+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function mt(e){return e*Qe}function ht(e){return e*$e}function gt(e){return!(e&e-1)&&e!==0}function _t(e){return 2**Math.ceil(Math.log(e)/Math.LN2)}function vt(e){return 2**Math.floor(Math.log(e)/Math.LN2)}function yt(e,t,n,r,i){let a=Math.cos,o=Math.sin,s=a(n/2),c=o(n/2),l=a((t+r)/2),u=o((t+r)/2),d=a((t-r)/2),f=o((t-r)/2),p=a((r-t)/2),m=o((r-t)/2);switch(i){case`XYX`:e.set(s*u,c*d,c*f,s*l);break;case`YZY`:e.set(c*f,s*u,c*d,s*l);break;case`ZXZ`:e.set(c*d,c*f,s*u,s*l);break;case`XZX`:e.set(s*u,c*m,c*p,s*l);break;case`YXY`:e.set(c*p,s*u,c*m,s*l);break;case`ZYZ`:e.set(c*m,c*p,s*u,s*l);break;default:console.warn(`../math.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: `+i)}}function bt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`Invalid component type.`)}}function xt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`Invalid component type.`)}}var St={DEG2RAD:Qe,RAD2DEG:$e,generateUUID:et,clamp:tt,euclideanModulo:nt,mapLinear:rt,inverseLerp:it,lerp:at,damp:ot,pingpong:st,smoothstep:ct,smootherstep:lt,randInt:ut,randFloat:dt,randFloatSpread:ft,seededRandom:pt,degToRad:mt,radToDeg:ht,isPowerOfTwo:gt,ceilPowerOfTwo:_t,floorPowerOfTwo:vt,setQuaternionFromProperEuler:yt,normalize:xt,denormalize:bt},T=class e{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(o===0){e[t+0]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u;return}if(o===1){e[t+0]=d,e[t+1]=f,e[t+2]=p,e[t+3]=m;return}if(u!==m||s!==d||c!==f||l!==p){let e=1-o,t=s*d+c*f+l*p+u*m,n=t>=0?1:-1,r=1-t*t;if(r>2**-52){let i=Math.sqrt(r),a=Math.atan2(i,t*n);e=Math.sin(e*a)/i,o=Math.sin(o*a)/i}let i=o*n;if(s=s*e+d*i,c=c*e+f*i,l=l*e+p*i,u=u*e+m*i,e===1-o){let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new e(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:console.warn(`../math.Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<2**-52?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(tt(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,r=this._y,i=this._z,a=this._w,o=a*e._w+n*e._x+r*e._y+i*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=r,this._z=i,this;let s=1-o*o;if(s<=2**-52){let e=1-t;return this._w=e*a+t*this._w,this._x=e*n+t*this._x,this._y=e*r+t*this._y,this._z=e*i+t*this._z,this.normalize(),this}let c=Math.sqrt(s),l=Math.atan2(c,o),u=Math.sin((1-t)*l)/c,d=Math.sin(t*l)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=r*u+this._y*d,this._z=i*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},E=class e{constructor(t=0,n=0,r=0){this.isVector3=!0,e.prototype.isVector3=!0,this.x=t,this.y=n,this.z=r}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(wt.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(wt.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ct.copy(this).projectOnVector(e),this.sub(Ct)}reflect(e){return this.sub(Ct.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(tt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}abs(){return this.x=Math.abs(this.x),this.y=Math.abs(this.y),this.z=Math.abs(this.z),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ct=new E,wt=new T,Tt=2e3,Et=2001,Dt=class e{constructor(t,n,r,i,a,o,s,c,l,u,d,f,p,m,h,g){this.isMatrix4=!0,e.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,n,r,i,a,o,s,c,l,u,d,f,p,m,h,g)}extractPosition(e){return console.warn(`THREE.Matrix4: .extractPosition() has been renamed to .copyPosition().`),this.copyPosition(e)}multiplyToArray(e,t,n){return console.error(`THREE.Matrix4: .multiplyToArray() has been removed.`),this}setRotationFromQuaternion(e){return this.makeRotationFromQuaternion(e)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,r=1/Ot.setFromMatrixColumn(e,0).length(),i=1/Ot.setFromMatrixColumn(e,1).length(),a=1/Ot.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(At,e,jt)}lookAt(e,t,n){let r=this.elements;return Pt.subVectors(e,t),Pt.lengthSq()===0&&(Pt.z=1),Pt.normalize(),Mt.crossVectors(n,Pt),Mt.lengthSq()===0&&(Math.abs(n.z)===1?Pt.x+=1e-4:Pt.z+=1e-4,Pt.normalize(),Mt.crossVectors(n,Pt)),Mt.normalize(),Nt.crossVectors(Pt,Mt),r[0]=Mt.x,r[4]=Nt.x,r[8]=Pt.x,r[1]=Mt.y,r[5]=Nt.y,r[9]=Pt.y,r[2]=Mt.z,r[6]=Nt.z,r[10]=Pt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],ee=r[12],te=r[1],ne=r[5],re=r[9],ie=r[13],ae=r[2],oe=r[6],se=r[10],ce=r[14],le=r[3],ue=r[7],de=r[11],fe=r[15];return i[0]=a*x+o*te+s*ae+c*le,i[4]=a*S+o*ne+s*oe+c*ue,i[8]=a*C+o*re+s*se+c*de,i[12]=a*ee+o*ie+s*ce+c*fe,i[1]=l*x+u*te+d*ae+f*le,i[5]=l*S+u*ne+d*oe+f*ue,i[9]=l*C+u*re+d*se+f*de,i[13]=l*ee+u*ie+d*ce+f*fe,i[2]=p*x+m*te+h*ae+g*le,i[6]=p*S+m*ne+h*oe+g*ue,i[10]=p*C+m*re+h*se+g*de,i[14]=p*ee+m*ie+h*ce+g*fe,i[3]=_*x+v*te+y*ae+b*le,i[7]=_*S+v*ne+y*oe+b*ue,i[11]=_*C+v*re+y*se+b*de,i[15]=_*ee+v*ie+y*ce+b*fe,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15];return p*(+i*s*u-r*c*u-i*o*d+n*c*d+r*o*f-n*s*f)+m*(+t*s*f-t*c*d+i*a*d-r*a*f+r*c*l-i*s*l)+h*(+t*c*u-t*o*f-i*a*u+n*a*f+i*o*l-n*c*l)+g*(-r*o*l-t*s*u+t*o*d+r*a*u-n*a*d+n*s*l)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=u*h*c-m*d*c+m*s*f-o*h*f-u*s*g+o*d*g,v=p*d*c-l*h*c-p*s*f+a*h*f+l*s*g-a*d*g,y=l*m*c-p*u*c+p*o*f-a*m*f-l*o*g+a*u*g,b=p*u*s-l*m*s-p*o*d+a*m*d+l*o*h-a*u*h,x=t*_+n*v+r*y+i*b;if(x===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let S=1/x;return e[0]=_*S,e[1]=(m*d*i-u*h*i-m*r*f+n*h*f+u*r*g-n*d*g)*S,e[2]=(o*h*i-m*s*i+m*r*c-n*h*c-o*r*g+n*s*g)*S,e[3]=(u*s*i-o*d*i-u*r*c+n*d*c+o*r*f-n*s*f)*S,e[4]=v*S,e[5]=(l*h*i-p*d*i+p*r*f-t*h*f-l*r*g+t*d*g)*S,e[6]=(p*s*i-a*h*i-p*r*c+t*h*c+a*r*g-t*s*g)*S,e[7]=(a*d*i-l*s*i+l*r*c-t*d*c-a*r*f+t*s*f)*S,e[8]=y*S,e[9]=(p*u*i-l*m*i-p*n*f+t*m*f+l*n*g-t*u*g)*S,e[10]=(a*m*i-p*o*i+p*n*c-t*m*c-a*n*g+t*o*g)*S,e[11]=(l*o*i-a*u*i-l*n*c+t*u*c+a*n*f-t*o*f)*S,e[12]=b*S,e[13]=(l*m*r-p*u*r+p*n*d-t*m*d-l*n*h+t*u*h)*S,e[14]=(p*o*r-a*m*r-p*n*s+t*m*s+a*n*h-t*o*h)*S,e[15]=(a*u*r-l*o*r+l*n*s-t*u*s-a*n*d+t*o*d)*S,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements,i=Ot.set(r[0],r[1],r[2]).length(),a=Ot.set(r[4],r[5],r[6]).length(),o=Ot.set(r[8],r[9],r[10]).length();this.determinant()<0&&(i=-i),e.x=r[12],e.y=r[13],e.z=r[14],kt.copy(this);let s=1/i,c=1/a,l=1/o;return kt.elements[0]*=s,kt.elements[1]*=s,kt.elements[2]*=s,kt.elements[4]*=c,kt.elements[5]*=c,kt.elements[6]*=c,kt.elements[8]*=l,kt.elements[9]*=l,kt.elements[10]*=l,t.setFromRotationMatrix(kt),n.x=i,n.y=a,n.z=o,this}makePerspective(e,t,n,r,i,a,o=Tt){let s=this.elements,c=2*i/(t-e),l=2*i/(n-r),u=(t+e)/(t-e),d=(n+r)/(n-r),f,p;if(o===2e3)f=-(a+i)/(a-i),p=-2*a*i/(a-i);else if(o===2001)f=-a/(a-i),p=-a*i/(a-i);else throw Error(`Matrix4.makePerspective(): Invalid coordinate system: `+o);return s[0]=c,s[4]=0,s[8]=u,s[12]=0,s[1]=0,s[5]=l,s[9]=d,s[13]=0,s[2]=0,s[6]=0,s[10]=f,s[14]=p,s[3]=0,s[7]=0,s[11]=-1,s[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=Tt){let s=this.elements,c=1/(t-e),l=1/(n-r),u=1/(a-i),d=(t+e)*c,f=(n+r)*l,p,m;if(o===2e3)p=(a+i)*u,m=-2*u;else if(o===2001)p=i*u,m=-1*u;else throw Error(`../math.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return s[0]=2*c,s[4]=0,s[8]=0,s[12]=-d,s[1]=0,s[5]=2*l,s[9]=0,s[13]=-f,s[2]=0,s[6]=0,s[10]=m,s[14]=-p,s[3]=0,s[7]=0,s[11]=0,s[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Ot=new E,kt=new Dt,At=new E(0,0,0),jt=new E(1,1,1),Mt=new E,Nt=new E,Pt=new E,Ft=new Dt,It=new T,Lt=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new e(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin(tt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-tt(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin(tt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-tt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(tt(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-tt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:console.warn(`../math.Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Ft.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Ft,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return It.setFromEuler(this),this.setFromQuaternion(It,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(e){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Lt.DEFAULT_ORDER=`XYZ`;var Rt=class e{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(tt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Rt.isVector2=!0;var zt=class e{constructor(t=0,n=0,r=0,i=1){e.prototype.isVector4=!0,this.x=t,this.y=n,this.z=r,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`index is out of range: `+e)}}clone(){return new e(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Bt=class e{constructor(t,n,r,i,a,o,s,c,l){e.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,n,r,i,a,o,s,c,l)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Vt.makeScale(e,t)),this}rotate(e){return this.premultiply(Vt.makeRotation(-e)),this}translate(e,t){return this.premultiply(Vt.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new e().fromArray(this.elements)}},Vt=new Bt,Ht;(function(e){e[e.Random=0]=`Random`,e[e.Loop=1]=`Loop`,e[e.PingPong=2]=`PingPong`,e[e.Burst=3]=`Burst`})(Ht||={});function Ut(e,t,n,r){let i;switch(Ht.Random===e?t=Math.random():Ht.Burst===e&&r.isBursting&&(t=r.burstParticleIndex/r.burstParticleCount),i=n>0?Math.floor(t/n)*n:t,e){case Ht.Loop:i%=1;break;case Ht.PingPong:i=Math.abs(i%2-1)}return i}var Wt=class e{constructor(e,t,n,r){this.p=[e,t,n,r]}genValue(e){let t=e*e,n=e*e*e,r=1-e,i=r*r,a=i*r;return this.p[0]*a+this.p[1]*i*e*3+this.p[2]*r*t*3+this.p[3]*n}derivativeCoefficients(e){let t=[];for(let n=e,r=n.length-1;r>0;r--){let e=[];for(let t=0;t<r;t++){let i=r*(n[t+1]-n[t]);e.push(i)}t.push(e),n=e}return t}getSlope(e){let t=this.derivativeCoefficients(this.p)[0],n=1-e,r=n*n,i=n*e*2,a=e*e;return r*t[0]+i*t[1]+a*t[2]}controlCurve(e,t){this.p[1]=e/3+this.p[0],this.p[2]=this.p[3]-t/3}hull(e){let t=this.p,n=[],r,i=0,a=0,o=0,s=[];for(s[i++]=t[0],s[i++]=t[1],s[i++]=t[2],s[i++]=t[3];t.length>1;){for(n=[],a=0,o=t.length-1;a<o;a++)r=e*t[a]+(1-e)*t[a+1],s[i++]=r,n.push(r);t=n}return s}split(t){let n=this.hull(t);return{left:new e(n[0],n[4],n[7],n[9]),right:new e(n[9],n[8],n[6],n[3]),span:n}}clone(){return new e(this.p[0],this.p[1],this.p[2],this.p[3])}toJSON(){return{p0:this.p[0],p1:this.p[1],p2:this.p[2],p3:this.p[3]}}static fromJSON(t){return new e(t.p0,t.p1,t.p2,t.p3)}},Gt=e=>({r:e.x,g:e.y,b:e.z,a:e.w}),Kt=e=>new zt(e.r,e.g,e.b,e.a),qt=(e,t)=>{switch(t){case`Vector3`:return new E(e.x,e.y,e.z);case`Vector4`:return new zt(e.x,e.y,e.z,e.w);case`Color`:return new E(e.r,e.g,e.b);case`Number`:return e;default:return e}},Jt=(e,t)=>{switch(t){case`Vector3`:return{x:e.x,y:e.y,z:e.z};case`Vector4`:return{x:e.x,y:e.y,z:e.z,w:e.w};case`Color`:return{r:e.x,g:e.y,b:e.z};case`Number`:return e;default:return e}},Yt=class e{constructor(e,t){this.a=e,this.b=t,this.type=`value`}startGen(e){}genColor(e,t){let n=Math.random();return t.copy(this.a).lerp(this.b,n)}toJSON(){return{type:`RandomColor`,a:Gt(this.a),b:Gt(this.b)}}static fromJSON(t){return new e(Kt(t.a),Kt(t.b))}clone(){return new e(this.a.clone(),this.b.clone())}},Xt=class e{constructor(e,t){this.a=e,this.b=t,this.indexCount=-1,this.type=`value`}startGen(e){this.indexCount=e.length,e.push(Math.random())}genColor(e,t){return this.indexCount===-1&&this.startGen(e),t.copy(this.a).lerp(this.b,e[this.indexCount])}toJSON(){return{type:`ColorRange`,a:Gt(this.a),b:Gt(this.b)}}static fromJSON(t){return new e(Kt(t.a),Kt(t.b))}clone(){return new e(this.a.clone(),this.b.clone())}},Zt=class e{constructor(e,t){this.subType=t,this.type=`function`,this.keys=e}findKey(e){let t=0,n=0,r=this.keys.length-1;for(;n+1<r;)if(t=Math.floor((n+r)/2),e<this.getStartX(t))r=t-1;else if(e>this.getEndX(t))n=t+1;else return t;for(let t=n;t<=r;t++)if(e>=this.getStartX(t)&&e<=this.getEndX(t))return t;return-1}getStartX(e){return this.keys[e][1]}getEndX(e){return e+1<this.keys.length?this.keys[e+1][1]:1}genValue(e,t){let n=this.findKey(t);return this.subType===`Number`?n===-1?this.keys[0][0]:n+1>=this.keys.length?this.keys[this.keys.length-1][0]:(this.keys[n+1][0]-this.keys[n][0])*((t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))+this.keys[n][0]:n===-1?e.copy(this.keys[0][0]):n+1>=this.keys.length?e.copy(this.keys[this.keys.length-1][0]):e.copy(this.keys[n][0]).lerp(this.keys[n+1][0],(t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))}toJSON(){return this.keys[0][0].constructor.name,{type:`CLinearFunction`,subType:this.subType,keys:this.keys.map(([e,t])=>({value:Jt(e,this.subType),pos:t}))}}static fromJSON(t){return new e(t.keys.map(e=>[qt(e.value,t.subType),e.pos]),t.subType)}clone(){return this.subType===`Number`?new e(this.keys.map(([e,t])=>[e,t]),this.subType):new e(this.keys.map(([e,t])=>[e.clone(),t]),this.subType)}},Qt=new E,$t=class e{constructor(e=[[new E(0,0,0),0],[new E(1,1,1),0]],t=[[1,0],[1,1]]){this.type=`function`,this.color=new Zt(e,`Color`),this.alpha=new Zt(t,`Number`)}genColor(e,t,n){return this.color.genValue(Qt,n),t.set(Qt.x,Qt.y,Qt.z,this.alpha.genValue(1,n))}toJSON(){return{type:`Gradient`,color:this.color.toJSON(),alpha:this.alpha.toJSON()}}static fromJSON(t){if(t.functions){let n=t.functions.map(e=>[Xt.fromJSON(e.function).a,e.start]);return t.functions.length>0&&n.push([Xt.fromJSON(t.functions[t.functions.length-1].function).b,1]),new e(n.map(e=>[new E(e[0].x,e[0].y,e[0].z),e[1]]),n.map(e=>[e[0].w,e[1]]))}{let n=new e;return n.alpha=Zt.fromJSON(t.alpha),n.color=Zt.fromJSON(t.color),n}}clone(){let t=new e;return t.alpha=this.alpha.clone(),t.color=this.color.clone(),t}startGen(e){}},en=new zt,tn=class e{constructor(e,t){this.indexCount=0,this.type=`function`,this.gradient1=e,this.gradient2=t}startGen(e){this.indexCount=e.length,e.push(Math.random())}genColor(e,t,n){return this.gradient1.genColor(e,t,n),this.gradient2.genColor(e,en,n),e&&e[this.indexCount]!==void 0?t.lerp(en,e[this.indexCount]):t.lerp(en,Math.random()),t}toJSON(){return{type:`RandomColorBetweenGradient`,gradient1:this.gradient1.toJSON(),gradient2:this.gradient2.toJSON()}}static fromJSON(t){return new e($t.fromJSON(t.gradient1),$t.fromJSON(t.gradient2))}clone(){return new e(this.gradient1.clone(),this.gradient2.clone())}},nn=class e{constructor(e){this.color=e,this.type=`value`}startGen(e){}genColor(e,t){return t.copy(this.color)}toJSON(){return{type:`ConstantColor`,color:Gt(this.color)}}static fromJSON(t){return new e(Kt(t.color))}clone(){return new e(this.color.clone())}};function rn(e){switch(e.type){case`ConstantColor`:return nn.fromJSON(e);case`ColorRange`:return Xt.fromJSON(e);case`RandomColor`:return Yt.fromJSON(e);case`Gradient`:return $t.fromJSON(e);case`RandomColorBetweenGradient`:return tn.fromJSON(e);default:return new nn(new zt(1,1,1,1))}}var an=class e{constructor(e){this.value=e,this.type=`value`}startGen(e){}genValue(e){return this.value}toJSON(){return{type:`ConstantValue`,value:this.value}}static fromJSON(t){return new e(t.value)}clone(){return new e(this.value)}},on=class e{constructor(e,t){this.a=e,this.b=t,this.indexCount=-1,this.type=`value`}startGen(e){this.indexCount=e.length,e.push(Math.random())}genValue(e){return this.indexCount===-1&&this.startGen(e),St.lerp(this.a,this.b,e[this.indexCount])}toJSON(){return{type:`IntervalValue`,a:this.a,b:this.b}}static fromJSON(t){return new e(t.a,t.b)}clone(){return new e(this.a,this.b)}},sn=class{constructor(){this.functions=[]}findFunction(e){let t=0,n=0,r=this.functions.length-1;for(;n+1<r;)if(t=Math.floor((n+r)/2),e<this.getStartX(t))r=t-1;else if(e>this.getEndX(t))n=t+1;else return t;for(let t=n;t<=r;t++)if(e>=this.functions[t][1]&&e<=this.getEndX(t))return t;return-1}getStartX(e){return this.functions[e][1]}setStartX(e,t){e>0&&(this.functions[e][1]=t)}getEndX(e){return e+1<this.functions.length?this.functions[e+1][1]:1}setEndX(e,t){e+1<this.functions.length&&(this.functions[e+1][1]=t)}insertFunction(e,t){let n=this.findFunction(e);this.functions.splice(n+1,0,[t,e])}removeFunction(e){return this.functions.splice(e,1)[0][0]}getFunction(e){return this.functions[e][0]}setFunction(e,t){this.functions[e][0]=t}get numOfFunctions(){return this.functions.length}},cn=class e extends sn{constructor(e=[[new Wt(0,1/3,1/3*2,1),0]]){super(),this.type=`function`,this.functions=e}genValue(e,t=0){let n=this.findFunction(t);return n===-1?0:this.functions[n][0].genValue((t-this.getStartX(n))/(this.getEndX(n)-this.getStartX(n)))}toSVG(e,t){if(t<1)return``;let n=[`M`,0,this.functions[0][0].p[0]].join(` `);for(let r=1/t;r<=1;r+=1/t)n=[n,`L`,r*e,this.genValue(void 0,r)].join(` `);return n}toJSON(){return{type:`PiecewiseBezier`,functions:this.functions.map(([e,t])=>({function:e.toJSON(),start:t}))}}static fromJSON(t){return new e(t.functions.map(e=>[Wt.fromJSON(e.function),e.start]))}clone(){return new e(this.functions.map(([e,t])=>[e.clone(),t]))}startGen(e){}};function D(e){switch(e.type){case`ConstantValue`:return an.fromJSON(e);case`IntervalValue`:return on.fromJSON(e);case`PiecewiseBezier`:return cn.fromJSON(e);default:return new an(0)}}var ln=class e{constructor(){this.indexCount=0,this.type=`rotation`}startGen(e){this.indexCount=e.length,e.push(new T);let t,n,r,i,a,o;do t=Math.random()*2-1,n=Math.random()*2-1,r=t*t+n*n;while(r>1);do i=Math.random()*2-1,a=Math.random()*2-1,o=i*i+a*a;while(o>1);let s=Math.sqrt((1-r)/o);e[this.indexCount].set(t,n,s*i,s*a)}genValue(e,t,n,r){return this.indexCount===-1&&this.startGen(e),t.copy(e[this.indexCount]),t}toJSON(){return{type:`RandomQuat`}}static fromJSON(t){return new e}clone(){return new e}},un=class e{constructor(e,t){this.axis=e,this.angle=t,this.type=`rotation`}startGen(e){this.angle.startGen(e)}genValue(e,t,n,r){return t.setFromAxisAngle(this.axis,this.angle.genValue(e,r)*n)}toJSON(){return{type:`AxisAngle`,axis:{x:this.axis.x,y:this.axis.y,z:this.axis.z},angle:this.angle.toJSON()}}static fromJSON(t){return new e(new E(t.axis.x,t.axis.y,t.axis.z),D(t.angle))}clone(){return new e(this.axis.clone(),this.angle.clone())}},dn=class e{constructor(e,t,n,r){this.angleX=e,this.angleY=t,this.angleZ=n,this.type=`rotation`,this.eular=new Lt(0,0,0,r)}startGen(e){this.angleX.startGen(e),this.angleY.startGen(e),this.angleZ.startGen(e)}genValue(e,t,n,r){return this.eular.set(this.angleX.genValue(e,r)*n,this.angleY.genValue(e,r)*n,this.angleZ.genValue(e,r)*n),t.setFromEuler(this.eular)}toJSON(){return{type:`Euler`,angleX:this.angleX.toJSON(),angleY:this.angleY.toJSON(),angleZ:this.angleZ.toJSON(),eulerOrder:this.eular.order}}static fromJSON(t){return new e(D(t.angleX),D(t.angleY),D(t.angleZ),t.eulerOrder)}clone(){return new e(this.angleX,this.angleY,this.angleZ,this.eular.order)}};function fn(e){switch(e.type){case`AxisAngle`:return un.fromJSON(e);case`Euler`:return dn.fromJSON(e);case`RandomQuat`:return ln.fromJSON(e);default:return new ln}}var pn=class e{constructor(e,t,n){this.x=e,this.y=t,this.z=n,this.type=`vec3function`}startGen(e){this.x.startGen(e),this.y.startGen(e),this.z.startGen(e)}genValue(e,t,n){return t.set(this.x.genValue(e,n),this.y.genValue(e,n),this.z.genValue(e,n))}toJSON(){return{type:`Vector3Function`,x:this.x.toJSON(),y:this.y.toJSON(),z:this.z.toJSON()}}static fromJSON(t){return new e(D(t.x),D(t.y),D(t.z))}clone(){return new e(this.x,this.y,this.z)}};function mn(e){switch(e.type){case`Vector3Function`:return pn.fromJSON(e);default:return new pn(new an(0),new an(0),new an(0))}}function hn(e){switch(e.type){case`ConstantValue`:case`IntervalValue`:case`PiecewiseBezier`:return D(e);case`AxisAngle`:case`RandomQuat`:case`Euler`:return fn(e);case`Vector3Function`:return mn(e);default:return new an(0)}}var gn=class e{constructor(e={}){this.type=`cone`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.angle=e.angle??Math.PI/6,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[]}update(e,t){Ht.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t),r=St.lerp(1-this.thickness,1,Math.random()),i=n*this.arc,a=Math.sqrt(r),o=Math.sin(i),s=Math.cos(i);e.position.x=a*s,e.position.y=a*o,e.position.z=0;let c=this.angle*a;e.velocity.set(0,0,Math.cos(c)).addScaledVector(e.position,Math.sin(c)).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius)}toJSON(){return{type:`cone`,radius:this.radius,arc:this.arc,thickness:this.thickness,angle:this.angle,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,angle:t.angle,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,angle:this.angle,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},_n=class e{constructor(e={}){this.type=`circle`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[]}update(e,t){this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t),r=St.lerp(1-this.thickness,1,Math.random()),i=n*this.arc;e.position.x=Math.cos(i),e.position.y=Math.sin(i),e.position.z=0,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*r)}toJSON(){return{type:`circle`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}};function vn(e,t){return Math.floor(Math.random()*(t-e))+e}var yn=new E(0,1,0),bn=new E(0,0,0),xn=new E(1,1,1),Sn=new E(0,0,1),Cn=class e{constructor(e={}){this.type=`donut`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.donutRadius=e.donutRadius??this.radius*.2,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[],this._m1=new Dt}update(e,t){Ht.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=St.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=r*Math.PI*2,s=Math.sin(a),c=Math.cos(a);if(e.position.x=this.radius*c,e.position.y=this.radius*s,e.position.z=0,e.velocity.z=this.donutRadius*i*Math.sin(o),e.velocity.x=this.donutRadius*i*Math.cos(o)*c,e.velocity.y=this.donutRadius*i*Math.cos(o)*s,e.position.add(e.velocity),e.velocity.normalize().multiplyScalar(e.startSpeed),e.rotation instanceof T){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(bn,e.velocity,yn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`donut`,radius:this.radius,arc:this.arc,thickness:this.thickness,donutRadius:this.donutRadius,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,donutRadius:t.donutRadius,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,donutRadius:this.donutRadius,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},wn=class e{constructor(){this.type=`point`,this._m1=new Dt}update(e,t){}initialize(e){let t=Math.random(),n=Math.random(),r=t*Math.PI*2,i=Math.acos(2*n-1),a=Math.cbrt(Math.random()),o=Math.sin(r),s=Math.cos(r),c=Math.sin(i),l=Math.cos(i);if(e.velocity.x=a*c*s,e.velocity.y=a*c*o,e.velocity.z=a*l,e.velocity.multiplyScalar(e.startSpeed),e.position.setScalar(0),e.rotation instanceof T){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(bn,e.velocity,yn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`point`}}static fromJSON(t){return new e}clone(){return new e}},Tn=class e{constructor(e={}){this.type=`sphere`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[],this._m1=new Dt}update(e,t){Ht.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=St.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=Math.acos(2*r-1),s=Math.sin(a),c=Math.cos(a),l=Math.sin(o),u=Math.cos(o);if(e.position.x=l*c,e.position.y=l*s,e.position.z=u,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*i),e.rotation instanceof T){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(bn,e.position,yn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`sphere`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},En=class e{constructor(e={}){this.type=`hemisphere`,this.currentValue=0,this.radius=e.radius??10,this.arc=e.arc??2*Math.PI,this.thickness=e.thickness??1,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[],this._m1=new Dt}update(e,t){Ht.Random!=this.mode&&(this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t)}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t),r=Math.random(),i=St.lerp(1-this.thickness,1,Math.random()),a=n*this.arc,o=Math.acos(r),s=Math.sin(a),c=Math.cos(a),l=Math.sin(o),u=Math.cos(o);if(e.position.x=l*c,e.position.y=l*s,e.position.z=u,e.velocity.copy(e.position).multiplyScalar(e.startSpeed),e.position.multiplyScalar(this.radius*i),e.rotation instanceof T){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(bn,e.position,yn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`hemisphere`,radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({radius:t.radius,arc:t.arc,thickness:t.thickness,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({radius:this.radius,arc:this.arc,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},Dn=class e{constructor(e={}){this.type=`grid`,this.width=e.width??1,this.height=e.height??1,this.column=e.column??10,this.row=e.row??10}initialize(e){let t=Math.floor(Math.random()*this.row),n=Math.floor(Math.random()*this.column);e.position.x=n*this.width/this.column-this.width/2,e.position.y=t*this.height/this.row-this.height/2,e.position.z=0,e.velocity.set(0,0,e.startSpeed)}toJSON(){return{type:`grid`,width:this.width,height:this.height,column:this.column,row:this.row}}static fromJSON(t){return new e(t)}clone(){return new e({width:this.width,height:this.height,column:this.column,row:this.row})}update(e,t){}},On=class e{constructor(e={}){this.type=`rectangle`,this.currentValue=0,this.width=e.width??10,this.height=e.height??10,this.thickness=e.thickness??1,this.mode=e.mode??Ht.Random,this.spread=e.spread??0,this.speed=e.speed??new an(1),this.memory=[],this._m1=new Dt}update(e,t){this.currentValue+=this.speed.genValue(this.memory,e.emissionState.time/e.duration)*t}initialize(e,t){let n=Ut(this.mode,this.currentValue,this.spread,t)*(2*(this.width+this.height)),r,i;n<this.width?(r=n-this.width/2,i=-this.height/2):n<this.width+this.height?(r=this.width/2,i=n-this.width-this.height/2):n<2*this.width+this.height?(r=this.width/2-(n-this.width-this.height),i=this.height/2):(r=-this.width/2,i=this.height/2-(n-2*this.width-this.height));let a=Math.random(),o=1-this.thickness*a;if(e.position.x=r*o,e.position.y=i*o,e.position.z=0,e.velocity.x=r,e.velocity.y=i,e.velocity.z=0,e.velocity.normalize().multiplyScalar(e.startSpeed),e.rotation instanceof T){let t=e.rotation;t.x===0&&t.y===0&&t.z===0&&t.w===1&&(this._m1.lookAt(bn,e.velocity,yn),e.rotation.setFromRotationMatrix(this._m1))}}toJSON(){return{type:`rectangle`,width:this.width,height:this.height,thickness:this.thickness,mode:this.mode,spread:this.spread,speed:this.speed.toJSON()}}static fromJSON(t){return new e({width:t.width,height:t.height,thickness:t.thickness,mode:t.mode,speed:t.speed?D(t.speed):void 0,spread:t.spread})}clone(){return new e({width:this.width,height:this.height,thickness:this.thickness,mode:this.mode,speed:this.speed.clone(),spread:this.spread})}},kn={circle:{type:`circle`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:_n,loadJSON:_n.fromJSON},cone:{type:`cone`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:gn,loadJSON:gn.fromJSON},donut:{type:`donut`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`donutRadius`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:Cn,loadJSON:Cn.fromJSON},point:{type:`point`,params:[],constructor:wn,loadJSON:wn.fromJSON},sphere:{type:`sphere`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:Tn,loadJSON:Tn.fromJSON},hemisphere:{type:`hemisphere`,params:[[`radius`,[`number`]],[`arc`,[`radian`]],[`thickness`,[`number`]],[`angle`,[`radian`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:En,loadJSON:En.fromJSON},grid:{type:`grid`,params:[[`width`,[`number`]],[`height`,[`number`]],[`rows`,[`number`]],[`column`,[`number`]]],constructor:Dn,loadJSON:Dn.fromJSON},rectangle:{type:`rectangle`,params:[[`width`,[`number`]],[`height`,[`number`]],[`thickness`,[`number`]],[`mode`,[`emitterMode`]],[`spread`,[`number`]],[`speed`,[`valueFunc`,`value`]]],constructor:On,loadJSON:On.fromJSON}};function An(e,t){return kn[e.type].loadJSON(e,t)}var jn=class e{constructor(e){this.color=e,this.type=`ColorOverLife`}initialize(e){this.color.startGen(e.memory)}update(e,t){this.color.genColor(e.memory,e.color,e.age/e.life),e.color.x*=e.startColor.x,e.color.y*=e.startColor.y,e.color.z*=e.startColor.z,e.color.w*=e.startColor.w}frameUpdate(e){}toJSON(){return{type:this.type,color:this.color.toJSON()}}static fromJSON(t){return new e(rn(t.color))}clone(){return new e(this.color.clone())}reset(){}},Mn=class e{constructor(e){this.angularVelocity=e,this.type=`RotationOverLife`}initialize(e){typeof e.rotation==`number`&&this.angularVelocity.startGen(e.memory)}update(e,t){typeof e.rotation==`number`&&(e.rotation+=t*this.angularVelocity.genValue(e.memory,e.age/e.life))}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON()}}static fromJSON(t){return new e(D(t.angularVelocity))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone())}reset(){}},Nn=class e{constructor(e){this.angularVelocity=e,this.type=`Rotation3DOverLife`,this.tempQuat=new T,this.tempQuat2=new T}initialize(e){e.rotation instanceof T&&(e.angularVelocity=new T,this.angularVelocity.startGen(e.memory))}update(e,t){e.rotation instanceof T&&(this.angularVelocity.genValue(e.memory,this.tempQuat,t,e.age/e.life),e.rotation.multiply(this.tempQuat))}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON()}}static fromJSON(t){return new e(fn(t.angularVelocity))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone())}reset(){}},Pn=class e{initialize(e,t){this.ps=t,this.x.startGen(e.memory),this.y.startGen(e.memory),this.z.startGen(e.memory)}constructor(e,t,n){this.x=e,this.y=t,this.z=n,this.type=`ForceOverLife`,this._temp=new E,this._tempScale=new E,this._tempQ=new T}update(e,t){this._temp.set(this.x.genValue(e.memory,e.age/e.life),this.y.genValue(e.memory,e.age/e.life),this.z.genValue(e.memory,e.age/e.life)),this.ps.worldSpace||this._temp.multiply(this._tempScale).applyQuaternion(this._tempQ),e.velocity.addScaledVector(this._temp,t)}toJSON(){return{type:this.type,x:this.x.toJSON(),y:this.y.toJSON(),z:this.z.toJSON()}}static fromJSON(t){return new e(D(t.x),D(t.y),D(t.z))}frameUpdate(e){if(this.ps&&!this.ps.worldSpace){let e=this._temp,t=this._tempQ,n=this._tempScale;this.ps.emitter.matrixWorld.decompose(e,t,n),t.invert(),n.set(1/n.x,1/n.y,1/n.z)}}clone(){return new e(this.x.clone(),this.y.clone(),this.z.clone())}reset(){}},Fn=class e{initialize(e){this.size.startGen(e.memory)}constructor(e){this.size=e,this.type=`SizeOverLife`}update(e){this.size instanceof pn?this.size.genValue(e.memory,e.size,e.age/e.life).multiply(e.startSize):e.size.copy(e.startSize).multiplyScalar(this.size.genValue(e.memory,e.age/e.life))}toJSON(){return{type:this.type,size:this.size.toJSON()}}static fromJSON(t){return new e(hn(t.size))}frameUpdate(e){}clone(){return new e(this.size.clone())}reset(){}},In=class e{initialize(e){this.speed.startGen(e.memory)}constructor(e){this.speed=e,this.type=`SpeedOverLife`}update(e){e.speedModifier=this.speed.genValue(e.memory,e.age/e.life)}toJSON(){return{type:this.type,speed:this.speed.toJSON()}}static fromJSON(t){return new e(D(t.speed))}frameUpdate(e){}clone(){return new e(this.speed.clone())}reset(){}},Ln=class e{constructor(e){this.frame=e,this.type=`FrameOverLife`}initialize(e){this.frame.startGen(e.memory)}update(e,t){this.frame instanceof cn&&(e.uvTile=this.frame.genValue(e.memory,e.age/e.life))}frameUpdate(e){}toJSON(){return{type:this.type,frame:this.frame.toJSON()}}static fromJSON(t){return new e(D(t.frame))}clone(){return new e(this.frame.clone())}reset(){}},Rn=class e{constructor(e,t=new E(0,1,0)){this.orbitSpeed=e,this.axis=t,this.type=`OrbitOverLife`,this.temp=new E,this.rotation=new T}initialize(e){this.orbitSpeed.startGen(e.memory)}update(e,t){this.temp.copy(e.position).projectOnVector(this.axis),this.rotation.setFromAxisAngle(this.axis,this.orbitSpeed.genValue(e.memory,e.age/e.life)*t),e.position.sub(this.temp),e.position.applyQuaternion(this.rotation),e.position.add(this.temp)}frameUpdate(e){}toJSON(){return{type:this.type,orbitSpeed:this.orbitSpeed.toJSON(),axis:[this.axis.x,this.axis.y,this.axis.z]}}static fromJSON(t){return new e(D(t.orbitSpeed),t.axis?new E(t.axis[0],t.axis[1],t.axis[2]):void 0)}clone(){return new e(this.orbitSpeed.clone())}reset(){}},zn=class{constructor(e){this.data=e,this.next=null,this.prev=null}hasPrev(){return this.prev!==null}hasNext(){return this.next!==null}},Bn=class{constructor(){this.length=0,this.head=this.tail=null}isEmpty(){return this.head===null}clear(){this.length=0,this.head=this.tail=null}front(){return this.head===null?null:this.head.data}back(){return this.tail===null?null:this.tail.data}dequeue(){if(this.head){let e=this.head.data;return this.head=this.head.next,this.head?this.head.prev=null:this.tail=null,this.length--,e}}pop(){if(this.tail){let e=this.tail.data;return this.tail=this.tail.prev,this.tail?this.tail.next=null:this.head=null,this.length--,e}}queue(e){let t=new zn(e);this.tail||=t,this.head&&(this.head.prev=t,t.next=this.head),this.head=t,this.length++}push(e){let t=new zn(e);this.head||=t,this.tail&&(this.tail.next=t,t.prev=this.tail),this.tail=t,this.length++}insertBefore(e,t){let n=new zn(t);n.next=e,n.prev=e.prev,n.prev!==null&&(n.prev.next=n),n.next.prev=n,e==this.head&&(this.head=n),this.length++}remove(e){if(this.head===null||this.tail===null)return;let t=this.head;for(e===this.head.data&&(this.head=this.head.next),e===this.tail.data&&(this.tail=this.tail.prev);t.next!==null&&t.data!==e;)t=t.next;t.data===e&&(t.prev!==null&&(t.prev.next=t.next),t.next!==null&&(t.next.prev=t.prev),this.length--)}*values(){let e=this.head;for(;e!==null;)yield e.data,e=e.next}},Vn=class{constructor(){this.position=new E,this.velocity=new E,this.age=0,this.life=1,this.size=new E,this.rotation=0,this.color=new zt(1,1,1,1),this.uvTile=0,this.memory=[]}get died(){return this.age>=this.life}reset(){this.memory.length=0,this.position.set(0,0,0),this.velocity.set(0,0,0),this.age=0,this.life=1,this.size.set(1,1,1),this.rotation=0,this.color.set(1,1,1,1),this.uvTile=0}},Hn=class{constructor(){this.startSpeed=0,this.startColor=new zt,this.startSize=new E(1,1,1),this.position=new E,this.velocity=new E,this.age=0,this.life=1,this.size=new E(1,1,1),this.speedModifier=1,this.rotation=0,this.color=new zt,this.uvTile=0,this.memory=[]}get died(){return this.age>=this.life}reset(){this.memory.length=0}},Un=class{constructor(e,t,n){this.position=e,this.size=t,this.color=n}},Wn=class{constructor(){this.startSpeed=0,this.startColor=new zt,this.startSize=new E(1,1,1),this.position=new E,this.velocity=new E,this.age=0,this.life=1,this.size=new E(1,1,1),this.length=100,this.speedModifier=1,this.color=new zt,this.previous=new Bn,this.uvTile=0,this.memory=[]}update(){for(this.age<=this.life?this.previous.push(new Un(this.position.clone(),this.size.x,this.color.clone())):this.previous.length>0&&this.previous.dequeue();this.previous.length>this.length;)this.previous.dequeue()}get died(){return this.age>=this.life}reset(){this.memory.length=0,this.previous.clear()}},Gn=class e{initialize(e){this.width.startGen(e.memory)}constructor(e){this.width=e,this.type=`WidthOverLength`}update(e){if(e instanceof Wn){let t=e.previous.values();for(let n=0;n<e.previous.length;n++){let r=t.next();r.value.size=this.width.genValue(e.memory,(e.previous.length-n)/e.length)}}}frameUpdate(e){}toJSON(){return{type:this.type,width:this.width.toJSON()}}static fromJSON(t){return new e(D(t.width))}clone(){return new e(this.width.clone())}reset(){}},Kn=class e{constructor(e,t){this.direction=e,this.magnitude=t,this.type=`ApplyForce`,this.memory={data:[],dataCount:0},this.magnitudeValue=this.magnitude.genValue(this.memory)}initialize(e){}update(e,t){e.velocity.addScaledVector(this.direction,this.magnitudeValue*t)}frameUpdate(e){this.magnitudeValue=this.magnitude.genValue(this.memory)}toJSON(){return{type:this.type,direction:[this.direction.x,this.direction.y,this.direction.z],magnitude:this.magnitude.toJSON()}}static fromJSON(t){return new e(new E(t.direction[0],t.direction[1],t.direction[2]),D(t.magnitude??t.force))}clone(){return new e(this.direction.clone(),this.magnitude.clone())}reset(){}},qn=class e{constructor(e,t){this.center=e,this.magnitude=t,this.type=`GravityForce`,this.temp=new E}initialize(e){}update(e,t){this.temp.copy(this.center).sub(e.position).normalize(),e.velocity.addScaledVector(this.temp,this.magnitude/e.position.distanceToSquared(this.center)*t)}frameUpdate(e){}toJSON(){return{type:this.type,center:[this.center.x,this.center.y,this.center.z],magnitude:this.magnitude}}static fromJSON(t){return new e(new E(t.center[0],t.center[1],t.center[2]),t.magnitude)}clone(){return new e(this.center.clone(),this.magnitude)}reset(){}},Jn=class e{constructor(e){this.angle=e,this.type=`ChangeEmitDirection`,this._temp=new E,this._q=new T,this.memory={data:[],dataCount:0}}initialize(e){let t=e.velocity.length();t!=0&&(e.velocity.normalize(),e.velocity.x===0&&e.velocity.y===0?this._temp.set(0,e.velocity.z,0):this._temp.set(-e.velocity.y,e.velocity.x,0),this.angle.startGen(this.memory),this._q.setFromAxisAngle(this._temp.normalize(),this.angle.genValue(this.memory)),this._temp.copy(e.velocity),e.velocity.applyQuaternion(this._q),this._q.setFromAxisAngle(this._temp,Math.random()*Math.PI*2),e.velocity.applyQuaternion(this._q),e.velocity.setLength(t))}update(e,t){}frameUpdate(e){}toJSON(){return{type:this.type,angle:this.angle.toJSON()}}static fromJSON(t){return new e(D(t.angle))}clone(){return new e(this.angle)}reset(){}},Yn;(function(e){e[e.Death=0]=`Death`,e[e.Birth=1]=`Birth`,e[e.Frame=2]=`Frame`})(Yn||={});var Xn=class e{constructor(e,t,n,r=Yn.Frame,i=1){this.particleSystem=e,this.useVelocityAsBasis=t,this.subParticleSystem=n,this.mode=r,this.emitProbability=i,this.type=`EmitSubParticleSystem`,this.q_=new T,this.v_=new E,this.v2_=new E,this.subEmissions=[],this.subParticleSystem&&this.subParticleSystem.system&&(this.subParticleSystem.system.onlyUsedByOther=!0)}initialize(e){}update(e,t){(this.mode===Yn.Frame||this.mode===Yn.Birth&&e.age===0||this.mode===Yn.Death&&e.age+t>=e.life)&&this.emit(e,t)}emit(e,t){if(!this.subParticleSystem||Math.random()>this.emitProbability)return;let n=new Dt;this.setMatrixFromParticle(n,e),this.subEmissions.push({burstParticleCount:0,burstParticleIndex:0,isBursting:!1,burstIndex:0,burstWaveIndex:0,time:0,waitEmiting:0,matrix:n,travelDistance:0,particle:e})}frameUpdate(e){if(this.subParticleSystem)for(let t=0;t<this.subEmissions.length;t++)if(this.subEmissions[t].time>=this.subParticleSystem.system.duration)this.subEmissions[t]=this.subEmissions[this.subEmissions.length-1],this.subEmissions.length=this.subEmissions.length-1,t--;else{let n=this.subEmissions[t];n.particle&&n.particle.age<n.particle.life?this.setMatrixFromParticle(n.matrix,n.particle):n.particle=void 0,this.subParticleSystem.system.emit(e,n,n.matrix)}}toJSON(){return{type:this.type,subParticleSystem:this.subParticleSystem?this.subParticleSystem.uuid:``,useVelocityAsBasis:this.useVelocityAsBasis,mode:this.mode,emitProbability:this.emitProbability}}static fromJSON(t,n){return new e(n,t.useVelocityAsBasis,t.subParticleSystem,t.mode,t.emitProbability)}clone(){return new e(this.particleSystem,this.useVelocityAsBasis,this.subParticleSystem,this.mode,this.emitProbability)}reset(){}setMatrixFromParticle(e,t){let n;if(t.rotation===void 0||this.useVelocityAsBasis){if(t.velocity.x===0&&t.velocity.y===0&&(t.velocity.z===1||t.velocity.z===0))e.set(1,0,0,t.position.x,0,1,0,t.position.y,0,0,1,t.position.z,0,0,0,1);else{this.v_.copy(Sn).cross(t.velocity),this.v2_.copy(t.velocity).cross(this.v_);let n=this.v_.length(),r=this.v2_.length();e.set(this.v_.x/n,this.v2_.x/r,t.velocity.x,t.position.x,this.v_.y/n,this.v2_.y/r,t.velocity.y,t.position.y,this.v_.z/n,this.v2_.z/r,t.velocity.z,t.position.z,0,0,0,1)}}else t.rotation instanceof T?n=t.rotation:(this.q_.setFromAxisAngle(Sn,t.rotation),n=this.q_),e.compose(t.position,n,xn);this.particleSystem.worldSpace||e.multiplyMatrices(this.particleSystem.emitter.matrixWorld,e)}},Zn=.5*(Math.sqrt(3)-1),Qn=(3-Math.sqrt(3))/6,$n=1/3,er=1/6,tr=(Math.sqrt(5)-1)/4,nr=(5-Math.sqrt(5))/20,rr=new Float32Array([1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,-1]),ir=new Float32Array([0,1,1,1,0,1,1,-1,0,1,-1,1,0,1,-1,-1,0,-1,1,1,0,-1,1,-1,0,-1,-1,1,0,-1,-1,-1,1,0,1,1,1,0,1,-1,1,0,-1,1,1,0,-1,-1,-1,0,1,1,-1,0,1,-1,-1,0,-1,1,-1,0,-1,-1,1,1,0,1,1,1,0,-1,1,-1,0,1,1,-1,0,-1,-1,1,0,1,-1,1,0,-1,-1,-1,0,1,-1,-1,0,-1,1,1,1,0,1,1,-1,0,1,-1,1,0,1,-1,-1,0,-1,1,1,0,-1,1,-1,0,-1,-1,1,0,-1,-1,-1,0]),ar=class{constructor(e=Math.random){let t=typeof e==`function`?e:sr(e);this.p=or(t),this.perm=new Uint8Array(512),this.permMod12=new Uint8Array(512);for(let e=0;e<512;e++)this.perm[e]=this.p[e&255],this.permMod12[e]=this.perm[e]%12}noise2D(e,t){let n=this.permMod12,r=this.perm,i=0,a=0,o=0,s=(e+t)*Zn,c=Math.floor(e+s),l=Math.floor(t+s),u=(c+l)*Qn,d=c-u,f=l-u,p=e-d,m=t-f,h,g;p>m?(h=1,g=0):(h=0,g=1);let _=p-h+Qn,v=m-g+Qn,y=p-1+2*Qn,b=m-1+2*Qn,x=c&255,S=l&255,C=.5-p*p-m*m;if(C>=0){let e=n[x+r[S]]*3;C*=C,i=C*C*(rr[e]*p+rr[e+1]*m)}let ee=.5-_*_-v*v;if(ee>=0){let e=n[x+h+r[S+g]]*3;ee*=ee,a=ee*ee*(rr[e]*_+rr[e+1]*v)}let te=.5-y*y-b*b;if(te>=0){let e=n[x+1+r[S+1]]*3;te*=te,o=te*te*(rr[e]*y+rr[e+1]*b)}return 70*(i+a+o)}noise3D(e,t,n){let r=this.permMod12,i=this.perm,a,o,s,c,l=(e+t+n)*$n,u=Math.floor(e+l),d=Math.floor(t+l),f=Math.floor(n+l),p=(u+d+f)*er,m=u-p,h=d-p,g=f-p,_=e-m,v=t-h,y=n-g,b,x,S,C,ee,te;_>=v?v>=y?(b=1,x=0,S=0,C=1,ee=1,te=0):_>=y?(b=1,x=0,S=0,C=1,ee=0,te=1):(b=0,x=0,S=1,C=1,ee=0,te=1):v<y?(b=0,x=0,S=1,C=0,ee=1,te=1):_<y?(b=0,x=1,S=0,C=0,ee=1,te=1):(b=0,x=1,S=0,C=1,ee=1,te=0);let ne=_-b+er,re=v-x+er,ie=y-S+er,ae=_-C+2*er,oe=v-ee+2*er,se=y-te+2*er,ce=_-1+3*er,le=v-1+3*er,ue=y-1+3*er,de=u&255,fe=d&255,pe=f&255,me=.6-_*_-v*v-y*y;if(me<0)a=0;else{let e=r[de+i[fe+i[pe]]]*3;me*=me,a=me*me*(rr[e]*_+rr[e+1]*v+rr[e+2]*y)}let he=.6-ne*ne-re*re-ie*ie;if(he<0)o=0;else{let e=r[de+b+i[fe+x+i[pe+S]]]*3;he*=he,o=he*he*(rr[e]*ne+rr[e+1]*re+rr[e+2]*ie)}let ge=.6-ae*ae-oe*oe-se*se;if(ge<0)s=0;else{let e=r[de+C+i[fe+ee+i[pe+te]]]*3;ge*=ge,s=ge*ge*(rr[e]*ae+rr[e+1]*oe+rr[e+2]*se)}let _e=.6-ce*ce-le*le-ue*ue;if(_e<0)c=0;else{let e=r[de+1+i[fe+1+i[pe+1]]]*3;_e*=_e,c=_e*_e*(rr[e]*ce+rr[e+1]*le+rr[e+2]*ue)}return 32*(a+o+s+c)}noise4D(e,t,n,r){let i=this.perm,a,o,s,c,l,u=(e+t+n+r)*tr,d=Math.floor(e+u),f=Math.floor(t+u),p=Math.floor(n+u),m=Math.floor(r+u),h=(d+f+p+m)*nr,g=d-h,_=f-h,v=p-h,y=m-h,b=e-g,x=t-_,S=n-v,C=r-y,ee=0,te=0,ne=0,re=0;b>x?ee++:te++,b>S?ee++:ne++,b>C?ee++:re++,x>S?te++:ne++,x>C?te++:re++,S>C?ne++:re++;let ie=+(ee>=3),ae=+(te>=3),oe=+(ne>=3),se=+(re>=3),ce=+(ee>=2),le=+(te>=2),ue=+(ne>=2),de=+(re>=2),fe=+(ee>=1),pe=+(te>=1),me=+(ne>=1),he=+(re>=1),ge=b-ie+nr,_e=x-ae+nr,ve=S-oe+nr,ye=C-se+nr,be=b-ce+2*nr,xe=x-le+2*nr,Se=S-ue+2*nr,Ce=C-de+2*nr,we=b-fe+3*nr,Te=x-pe+3*nr,Ee=S-me+3*nr,De=C-he+3*nr,Oe=b-1+4*nr,ke=x-1+4*nr,Ae=S-1+4*nr,je=C-1+4*nr,Me=d&255,Ne=f&255,Pe=p&255,Fe=m&255,Ie=.6-b*b-x*x-S*S-C*C;if(Ie<0)a=0;else{let e=i[Me+i[Ne+i[Pe+i[Fe]]]]%32*4;Ie*=Ie,a=Ie*Ie*(ir[e]*b+ir[e+1]*x+ir[e+2]*S+ir[e+3]*C)}let Le=.6-ge*ge-_e*_e-ve*ve-ye*ye;if(Le<0)o=0;else{let e=i[Me+ie+i[Ne+ae+i[Pe+oe+i[Fe+se]]]]%32*4;Le*=Le,o=Le*Le*(ir[e]*ge+ir[e+1]*_e+ir[e+2]*ve+ir[e+3]*ye)}let Re=.6-be*be-xe*xe-Se*Se-Ce*Ce;if(Re<0)s=0;else{let e=i[Me+ce+i[Ne+le+i[Pe+ue+i[Fe+de]]]]%32*4;Re*=Re,s=Re*Re*(ir[e]*be+ir[e+1]*xe+ir[e+2]*Se+ir[e+3]*Ce)}let ze=.6-we*we-Te*Te-Ee*Ee-De*De;if(ze<0)c=0;else{let e=i[Me+fe+i[Ne+pe+i[Pe+me+i[Fe+he]]]]%32*4;ze*=ze,c=ze*ze*(ir[e]*we+ir[e+1]*Te+ir[e+2]*Ee+ir[e+3]*De)}let Be=.6-Oe*Oe-ke*ke-Ae*Ae-je*je;if(Be<0)l=0;else{let e=i[Me+1+i[Ne+1+i[Pe+1+i[Fe+1]]]]%32*4;Be*=Be,l=Be*Be*(ir[e]*Oe+ir[e+1]*ke+ir[e+2]*Ae+ir[e+3]*je)}return 27*(a+o+s+c+l)}};function or(e){let t=new Uint8Array(256);for(let e=0;e<256;e++)t[e]=e;for(let n=0;n<255;n++){let r=n+~~(e()*(256-n)),i=t[n];t[n]=t[r],t[r]=i}return t}function sr(e){let t=0,n=0,r=0,i=1,a=cr();return t=a(` `),n=a(` `),r=a(` `),t-=a(e),t<0&&(t+=1),n-=a(e),n<0&&(n+=1),r-=a(e),r<0&&(r+=1),function(){let e=2091639*t+i*23283064365386963e-26;return t=n,n=r,r=e-(i=e|0)}}function cr(){let e=4022871197;return function(t){t=t.toString();for(let n=0;n<t.length;n++){e+=t.charCodeAt(n);let r=.02519603282416938*e;e=r>>>0,r-=e,r*=e,e=r>>>0,r-=e,e+=r*4294967296}return(e>>>0)*23283064365386963e-26}}var lr=class e{constructor(e,t,n,r){this.scale=e,this.octaves=t,this.velocityMultiplier=n,this.timeScale=r,this.type=`TurbulenceField`,this.generator=new ar,this.timeOffset=new E,this.temp=new E,this.temp2=new E,this.timeOffset.x=Math.random()/this.scale.x*this.timeScale.x,this.timeOffset.y=Math.random()/this.scale.y*this.timeScale.y,this.timeOffset.z=Math.random()/this.scale.z*this.timeScale.z}initialize(e){}update(e,t){let n=e.position.x/this.scale.x,r=e.position.y/this.scale.y,i=e.position.z/this.scale.z;this.temp.set(0,0,0);let a=1;for(let e=0;e<this.octaves;e++)this.temp2.set(this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.x*a)/a,this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.y*a)/a,this.generator.noise4D(n*a,r*a,i*a,this.timeOffset.z*a)/a),this.temp.add(this.temp2),a*=2;this.temp.multiply(this.velocityMultiplier),e.velocity.addScaledVector(this.temp,t)}toJSON(){return{type:this.type,scale:[this.scale.x,this.scale.y,this.scale.z],octaves:this.octaves,velocityMultiplier:[this.velocityMultiplier.x,this.velocityMultiplier.y,this.velocityMultiplier.z],timeScale:[this.timeScale.x,this.timeScale.y,this.timeScale.z]}}frameUpdate(e){this.timeOffset.x+=e*this.timeScale.x,this.timeOffset.y+=e*this.timeScale.y,this.timeOffset.z+=e*this.timeScale.z}static fromJSON(t){return new e(new E(t.scale[0],t.scale[1],t.scale[2]),t.octaves,new E(t.velocityMultiplier[0],t.velocityMultiplier[1],t.velocityMultiplier[2]),new E(t.timeScale[0],t.timeScale[1],t.timeScale[2]))}clone(){return new e(this.scale.clone(),this.octaves,this.velocityMultiplier.clone(),this.timeScale.clone())}reset(){}},ur=[],dr=new E,fr=new T,pr=class e{constructor(e,t,n=new an(1),r=new an(0)){if(this.frequency=e,this.power=t,this.positionAmount=n,this.rotationAmount=r,this.type=`Noise`,this.duration=0,ur.length===0)for(let e=0;e<100;e++)ur.push(new ar)}initialize(e){e.lastPosNoise=new E,e.lastRotNoise=typeof e.rotation==`number`?0:new T,e.generatorIndex=[vn(0,100),vn(0,100),vn(0,100),vn(0,100)],this.positionAmount.startGen(e.memory),this.rotationAmount.startGen(e.memory),this.frequency.startGen(e.memory),this.power.startGen(e.memory)}update(e,t){let n=this.frequency.genValue(e.memory,e.age/e.life),r=this.power.genValue(e.memory,e.age/e.life),i=this.positionAmount.genValue(e.memory,e.age/e.life),a=this.rotationAmount.genValue(e.memory,e.age/e.life);i>0&&e.lastPosNoise!==void 0&&(e.position.sub(e.lastPosNoise),dr.set(ur[e.generatorIndex[0]].noise2D(0,e.age*n)*r*i,ur[e.generatorIndex[1]].noise2D(0,e.age*n)*r*i,ur[e.generatorIndex[2]].noise2D(0,e.age*n)*r*i),e.position.add(dr),e.lastPosNoise.copy(dr)),a>0&&e.lastRotNoise!==void 0&&(typeof e.rotation==`number`?(e.rotation-=e.lastRotNoise,e.rotation+=ur[e.generatorIndex[3]].noise2D(0,e.age*n)*Math.PI*r*a):(e.lastRotNoise.invert(),e.rotation.multiply(e.lastRotNoise),fr.set(ur[e.generatorIndex[0]].noise2D(0,e.age*n)*r*a,ur[e.generatorIndex[1]].noise2D(0,e.age*n)*r*a,ur[e.generatorIndex[2]].noise2D(0,e.age*n)*r*a,ur[e.generatorIndex[3]].noise2D(0,e.age*n)*r*a).normalize(),e.rotation.multiply(fr),e.lastRotNoise.copy(fr)))}toJSON(){return{type:this.type,frequency:this.frequency.toJSON(),power:this.power.toJSON(),positionAmount:this.positionAmount.toJSON(),rotationAmount:this.rotationAmount.toJSON()}}frameUpdate(e){this.duration+=e}static fromJSON(t){return new e(D(t.frequency),D(t.power),D(t.positionAmount),D(t.rotationAmount))}clone(){return new e(this.frequency.clone(),this.power.clone(),this.positionAmount.clone(),this.rotationAmount.clone())}reset(){}},mr=class e{constructor(e=0,t=0,n=new E){this.scaleX=e,this.scaleY=t,this.position=n,this.locations=[]}transform(e,t){e.x=this.locations[t%this.locations.length].x*this.scaleX+this.position.x,e.y=this.locations[t%this.locations.length].y*this.scaleY+this.position.y,e.z=this.position.z}static fromJSON(t){let n=new e(t.scaleX,t.scaleY,new E(t.position[0],t.position[1],t.position[2]));return n.locations=t.locations.map(e=>new Rt(e.x,e.y)),n}clone(){let t=new e(this.scaleX,this.scaleY,this.position.clone());return t.locations=this.locations.map(e=>e.clone()),t}toJSON(){return{scaleX:this.scaleX,scaleY:this.scaleY,position:this.position,locations:this.locations.map(e=>({x:e.x,y:e.y}))}}fromImage(e,t){let n=document.createElement(`canvas`);n.width=e.width,n.height=e.height;let r=n.getContext(`2d`);if(!r)return;r.drawImage(e,0,0);let i=r.getImageData(0,0,n.width,n.height,{colorSpace:`srgb`});n.remove(),this.locations.length=0;for(let e=0;e<i.height;e++)for(let n=0;n<i.width;n++)i.data[(e*i.width+n)*4+3]>t&&this.locations.push(new Rt(n,i.height-e))}};function hr(e){switch(e.type){case`TextureSequencer`:return mr.fromJSON(e);default:return new mr}}var gr=class e{constructor(e){this.type=`ApplySequences`,this.sequencers=[],this.time=0,this.index=0,this.pCount=0,this.tempV=new E,this.delay=e}initialize(e){e.id=this.pCount,e.dst=new E,e.begin=new E,e.inMotion=!1,this.pCount++}reset(){this.time=0,this.index=0,this.pCount=0}update(t,n){let r=this.sequencers[this.index],i=t.id*this.delay;this.time>=r[0].a+i&&this.time<=r[0].b+i?(t.inMotion||(t.inMotion=!0,t.begin.copy(t.position),r[1].transform(t.dst,t.id)),t.position.lerpVectors(t.begin,t.dst,e.BEZIER.genValue((this.time-r[0].a-i)/(r[0].b-r[0].a)))):this.time>r[0].b+i&&(t.inMotion=!1)}frameUpdate(e){for(;this.index+1<this.sequencers.length&&this.time>=this.sequencers[this.index+1][0].a;)this.index++;this.time+=e}appendSequencer(e,t){this.sequencers.push([e,t])}toJSON(){return{type:this.type,delay:this.delay,sequencers:this.sequencers.map(([e,t])=>({range:e.toJSON(),sequencer:t.toJSON()}))}}static fromJSON(t){let n=new e(t.delay);return t.sequencers.forEach(e=>{n.sequencers.push([D(e.range),hr(e.sequencer)])}),n}clone(){let t=new e(this.delay);return t.sequencers=this.sequencers.map(e=>[e[0].clone(),e[1].clone()]),t}};gr.BEZIER=new Wt(0,0,1,1);var _r;function vr(e){_r=e}function yr(){return _r}var br=class e{constructor(e,t){this.resolver=e,this.bounce=t,this.type=`ApplyCollision`,this.tempV=new E}initialize(e){}update(e,t){this.resolver.resolve(e.position,this.tempV)&&e.velocity.reflect(this.tempV).multiplyScalar(this.bounce)}frameUpdate(e){}toJSON(){return{type:this.type,bounce:this.bounce}}static fromJSON(t){return new e(yr(),t.bounce)}clone(){return new e(this.resolver,this.bounce)}reset(){}},xr=class e{constructor(e,t){this.color=e,this.speedRange=t,this.type=`ColorBySpeed`}initialize(e){this.color.startGen(e.memory)}update(e,t){let n=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);this.color.genColor(e.memory,e.color,n),e.color.x*=e.startColor.x,e.color.y*=e.startColor.y,e.color.z*=e.startColor.z,e.color.w*=e.startColor.w}frameUpdate(e){}toJSON(){return{type:this.type,color:this.color.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(rn(t.color),on.fromJSON(t.speedRange))}clone(){return new e(this.color.clone(),this.speedRange.clone())}reset(){}},Sr=class e{initialize(e){this.size.startGen(e.memory)}constructor(e,t){this.size=e,this.speedRange=t,this.type=`SizeBySpeed`}update(e){let t=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);this.size instanceof pn?this.size.genValue(e.memory,e.size,t).multiply(e.startSize):e.size.copy(e.startSize).multiplyScalar(this.size.genValue(e.memory,t))}toJSON(){return{type:this.type,size:this.size.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(hn(t.size),on.fromJSON(t.speedRange))}frameUpdate(e){}clone(){return new e(this.size.clone(),this.speedRange.clone())}reset(){}},Cr=class e{constructor(e,t){this.angularVelocity=e,this.speedRange=t,this.type=`RotationBySpeed`,this.tempQuat=new T}initialize(e){typeof e.rotation==`number`&&this.angularVelocity.startGen(e.memory)}update(e,t){if(typeof e.rotation==`number`){let n=(e.startSpeed-this.speedRange.a)/(this.speedRange.b-this.speedRange.a);e.rotation+=t*this.angularVelocity.genValue(e.memory,n)}}toJSON(){return{type:this.type,angularVelocity:this.angularVelocity.toJSON(),speedRange:this.speedRange.toJSON()}}static fromJSON(t){return new e(D(t.angularVelocity),on.fromJSON(t.speedRange))}frameUpdate(e){}clone(){return new e(this.angularVelocity.clone(),this.speedRange.clone())}reset(){}},wr=class e{initialize(e){this.speed.startGen(e.memory)}constructor(e,t){this.speed=e,this.dampen=t,this.type=`LimitSpeedOverLife`}update(e,t){let n=e.velocity.length(),r=this.speed.genValue(e.memory,e.age/e.life);if(n>r){let i=(n-r)/n;e.velocity.multiplyScalar(1-i*this.dampen*t*20)}}toJSON(){return{type:this.type,speed:this.speed.toJSON(),dampen:this.dampen}}static fromJSON(t){return new e(D(t.speed),t.dampen)}frameUpdate(e){}clone(){return new e(this.speed.clone(),this.dampen)}reset(){}},Tr={ApplyForce:{type:`ApplyForce`,constructor:Kn,params:[[`direction`,[`vec3`]],[`magnitude`,[`value`]]],loadJSON:Kn.fromJSON},Noise:{type:`Noise`,constructor:pr,params:[[`frequency`,[`value`]],[`power`,[`value`]],[`positionAmount`,[`value`]],[`rotationAmount`,[`value`]]],loadJSON:pr.fromJSON},TurbulenceField:{type:`TurbulenceField`,constructor:lr,params:[[`scale`,[`vec3`]],[`octaves`,[`number`]],[`velocityMultiplier`,[`vec3`]],[`timeScale`,[`vec3`]]],loadJSON:lr.fromJSON},GravityForce:{type:`GravityForce`,constructor:qn,params:[[`center`,[`vec3`]],[`magnitude`,[`number`]]],loadJSON:qn.fromJSON},ColorOverLife:{type:`ColorOverLife`,constructor:jn,params:[[`color`,[`colorFunc`]]],loadJSON:jn.fromJSON},RotationOverLife:{type:`RotationOverLife`,constructor:Mn,params:[[`angularVelocity`,[`value`,`valueFunc`]]],loadJSON:Mn.fromJSON},Rotation3DOverLife:{type:`Rotation3DOverLife`,constructor:Nn,params:[[`angularVelocity`,[`rotationFunc`]]],loadJSON:Nn.fromJSON},SizeOverLife:{type:`SizeOverLife`,constructor:Fn,params:[[`size`,[`value`,`valueFunc`,`vec3Func`]]],loadJSON:Fn.fromJSON},ColorBySpeed:{type:`ColorBySpeed`,constructor:xr,params:[[`color`,[`colorFunc`]],[`speedRange`,[`range`]]],loadJSON:xr.fromJSON},RotationBySpeed:{type:`RotationBySpeed`,constructor:Cr,params:[[`angularVelocity`,[`value`,`valueFunc`]],[`speedRange`,[`range`]]],loadJSON:Cr.fromJSON},SizeBySpeed:{type:`SizeBySpeed`,constructor:Sr,params:[[`size`,[`value`,`valueFunc`,`vec3Func`]],[`speedRange`,[`range`]]],loadJSON:Sr.fromJSON},SpeedOverLife:{type:`SpeedOverLife`,constructor:In,params:[[`speed`,[`value`,`valueFunc`]]],loadJSON:In.fromJSON},FrameOverLife:{type:`FrameOverLife`,constructor:Ln,params:[[`frame`,[`value`,`valueFunc`]]],loadJSON:Ln.fromJSON},ForceOverLife:{type:`ForceOverLife`,constructor:Pn,params:[[`x`,[`value`,`valueFunc`]],[`y`,[`value`,`valueFunc`]],[`z`,[`value`,`valueFunc`]]],loadJSON:Pn.fromJSON},OrbitOverLife:{type:`OrbitOverLife`,constructor:Rn,params:[[`orbitSpeed`,[`value`,`valueFunc`]],[`axis`,[`vec3`]]],loadJSON:Rn.fromJSON},WidthOverLength:{type:`WidthOverLength`,constructor:Gn,params:[[`width`,[`value`,`valueFunc`]]],loadJSON:Gn.fromJSON},ChangeEmitDirection:{type:`ChangeEmitDirection`,constructor:Jn,params:[[`angle`,[`value`]]],loadJSON:Jn.fromJSON},EmitSubParticleSystem:{type:`EmitSubParticleSystem`,constructor:Xn,params:[[`particleSystem`,[`self`]],[`useVelocityAsBasis`,[`boolean`]],[`subParticleSystem`,[`particleSystem`]],[`mode`,[`number`]],[`emitProbability`,[`number`]]],loadJSON:Xn.fromJSON},LimitSpeedOverLife:{type:`LimitSpeedOverLife`,constructor:wr,params:[[`speed`,[`value`,`valueFunc`]],[`dampen`,[`number`]]],loadJSON:wr.fromJSON}};function Er(e,t){return Tr[e.type]?Tr[e.type].loadJSON(e,t):null}var Dr=[];function Or(e){if(!Dr.find(t=>t.id===e.id)){e.initialize();for(let t of e.emitterShapes)kn[t.type]||(kn[t.type]=t);for(let t of e.behaviors)Tr[t.type]||(Tr[t.type]=t)}}function kr(e){let t=Dr.find(t=>t.id===e);if(t){for(let e of t.emitterShapes)kn[e.type]&&delete kn[e.type];for(let e of t.behaviors)Tr[e.type]&&delete Tr[e.type]}}var Ar=e({ApplyCollision:()=>br,ApplyForce:()=>Kn,ApplySequences:()=>gr,AxisAngleGenerator:()=>un,BatchedParticleRenderer:()=>fi,BatchedRenderer:()=>di,BehaviorFromJSON:()=>Er,BehaviorTypes:()=>Tr,Bezier:()=>Wt,ChangeEmitDirection:()=>Jn,CircleEmitter:()=>_n,ColorBySpeed:()=>xr,ColorGeneratorFromJSON:()=>rn,ColorOverLife:()=>jn,ColorRange:()=>Xt,ConeEmitter:()=>gn,ConstantColor:()=>nn,ConstantValue:()=>an,DEG2RAD:()=>Qe,DonutEmitter:()=>Cn,EmitSubParticleSystem:()=>Xn,EmitterFromJSON:()=>An,EmitterMode:()=>Ht,EmitterShapes:()=>kn,Euler:()=>Lt,EulerGenerator:()=>dn,ForceOverLife:()=>Pn,FrameOverLife:()=>Ln,GeneratorFromJSON:()=>hn,Gradient:()=>$t,GravityForce:()=>qn,GridEmitter:()=>Dn,HemisphereEmitter:()=>En,IntervalValue:()=>on,LimitSpeedOverLife:()=>wr,MathUtils:()=>St,Matrix3:()=>Bt,Matrix4:()=>Dt,MeshSurfaceEmitter:()=>jr,MeshSurfaceEmitterPlugin:()=>Mr,NodeParticle:()=>Vn,Noise:()=>pr,OrbitOverLife:()=>Rn,ParticleEmitter:()=>Ur,ParticleMeshPhysicsMaterial:()=>oi,ParticleMeshStandardMaterial:()=>ai,ParticleSystem:()=>Zr,PiecewiseBezier:()=>cn,PiecewiseFunction:()=>sn,Plugins:()=>Dr,PointEmitter:()=>wn,QuarksLoader:()=>mi,QuarksPrefab:()=>pi,QuarksUtil:()=>hi,Quaternion:()=>T,RAD2DEG:()=>$e,RandomColor:()=>Yt,RandomColorBetweenGradient:()=>tn,RandomQuatGenerator:()=>ln,RecordState:()=>Un,RectangleEmitter:()=>On,RenderMode:()=>O,Rotation3DOverLife:()=>Nn,RotationBySpeed:()=>Cr,RotationGeneratorFromJSON:()=>fn,RotationOverLife:()=>Mn,SequencerFromJSON:()=>hr,SizeBySpeed:()=>Sr,SizeOverLife:()=>Fn,SpeedOverLife:()=>In,SphereEmitter:()=>Tn,SpriteBatch:()=>si,SpriteParticle:()=>Hn,SubParticleEmitMode:()=>Yn,TextureSequencer:()=>mr,TrailBatch:()=>ui,TrailParticle:()=>Wn,TurbulenceField:()=>lr,VFXBatch:()=>Wr,ValueGeneratorFromJSON:()=>D,Vector2:()=>Rt,Vector3:()=>E,Vector3Function:()=>pn,Vector3GeneratorFromJSON:()=>mn,Vector4:()=>zt,WebGLCoordinateSystem:()=>Tt,WebGPUCoordinateSystem:()=>Et,WidthOverLength:()=>Gn,ceilPowerOfTwo:()=>_t,clamp:()=>tt,damp:()=>ot,degToRad:()=>mt,denormalize:()=>bt,euclideanModulo:()=>nt,floorPowerOfTwo:()=>vt,generateUUID:()=>et,getPhysicsResolver:()=>yr,getValueFromEmitterMode:()=>Ut,inverseLerp:()=>it,isPowerOfTwo:()=>gt,lerp:()=>at,loadPlugin:()=>Or,mapLinear:()=>rt,normalize:()=>xt,pingpong:()=>st,radToDeg:()=>ht,randFloat:()=>dt,randFloatSpread:()=>ft,randInt:()=>ut,registerShaderChunks:()=>Hr,seededRandom:()=>pt,setPhysicsResolver:()=>vr,setQuaternionFromProperEuler:()=>yt,smootherstep:()=>lt,smoothstep:()=>ct,unloadPlugin:()=>kr}),jr=class e{get geometry(){return this._geometry}set geometry(e){if(this._geometry=e,e===void 0||typeof e==`string`)return;let t=new ve;this._triangleIndexToArea.length=0;let n=0;if(!e.getIndex())return;let r=e.getIndex().array,i=r.length/3;this._triangleIndexToArea.push(0);for(let a=0;a<i;a++)t.setFromAttributeAndIndices(e.getAttribute(`position`),r[a*3],r[a*3+1],r[a*3+2]),n+=t.getArea(),this._triangleIndexToArea.push(n);e.userData.triangleIndexToArea=this._triangleIndexToArea}constructor(e){this.type=`mesh_surface`,this._triangleIndexToArea=[],this._tempA=new w,this._tempB=new w,this._tempC=new w,e&&(this.geometry=e)}initialize(e){let t=this._geometry;if(!t||t.getIndex()===null){e.position.set(0,0,0),e.velocity.set(0,0,1).multiplyScalar(e.startSpeed);return}let n=this._triangleIndexToArea.length-1,r=0,i=n,a=Math.random()*this._triangleIndexToArea[n];for(;r+1<i;){let e=Math.floor((r+i)/2);a<this._triangleIndexToArea[e]?i=e:r=e}let o=Math.random(),s=Math.random();o+s>1&&(o=1-o,s=1-s);let c=t.getIndex().array[r*3],l=t.getIndex().array[r*3+1],u=t.getIndex().array[r*3+2],d=t.getAttribute(`position`);this._tempA.fromBufferAttribute(d,c),this._tempB.fromBufferAttribute(d,l),this._tempC.fromBufferAttribute(d,u),this._tempB.sub(this._tempA),this._tempC.sub(this._tempA),this._tempA.addScaledVector(this._tempB,o).addScaledVector(this._tempC,s),e.position.copy(this._tempA),this._tempA.copy(this._tempB).cross(this._tempC).normalize(),e.velocity.copy(this._tempA).normalize().multiplyScalar(e.startSpeed)}toJSON(){return{type:`mesh_surface`,mesh:this._geometry?this._geometry.uuid:``}}static fromJSON(t,n){return new e(n.geometries[t.geometry])}clone(){return new e(this._geometry)}update(e,t){}},Mr={id:`three.quarks`,initialize:()=>{},emitterShapes:[{type:`mesh_surface`,params:[[`geometry`,[`geometry`]]],constructor:jr,loadJSON:jr.fromJSON}],behaviors:[]},Nr=`
#ifdef SOFT_PARTICLES

    /* #ifdef LOGDEPTH
    float distSample = linearize_depth_log(sampleDepth, near, far);
    #else
    float distSample = ortho ? linearize_depth_ortho(sampleDepth, near, far) : linearize_depth(sampleDepth, near, far);
    #endif */

    vec2 p2 = projPosition.xy / projPosition.w;
    
    p2 = 0.5 * p2 + 0.5;

    float readDepth = texture2D(depthTexture, p2.xy).r;
    float viewDepth = linearize_depth(readDepth);

    float softParticlesFade = saturate(SOFT_INV_FADE_DISTANCE * ((viewDepth - SOFT_NEAR_FADE) - linearDepth));
    
    gl_FragColor *= softParticlesFade;

    //gl_FragColor = vec4(softParticlesFade , 0, 0, 1);
#endif
`,Pr=`
#ifdef SOFT_PARTICLES

    uniform sampler2D depthTexture;
    uniform vec4 projParams;
    uniform vec2 softParams;

    varying vec4 projPosition;
    varying float linearDepth;

    #define SOFT_NEAR_FADE softParams.x
    #define SOFT_INV_FADE_DISTANCE softParams.y

    #define zNear projParams.x
    #define zFar projParams.y

    float linearize_depth(float d)
    {
        return (zFar * zNear) / (zFar - d * (zFar - zNear));
    }

#endif
`,Fr=`
#ifdef SOFT_PARTICLES
    varying vec4 projPosition;
    varying float linearDepth;
#endif
`,Ir=`
#ifdef SOFT_PARTICLES
    projPosition = gl_Position;
    linearDepth = -mvPosition.z;
#endif
`,Lr=`
#ifdef USE_MAP
    vec4 texelColor = texture2D( map, vUv);
    #ifdef TILE_BLEND
        texelColor = mix( texelColor, texture2D( map, vUvNext ), vUvBlend );
    #endif
    diffuseColor *= texelColor;
#endif
`,Rr=`
#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;
#ifdef TILE_BLEND
    varying vec2 vUvNext;
    varying float vUvBlend;
#endif

#endif
#ifdef USE_MAP

	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#ifdef TILE_BLEND
    varying vec2 vMapUvNext;
#endif

#endif
#ifdef USE_ALPHAMAP

	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;

#endif
#ifdef USE_DISPLACEMENTMAP

	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SPECULARMAP

	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,zr=`
#ifdef UV_TILE
    attribute float uvTile;
    uniform vec2 tileCount;
    
    mat3 makeTileTransform(float uvTile) {
        float col = mod(uvTile, tileCount.x);
        float row = (tileCount.y - floor(uvTile / tileCount.x) - 1.0);
        
        return mat3(
          1.0 / tileCount.x, 0.0, 0.0,
          0.0, 1.0 / tileCount.y, 0.0, 
          col / tileCount.x, row / tileCount.y, 1.0);
    }
#else
    mat3 makeTileTransform(float uvTile) {
        return mat3(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0);
    }
#endif

#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;
#ifdef TILE_BLEND
    varying vec2 vUvNext;
    varying float vUvBlend;
#endif

#endif
#ifdef USE_MAP

	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#ifdef TILE_BLEND
    varying vec2 vMapUvNext;
#endif

#endif
#ifdef USE_ALPHAMAP

	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;

#endif
#ifdef USE_DISPLACEMENTMAP

	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SPECULARMAP

	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,Br=`
#ifdef UV_TILE
    mat3 tileTransform = makeTileTransform(floor(uvTile));
    #ifdef TILE_BLEND
        mat3 nextTileTransform = makeTileTransform(ceil(uvTile));
        vUvBlend = fract(uvTile);
    #endif
#else
    mat3 tileTransform = makeTileTransform(0.0);
#endif

#if defined( USE_UV ) || defined( USE_ANISOTROPY )

vUv = (tileTransform *vec3( uv, 1 )).xy;
#if defined( TILE_BLEND ) && defined( UV_TILE )
    vUvNext = (nextTileTransform *vec3( uv, 1 )).xy;
#endif

#endif
#ifdef USE_MAP

vMapUv = ( tileTransform * (mapTransform * vec3( MAP_UV, 1 ) )).xy;
#if defined( TILE_BLEND ) && defined( UV_TILE )
    vMapUvNext = (nextTileTransform * (mapTransform * vec3( MAP_UV, 1 ))).xy;
#endif

#endif
#ifdef USE_ALPHAMAP

vAlphaMapUv = ( tileTransform * (alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) )).xy;
    
#endif
#ifdef USE_LIGHTMAP

vLightMapUv = ( tileTransform * (lightMapTransform * vec3( LIGHTMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_AOMAP

vAoMapUv = ( tileTransform * (aoMapTransform * vec3( AOMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_BUMPMAP

vBumpMapUv = ( tileTransform * (bumpMapTransform * vec3( BUMPMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_NORMALMAP

vNormalMapUv = ( tileTransform * (normalMapTransform * vec3( NORMALMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_DISPLACEMENTMAP

vDisplacementMapUv = ( tileTransform * (displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_EMISSIVEMAP

vEmissiveMapUv = ( tileTransform * (emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_METALNESSMAP

vMetalnessMapUv = ( tileTransform * (metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_ROUGHNESSMAP

vRoughnessMapUv = ( tileTransform * (roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_ANISOTROPYMAP

vAnisotropyMapUv = ( tileTransform * (anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOATMAP

vClearcoatMapUv = ( tileTransform * (clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

vClearcoatNormalMapUv = ( tileTransform * (clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

vClearcoatRoughnessMapUv = ( tileTransform * (clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_IRIDESCENCEMAP

vIridescenceMapUv = ( tileTransform * (iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

vIridescenceThicknessMapUv = ( tileTransform * (iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SHEEN_COLORMAP

vSheenColorMapUv = ( tileTransform * (sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

vSheenRoughnessMapUv = ( tileTransform * (sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULARMAP

vSpecularMapUv = ( tileTransform * (specularMapTransform * vec3( SPECULARMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULAR_COLORMAP

vSpecularColorMapUv = ( tileTransform * (specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

vSpecularIntensityMapUv = ( tileTransform * (specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_TRANSMISSIONMAP

vTransmissionMapUv = ( tileTransform * transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) )).xy;

#endif
#ifdef USE_THICKNESSMAP

vThicknessMapUv = ( tileTransform * thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) )).xy;

#endif

`,Vr=xe;function Hr(){Vr.tile_pars_vertex=zr,Vr.tile_vertex=Br,Vr.tile_pars_fragment=Rr,Vr.tile_fragment=Lr,Vr.soft_pars_vertex=Fr,Vr.soft_vertex=Ir,Vr.soft_pars_fragment=Pr,Vr.soft_fragment=Nr}var Ur=class extends Fe{constructor(e){super(),this.type=`ParticleEmitter`,this.system=e}clone(){let e=this.system.clone();return e.emitter.copy(this,!0),e.emitter}dispose(){}extractFromCache(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}toJSON(e,t={}){let n=this.children;this.children=this.children.filter(e=>e.type!==`ParticleSystemPreview`);let r=super.toJSON(e);return this.children=n,this.system!==null&&(r.object.ps=this.system.toJSON(e,t)),r}},O;(function(e){e[e.BillBoard=0]=`BillBoard`,e[e.StretchedBillBoard=1]=`StretchedBillBoard`,e[e.Mesh=2]=`Mesh`,e[e.Trail=3]=`Trail`,e[e.HorizontalBillBoard=4]=`HorizontalBillBoard`,e[e.VerticalBillBoard=5]=`VerticalBillBoard`})(O||={});var Wr=class extends l{constructor(e){super(),this.type=`VFXBatch`,this.maxParticles=1e3,this.systems=new Set;let t=new h;t.mask=e.layers.mask;let n=e.material.clone();n.defines={},Object.assign(n.defines,e.material.defines),this.settings={instancingGeometry:e.instancingGeometry,renderMode:e.renderMode,renderOrder:e.renderOrder,material:n,uTileCount:e.uTileCount,vTileCount:e.vTileCount,blendTiles:e.blendTiles,softParticles:e.softParticles,softNearFade:e.softNearFade,softFarFade:e.softFarFade,layers:t},this.frustumCulled=!1,this.renderOrder=this.settings.renderOrder}addSystem(e){this.systems.add(e)}removeSystem(e){this.systems.delete(e)}applyDepthTexture(e){let t=this.material.uniforms.depthTexture;t&&t.value!==e&&(t.value=e,this.material.needsUpdate=!0)}getVisibleSystems(){return Array.from(this.systems).filter(e=>e.emitter.visible)}},Gr=new E(0,0,1),Kr=new T,qr=new E,Jr=new E;new E;var Yr=60,Xr=new v(1,1,1,1),Zr=class e{set time(e){this.emissionState.time=e}get time(){return this.emissionState.time}get layers(){return this.rendererSettings.layers}get texture(){return this.rendererSettings.material.map}set texture(e){this.rendererSettings.material.map=e,this.neededToUpdateRender=!0}get material(){return this.rendererSettings.material}set material(e){this.rendererSettings.material=e,this.neededToUpdateRender=!0}get uTileCount(){return this.rendererSettings.uTileCount}set uTileCount(e){this.rendererSettings.uTileCount=e,this.neededToUpdateRender=!0}get vTileCount(){return this.rendererSettings.vTileCount}set vTileCount(e){this.rendererSettings.vTileCount=e,this.neededToUpdateRender=!0}get blendTiles(){return this.rendererSettings.blendTiles}set blendTiles(e){this.rendererSettings.blendTiles=e,this.neededToUpdateRender=!0}get softParticles(){return this.rendererSettings.softParticles}set softParticles(e){this.rendererSettings.softParticles=e,this.neededToUpdateRender=!0}get softNearFade(){return this.rendererSettings.softNearFade}set softNearFade(e){this.rendererSettings.softNearFade=e,this.neededToUpdateRender=!0}get softFarFade(){return this.rendererSettings.softFarFade}set softFarFade(e){this.rendererSettings.softFarFade=e,this.neededToUpdateRender=!0}get instancingGeometry(){return this.rendererSettings.instancingGeometry}set instancingGeometry(e){this.restart(),this.particles.length=0,this.rendererSettings.instancingGeometry=e,this.neededToUpdateRender=!0}get renderMode(){return this.rendererSettings.renderMode}set renderMode(e){if(this.rendererSettings.renderMode!==e){let t=!1;switch(this.rendererSettings.renderMode===O.Trail&&(t=!0),this.rendererSettings.renderMode===O.Mesh&&(this.startRotation=new an(0)),e){case O.Trail:this.rendererEmitterSettings={startLength:new an(30),followLocalOrigin:!1},t=!0;break;case O.Mesh:this.rendererEmitterSettings={geometry:Xr},this.startRotation=new un(new E(0,1,0),new an(0));break;case O.StretchedBillBoard:this.rendererEmitterSettings={speedFactor:0,lengthFactor:2},this.rendererSettings.instancingGeometry=Xr;break;case O.BillBoard:case O.VerticalBillBoard:case O.HorizontalBillBoard:this.rendererEmitterSettings={},this.rendererSettings.instancingGeometry=Xr}this.rendererSettings.renderMode=e,t&&(this.restart(),this.particles.length=0),this.neededToUpdateRender=!0}}get renderOrder(){return this.rendererSettings.renderOrder}set renderOrder(e){this.rendererSettings.renderOrder=e,this.neededToUpdateRender=!0}get blending(){return this.rendererSettings.material.blending}set blending(e){this.rendererSettings.material.blending=e,this.neededToUpdateRender=!0}constructor(e){if(this.temp=new E,this.travelDistance=0,this.normalMatrix=new Bt,this.memory=[],this.listeners={},this.firstTimeUpdate=!0,this.autoDestroy=e.autoDestroy!==void 0&&e.autoDestroy,this.duration=e.duration??1,this.looping=e.looping===void 0||e.looping,this.prewarm=e.prewarm!==void 0&&e.prewarm,this.startLife=e.startLife??new an(5),this.startSpeed=e.startSpeed??new an(0),this.startRotation=e.startRotation??new an(0),this.startSize=e.startSize??new an(1),this.startColor=e.startColor??new nn(new zt(1,1,1,1)),this.emissionOverTime=e.emissionOverTime??new an(10),this.emissionOverDistance=e.emissionOverDistance??new an(0),this.emissionBursts=e.emissionBursts??[],this.onlyUsedByOther=e.onlyUsedByOther??!1,this.emitterShape=e.shape??new Tn,this.behaviors=e.behaviors??[],this.worldSpace=e.worldSpace??!1,this.rendererEmitterSettings=e.rendererEmitterSettings??{},e.renderMode===O.StretchedBillBoard){let t=this.rendererEmitterSettings;e.speedFactor!==void 0&&(t.speedFactor=e.speedFactor),t.speedFactor=t.speedFactor??0,t.lengthFactor=t.lengthFactor??0}this.rendererSettings={instancingGeometry:e.instancingGeometry??Xr,renderMode:e.renderMode??O.BillBoard,renderOrder:e.renderOrder??0,material:e.material,uTileCount:e.uTileCount??1,vTileCount:e.vTileCount??1,blendTiles:e.blendTiles??!1,softParticles:e.softParticles??!1,softNearFade:e.softNearFade??0,softFarFade:e.softFarFade??0,layers:e.layers??new h},this.neededToUpdateRender=!0,this.particles=[],this.startTileIndex=e.startTileIndex||new an(0),this.emitter=new Ur(this),this.paused=!1,this.particleNum=0,this.emissionState={isBursting:!1,burstParticleIndex:0,burstParticleCount:0,burstIndex:0,burstWaveIndex:0,time:0,waitEmiting:0,travelDistance:0},this.emissionBursts.forEach(e=>e.count.startGen(this.memory)),this.emissionOverDistance.startGen(this.memory),this.emitEnded=!1,this.markForDestroy=!1,this.prewarmed=!1}pause(){this.paused=!0}play(){this.paused=!1}stop(){this.restart(),this.pause()}spawn(e,t,n){Kr.setFromRotationMatrix(n);let r=qr,i=Kr,a=Jr;n.decompose(r,i,a);for(let r=0;r<e;r++){for(t.burstParticleIndex=r,this.particleNum++;this.particles.length<this.particleNum;)this.rendererSettings.renderMode===O.Trail?this.particles.push(new Wn):this.particles.push(new Hn);let e=this.particles[this.particleNum-1];if(e.reset(),e.speedModifier=1,this.startColor.startGen(e.memory),this.startColor.genColor(e.memory,e.startColor,this.emissionState.time),e.color.copy(e.startColor),this.startSpeed.startGen(e.memory),e.startSpeed=this.startSpeed.genValue(e.memory,t.time/this.duration),this.startLife.startGen(e.memory),e.life=this.startLife.genValue(e.memory,t.time/this.duration),e.age=0,this.startSize.startGen(e.memory),this.startSize.type===`vec3function`)this.startSize.genValue(e.memory,e.startSize,t.time/this.duration);else{let n=this.startSize.genValue(e.memory,t.time/this.duration);e.startSize.set(n,n,n)}if(this.startTileIndex.startGen(e.memory),e.uvTile=this.startTileIndex.genValue(e.memory),e.size.copy(e.startSize),this.rendererSettings.renderMode===O.Mesh||this.rendererSettings.renderMode===O.BillBoard||this.rendererSettings.renderMode===O.VerticalBillBoard||this.rendererSettings.renderMode===O.HorizontalBillBoard||this.rendererSettings.renderMode===O.StretchedBillBoard){let n=e;this.startRotation.startGen(e.memory),this.rendererSettings.renderMode===O.Mesh?(n.rotation instanceof T||(n.rotation=new T),this.startRotation.type===`rotation`?this.startRotation.genValue(e.memory,n.rotation,1,t.time/this.duration):n.rotation.setFromAxisAngle(Gr,this.startRotation.genValue(n.memory,t.time/this.duration))):n.rotation=this.startRotation.type===`rotation`?0:this.startRotation.genValue(n.memory,t.time/this.duration)}else if(this.rendererSettings.renderMode===O.Trail){let n=e;this.rendererEmitterSettings.startLength.startGen(n.memory),n.length=this.rendererEmitterSettings.startLength.genValue(n.memory,t.time/this.duration)}if(this.emitterShape.initialize(e,t),this.rendererSettings.renderMode===O.Trail&&this.rendererEmitterSettings.followLocalOrigin){let t=e;t.localPosition=new E().copy(t.position)}this.worldSpace?(e.position.applyMatrix4(n),e.startSize.multiply(a).abs(),e.size.copy(e.startSize),e.velocity.multiply(a).applyMatrix3(this.normalMatrix),e.rotation&&e.rotation instanceof T&&e.rotation.multiplyQuaternions(Kr,e.rotation)):this.onlyUsedByOther&&(e.parentMatrix=n);for(let t=0;t<this.behaviors.length;t++)this.behaviors[t].initialize(e,this)}}endEmit(){this.emitEnded=!0,this.autoDestroy&&(this.markForDestroy=!0),this.fire({type:`emitEnd`,particleSystem:this})}dispose(){this._renderer&&this._renderer.deleteSystem(this),this.emitter.dispose(),this.emitter.parent&&this.emitter.parent.remove(this.emitter),this.fire({type:`destroy`,particleSystem:this})}restart(){this.memory.length=0,this.paused=!1,this.particleNum=0,this.emissionState.isBursting=!1,this.emissionState.burstIndex=0,this.emissionState.burstWaveIndex=0,this.emissionState.time=0,this.emissionState.waitEmiting=0,this.behaviors.forEach(e=>{e.reset()}),this.emitEnded=!1,this.markForDestroy=!1,this.prewarmed=!1,this.emissionBursts.forEach(e=>e.count.startGen(this.memory)),this.emissionOverDistance.startGen(this.memory)}update(e){if(this.paused)return;let t=this.emitter;for(;t.parent;)t=t.parent;if(t.type!==`Scene`){this.dispose();return}if(this.firstTimeUpdate&&(this.firstTimeUpdate=!1,this.emitter.updateWorldMatrix(!0,!1)),this.emitEnded&&this.particleNum===0){this.markForDestroy&&this.emitter.parent&&this.dispose();return}if(this.looping&&this.prewarm&&!this.prewarmed){this.prewarmed=!0;for(let e=0;e<this.duration*Yr;e++)this.update(1/Yr)}e>.1&&(e=.1),this.neededToUpdateRender&&=(this._renderer&&this._renderer.updateSystem(this),!1),this.onlyUsedByOther||this.emit(e,this.emissionState,this.emitter.matrixWorld),this.emitterShape.update(this,e);for(let t=0;t<this.behaviors.length;t++){this.behaviors[t].frameUpdate(e);for(let n=0;n<this.particleNum;n++)this.particles[n].died||this.behaviors[t].update(this.particles[n],e)}for(let t=0;t<this.particleNum;t++)this.rendererEmitterSettings.followLocalOrigin&&this.particles[t].localPosition?(this.particles[t].position.copy(this.particles[t].localPosition),this.particles[t].parentMatrix?this.particles[t].position.applyMatrix4(this.particles[t].parentMatrix):this.particles[t].position.applyMatrix4(this.emitter.matrixWorld)):this.particles[t].position.addScaledVector(this.particles[t].velocity,e*this.particles[t].speedModifier),this.particles[t].age+=e;if(this.rendererSettings.renderMode===O.Trail)for(let e=0;e<this.particleNum;e++)this.particles[e].update();for(let e=0;e<this.particleNum;e++){let t=this.particles[e];t.died&&(!(t instanceof Wn)||t.previous.length===0)&&(this.particles[e]=this.particles[this.particleNum-1],this.particles[this.particleNum-1]=t,this.particleNum--,e--,this.fire({type:`particleDied`,particleSystem:this,particle:t}))}}emit(e,t,n){t.time>this.duration&&(this.looping?(t.time-=this.duration,t.burstIndex=0,this.behaviors.forEach(e=>{e.reset()})):!this.emitEnded&&!this.onlyUsedByOther&&this.endEmit()),this.normalMatrix.getNormalMatrix(n);let r=Math.ceil(t.waitEmiting);for(this.spawn(r,t,n),t.waitEmiting-=r;t.burstIndex<this.emissionBursts.length&&this.emissionBursts[t.burstIndex].time<=t.time;){if(Math.random()<this.emissionBursts[t.burstIndex].probability){let e=this.emissionBursts[t.burstIndex].count.genValue(this.memory,this.time);t.isBursting=!0,t.burstParticleCount=e,this.spawn(e,t,n),t.isBursting=!1}t.burstIndex++}if(!this.emitEnded&&(t.waitEmiting+=e*this.emissionOverTime.genValue(this.memory,t.time/this.duration),t.previousWorldPos!=null)){this.temp.set(n.elements[12],n.elements[13],n.elements[14]),t.travelDistance+=t.previousWorldPos.distanceTo(this.temp);let e=this.emissionOverDistance.genValue(this.memory,t.time/this.duration);if(t.travelDistance*e>0){let n=Math.floor(t.travelDistance*e);t.travelDistance-=n/e,t.waitEmiting+=n}}t.previousWorldPos===void 0&&(t.previousWorldPos=new E),t.previousWorldPos.set(n.elements[12],n.elements[13],n.elements[14]),t.time+=e}toJSON(e,t={}){if((e===void 0||typeof e==`string`)&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}}),e.materials[this.rendererSettings.material.uuid]=this.rendererSettings.material.toJSON(e),t.useUrlForImage&&this.texture?.source!==void 0){let t=this.texture.source;e.images[t.uuid]={uuid:t.uuid,url:this.texture.image.url}}let n;n=this.renderMode===O.Trail?{startLength:this.rendererEmitterSettings.startLength.toJSON(),followLocalOrigin:this.rendererEmitterSettings.followLocalOrigin}:this.renderMode===O.Mesh?{}:this.renderMode===O.StretchedBillBoard?{speedFactor:this.rendererEmitterSettings.speedFactor,lengthFactor:this.rendererEmitterSettings.lengthFactor}:{};let r=this.rendererSettings.instancingGeometry;return e.geometries&&!e.geometries[r.uuid]&&(e.geometries[r.uuid]=r.toJSON()),{version:`3.0`,autoDestroy:this.autoDestroy,looping:this.looping,prewarm:this.prewarm,duration:this.duration,shape:this.emitterShape.toJSON(),startLife:this.startLife.toJSON(),startSpeed:this.startSpeed.toJSON(),startRotation:this.startRotation.toJSON(),startSize:this.startSize.toJSON(),startColor:this.startColor.toJSON(),emissionOverTime:this.emissionOverTime.toJSON(),emissionOverDistance:this.emissionOverDistance.toJSON(),emissionBursts:this.emissionBursts.map(e=>({time:e.time,count:e.count.toJSON(),probability:e.probability,interval:e.interval,cycle:e.cycle})),onlyUsedByOther:this.onlyUsedByOther,instancingGeometry:this.rendererSettings.instancingGeometry.uuid,renderOrder:this.renderOrder,renderMode:this.renderMode,rendererEmitterSettings:n,material:this.rendererSettings.material.uuid,layers:this.layers.mask,startTileIndex:this.startTileIndex.toJSON(),uTileCount:this.uTileCount,vTileCount:this.vTileCount,blendTiles:this.blendTiles,softParticles:this.rendererSettings.softParticles,softFarFade:this.rendererSettings.softFarFade,softNearFade:this.rendererSettings.softNearFade,behaviors:this.behaviors.map(e=>e.toJSON()),worldSpace:this.worldSpace}}static fromJSON(t,n,r){let i=An(t.shape,n),a;if(t.renderMode===O.Trail){let e=t.rendererEmitterSettings;a={startLength:e.startLength==null?new an(30):D(e.startLength),followLocalOrigin:e.followLocalOrigin}}else t.renderMode===O.Mesh?a={}:t.renderMode===O.StretchedBillBoard?(a=t.rendererEmitterSettings,t.speedFactor!=null&&(a.speedFactor=t.speedFactor)):a={};let o=new h;t.layers&&(o.mask=t.layers);let s=new e({autoDestroy:t.autoDestroy,looping:t.looping,prewarm:t.prewarm,duration:t.duration,shape:i,startLife:D(t.startLife),startSpeed:D(t.startSpeed),startRotation:hn(t.startRotation),startSize:hn(t.startSize),startColor:rn(t.startColor),emissionOverTime:D(t.emissionOverTime),emissionOverDistance:D(t.emissionOverDistance),emissionBursts:t.emissionBursts?.map(e=>({time:e.time,count:typeof e.count==`number`?new an(e.count):D(e.count),probability:e.probability??1,interval:e.interval??.1,cycle:e.cycle??1})),onlyUsedByOther:t.onlyUsedByOther,instancingGeometry:n.geometries[t.instancingGeometry],renderMode:t.renderMode,rendererEmitterSettings:a,renderOrder:t.renderOrder,layers:o,material:t.material?n.materials[t.material]:t.texture?new S({map:n.textures[t.texture],transparent:t.transparent??!0,blending:t.blending,side:2}):new S({color:16777215,transparent:!0,blending:2,side:2}),startTileIndex:typeof t.startTileIndex==`number`?new an(t.startTileIndex):D(t.startTileIndex),uTileCount:t.uTileCount,vTileCount:t.vTileCount,blendTiles:t.blendTiles,softParticles:t.softParticles,softFarFade:t.softFarFade,softNearFade:t.softNearFade,behaviors:[],worldSpace:t.worldSpace});return s.behaviors=t.behaviors.map(e=>{let t=Er(e,s);return t&&t.type===`EmitSubParticleSystem`&&(r[e.subParticleSystem]=t),t}).filter(e=>e!==null),s}addBehavior(e){this.behaviors.push(e)}getRendererSettings(){return this.rendererSettings}addEventListener(e,t){this.listeners[e]||(this.listeners[e]=[]),this.listeners[e].push(t)}removeAllEventListeners(e){this.listeners[e]&&(this.listeners[e]=[])}removeEventListener(e,t){if(this.listeners[e]){let n=this.listeners[e].indexOf(t);n!==-1&&this.listeners[e].splice(n,1)}}fire(e){this.listeners[e.type]&&this.listeners[e.type].forEach(t=>t(e))}clone(){let t=[];for(let e of this.emissionBursts){let n={};Object.assign(n,e),t.push(n)}let n=[];for(let e of this.behaviors)n.push(e.clone());let r;r=this.renderMode===O.Trail?{startLength:this.rendererEmitterSettings.startLength.clone(),followLocalOrigin:this.rendererEmitterSettings.followLocalOrigin}:this.renderMode===O.StretchedBillBoard?{lengthFactor:this.rendererEmitterSettings.lengthFactor,speedFactor:this.rendererEmitterSettings.speedFactor}:{};let i=new h;return i.mask=this.layers.mask,new e({autoDestroy:this.autoDestroy,looping:this.looping,duration:this.duration,shape:this.emitterShape.clone(),startLife:this.startLife.clone(),startSpeed:this.startSpeed.clone(),startRotation:this.startRotation.clone(),startSize:this.startSize.clone(),startColor:this.startColor.clone(),emissionOverTime:this.emissionOverTime.clone(),emissionOverDistance:this.emissionOverDistance.clone(),emissionBursts:t,onlyUsedByOther:this.onlyUsedByOther,instancingGeometry:this.rendererSettings.instancingGeometry,renderMode:this.renderMode,renderOrder:this.renderOrder,rendererEmitterSettings:r,material:this.rendererSettings.material,startTileIndex:this.startTileIndex,uTileCount:this.uTileCount,vTileCount:this.vTileCount,blendTiles:this.blendTiles,softParticles:this.softParticles,softFarFade:this.softFarFade,softNearFade:this.softNearFade,behaviors:n,worldSpace:this.worldSpace,layers:i})}},Qr=`

#include <common>
#include <color_pars_fragment>
#include <map_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
#include <alphatest_pars_fragment>

#include <tile_pars_fragment>
#include <soft_pars_fragment>

void main() {

    #include <clipping_planes_fragment>
    
    vec3 outgoingLight = vec3( 0.0 );
    vec4 diffuseColor = vColor;
    
    #include <logdepthbuf_fragment>
    
    #include <tile_fragment>
    #include <alphatest_fragment>

    outgoingLight = diffuseColor.rgb;
    
    #ifdef USE_COLOR_AS_ALPHA
    gl_FragColor = vec4( outgoingLight, diffuseColor.r );
    #else
    gl_FragColor = vec4( outgoingLight, diffuseColor.a );
    #endif
    
    #include <soft_fragment>
    #include <tonemapping_fragment>
}
`,$r=`
#define STANDARD

#ifdef PHYSICAL
#define IOR
#define USE_SPECULAR
#endif

uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;

#ifdef IOR
uniform float ior;
#endif

#ifdef USE_SPECULAR
uniform float specularIntensity;
uniform vec3 specularColor;

#ifdef USE_SPECULAR_COLORMAP
uniform sampler2D specularColorMap;
#endif

#ifdef USE_SPECULAR_INTENSITYMAP
uniform sampler2D specularIntensityMap;
#endif
#endif

#ifdef USE_CLEARCOAT
uniform float clearcoat;
uniform float clearcoatRoughness;
#endif

#ifdef USE_DISPERSION
uniform float dispersion;
#endif

#ifdef USE_IRIDESCENCE
uniform float iridescence;
uniform float iridescenceIOR;
uniform float iridescenceThicknessMinimum;
uniform float iridescenceThicknessMaximum;
#endif

#ifdef USE_SHEEN
uniform vec3 sheenColor;
uniform float sheenRoughness;

#ifdef USE_SHEEN_COLORMAP
uniform sampler2D sheenColorMap;
#endif

#ifdef USE_SHEEN_ROUGHNESSMAP
uniform sampler2D sheenRoughnessMap;
#endif
#endif

#ifdef USE_ANISOTROPY
uniform vec2 anisotropyVector;

#ifdef USE_ANISOTROPYMAP
uniform sampler2D anisotropyMap;
#endif
#endif

varying vec3 vViewPosition;

#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

vec4 diffuseColor = vec4( diffuse, opacity );
#include <clipping_planes_fragment>

ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
vec3 totalEmissiveRadiance = emissive;

#include <logdepthbuf_fragment>
#include <map_fragment>
#include <color_fragment>
#include <alphamap_fragment>
#include <alphatest_fragment>
#include <alphahash_fragment>
#include <roughnessmap_fragment>
#include <metalnessmap_fragment>
#include <normal_fragment_begin>
#include <normal_fragment_maps>
#include <clearcoat_normal_fragment_begin>
#include <clearcoat_normal_fragment_maps>
#include <emissivemap_fragment>

// accumulation
#include <lights_physical_fragment>
#include <lights_fragment_begin>
#include <lights_fragment_maps>
#include <lights_fragment_end>

// modulation
#include <aomap_fragment>

vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;

#include <transmission_fragment>

vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;

#ifdef USE_SHEEN

// Sheen energy compensation approximation calculation can be found at the end of
// https://drive.google.com/file/d/1T0D1VSyR4AllqIJTQAraEIzjlb5h4FKH/view?usp=sharing
float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );

outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;

#endif

#ifdef USE_CLEARCOAT

float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );

vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );

outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;

#endif

#include <opaque_fragment>
#include <tonemapping_fragment>
#include <colorspace_fragment>
#include <fog_fragment>
#include <premultiplied_alpha_fragment>
#include <dithering_fragment>
}`,ei=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute float rotation;
attribute vec3 size;

void main() {
	
    vec2 alignedPosition = position.xy * size.xy;
    
    vec2 rotatedPosition;
    rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
    rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
#ifdef HORIZONTAL
    vec4 mvPosition = modelMatrix * vec4( offset, 1.0 );
    mvPosition.x += rotatedPosition.x;
    mvPosition.z -= rotatedPosition.y;
    mvPosition = viewMatrix * mvPosition;
#elif defined(VERTICAL)
    vec4 mvPosition = modelMatrix * vec4( offset, 1.0 );
    mvPosition.y += rotatedPosition.y;
    mvPosition = viewMatrix * mvPosition;
    mvPosition.x += rotatedPosition.x;
#else
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    mvPosition.xy += rotatedPosition;
#endif

	vColor = color;

	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>

	#include <clipping_planes_vertex>

	#include <tile_vertex>
	#include <soft_vertex>
}
`,ti=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute vec4 rotation;
attribute vec3 size;
// attribute vec4 color;

void main() {

    float x2 = rotation.x + rotation.x, y2 = rotation.y + rotation.y, z2 = rotation.z + rotation.z;
    float xx = rotation.x * x2, xy = rotation.x * y2, xz = rotation.x * z2;
    float yy = rotation.y * y2, yz = rotation.y * z2, zz = rotation.z * z2;
    float wx = rotation.w * x2, wy = rotation.w * y2, wz = rotation.w * z2;
    float sx = size.x, sy = size.y, sz = size.z;
    
    mat4 matrix = mat4(( 1.0 - ( yy + zz ) ) * sx, ( xy + wz ) * sx, ( xz - wy ) * sx, 0.0,  // 1. column
                      ( xy - wz ) * sy, ( 1.0 - ( xx + zz ) ) * sy, ( yz + wx ) * sy, 0.0,  // 2. column
                      ( xz + wy ) * sz, ( yz - wx ) * sz, ( 1.0 - ( xx + yy ) ) * sz, 0.0,  // 3. column
                      offset.x, offset.y, offset.z, 1.0);
    
    vec4 mvPosition = modelViewMatrix * (matrix * vec4( position, 1.0 ));

	vColor = color;

	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
    #include <tile_vertex>
    #include <soft_vertex>
}
`,ni=`
#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>

attribute vec3 offset;
attribute vec4 rotation;
attribute vec3 size;
#include <tile_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

    #include <tile_vertex>
    float x2 = rotation.x + rotation.x, y2 = rotation.y + rotation.y, z2 = rotation.z + rotation.z;
    float xx = rotation.x * x2, xy = rotation.x * y2, xz = rotation.x * z2;
    float yy = rotation.y * y2, yz = rotation.y * z2, zz = rotation.z * z2;
    float wx = rotation.w * x2, wy = rotation.w * y2, wz = rotation.w * z2;
    float sx = size.x, sy = size.y, sz = size.z;

    mat4 particleMatrix = mat4(( 1.0 - ( yy + zz ) ) * sx, ( xy + wz ) * sx, ( xz - wy ) * sx, 0.0,  // 1. column
                      ( xy - wz ) * sy, ( 1.0 - ( xx + zz ) ) * sy, ( yz + wx ) * sy, 0.0,  // 2. column
                      ( xz + wy ) * sz, ( yz - wx ) * sz, ( 1.0 - ( xx + yy ) ) * sz, 0.0,  // 3. column
                      offset.x, offset.y, offset.z, 1.0);

#include <color_vertex>
#include <morphinstance_vertex>
#include <morphcolor_vertex>
#include <batching_vertex>

#include <beginnormal_vertex>
#include <morphnormal_vertex>
#include <skinbase_vertex>
#include <skinnormal_vertex>

	// replace defaultnormal_vertex
	vec3 transformedNormal = objectNormal;
    mat3 m = mat3( particleMatrix );
    transformedNormal /= vec3( dot( m[ 0 ], m[ 0 ] ), dot( m[ 1 ], m[ 1 ] ), dot( m[ 2 ], m[ 2 ] ) );
    transformedNormal = m * transformedNormal;
    transformedNormal = normalMatrix * transformedNormal;
    #ifdef FLIP_SIDED
        transformedNormal = - transformedNormal;
    #endif
    #ifdef USE_TANGENT
        vec3 transformedTangent = ( modelViewMatrix * vec4( objectTangent, 0.0 ) ).xyz;
        #ifdef FLIP_SIDED
        transformedTangent = - transformedTangent;
        #endif
    #endif

	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>

	// replace include <project_vertex>
  vec4 mvPosition = vec4( transformed, 1.0 );
  mvPosition = modelViewMatrix * (particleMatrix * mvPosition);
	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	
	vViewPosition = - mvPosition.xyz;
	
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
    vWorldPosition = worldPosition.xyz;
#endif
}
`,ri=`
#include <common>
#include <color_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#include <tile_pars_vertex>
#include <soft_pars_vertex>

attribute vec3 offset;
attribute float rotation;
attribute vec3 size;
attribute vec4 velocity;

uniform float speedFactor;

void main() {
    float lengthFactor = velocity.w;
    float avgSize = (size.x + size.y) * 0.5;
#ifdef USE_SKEW
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    vec3 viewVelocity = normalMatrix * velocity.xyz;

    vec3 scaledPos = vec3(position.xy * size.xy, position.z);
    float vlength = length(viewVelocity);
    vec3 projVelocity =  dot(scaledPos, viewVelocity) * viewVelocity / vlength;
    mvPosition.xyz += scaledPos + projVelocity * (speedFactor / avgSize + lengthFactor / vlength);
#else
    vec4 mvPosition = modelViewMatrix * vec4( offset, 1.0 );
    vec3 viewVelocity = normalMatrix * velocity.xyz;
    float vlength = length(viewVelocity); 
    mvPosition.xyz += position.y * normalize(cross(mvPosition.xyz, viewVelocity)) * avgSize; // switch the cross to  match unity implementation
    mvPosition.xyz -= (position.x + 0.5) * viewVelocity * (1.0 + lengthFactor / vlength) * avgSize; // minus position.x to match unity implementation
#endif
	vColor = color;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <tile_vertex>
	#include <soft_vertex>
}
`;function ii(e){return e===0?`uv`:`uv${e}`}var ai=class extends c{constructor(e){super(e)}onBeforeCompile(e,t){super.onBeforeCompile(e,t),e.vertexShader=ni,e.fragmentShader=$r}},oi=class extends ee{constructor(e){super(e)}onBeforeCompile(e,t){super.onBeforeCompile(e,t),e.vertexShader=ni,e.fragmentShader=$r}},si=class extends Wr{constructor(e){super(e),this.vector_=new E,this.vector2_=new E,this.vector3_=new E,this.quaternion_=new T,this.quaternion2_=new T,this.quaternion3_=new T,this.rotationMat_=new Bt,this.rotationMat2_=new Bt,this.maxParticles=1e3,this.setupBuffers(),this.rebuildMaterial()}buildExpandableBuffers(){this.offsetBuffer=new we(new Float32Array(this.maxParticles*3),3),this.offsetBuffer.setUsage(i),this.geometry.setAttribute(`offset`,this.offsetBuffer),this.colorBuffer=new we(new Float32Array(this.maxParticles*4),4),this.colorBuffer.setUsage(i),this.geometry.setAttribute(`color`,this.colorBuffer),this.settings.renderMode===O.Mesh?(this.rotationBuffer=new we(new Float32Array(this.maxParticles*4),4),this.rotationBuffer.setUsage(i),this.geometry.setAttribute(`rotation`,this.rotationBuffer)):(this.settings.renderMode===O.BillBoard||this.settings.renderMode===O.HorizontalBillBoard||this.settings.renderMode===O.VerticalBillBoard||this.settings.renderMode===O.StretchedBillBoard)&&(this.rotationBuffer=new we(new Float32Array(this.maxParticles),1),this.rotationBuffer.setUsage(i),this.geometry.setAttribute(`rotation`,this.rotationBuffer)),this.sizeBuffer=new we(new Float32Array(this.maxParticles*3),3),this.sizeBuffer.setUsage(i),this.geometry.setAttribute(`size`,this.sizeBuffer),this.uvTileBuffer=new we(new Float32Array(this.maxParticles),1),this.uvTileBuffer.setUsage(i),this.geometry.setAttribute(`uvTile`,this.uvTileBuffer),this.settings.renderMode===O.StretchedBillBoard&&(this.velocityBuffer=new we(new Float32Array(this.maxParticles*4),4),this.velocityBuffer.setUsage(i),this.geometry.setAttribute(`velocity`,this.velocityBuffer))}setupBuffers(){this.geometry&&this.geometry.dispose(),this.geometry=new n,this.geometry.setIndex(this.settings.instancingGeometry.getIndex()),this.settings.instancingGeometry.hasAttribute(`normal`)&&this.geometry.setAttribute(`normal`,this.settings.instancingGeometry.getAttribute(`normal`)),this.geometry.setAttribute(`position`,this.settings.instancingGeometry.getAttribute(`position`)),this.settings.instancingGeometry.hasAttribute(`uv`)&&this.geometry.setAttribute(`uv`,this.settings.instancingGeometry.getAttribute(`uv`)),this.buildExpandableBuffers()}expandBuffers(e){for(;e>=this.maxParticles;)this.maxParticles*=2;this.setupBuffers()}rebuildMaterial(){this.layers.mask=this.settings.layers.mask;let e={},t={};this.settings.material.type!==`MeshStandardMaterial`&&this.settings.material.type!==`MeshPhysicalMaterial`&&(e.map=new ae(this.settings.material.map)),this.settings.material.alphaTest&&(t.USE_ALPHATEST=``,e.alphaTest=new ae(this.settings.material.alphaTest)),t.USE_UV=``;let n=this.settings.uTileCount,r=this.settings.vTileCount;(n>1||r>1)&&(t.UV_TILE=``,e.tileCount=new ae(new Rt(n,r))),this.settings.material.defines&&this.settings.material.defines.USE_COLOR_AS_ALPHA!==void 0&&(t.USE_COLOR_AS_ALPHA=``),this.settings.material.normalMap&&(t.USE_NORMALMAP=``,t.NORMALMAP_UV=ii(this.settings.material.normalMap.channel),e.normalMapTransform=new ae(new Bt().copy(this.settings.material.normalMap.matrix))),this.settings.material.map&&(t.USE_MAP=``,this.settings.blendTiles&&(t.TILE_BLEND=``),t.MAP_UV=ii(this.settings.material.map.channel),e.mapTransform=new ae(new Bt().copy(this.settings.material.map.matrix))),t.USE_COLOR_ALPHA=``;let i;if(this.settings.softParticles){t.SOFT_PARTICLES=``;let n=this.settings.softNearFade,r=1/(this.settings.softFarFade-this.settings.softNearFade);e.softParams=new ae(new Rt(n,r)),e.depthTexture=new ae(null);let a=e.projParams=new ae(new zt);i=(e,t,n)=>{a.value.set(n.near,n.far,0,0)}}let a=!1;if(this.settings.renderMode===O.BillBoard||this.settings.renderMode===O.VerticalBillBoard||this.settings.renderMode===O.HorizontalBillBoard||this.settings.renderMode===O.Mesh){let n,r;this.settings.renderMode===O.Mesh?this.settings.material.type===`MeshStandardMaterial`||this.settings.material.type===`MeshPhysicalMaterial`?(t.USE_COLOR=``,n=ni,r=$r,a=!0):(n=ti,r=Qr):(n=ei,r=Qr),this.settings.renderMode===O.VerticalBillBoard?t.VERTICAL=``:this.settings.renderMode===O.HorizontalBillBoard&&(t.HORIZONTAL=``);let i=!1;this.settings.renderMode===O.Mesh&&(this.settings.material.type===`MeshStandardMaterial`?(this.material=new ai({}),this.material.copy(this.settings.material),this.material.uniforms=e,this.material.defines=t,i=!0):this.settings.material.type===`MeshPhysicalMaterial`&&(this.material=new oi({}),this.material.copy(this.settings.material),this.material.uniforms=e,this.material.defines=t,i=!0)),i||(this.material=new se({uniforms:e,defines:t,vertexShader:n,fragmentShader:r,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,blending:this.settings.material.blending,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha,side:this.settings.material.side,alphaTest:this.settings.material.alphaTest,depthTest:this.settings.material.depthTest,lights:a}))}else if(this.settings.renderMode===O.StretchedBillBoard)e.speedFactor=new ae(1),this.material=new se({uniforms:e,defines:t,vertexShader:ri,fragmentShader:Qr,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,blending:this.settings.material.blending,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha,side:this.settings.material.side,alphaTest:this.settings.material.alphaTest,depthTest:this.settings.material.depthTest});else throw Error(`render mode unavailable`);this.material&&i&&(this.material.onBeforeRender=i)}update(){let e=0,t=0,n=this.getVisibleSystems();for(let e of n)t+=e.particleNum;t>this.maxParticles&&this.expandBuffers(t);for(let t of n){t.emitter.updateMatrixWorld&&(t.emitter.updateWorldMatrix(!0,!1),t.emitter.updateMatrixWorld(!0));let n=t.particles,r=t.particleNum,i=this.quaternion2_,a=this.vector2_,o=this.vector3_;t.emitter.matrixWorld.decompose(a,i,o),this.rotationMat_.setFromMatrix4(t.emitter.matrixWorld);for(let a=0;a<r;a++,e++){let r=n[a];if(this.settings.renderMode===O.Mesh){let n;if(t.worldSpace)n=r.rotation;else{let e;e=r.parentMatrix?this.quaternion3_.setFromRotationMatrix(r.parentMatrix):i,n=this.quaternion_,n.copy(e).multiply(r.rotation)}this.rotationBuffer.setXYZW(e,n.x,n.y,n.z,n.w)}else(this.settings.renderMode===O.StretchedBillBoard||this.settings.renderMode===O.VerticalBillBoard||this.settings.renderMode===O.HorizontalBillBoard||this.settings.renderMode===O.BillBoard)&&this.rotationBuffer.setX(e,r.rotation);let s;if(t.worldSpace?s=r.position:(s=this.vector_,r.parentMatrix?s.copy(r.position).applyMatrix4(r.parentMatrix):s.copy(r.position).applyMatrix4(t.emitter.matrixWorld)),this.offsetBuffer.setXYZ(e,s.x,s.y,s.z),this.colorBuffer.setXYZW(e,r.color.x,r.color.y,r.color.z,r.color.w),t.worldSpace||r.parentMatrix?this.sizeBuffer.setXYZ(e,r.size.x,r.size.y,r.size.z):this.sizeBuffer.setXYZ(e,r.size.x*Math.abs(o.x),r.size.y*Math.abs(o.y),r.size.z*Math.abs(o.z)),this.uvTileBuffer.setX(e,r.uvTile),this.settings.renderMode===O.StretchedBillBoard&&this.velocityBuffer){let n=t.rendererEmitterSettings.speedFactor;n===0&&(n=.001);let i=t.rendererEmitterSettings.lengthFactor,a;t.worldSpace?a=r.velocity:(a=this.vector_,r.parentMatrix?(this.rotationMat2_.setFromMatrix4(r.parentMatrix),a.copy(r.velocity).applyMatrix3(this.rotationMat2_)):a.copy(r.velocity).applyMatrix3(this.rotationMat_)),this.velocityBuffer.setXYZW(e,a.x*n,a.y*n,a.z*n,i)}}}this.geometry.instanceCount=e,e>0&&(this.offsetBuffer.clearUpdateRanges(),this.offsetBuffer.addUpdateRange(0,e*3),this.offsetBuffer.needsUpdate=!0,this.sizeBuffer.clearUpdateRanges(),this.sizeBuffer.addUpdateRange(0,e*3),this.sizeBuffer.needsUpdate=!0,this.colorBuffer.clearUpdateRanges(),this.colorBuffer.addUpdateRange(0,e*4),this.colorBuffer.needsUpdate=!0,this.uvTileBuffer.clearUpdateRanges(),this.uvTileBuffer.addUpdateRange(0,e),this.uvTileBuffer.needsUpdate=!0,this.settings.renderMode===O.StretchedBillBoard&&this.velocityBuffer&&(this.velocityBuffer.clearUpdateRanges(),this.velocityBuffer.addUpdateRange(0,e*4),this.velocityBuffer.needsUpdate=!0),this.settings.renderMode===O.Mesh?(this.rotationBuffer.clearUpdateRanges(),this.rotationBuffer.addUpdateRange(0,e*4),this.rotationBuffer.needsUpdate=!0):(this.settings.renderMode===O.StretchedBillBoard||this.settings.renderMode===O.HorizontalBillBoard||this.settings.renderMode===O.VerticalBillBoard||this.settings.renderMode===O.BillBoard)&&(this.rotationBuffer.clearUpdateRanges(),this.rotationBuffer.addUpdateRange(0,e),this.rotationBuffer.needsUpdate=!0))}dispose(){this.geometry.dispose()}},ci=`

#include <common>
#include <tile_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

uniform sampler2D alphaMap;
uniform float useAlphaMap;
uniform float visibility;
uniform float alphaTest;

varying vec4 vColor;
    
void main() {
    #include <clipping_planes_fragment>
    #include <logdepthbuf_fragment>

    vec4 diffuseColor = vColor;
    
    #ifdef USE_MAP
    #include <tile_fragment>
    #ifndef USE_COLOR_AS_ALPHA
    #endif
    #endif
    if( useAlphaMap == 1. ) diffuseColor.a *= texture2D( alphaMap, vUv).a;
    if( diffuseColor.a < alphaTest ) discard;
    gl_FragColor = diffuseColor;

    #include <fog_fragment>
    #include <tonemapping_fragment>
}`,li=`
#include <common>
#include <tile_pars_vertex>
#include <color_pars_vertex>
#include <clipping_planes_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <fog_pars_vertex>

attribute vec3 previous;
attribute vec3 next;
attribute float side;
attribute float width;

uniform vec2 resolution;
uniform float lineWidth;
uniform float sizeAttenuation;
    
vec2 fix(vec4 i, float aspect) {
    vec2 res = i.xy / i.w;
    res.x *= aspect;
    return res;
}
    
void main() {

    #include <tile_vertex>
    
    float aspect = resolution.x / resolution.y;

    vColor = color;

    mat4 m = projectionMatrix * modelViewMatrix;
    vec4 finalPosition = m * vec4( position, 1.0 );
    vec4 prevPos = m * vec4( previous, 1.0 );
    vec4 nextPos = m * vec4( next, 1.0 );

    vec2 currentP = fix( finalPosition, aspect );
    vec2 prevP = fix( prevPos, aspect );
    vec2 nextP = fix( nextPos, aspect );

    float w = lineWidth * width;

    vec2 dir;
    if( nextP == currentP ) dir = normalize( currentP - prevP );
    else if( prevP == currentP ) dir = normalize( nextP - currentP );
    else {
        vec2 dir1 = normalize( currentP - prevP );
        vec2 dir2 = normalize( nextP - currentP );
        dir = normalize( dir1 + dir2 );

        vec2 perp = vec2( -dir1.y, dir1.x );
        vec2 miter = vec2( -dir.y, dir.x );
        //w = clamp( w / dot( miter, perp ), 0., 4., * lineWidth * width );

    }

    //vec2 normal = ( cross( vec3( dir, 0. ) vec3( 0., 0., 1. ) ) ).xy;
    vec4 normal = vec4( -dir.y, dir.x, 0., 1. );
    normal.xy *= .5 * w;
    normal *= projectionMatrix;
    if( sizeAttenuation == 0. ) {
        normal.xy *= finalPosition.w;
        normal.xy /= ( vec4( resolution, 0., 1. ) * projectionMatrix ).xy;
    }

    finalPosition.xy += normal.xy * side;

    gl_Position = finalPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	
    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );
    
	#include <fog_vertex>
}`,ui=class extends Wr{constructor(e){super(e),this.vector_=new E,this.vector2_=new E,this.vector3_=new E,this.quaternion_=new T,this.maxParticles=1e4,this.setupBuffers(),this.rebuildMaterial()}setupBuffers(){this.geometry&&this.geometry.dispose(),this.geometry=new ye,this.indexBuffer=new De(new Uint32Array(this.maxParticles*6),1),this.indexBuffer.setUsage(i),this.geometry.setIndex(this.indexBuffer),this.positionBuffer=new De(new Float32Array(this.maxParticles*6),3),this.positionBuffer.setUsage(i),this.geometry.setAttribute(`position`,this.positionBuffer),this.previousBuffer=new De(new Float32Array(this.maxParticles*6),3),this.previousBuffer.setUsage(i),this.geometry.setAttribute(`previous`,this.previousBuffer),this.nextBuffer=new De(new Float32Array(this.maxParticles*6),3),this.nextBuffer.setUsage(i),this.geometry.setAttribute(`next`,this.nextBuffer),this.widthBuffer=new De(new Float32Array(this.maxParticles*2),1),this.widthBuffer.setUsage(i),this.geometry.setAttribute(`width`,this.widthBuffer),this.sideBuffer=new De(new Float32Array(this.maxParticles*2),1),this.sideBuffer.setUsage(i),this.geometry.setAttribute(`side`,this.sideBuffer),this.uvBuffer=new De(new Float32Array(this.maxParticles*4),2),this.uvBuffer.setUsage(i),this.geometry.setAttribute(`uv`,this.uvBuffer),this.colorBuffer=new De(new Float32Array(this.maxParticles*8),4),this.colorBuffer.setUsage(i),this.geometry.setAttribute(`color`,this.colorBuffer)}expandBuffers(e){for(;e>=this.maxParticles;)this.maxParticles*=2;this.setupBuffers()}rebuildMaterial(){this.layers.mask=this.settings.layers.mask;let e={lineWidth:{value:1},map:{value:null},useMap:{value:0},alphaMap:{value:null},useAlphaMap:{value:0},resolution:{value:new Rt(1,1)},sizeAttenuation:{value:1},visibility:{value:1},alphaTest:{value:0}},t={};if(t.USE_UV=``,t.USE_COLOR_ALPHA=``,this.settings.material.map&&(t.USE_MAP=``,t.MAP_UV=ii(this.settings.material.map.channel),e.map=new ae(this.settings.material.map),e.mapTransform=new ae(new Bt().copy(this.settings.material.map.matrix))),this.settings.material.defines&&this.settings.material.defines.USE_COLOR_AS_ALPHA!==void 0&&(t.USE_COLOR_AS_ALPHA=``),this.settings.renderMode===O.Trail)this.material=new se({uniforms:e,defines:t,vertexShader:li,fragmentShader:ci,transparent:this.settings.material.transparent,depthWrite:!this.settings.material.transparent,side:this.settings.material.side,blending:this.settings.material.blending||2,blendDst:this.settings.material.blendDst,blendSrc:this.settings.material.blendSrc,blendEquation:this.settings.material.blendEquation,premultipliedAlpha:this.settings.material.premultipliedAlpha});else throw Error(`render mode unavailable`)}update(){let e=0,t=0,n=0,r=this.getVisibleSystems();for(let e of r)for(let t=0;t<e.particleNum;t++)n+=e.particles[t].previous.length*2;n>this.maxParticles&&this.expandBuffers(n);for(let n of r){n.emitter.updateMatrixWorld&&(n.emitter.updateWorldMatrix(!0,!1),n.emitter.updateMatrixWorld(!0));let r=this.quaternion_,i=this.vector2_,a=this.vector3_;n.emitter.matrixWorld.decompose(i,r,a);let o=n.particles,s=n.particleNum,c=this.settings.uTileCount,l=this.settings.vTileCount,u=1/c,d=1/l;for(let r=0;r<s;r++){let i=o[r],s=i.uvTile%l,c=Math.floor(i.uvTile/l+.001),f=i.previous.values(),p=f.next(),m=p.value,h=m;p.done||(p=f.next());let g;g=p.value===void 0?h:p.value;for(let r=0;r<i.previous.length;r++,e+=2){if(this.positionBuffer.setXYZ(e,h.position.x,h.position.y,h.position.z),this.positionBuffer.setXYZ(e+1,h.position.x,h.position.y,h.position.z),n.worldSpace?(this.positionBuffer.setXYZ(e,h.position.x,h.position.y,h.position.z),this.positionBuffer.setXYZ(e+1,h.position.x,h.position.y,h.position.z)):(i.parentMatrix?this.vector_.copy(h.position).applyMatrix4(i.parentMatrix):this.vector_.copy(h.position).applyMatrix4(n.emitter.matrixWorld),this.positionBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.positionBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),n.worldSpace?(this.previousBuffer.setXYZ(e,m.position.x,m.position.y,m.position.z),this.previousBuffer.setXYZ(e+1,m.position.x,m.position.y,m.position.z)):(i.parentMatrix?this.vector_.copy(m.position).applyMatrix4(i.parentMatrix):this.vector_.copy(m.position).applyMatrix4(n.emitter.matrixWorld),this.previousBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.previousBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),n.worldSpace?(this.nextBuffer.setXYZ(e,g.position.x,g.position.y,g.position.z),this.nextBuffer.setXYZ(e+1,g.position.x,g.position.y,g.position.z)):(i.parentMatrix?this.vector_.copy(g.position).applyMatrix4(i.parentMatrix):this.vector_.copy(g.position).applyMatrix4(n.emitter.matrixWorld),this.nextBuffer.setXYZ(e,this.vector_.x,this.vector_.y,this.vector_.z),this.nextBuffer.setXYZ(e+1,this.vector_.x,this.vector_.y,this.vector_.z)),this.sideBuffer.setX(e,1),this.sideBuffer.setX(e+1,-1),n.worldSpace)this.widthBuffer.setX(e,h.size),this.widthBuffer.setX(e+1,h.size);else if(i.parentMatrix)this.widthBuffer.setX(e,h.size),this.widthBuffer.setX(e+1,h.size);else{let t=(Math.abs(a.x)+Math.abs(a.y)+Math.abs(a.z))/3;this.widthBuffer.setX(e,h.size*t),this.widthBuffer.setX(e+1,h.size*t)}this.uvBuffer.setXY(e,(r/i.previous.length+s)*u,(l-c-1)*d),this.uvBuffer.setXY(e+1,(r/i.previous.length+s)*u,(l-c)*d),this.colorBuffer.setXYZW(e,h.color.x,h.color.y,h.color.z,h.color.w),this.colorBuffer.setXYZW(e+1,h.color.x,h.color.y,h.color.z,h.color.w),r+1<i.previous.length&&(this.indexBuffer.setX(t*3,e),this.indexBuffer.setX(t*3+1,e+1),this.indexBuffer.setX(t*3+2,e+2),t++,this.indexBuffer.setX(t*3,e+2),this.indexBuffer.setX(t*3+1,e+1),this.indexBuffer.setX(t*3+2,e+3),t++),m=h,h=g,p.done||(p=f.next(),p.value!==void 0&&(g=p.value))}}}this.positionBuffer.clearUpdateRanges(),this.positionBuffer.addUpdateRange(0,e*3),this.positionBuffer.needsUpdate=!0,this.previousBuffer.clearUpdateRanges(),this.previousBuffer.addUpdateRange(0,e*3),this.previousBuffer.needsUpdate=!0,this.nextBuffer.clearUpdateRanges(),this.nextBuffer.addUpdateRange(0,e*3),this.nextBuffer.needsUpdate=!0,this.sideBuffer.clearUpdateRanges(),this.sideBuffer.addUpdateRange(0,e),this.sideBuffer.needsUpdate=!0,this.widthBuffer.clearUpdateRanges(),this.widthBuffer.addUpdateRange(0,e),this.widthBuffer.needsUpdate=!0,this.uvBuffer.clearUpdateRanges(),this.uvBuffer.addUpdateRange(0,e*2),this.uvBuffer.needsUpdate=!0,this.colorBuffer.clearUpdateRanges(),this.colorBuffer.addUpdateRange(0,e*4),this.colorBuffer.needsUpdate=!0,this.indexBuffer.clearUpdateRanges(),this.indexBuffer.addUpdateRange(0,t*3),this.indexBuffer.needsUpdate=!0,this.geometry.setDrawRange(0,t*3)}dispose(){this.geometry.dispose()}},di=class e extends Fe{constructor(){super(),this.batches=[],this.systemToBatchIndex=new Map,this.type=`BatchedRenderer`,this.depthTexture=null}static equals(e,t){return e.material.side===t.material.side&&e.material.blending===t.material.blending&&e.material.blendSrc===t.material.blendSrc&&e.material.blendDst===t.material.blendDst&&e.material.blendEquation===t.material.blendEquation&&e.material.premultipliedAlpha===t.material.premultipliedAlpha&&e.material.transparent===t.material.transparent&&e.material.depthTest===t.material.depthTest&&e.material.type===t.material.type&&e.material.alphaTest===t.material.alphaTest&&e.material.map===t.material.map&&e.renderMode===t.renderMode&&e.blendTiles===t.blendTiles&&e.softParticles===t.softParticles&&e.softFarFade===t.softFarFade&&e.softNearFade===t.softNearFade&&e.uTileCount===t.uTileCount&&e.vTileCount===t.vTileCount&&e.instancingGeometry===t.instancingGeometry&&e.renderOrder===t.renderOrder&&e.layers.mask===t.layers.mask}addSystem(t){t._renderer=this;let n=t.getRendererSettings();for(let r=0;r<this.batches.length;r++)if(e.equals(this.batches[r].settings,n)){this.batches[r].addSystem(t),this.systemToBatchIndex.set(t,r);return}let r;switch(n.renderMode){case O.Trail:r=new ui(n);break;case O.Mesh:case O.BillBoard:case O.VerticalBillBoard:case O.HorizontalBillBoard:case O.StretchedBillBoard:r=new si(n)}this.depthTexture&&r.applyDepthTexture(this.depthTexture),r.addSystem(t),this.batches.push(r),this.systemToBatchIndex.set(t,this.batches.length-1),this.add(r)}deleteSystem(e){let t=this.systemToBatchIndex.get(e);t!=null&&(this.batches[t].removeSystem(e),this.systemToBatchIndex.delete(e))}setDepthTexture(e){this.depthTexture=e;for(let t of this.batches)t.applyDepthTexture(e)}updateSystem(e){this.deleteSystem(e),this.addSystem(e)}update(e){this.systemToBatchIndex.forEach((t,n)=>{n.update(e)});for(let e=0;e<this.batches.length;e++)this.batches[e].update()}},fi=di,pi=class e extends o{constructor(){super(),this.type=`QuarksPrefab`,this.animationData=[],this.isPlaying=!1,this.currentTime=-1e-5,this.timeScale=1,this.duration=0,this._mixers=new Map,this._tempAnimationJSON=[],this._clock=new We(!0)}registerBatchedRenderer(e){this._batchedRenderer=e}getOrCreateMixer(e){if(!this._mixers.has(e)){let t=new ue(e);this._mixers.set(e,t)}return this._mixers.get(e)}addThreeAnimation(e,t,n=0,i=t.duration,a=!1){let o=this.getOrCreateMixer(e),s=o.clipAction(t);a||(s.setLoop(r,1),s.clampWhenFinished=!0);let c={startTime:n,duration:i,type:`three`,loop:a,target:e,clip:t,mixer:o,action:s};return this.animationData.push(c),this.updateDuration(),c}addParticleSystemAnimation(e,t=0,n=0,r=!1){n<=0&&(n=e.system.duration);let i={startTime:t,duration:n,type:`ps`,loop:r,target:e};return this.animationData.push(i),this.pause(),this.updateDuration(),i}removeAnimation(e){this.animationData.splice(e,1),this.updateDuration()}play(){this.isPlaying||=!0}pause(){this.isPlaying&&(this.isPlaying=!1,this.animationData.forEach(e=>{e.target&&(e.type===`ps`&&!e.target.system.paused?e.target.system.pause():e.type===`three`&&e.action&&e.action.isRunning()&&(e.action.paused=!0))}))}stop(){this.pause(),this.currentTime=-1e-5,this.animationData.forEach(e=>{e.type===`ps`&&e.target?e.target.system.stop():e.type===`three`&&e.mixer&&e.action&&e.action.reset()})}update(e){if(!this.isPlaying)return;let t=e===void 0?this._clock.getDelta():e;this.currentTime+=t*this.timeScale,this.currentTime>this.duration&&this.stop();let n=new Set;this.animationData.forEach(e=>{let{startTime:r,duration:i,type:a,loop:o,target:s,action:c,mixer:l}=e,u=r+i,d=this.currentTime>=r,f=this.currentTime>u,p=Math.abs(this.currentTime-r)<t;a===`three`&&c&&l?d&&!f?(p?(c.reset(),c.play()):c.paused&&(c.paused=!1,c.play()),this.currentTime-r,n.add(l)):f&&(c.paused=!0):a===`ps`&&s&&(d&&!f?p&&e.target.system.restart():f&&e.target.system.endEmit())}),n.forEach(e=>{e.update(t)})}setTime(e){let t=this.currentTime;this.currentTime=e,this.animationData.forEach(n=>{let{startTime:r,duration:i,type:a,target:o,action:s,mixer:c}=n;a===`three`&&s&&c?(s.reset(),e>=r&&e<r+i&&(s.time=e-r,s.play(),c.update(0),s.paused=!this.isPlaying)):a===`ps`&&o&&(e>=r&&e<r+i?(t<r||t>=r+i)&&o.system.restart():o.system.endEmit())})}getDuration(){return this.duration}updateDuration(){let e=0;this.animationData.forEach(t=>{let n=t.startTime+t.duration;n>e&&(e=n)}),this.duration=e}resolveReferences(e){this._tempAnimationJSON.forEach(t=>{let n;if(e.traverse(e=>{e.uuid===t.targetUUID&&(n=e)}),n){if(t.type===`three`&&t.clipUUID){let e;n.animations&&(e=n.animations.find(e=>e.uuid===t.clipUUID)),e&&this.addThreeAnimation(n,e,t.startTime,t.duration,t.loop)}else t.type===`ps`&&this.addParticleSystemAnimation(n,t.startTime,t.duration,t.loop)}}),this.updateDuration(),this._tempAnimationJSON=[]}toJSON(){let e=super.toJSON();return e.object.animationData=this.animationData.map(e=>({startTime:e.startTime,duration:e.duration,type:e.type,targetUUID:e.target.uuid,clipUUID:e.clip?.uuid,loop:e.loop})),e}static fromJSON(t){let n=new e;return t.animationData&&(n._tempAnimationJSON=t.animationData),n}},mi=class extends d{constructor(e){super(e)}linkReference(e){let t={};e.traverse(function(e){t[e.uuid]=e}),e.traverse(function(e){if(e.type===`ParticleEmitter`){let n=e.system;n.emitterShape;for(let e=0;e<n.behaviors.length;e++)n.behaviors[e]instanceof Xn&&(n.behaviors[e].subParticleSystem=t[n.behaviors[e].subParticleSystem])}})}parse(e,t){let n=super.parse(e,t);return this.linkReference(n),n}parseObject(e,n,r,i,c){let u;function d(e){return n[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined geometry`,e),n[e]}function f(e){if(e!==void 0){if(Array.isArray(e)){let t=[];for(let n=0,i=e.length;n<i;n++){let i=e[n];r[i]===void 0&&console.warn(`THREE.ObjectLoader: Undefined material`,i),t.push(r[i])}return t}return r[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined material`,e),r[e]}}function h(e){return i[e]===void 0&&console.warn(`THREE.ObjectLoader: Undefined texture`,e),i[e]}let g,v,S={textures:i,geometries:n,materials:r},C={};switch(e.type){case`QuarksPrefab`:u=pi.fromJSON(e);break;case`ParticleEmitter`:u=Zr.fromJSON(e.ps,S,C).emitter;break;case`Scene`:u=new Se,e.background!==void 0&&(Number.isInteger(e.background)?u.background=new Je(e.background):u.background=h(e.background)),e.environment!==void 0&&(u.environment=h(e.environment)),e.fog!==void 0&&(e.fog.type===`Fog`?u.fog=new Ke(e.fog.color,e.fog.near,e.fog.far):e.fog.type===`FogExp2`&&(u.fog=new x(e.fog.color,e.fog.density)),e.fog.name!==``&&(u.fog.name=e.fog.name)),e.backgroundBlurriness!==void 0&&(u.backgroundBlurriness=e.backgroundBlurriness),e.backgroundIntensity!==void 0&&(u.backgroundIntensity=e.backgroundIntensity),e.backgroundRotation!==void 0&&u.backgroundRotation.fromArray(e.backgroundRotation),e.environmentIntensity!==void 0&&(u.environmentIntensity=e.environmentIntensity),e.environmentRotation!==void 0&&u.environmentRotation.fromArray(e.environmentRotation);break;case`PerspectiveCamera`:u=new re(e.fov,e.aspect,e.near,e.far),e.focus!==void 0&&(u.focus=e.focus),e.zoom!==void 0&&(u.zoom=e.zoom),e.filmGauge!==void 0&&(u.filmGauge=e.filmGauge),e.filmOffset!==void 0&&(u.filmOffset=e.filmOffset),e.view!==void 0&&(u.view=Object.assign({},e.view));break;case`OrthographicCamera`:u=new te(e.left,e.right,e.top,e.bottom,e.near,e.far),e.zoom!==void 0&&(u.zoom=e.zoom),e.view!==void 0&&(u.view=Object.assign({},e.view));break;case`AmbientLight`:u=new Re(e.color,e.intensity);break;case`DirectionalLight`:u=new b(e.color,e.intensity);break;case`PointLight`:u=new t(e.color,e.intensity,e.distance,e.decay);break;case`RectAreaLight`:u=new Ve(e.color,e.intensity,e.width,e.height);break;case`SpotLight`:u=new Ue(e.color,e.intensity,e.distance,e.angle,e.penumbra,e.decay);break;case`HemisphereLight`:u=new a(e.color,e.groundColor,e.intensity);break;case`LightProbe`:u=new _,e.sh!==void 0&&(u.sh=new Ee().fromArray(e.sh));break;case`SkinnedMesh`:g=d(e.geometry),v=f(e.material),u=new Me(g,v),e.bindMode!==void 0&&(u.bindMode=e.bindMode),e.bindMatrix!==void 0&&u.bindMatrix.fromArray(e.bindMatrix),e.skeleton!==void 0&&(u.skeleton=e.skeleton);break;case`Mesh`:g=d(e.geometry),v=f(e.material),u=new l(g,v);break;case`InstancedMesh`:{g=d(e.geometry),v=f(e.material);let t=e.count,n=e.instanceMatrix,r=e.instanceColor;u=new Ce(g,v,t),u.instanceMatrix=new we(new Float32Array(n.array),16),r!==void 0&&(u.instanceColor=new we(new Float32Array(r.array),r.itemSize));break}case`BatchedMesh`:g=d(e.geometry),v=f(e.material),u=new He(e.maxGeometryCount,e.maxVertexCount,e.maxIndexCount,v),u.geometry=g,u.perObjectFrustumCulled=e.perObjectFrustumCulled,u.sortObjects=e.sortObjects,u._drawRanges=e.drawRanges,u._reservedRanges=e.reservedRanges,u._visibility=e.visibility,u._active=e.active,u._bounds=e.bounds.map(e=>{let t=new he;t.min.fromArray(e.boxMin),t.max.fromArray(e.boxMax);let n=new ze;return n.radius=e.sphereRadius,n.center.fromArray(e.sphereCenter),{boxInitialized:e.boxInitialized,box:t,sphereInitialized:e.sphereInitialized,sphere:n}}),u._maxGeometryCount=e.maxGeometryCount,u._maxVertexCount=e.maxVertexCount,u._maxIndexCount=e.maxIndexCount,u._geometryInitialized=e.geometryInitialized,u._geometryCount=e.geometryCount,u._matricesTexture=h(e.matricesTexture.uuid);break;case`LOD`:u=new m;break;case`Line`:u=new s(d(e.geometry),f(e.material));break;case`LineLoop`:u=new p(d(e.geometry),f(e.material));break;case`LineSegments`:u=new y(d(e.geometry),f(e.material));break;case`PointCloud`:case`Points`:u=new me(d(e.geometry),f(e.material));break;case`Sprite`:u=new pe(f(e.material));break;case`Group`:u=new o;break;case`Bone`:u=new fe;break;default:u=new Fe}if(u.uuid=e.uuid,e.name!==void 0&&(u.name=e.name),e.matrix===void 0?(e.position!==void 0&&u.position.fromArray(e.position),e.rotation!==void 0&&u.rotation.fromArray(e.rotation),e.quaternion!==void 0&&u.quaternion.fromArray(e.quaternion),e.scale!==void 0&&u.scale.fromArray(e.scale)):(u.matrix.fromArray(e.matrix),e.matrixAutoUpdate!==void 0&&(u.matrixAutoUpdate=e.matrixAutoUpdate),u.matrixAutoUpdate&&(u.matrix.decompose(u.position,u.quaternion,u.scale),isNaN(u.quaternion.x)&&u.quaternion.set(0,0,0,1))),e.up!==void 0&&u.up.fromArray(e.up),e.castShadow!==void 0&&(u.castShadow=e.castShadow),e.receiveShadow!==void 0&&(u.receiveShadow=e.receiveShadow),e.shadow&&(e.shadow.bias!==void 0&&(u.shadow.bias=e.shadow.bias),e.shadow.normalBias!==void 0&&(u.normalBias=e.shadow.normalBias),e.shadow.radius!==void 0&&(u.radius=e.shadow.radius),e.shadow.mapSize!==void 0&&u.mapSize.fromArray(e.shadow.mapSize),e.shadow.camera!==void 0&&(u.camera=this.parseObject(e.shadow.camera))),e.visible!==void 0&&(u.visible=e.visible),e.frustumCulled!==void 0&&(u.frustumCulled=e.frustumCulled),e.renderOrder!==void 0&&(u.renderOrder=e.renderOrder),e.userData!==void 0&&(u.userData=e.userData),e.layers!==void 0&&(u.layers.mask=e.layers),e.children!==void 0){let t=e.children;for(let e=0;e<t.length;e++)u.add(this.parseObject(t[e],n,r,i,c))}if(e.animations!==void 0){let t=e.animations;for(let e=0;e<t.length;e++){let n=t[e];u.animations.push(c[n])}}if(e.type===`LOD`){e.autoUpdate!==void 0&&(u.autoUpdate=e.autoUpdate);let t=e.levels;for(let e=0;e<t.length;e++){let n=t[e],r=u.getObjectByProperty(`uuid`,n.object);r!==void 0&&u.addLevel(r,n.distance)}}else e.type===`QuarksPrefab`&&u.resolveReferences(u);return u}},hi=class e{static runOnAllParticleEmitters(e,t){e.traverse(e=>{e.type===`ParticleEmitter`&&t(e)}),e.type===`ParticleEmitter`&&t(e)}static addToBatchRenderer(t,n){e.runOnAllParticleEmitters(t,e=>{n.addSystem(e.system)})}static play(t){e.runOnAllParticleEmitters(t,e=>{e.system.play()})}static stop(t){e.runOnAllParticleEmitters(t,e=>{e.system.stop()})}static setAutoDestroy(t,n){e.runOnAllParticleEmitters(t,e=>{e.system.autoDestroy=n})}static endEmit(t){e.runOnAllParticleEmitters(t,e=>{e.system.endEmit()})}static restart(t){e.runOnAllParticleEmitters(t,e=>{e.system.restart()})}static pause(t){e.runOnAllParticleEmitters(t,e=>{e.system.pause()})}};Hr(),Or(Mr),console.log(`%c Particle system powered by three.quarks. https://quarks.art/`,`font-size: 14px; font-weight: bold;`);var gi;(function(e){e.Unimplemented=`UNIMPLEMENTED`,e.Unavailable=`UNAVAILABLE`})(gi||={});var _i=class extends Error{constructor(e,t,n){super(e),this.message=e,this.code=t,this.data=n}},vi=e=>e?.androidBridge?`android`:e?.webkit?.messageHandlers?.bridge?`ios`:`web`,yi=e=>{let t=e.CapacitorCustomPlatform||null,n=e.Capacitor||{},r=n.Plugins=n.Plugins||{},i=()=>t===null?vi(e):t.name,a=()=>i()!==`web`,o=e=>!!(l.get(e)?.platforms.has(i())||s(e)),s=e=>n.PluginHeaders?.find(t=>t.name===e),c=t=>e.console.error(t),l=new Map;return n.convertFileSrc||=e=>e,n.getPlatform=i,n.handleError=c,n.isNativePlatform=a,n.isPluginAvailable=o,n.registerPlugin=(e,a={})=>{let o=l.get(e);if(o)return console.warn(`Capacitor plugin "${e}" already registered. Cannot register plugins twice.`),o.proxy;let c=i(),u=s(e),d,f=async()=>(!d&&c in a?d=d=typeof a[c]==`function`?await a[c]():a[c]:t!==null&&!d&&`web`in a&&(d=d=typeof a.web==`function`?await a.web():a.web),d),p=(t,r)=>{if(u){let i=u?.methods.find(e=>r===e.name);if(i)return i.rtype===`promise`?t=>n.nativePromise(e,r.toString(),t):(t,i)=>n.nativeCallback(e,r.toString(),t,i);if(t)return t[r]?.bind(t)}else if(t)return t[r]?.bind(t);else throw new _i(`"${e}" plugin is not implemented on ${c}`,gi.Unimplemented)},m=t=>{let n,r=(...r)=>{let i=f().then(i=>{let a=p(i,t);if(a){let e=a(...r);return n=e?.remove,e}throw new _i(`"${e}.${t}()" is not implemented on ${c}`,gi.Unimplemented)});return t===`addListener`&&(i.remove=async()=>n()),i};return r.toString=()=>`${t.toString()}() { [capacitor code] }`,Object.defineProperty(r,"name",{value:t,writable:!1,configurable:!1}),r},h=m(`addListener`),g=m(`removeListener`),_=(e,t)=>{let n=h({eventName:e},t),r=async()=>{let r=await n;g({eventName:e,callbackId:r},t)},i=new Promise(e=>n.then(()=>e({remove:r})));return i.remove=async()=>{console.warn(`Using addListener() without 'await' is deprecated.`),await r()},i},v=new Proxy({},{get(e,t){switch(t){case`$$typeof`:return;case`toJSON`:return()=>({});case`addListener`:return u?_:h;case`removeListener`:return g;default:return m(t)}}});return r[e]=v,l.set(e,{name:e,proxy:v,platforms:new Set([...Object.keys(a),...u?[c]:[]])}),v},n.Exception=_i,n.DEBUG=!!n.DEBUG,n.isLoggingEnabled=!!n.isLoggingEnabled,n},bi=(e=>e.Capacitor=yi(e))(typeof globalThis<`u`?globalThis:typeof self<`u`?self:typeof window<`u`?window:typeof global<`u`?global:{}),xi=bi.registerPlugin,Si=class{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,t){let n=!1;this.listeners[e]||(this.listeners[e]=[],n=!0),this.listeners[e].push(t);let r=this.windowListeners[e];return r&&!r.registered&&this.addWindowListener(r),n&&this.sendRetainedArgumentsForEvent(e),Promise.resolve({remove:async()=>this.removeListener(e,t)})}async removeAllListeners(){this.listeners={};for(let e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,t,n){let r=this.listeners[e];if(!r){if(n){let n=this.retainedEventArguments[e];n||=[],n.push(t),this.retainedEventArguments[e]=n}return}r.forEach(e=>e(t))}hasListeners(e){return!!this.listeners[e]?.length}registerWindowListener(e,t){this.windowListeners[t]={registered:!1,windowEventName:e,pluginEventName:t,handler:e=>{this.notifyListeners(t,e)}}}unimplemented(e=`not implemented`){return new bi.Exception(e,gi.Unimplemented)}unavailable(e=`not available`){return new bi.Exception(e,gi.Unavailable)}async removeListener(e,t){let n=this.listeners[e];if(!n)return;let r=n.indexOf(t);r!==-1&&this.listeners[e].splice(r,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){let t=this.retainedEventArguments[e];t&&(delete this.retainedEventArguments[e],t.forEach(t=>{this.notifyListeners(e,t)}))}},Ci=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),wi=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent),Ti=class extends Si{async getCookies(){let e=document.cookie,t={};return e.split(`;`).forEach(e=>{if(e.length<=0)return;let[n,r]=e.replace(/=/,`CAP_COOKIE`).split(`CAP_COOKIE`);n=wi(n).trim(),r=wi(r).trim(),t[n]=r}),t}async setCookie(e){try{let t=Ci(e.key),n=Ci(e.value),r=e.expires?`; expires=${e.expires.replace(`expires=`,``)}`:``,i=(e.path||`/`).replace(`path=`,``),a=e.url!=null&&e.url.length>0?`domain=${e.url}`:``;document.cookie=`${t}=${n||``}${r}; path=${i}; ${a};`}catch(e){return Promise.reject(e)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(e){return Promise.reject(e)}}async clearCookies(){try{let e=document.cookie.split(`;`)||[];for(let t of e)document.cookie=t.replace(/^ +/,``).replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}};xi(`CapacitorCookies`,{web:()=>new Ti});var Ei=async e=>new Promise((t,n)=>{let r=new FileReader;r.onload=()=>{let e=r.result;t(e.indexOf(`,`)>=0?e.split(`,`)[1]:e)},r.onerror=e=>n(e),r.readAsDataURL(e)}),Di=(e={})=>{let t=Object.keys(e);return Object.keys(e).map(e=>e.toLocaleLowerCase()).reduce((n,r,i)=>(n[r]=e[t[i]],n),{})},Oi=(e,t=!0)=>e?Object.entries(e).reduce((e,n)=>{let[r,i]=n,a,o;return Array.isArray(i)?(o=``,i.forEach(e=>{a=t?encodeURIComponent(e):e,o+=`${r}=${a}&`}),o.slice(0,-1)):(a=t?encodeURIComponent(i):i,o=`${r}=${a}`),`${e}&${o}`},``).substr(1):null,ki=(e,t={})=>{let n=Object.assign({method:e.method||`GET`,headers:e.headers},t),r=Di(e.headers)[`content-type`]||``;if(typeof e.data==`string`)n.body=e.data;else if(r.includes(`application/x-www-form-urlencoded`)){let t=new URLSearchParams;for(let[n,r]of Object.entries(e.data||{}))t.set(n,r);n.body=t.toString()}else if(r.includes(`multipart/form-data`)||e.data instanceof FormData){let t=new FormData;if(e.data instanceof FormData)e.data.forEach((e,n)=>{t.append(n,e)});else for(let n of Object.keys(e.data))t.append(n,e.data[n]);n.body=t;let r=new Headers(n.headers);r.delete(`content-type`),n.headers=r}else(r.includes(`application/json`)||typeof e.data==`object`)&&(n.body=JSON.stringify(e.data));return n},Ai=class extends Si{async request(e){let t=ki(e,e.webFetchExtra),n=Oi(e.params,e.shouldEncodeUrlParams),r=n?`${e.url}?${n}`:e.url,i=await fetch(r,t),a=i.headers.get(`content-type`)||``,{responseType:o=`text`}=i.ok?e:{};a.includes(`application/json`)&&(o=`json`);let s,c;switch(o){case`arraybuffer`:case`blob`:c=await i.blob(),s=await Ei(c);break;case`json`:s=await i.json();break;default:s=await i.text()}let l={};return i.headers.forEach((e,t)=>{l[t]=e}),{data:s,headers:l,status:i.status,url:i.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:`GET`}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:`POST`}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:`PUT`}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:`PATCH`}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:`DELETE`}))}};xi(`CapacitorHttp`,{web:()=>new Ai});var ji;(function(e){e.Dark=`DARK`,e.Light=`LIGHT`,e.Default=`DEFAULT`})(ji||={});var Mi;(function(e){e.StatusBar=`StatusBar`,e.NavigationBar=`NavigationBar`})(Mi||={});var Ni=class extends Si{async setStyle(){this.unavailable(`not available for web`)}async setAnimation(){this.unavailable(`not available for web`)}async show(){this.unavailable(`not available for web`)}async hide(){this.unavailable(`not available for web`)}};xi(`SystemBars`,{web:()=>new Ni});var k={maxPixelRatio:2,difficultyPressureMultiplier:.88,obstacleSpawnCount:2,arenaSize:26,arenaLimit:12,playerSpeed:5,playerStartHeight:.75,playerRadius:1.05,cellPickupRadius:1.15,cellCashValue:1,baseCellCashValue:1,initialCellCount:5,initialObstacleTypes:[`regular`,`chaser`,`creeper`],cellSpawnInterval:5,cellMagnetRange:4,cellMagnetBaseSpeed:.8,boosterSpawnInterval:18,speedBoosterBaseDuration:5,thornShieldBaseDuration:4,freezerBaseDuration:3,pushbackBaseRange:3.5,pushbackBaseSpeed:.7,slowAuraBaseRange:4,slowAuraBaseEffect:.25,orbitalElectronOrbitRadius:3.5,orbitalElectronBaseSpeed:2.1,orbitalElectronBaseStunDuration:.65,orbitalElectronHitRadius:.28,cellMinDistance:3,chronoCellSpawnInterval:20,chronoCellLifetime:9,chronoCellMinDistance:4,chronoCellChronoshardValue:1,obstacleMinDistance:4,obstacleColliderRadius:.86,obstacleColliderIterations:2,creeperStaticCollisionSlowDuration:.35,creeperStaticCollisionSpeedMultiplier:.45,obstacleSpawnInterval:7.85,obstacleSpawnDecreasePerCell:.07,regularObstacleLifetime:32,regularObstacleLifetimeIncreasePerCell:.14,obstacleDespawnWarningDuration:2,obstacleDespawnWarningStartFrequency:1.2,obstacleDespawnWarningEndFrequency:10,obstacleSpawnWarningDuration:2,bangerExplosionVfxDuration:.65,bangerPulseStartInterval:.9,bangerPulseEndInterval:.1,bangerPulseVfxDuration:.55,fallingBlockStartHeight:16,obstacleGroundHeight:.86,fallingBlockGroundHeight:.86,fallingBlockDuration:1.8,fallingBlockLifetime:1.9,fallingBlockMinInterval:1.8,fallingBlockBaseInterval:24,fallingRockSpawnFrequencyMultiplier:.75,fallingBlockIntervalPerCell:.1,fallingRockImpactOffset:.8,fieryRockFireDuration:5,fieryRockFireRadius:1.7,poisonTrailDuration:5.5,fieryRockFlameCount:9,fieryRockEmberCount:12,splinterPieceCount:4,splinterPieceDistance:8,splinterPieceDuration:1,shockwaveBaseRadius:4.5,shockwaveBaseInterval:8,shockwavePushDistance:4.5,shockwaveVfxDuration:.65,shieldInvulnerabilityDuration:1,playerDeathVfxDuration:.9},Pi={sector1:{extraArenaPadding:0,cellsRequiredToAdvance:30,cashValueMultiplier:1,availableObstacleTypes:[`regular`,`creeper`],maxActiveEnemies:10,maxActiveEnemiesIncrementPerCell:.03,obstacleSpawnCountOffset:0,obstacleSpawnCountIncreasePerCell:.035,obstacleSpawnIntervalOffset:1.8,obstacleSpawnDecreasePerCellOffset:.002,obstacleLifetimeOffset:-7,obstacleLifetimeIncreasePerCellOffset:-.03,regularSpawnWeight:.7,creeperSpawnWeight:.3,availableFallingRockTypes:[`stoneRock`],fallingRockSpawnIntervalOffset:1.5,fallingRockSpawnDecreasePerCellOffset:-.04,stoneRockSpawnWeight:1},sector2:{extraArenaPadding:1,cellsRequiredToAdvance:100,cashValueMultiplier:2,availableObstacleTypes:[`regular`,`chaser`,`creeper`],maxActiveEnemies:11,maxActiveEnemiesIncrementPerCell:.04,obstacleSpawnCountOffset:1,obstacleSpawnCountIncreasePerCell:.047,obstacleSpawnIntervalOffset:.6,obstacleSpawnDecreasePerCellOffset:.014,obstacleLifetimeOffset:-4.8,obstacleLifetimeIncreasePerCellOffset:.012,regularSpawnWeight:.6,chaserSpawnWeight:.2,creeperSpawnWeight:.2,availableFallingRockTypes:[`stoneRock`,`splinter`],fallingRockSpawnIntervalOffset:-5.8,fallingRockSpawnDecreasePerCellOffset:-.01,stoneRockSpawnWeight:.8,splinterSpawnWeight:.2},sector3:{extraArenaPadding:2,cellsRequiredToAdvance:200,cashValueMultiplier:4,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:13,maxActiveEnemiesIncrementPerCell:.05,obstacleSpawnCountOffset:2,obstacleSpawnCountIncreasePerCell:.06,obstacleSpawnIntervalOffset:-.4,obstacleSpawnDecreasePerCellOffset:.025,obstacleLifetimeOffset:-2.4,obstacleLifetimeIncreasePerCellOffset:.032,regularSpawnWeight:.6,chaserSpawnWeight:.1,creeperSpawnWeight:.1,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-11,fallingRockSpawnDecreasePerCellOffset:.015,stoneRockSpawnWeight:.6,fieryRockSpawnWeight:.2,splinterSpawnWeight:.2},sector4:{extraArenaPadding:3,cellsRequiredToAdvance:300,cashValueMultiplier:8,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`],maxActiveEnemies:14,maxActiveEnemiesIncrementPerCell:.06,obstacleSpawnCountOffset:3,obstacleSpawnCountIncreasePerCell:.072,obstacleSpawnIntervalOffset:-.9,obstacleSpawnDecreasePerCellOffset:.03,obstacleLifetimeOffset:-.2,obstacleLifetimeIncreasePerCellOffset:.052,regularSpawnWeight:.5,chaserSpawnWeight:.16,creeperSpawnWeight:.14,bangerSpawnWeight:.1,shooterSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-16.2,fallingRockSpawnDecreasePerCellOffset:.065,stoneRockSpawnWeight:.4,fieryRockSpawnWeight:.35,splinterSpawnWeight:.25},sector5:{extraArenaPadding:4,cellsRequiredToAdvance:300,cashValueMultiplier:16,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`],maxActiveEnemies:16,maxActiveEnemiesIncrementPerCell:.07,obstacleSpawnCountOffset:5,obstacleSpawnCountIncreasePerCell:.085,obstacleSpawnIntervalOffset:-1.9,obstacleSpawnDecreasePerCellOffset:.042,obstacleLifetimeOffset:2,obstacleLifetimeIncreasePerCellOffset:.076,regularSpawnWeight:.42,chaserSpawnWeight:.2,creeperSpawnWeight:.15,bangerSpawnWeight:.12,shooterSpawnWeight:.11,porterSpawnWeight:.08,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-18.4,fallingRockSpawnDecreasePerCellOffset:.088,stoneRockSpawnWeight:.3,fieryRockSpawnWeight:.42,splinterSpawnWeight:.28},sector6:{extraArenaPadding:5,cellsRequiredToAdvance:300,cashValueMultiplier:32,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`],maxActiveEnemies:17,maxActiveEnemiesIncrementPerCell:.08,obstacleSpawnCountOffset:6,obstacleSpawnCountIncreasePerCell:.097,obstacleSpawnIntervalOffset:-2.8,obstacleSpawnDecreasePerCellOffset:.054,obstacleLifetimeOffset:4.2,obstacleLifetimeIncreasePerCellOffset:.1,regularSpawnWeight:.34,chaserSpawnWeight:.23,creeperSpawnWeight:.16,bangerSpawnWeight:.14,shooterSpawnWeight:.13,porterSpawnWeight:.1,magnetSpawnWeight:.09,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-20.6,fallingRockSpawnDecreasePerCellOffset:.112,stoneRockSpawnWeight:.24,fieryRockSpawnWeight:.47,splinterSpawnWeight:.29},sector7:{extraArenaPadding:6,cellsRequiredToAdvance:300,cashValueMultiplier:64,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:19,maxActiveEnemiesIncrementPerCell:.09,obstacleSpawnCountOffset:7,obstacleSpawnCountIncreasePerCell:.11,obstacleSpawnIntervalOffset:-3.7,obstacleSpawnDecreasePerCellOffset:.066,obstacleLifetimeOffset:6.6,obstacleLifetimeIncreasePerCellOffset:.124,regularSpawnWeight:.28,chaserSpawnWeight:.26,creeperSpawnWeight:.17,bangerSpawnWeight:.15,shooterSpawnWeight:.14,porterSpawnWeight:.11,magnetSpawnWeight:.11,sporeSpawnWeight:.1,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-22.7,fallingRockSpawnDecreasePerCellOffset:.136,stoneRockSpawnWeight:.18,fieryRockSpawnWeight:.51,splinterSpawnWeight:.31},sector8:{extraArenaPadding:7,cellsRequiredToAdvance:300,cashValueMultiplier:128,availableObstacleTypes:[`regular`,`chaser`,`creeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:20,maxActiveEnemiesIncrementPerCell:.1,obstacleSpawnCountOffset:8,obstacleSpawnCountIncreasePerCell:.123,obstacleSpawnIntervalOffset:-4.6,obstacleSpawnDecreasePerCellOffset:.078,obstacleLifetimeOffset:9.2,obstacleLifetimeIncreasePerCellOffset:.148,regularSpawnWeight:.22,chaserSpawnWeight:.29,creeperSpawnWeight:.18,bangerSpawnWeight:.16,shooterSpawnWeight:.15,porterSpawnWeight:.12,magnetSpawnWeight:.13,sporeSpawnWeight:.12,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-24.5,fallingRockSpawnDecreasePerCellOffset:.16,stoneRockSpawnWeight:.14,fieryRockSpawnWeight:.54,splinterSpawnWeight:.32},sector9:{extraArenaPadding:8,cellsRequiredToAdvance:400,cashValueMultiplier:256,availableObstacleTypes:[`regular`,`chaser`,`poisonCreeper`,`banger`,`shooter`,`porter`,`magnet`,`spore`],maxActiveEnemies:22,maxActiveEnemiesIncrementPerCell:.11,obstacleSpawnCountOffset:9,obstacleSpawnCountIncreasePerCell:.14,obstacleSpawnIntervalOffset:-5.4,obstacleSpawnDecreasePerCellOffset:.09,obstacleLifetimeOffset:12,obstacleLifetimeIncreasePerCellOffset:.17,regularSpawnWeight:.18,chaserSpawnWeight:.3,poisonCreeperSpawnWeight:.2,bangerSpawnWeight:.17,shooterSpawnWeight:.16,porterSpawnWeight:.14,magnetSpawnWeight:.14,sporeSpawnWeight:.14,availableFallingRockTypes:[`stoneRock`,`fieryRock`,`splinter`],fallingRockSpawnIntervalOffset:-26,fallingRockSpawnDecreasePerCellOffset:.18,stoneRockSpawnWeight:.1,fieryRockSpawnWeight:.56,splinterSpawnWeight:.34}},A={background:`#101b25`,floor:`#1d3a46`,gridMajor:`#50e5bc`,gridMinor:`#244b59`,arenaBoundary:`#ff795f`,player:`#67d46e`,playerEmissive:`#1d7437`,playerWing:`#9af08f`,playerWingEmissive:`#2f8b42`,playerRing:`#d7ffb8`,cell:`#63f5cd`,cellEmissive:`#00b487`,chronoCell:`#b59aff`,chronoCellEmissive:`#5933c7`,slowAura:`#63f5cd`,obstacle:`#41687c`,obstacleEmissive:`#07141d`,chaser:`#c36b55`,chaserEmissive:`#70281d`,creeper:`#8d71c5`,creeperEmissive:`#38265c`,poisonCreeper:`#215c3a`,poisonCreeperEmissive:`#0b3d25`,poisonTrail:`#75df65`,banger:`#ffb347`,bangerEmissive:`#8f3100`,shooter:`#63f58a`,shooterEmissive:`#086b35`,porter:`#4ba3ff`,porterEmissive:`#124b9e`,magnet:`#050505`,magnetEmissive:`#171717`,spore:`#ff8fd0`,sporeEmissive:`#9b145f`,fallingObstacle:`#66869a`,fallingObstacleEmissive:`#152b3b`,fieryRock:`#ff6948`,fieryRockEmissive:`#b11d08`,splinter:`#d2c27e`,splinterEmissive:`#675b25`,fire:`#ff8a38`,targetShadow:`#020407`,targetRing:`#ff795f`},Fi={fov:52,near:.1,far:100,angle:53,landscapeDistance:8,portraitDistance:16,followStrength:.06},Ii={floorMetalness:.5,floorRoughness:.55,floorOpacity:.76,starCount:720,brightStarCount:70,starfieldRadius:70,starSize:1.55,brightStarSize:3.1},Li={hemisphereSky:`#b8e8ff`,hemisphereGround:`#0a1016`,hemisphereIntensity:2.2,key:`#fff4cf`,keyIntensity:3},j={playerCoreRadius:.7,playerCoreDetail:1,playerCoreEmissiveIntensity:1.4,playerCoreMetalness:.35,playerCoreRoughness:.25,playerRingRadius:.92,playerRingTube:.07,playerRingRadialSegments:10,playerRingTubularSegments:32,cellRadius:.42,chronoCellRadius:.52,chronoCellEmissiveIntensity:2.4,obstacleRadius:.86,fallingRockDetail:1,obstacleCoreRadius:.48,obstacleSpikeRadius:.2,obstacleSpikeHeight:.68,obstacleSpikeSegments:5,cellEmissiveIntensity:1.8,cellMetalness:.08,cellRoughness:.48,obstacleMetalness:.6,obstacleRoughness:.3,fallingObstacleEmissiveIntensity:.8,fallingObstacleMetalness:.65,fallingObstacleRoughness:.25,chaserRangeIndicatorWidth:.08,chaserRangeIndicatorSegments:64,chaserRange:3.5,bangerRangeMultiplier:1.5,bangerFuseDuration:3,shooterRangeMultiplier:2,shooterProjectileRadius:.24,shooterProjectileSpeed:5.25,shooterProjectileLifetime:2.4,shooterProjectileCooldown:2,porterTeleportInterval:10,porterWarningDuration:2,porterTeleportMinDistance:3,porterTeleportMaxDistance:7,magnetPullSpeed:1.1,sporeFuseDuration:3,sporeFragmentCount:4,sporeFragmentChildCount:4,sporeFragmentDuration:1.35,sporeFragmentSpeed:4.6,sporeFragmentScale:.42,sporeFragmentChildScale:.18,poisonCreeperTrailInterval:.42,poisonCreeperTrailRadius:.9,spawnRingInnerRadius:.38,spawnRingOuterRadius:.5,spawnRingSegments:32,spawnCueGlowRadius:1.45,spawnCueBeamHeight:3.2,slowAuraRingWidth:.1,slowAuraRingSegments:64},M={playerTurnSpeed:1.4,playerCoreSpinSpeed:1.8,playerRingSpinSpeed:2.4,cellSpinSpeed:2.2,cellBobBaseHeight:.8,cellBobAmplitude:.16,cellBobSpeed:2.4,chronoCellSpinSpeed:3.6,chronoCellBobSpeed:3.2,chronoCellBobAmplitude:.24,obstacleBobBaseHeight:.72,obstacleBobAmplitude:.12,obstacleBobSpeed:1.8,fallingObstacleSpinXSpeed:3,fallingObstacleSpinZSpeed:2,targetShadowBaseScale:.38,targetShadowScaleGrowth:.9,targetShadowBaseOpacity:.32,targetShadowOpacityGrowth:.56,targetRingPulseSpeed:12,targetRingPulseAmount:.1,targetRingBaseScale:.82,targetRingScaleGrowth:.62,targetRingBaseOpacity:.95,targetRingOpacityFade:.4,chaserRangeIndicatorBaseOpacity:.24,chaserRangeIndicatorActiveOpacity:.7,chaserRangeIndicatorPulseSpeed:7,chaserRangeIndicatorPulseAmount:.1,bangerFusePulseSpeed:9,bangerFuseEmissiveBaseIntensity:.45,bangerFuseEmissivePulseAmount:.9,spawnRingBaseScale:.7,spawnRingScaleGrowth:1,spawnRingPulseSpeed:15,spawnRingPulseAmount:.12,spawnRingBaseOpacity:.9,spawnCueGlowBaseOpacity:.2,spawnCueGlowPulseAmount:.14,spawnCueBeamBaseOpacity:.26},Ri={masterVolume:.16,bangerPulseVolume:.32,fallingObstacleVolume:.82,cellCollectVolume:.26,obstacleSummonVolume:.17,buttonClickVolume:.2,spatialMaxDistance:24,spatialMinGain:.04,fallback:{bangerPulse:{startFrequency:180,endFrequency:860,duration:.055,type:`square`},fallingObstacle:{duration:k.fallingBlockDuration},cellCollect:{startFrequency:540,endFrequency:960,duration:.13,type:`triangle`},obstacleSummon:{startFrequency:130,endFrequency:310,duration:2,type:`sine`},buttonClick:{startFrequency:440,endFrequency:660,duration:.07,type:`square`}},assets:{bangerPulse:`./audio/banger-pulse.wav`,fallingObstacle:`./audio/falling-obstacle.wav`,cellCollect:`./audio/cell-collect.wav`,obstacleSummon:`./audio/obstacle-summon.wav`,buttonClick:`./audio/button-click.wav`}},zi={regular:{color:A.obstacle,emissive:A.obstacleEmissive,speed:0,range:0},chaser:{color:A.chaser,emissive:A.chaserEmissive,speed:k.playerSpeed/2,range:j.chaserRange},creeper:{color:A.creeper,emissive:A.creeperEmissive,speed:k.playerSpeed/4,range:1/0},banger:{color:A.banger,emissive:A.bangerEmissive,speed:0,range:j.chaserRange*j.bangerRangeMultiplier},shooter:{color:A.shooter,emissive:A.shooterEmissive,speed:0,range:j.chaserRange*j.shooterRangeMultiplier},porter:{color:A.porter,emissive:A.porterEmissive,speed:0,range:0},magnet:{color:A.magnet,emissive:A.magnetEmissive,speed:0,range:j.chaserRange},spore:{color:A.spore,emissive:A.sporeEmissive,speed:0,range:0},poisonCreeper:{color:A.creeper,emissive:A.creeperEmissive,speed:k.playerSpeed/4,range:1/0}},Bi={stoneRock:{name:`Stone Rock`,color:A.fallingObstacle,emissive:A.fallingObstacleEmissive,emissiveIntensity:j.fallingObstacleEmissiveIntensity},fieryRock:{name:`Fiery Rock`,color:A.fieryRock,emissive:A.fieryRockEmissive,emissiveIntensity:2.1},splinter:{name:`Splinter`,color:A.splinter,emissive:A.splinterEmissive,emissiveIntensity:1.2}},Vi={voidReaper:{name:`Void Reaper`,color:`#151021`,emissive:`#8d35ff`,eyeColor:`#d9ff6a`,telegraphDuration:3,speed:24,scale:2,sweepRadius:k.playerRadius*2,edgeOffset:3}},Hi=`language.english: "English"\r
menu.market: "MARKET"\r
missions.title: "DAILY MISSIONS"\r
missions.weekly: "WEEKLY CHALLENGE"\r
missions.claim: "CLAIM"\r
missions.claimed: "CLAIMED"\r
missions.open_chest: "OPEN CHEST"\r
missions.return: "RETURN TO GAME"\r
missions.reset_in: "Resets in {time}"\r
missions.next_in: "3 new missions in {time}"\r
missions.active: "{count}/{max} Missions"\r
missions.days: "{amount}d"\r
missions.hours: "{amount}h"\r
missions.minutes: "{amount}m"\r
missions.metric.cells: "Collect {target} Cells"\r
missions.metric.chronoPickups: "Collect {target} Chronoshard crystals"\r
missions.metric.aetheriumPickups: "Collect {target} Aetherium crystals"\r
missions.metric.playSeconds: "Play for {target} minutes"\r
missions.empty: "All rewards collected. New missions arrive at midnight."\r
missions.notifications: "{count} new or completed missions"\r
missions.reward_claimed: "Mission rewards collected!"\r
missions.chest_claimed: "Weekly chest opened: +100 Aetherium and +100 Chronoshards!"\r
missions.failed: "Rewards could not be saved. Please try again."\r
missions.debug_added: "Added {count} missions (maximum 9)."\r
missions.debug_completed: "One random mission completed. Claim its reward in Daily Missions."\r
missions.debug_none: "No unfinished missions available."\r
market.eyebrow: "THE ORBITAL EXCHANGE"\r
market.intro: "A little Aetherium. A bigger expedition."\r
market.categories: "Market categories"\r
market.buy_for: "Buy {product} for {price} Aetherium"\r
market.discount: "{percent}% off the standard unit price"\r
market.empty: "No bundles here yet."\r
market.purchasing: "Purchasing…"\r
market.purchased: "Bundle purchased. Ready for your next expedition."\r
market.insufficient: "Not enough Aetherium."\r
market.failed: "Purchase could not be completed. Please try again."\r
language.turkish: "Turkish"\r
language.spanish: "Spanish"\r
settings.language: "Language"\r
settings.language_help: "Choose the language used by the game interface."\r
save_slots.heading: "SELECT SAVE SLOT"\r
save_slots.archive: "COMMAND ARCHIVE"\r
save_slots.description: "Choose a pilot archive to continue your expedition."\r
save_slots.slot: "SLOT {slot}"\r
save_slots.new_expedition: "NEW EXPEDITION"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MAX CELLS"\r
save_slots.total_cash: "TOTAL CASH"\r
save_slots.total_chronoshards: "TOTAL CHRONOSHARDS"\r
research.category.player_enhancements: "Player Enhancements"\r
research.category.economy: "Economy"\r
research.category.boosters: "Boosters"\r
research.category.weapons: "Weapons"\r
research.category.building_system: "Building System"\r
research.category.enemy_debuff: "Enemy Debuff"\r
research.lucky-find.name: "Lucky Find"\r
research.lucky-find.description: "Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1."\r
research.weapon-recharge.name: "Weapon Recharge"\r
research.weapon-recharge.description: "Weapons are now capable of recharging over time."\r
research.weapon-recharge-rate.name: "Weapon Recharge Rate"\r
research.weapon-recharge-rate.description: "Reduces weapon recharge time."\r
research.weapon-charge-capacity.name: "Weapon Charge Capacity"\r
research.weapon-charge-capacity.description: "Increases the maximum stored charges for each equipped weapon by 1."\r
research.weapon-slots.name: "Weapon Slot"\r
research.weapon-slots.description: "Adds one weapon slot to your round loadout."\r
research.player-speed-multiplier.name: "Player Speed Multiplier"\r
research.player-speed-multiplier.description: "Increases player movement speed."\r
research.unlock-slow-aura.name: "Unlock Slow Aura"\r
research.unlock-slow-aura.description: "Unlocks the Slow Aura ability, which slows down nearby enemies within the range."\r
research.unlock-orbital-electron.name: "Unlock Orbital Electron"\r
research.unlock-orbital-electron.description: "Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc."\r
research.electron-stun-duration.name: "Electron Stun Duration"\r
research.electron-stun-duration.description: "Increases how long enemies hit by the Orbital Electron are stunned."\r
research.electron-speed.name: "Electron Speed"\r
research.electron-speed.description: "Increases Orbital Electron orbit speed."\r
research.slow-aura-effect.name: "Slow Aura Effect"\r
research.slow-aura-effect.description: "Increases the effect of the Slow Aura ability."\r
research.slow-aura-range.name: "Effect Range"\r
research.slow-aura-range.description: "Increases the range of every active range-based effect."\r
research.cell-spawn-rate.name: "Cell Spawn Rate"\r
research.cell-spawn-rate.description: "Increases the spawn rate of standard cells."\r
research.cell-increment-per-cell.name: "Cell Increment Per Cell"\r
research.cell-increment-per-cell.description: "Each collected Cell increases the standard Cell spawn rate."\r
research.cash-cell-multiplier.name: "Cash/Cell Multiplier"\r
research.cash-cell-multiplier.description: "Increases the Cash earned from every standard cell."\r
research.initial-cell-count.name: "Initial Cell"\r
research.initial-cell-count.description: "Adds one Cell to the arena at the start of every run."\r
research.cell-magnet.name: "Cell Magnet"\r
research.cell-magnet.description: "Pulls nearby Cells toward you. Each level increases pull speed."\r
research.chrono-spawn-rate.name: "Chrono Spawn Rate"\r
research.chrono-spawn-rate.description: "Makes Chrono Cells appear more frequently."\r
research.chrono-lifetime-multiplier.name: "Chrono Lifetime Multiplier"\r
research.chrono-lifetime-multiplier.description: "Increases the lifetime of Chrono Cells."\r
research.unlock-shockwave.name: "Unlock Shockwave"\r
research.unlock-shockwave.description: "Periodically emits a green shockwave that pushes enemies away."\r
research.shockwave-frequency.name: "Shockwave Frequency"\r
research.shockwave-frequency.description: "Makes Shockwaves trigger more frequently."\r
research.shield.name: "Shield"\r
research.shield.description: "Grants one death save per level at the start of every run."\r
research.building-slots.name: "Building Slots"\r
research.building-slots.description: "Increases the number of buildings you can place in the arena by 1."\r
research.unlock-speed-booster.name: "Unlock Speed Boosters"\r
research.unlock-speed-booster.description: "Unlocks Speed Booster pickups that double movement speed."\r
research.speed-booster-duration.name: "Speed Booster Duration"\r
research.speed-booster-duration.description: "Increases Speed Booster duration."\r
research.thorn-shield.name: "Thorn Shield"\r
research.thorn-shield.description: "Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact."\r
research.thorn-shield-duration.name: "Thorn Shield Duration"\r
research.thorn-shield-duration.description: "Increases Thorn Shield duration."\r
research.freezer.name: "Freezer"\r
research.freezer.description: "Unlocks Freezer pickups that freeze all enemies."\r
research.freezer-duration.name: "Freezer Duration"\r
research.freezer-duration.description: "Increases Freezer duration."\r
research.pushback.name: "Pushback"\r
research.pushback.description: "Pushes nearby stationary enemies away. Each level increases push speed."\r
research.shield-invulnerability-duration.name: "Shield Afterglow"\r
research.shield-invulnerability-duration.description: "Increases invulnerability time after the Shield breaks."\r
research.shield-break-explosion.name: "Shield Break Explosion"\r
research.shield-break-explosion.description: "Destroys all enemies within range when the Shield breaks. Each level increases the range."\r
research.regular-lifetime-debuff.name: "Regular Decay"\r
research.regular-lifetime-debuff.description: "Reduces Regular enemy lifetime."\r
research.chaser-range-debuff.name: "Chaser Range Dampener"\r
research.chaser-range-debuff.description: "Reduces Chaser detection range."\r
research.creeper-speed-debuff.name: "Creeper Slowdown"\r
research.creeper-speed-debuff.description: "Reduces Creeper movement speed."\r
research.banger-range-debuff.name: "Banger Range Dampener"\r
research.banger-range-debuff.description: "Reduces Banger blast range."\r
research.banger-enemy-destruction.name: "Banger Disruption"\r
research.banger-enemy-destruction.description: "Give the banger's blast a chance to destroy affected enemies."\r
research.shooter-range-debuff.name: "Shooter Range Dampener"\r
research.shooter-range-debuff.description: "Reduces Shooter firing range."\r
research.shooter-projectile-debuff.name: "Projectile Drag"\r
research.shooter-projectile-debuff.description: "Reduces Shooter projectile speed."\r
research.porter-interval-debuff.name: "Porter Delay Field"\r
research.porter-interval-debuff.description: "Increases the interval between Porter teleports."\r
research.magnet-strength-debuff.name: "Magnet Insulation"\r
research.magnet-strength-debuff.description: "Reduces Magnet pull strength."\r
research.spore-speed-debuff.name: "Spore Drag"\r
research.spore-speed-debuff.description: "Reduces Spore movement speed."\r
research.poison-creep-clean.name: "Poison Creep Clean"\r
research.poison-creep-clean.description: "Reduces how long Poison Creeper trails remain."\r
weapon.nuke.name: "Nuke"\r
weapon.nuke.description: "Destroys a percentage of enemies in the arena."\r
weapon.megaMagnet.name: "Mega Magnet"\r
weapon.megaMagnet.description: "Pulls every Cell rapidly toward your ship."\r
weapon.atmosphereShield.name: "Atmosphere Shield"\r
weapon.atmosphereShield.description: "Destroys and blocks falling meteors for a short time."\r
weapon.phaseDash.name: "Phase Dash"\r
weapon.phaseDash.description: "Dash through enemies and erase every enemy in your path."\r
weapon.chronoFreeze.name: "Chrono Freeze"\r
weapon.chronoFreeze.description: "Freezes every enemy and their lifetime for a short time."\r
weapon.plasmaOrbital.name: "Plasma Orbital"\r
weapon.plasmaOrbital.description: "Deploys plasma orbitals that destroy enemies on contact."\r
weapon.cellOverdrive.name: "Cell Overdrive"\r
weapon.cellOverdrive.description: "Doubles Cells collected for a short time."\r
weapon.demonMode.name: "Demon Mode"\r
weapon.demonMode.description: "Move faster and destroy enemies you pass through."\r
weapon.remove_loadout: "REMOVE FROM LOADOUT"\r
weapon.add_loadout: "ADD TO LOADOUT"\r
weapon.replace_with: "REPLACE WITH {weapon}"\r
weapon.replace_selected: "REPLACE SELECTED WEAPON"\r
weapon.buy: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.empty_slot: "EMPTY SLOT"\r
weapon.not_collected: "Not collected yet"\r
weapon.max_level: "MAX LEVEL"\r
weapon.claim: "CLAIM"\r
weapon.next: "NEXT"\r
weapon.unlocked: "UNLOCKED"\r
weapon.unlocked_level: "Unlocked at Level 1."\r
weapon.level_up: "LEVEL UP · LV. {level}"\r
weapon.upgraded_level: "Upgraded to Level {level}."\r
weapon.max_level_copy: "MAX LEVEL COPY"\r
weapon.max_level_detail: "This weapon is already at maximum level."\r
weapon.copy: "COPY · LV. {level}"\r
weapon.copy_progress: "{copies}/{required} copies toward Level {level}."\r
artifact.broken-radar.name: "Broken Radar"\r
artifact.broken-radar.buff: "+10% Cell spawn rate"\r
artifact.ftl-schematics.name: "FTL Schematics"\r
artifact.ftl-schematics.buff: "+10% player movement speed"\r
artifact.supply-depot.name: "Supply Depot"\r
artifact.supply-depot.buff: "+5 initial Cells"\r
artifact.broken-extractor.name: "Broken Extractor"\r
artifact.broken-extractor.buff: "+10% cash earned from Cells"\r
artifact.construction-bot.name: "Construction Bot"\r
artifact.construction-bot.buff: "-10% Building prices"\r
artifact.alientech-gizmo.name: "Alientech Gizmo"\r
artifact.alientech-gizmo.buff: "-20% Research cost"\r
artifact.broken-hard-drive.name: "Broken Hard-Drive"\r
artifact.broken-hard-drive.buff: "+1 Weapon Slot"\r
artifact.hubble-telescope.name: "Hubble Telescope"\r
artifact.hubble-telescope.buff: "+20% player effect range"\r
artifact.dark-core.name: "Dark Core"\r
artifact.dark-core.buff: "+1% Chronoshards earned"\r
artifact.map-to-earth.name: "Map To Earth"\r
artifact.map-to-earth.buff: "+20% arena size in every Sector"\r
building.chronoGenerator.name: "Chrono Generator"\r
building.autocannon.name: "Autocannon"\r
building.droneBay.name: "Drone Bay"\r
building.barrierNode.name: "Barrier Node"\r
building.overclockRelay.name: "Overclock Relay"\r
building.salvageExtractor.name: "Salvage Extractor"\r
building.upgrade.range: "Range"\r
building.upgrade.effectiveness: "Effectiveness"\r
building.upgrade.frequency: "Frequency"\r
building.upgrade.period: "Period"\r
building.upgrade.count: "Count"\r
building.upgrade.duration: "Duration"\r
building.upgrade.cash: "Cash"\r
encyclopedia.category.enemies: "Enemies"\r
encyclopedia.category.meteors: "Meteors"\r
encyclopedia.category.ultimate_enemy: "Ultimate Enemy"\r
enemy.regular.name: "Regular"\r
enemy.regular.description: "A stationary asteroid enemy. Keep clear of its body while collecting Cells."\r
enemy.chaser.name: "Chaser"\r
enemy.chaser.description: "Detects the ship within its range and pursues it."\r
enemy.creeper.name: "Creeper"\r
enemy.creeper.description: "Slowly closes in from any distance and becomes faster as it survives."\r
enemy.poisonCreeper.name: "Poison Creeper"\r
enemy.poisonCreeper.description: "A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind."\r
enemy.banger.name: "Banger"\r
enemy.banger.description: "Arms itself, pulses a warning, then detonates over a wide area."\r
enemy.shooter.name: "Shooter"\r
enemy.shooter.description: "Fires projectiles at the ship when it enters firing range."\r
enemy.porter.name: "Porter"\r
enemy.porter.description: "Occasionally teleports itself to random locations."\r
enemy.magnet.name: "Magnet"\r
enemy.magnet.description: "Pulls the ship toward itself while it is within range."\r
enemy.spore.name: "Spore"\r
enemy.spore.description: "Bursts into small pieces of itself, then bursts into even smaller pieces again."\r
enemy.voidReaper.name: "Void Reaper"\r
enemy.voidReaper.description: "A horrifying alien raider that marks a lethal path before tearing across the arena."\r
enemy.stoneRock.name: "Stone Rock"\r
enemy.stoneRock.description: "A standard falling meteor. Avoid its marked impact point."\r
enemy.fieryRock.name: "Fiery Rock"\r
enemy.fieryRock.description: "A burning meteor that leaves a damaging fire hazard after impact."\r
enemy.splinter.name: "Splinter"\r
enemy.splinter.description: "Shatters on impact and sends fragments outward."\r
status.fire: "Burning"\r
status.poison: "Poisoned"\r
anomaly.cell-scout.name: "Scout Rivalry"\r
anomaly.cell-scout.description: "A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you."\r
anomaly.tower-defense.name: "Tower Defense"\r
anomaly.tower-defense.description: "Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls."\r
anomaly.tower_health: "TOWER {current}/{maximum}"\r
anomaly.tower_defended: "TOWER DEFENDED"\r
anomaly.tower_defended_copy: "You destroyed {cells} enemies and secured the tower."\r
anomaly.tower_destroyed: "TOWER DESTROYED"\r
anomaly.tower_destroyed_copy: "The tower fell after {cells} enemies were destroyed."\r
anomaly.dark_core_stack: "ARTIFACT · {artifact} STACK"\r
anomaly.run: "ANOMALY RUN"\r
anomaly.weekly: "WEEKLY ANOMALY"\r
anomaly.start: "START ANOMALY RUN"\r
anomaly.verifying_title: "VERIFYING TIME"\r
anomaly.verifying_copy: "Checking the current Weekly Anomaly with the game server."\r
anomaly.reward: "{cells} CELLS · REWARD ✦ {reward}"\r
anomaly.reset: "(New Anomaly in {date})"\r
anomaly.reward_claimed: "This sector’s Weekly Anomaly reward has already been claimed."\r
anomaly.time_unverified_title: "TIME NOT VERIFIED"\r
anomaly.time_unverified_copy: "The current Weekly Anomaly could not be verified."\r
anomaly.time_unverified_error: "We could not verify the server time or check your internet connection. Please check your connection and try again."\r
menu.home: "HOME"\r
menu.research_lab: "RESEARCH LAB"\r
menu.weaponry: "WEAPONRY"\r
menu.buildings: "BUILDING SYSTEM"\r
menu.encyclopedia: "ENCYCLOPEDIA"\r
menu.settings: "SETTINGS"\r
menu.artifacts: "ARTIFACTS"\r
menu.exit_game: "EXIT GAME"\r
menu.start_run: "START RUN"\r
menu.continue: "CONTINUE"\r
menu.run_again: "RUN AGAIN"\r
menu.back: "BACK"\r
menu.pause: "PAUSE"\r
menu.round_paused: "ROUND PAUSED"\r
menu.reset: "RESET"\r
menu.surrender: "SURRENDER"\r
menu.return: "RETURN"\r
menu.main_menu: "MAIN MENU"\r
hud.cash: "CASH"\r
hud.chronoshards: "CHRONOSHARDS"\r
hud.cells: "CELLS"\r
hud.shields: "SHIELDS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SANDBOX SECTOR {sector}"\r
hud.anomaly_suffix: " · ANOMALY"\r
settings.preferences: "PREFERENCES"\r
settings.graphics: "GRAPHICS"\r
settings.gameplay: "GAMEPLAY"\r
settings.sound: "SOUND"\r
settings.quality: "Quality"\r
settings.quality_help: "Changes render resolution and shadows."\r
settings.low: "LOW"\r
settings.medium: "MEDIUM"\r
settings.high: "HIGH"\r
settings.shadows: "Shadows"\r
settings.shadows_help: "Show dynamic object shadows."\r
settings.hdr_emission: "HDR Emission"\r
settings.hdr_emission_help: "Controls how far bright effects bloom beyond their models."\r
settings.max_fps: "Maximum FPS"\r
settings.max_fps_help: "Limits rendering and simulation to reduce hardware load."\r
settings.unlimited: "UNLIMITED"\r
settings.auto_pause: "Auto Pause"\r
settings.auto_pause_help: "Pause the run when the game loses focus."\r
settings.high_contrast_hud: "High Contrast HUD"\r
settings.high_contrast_hud_help: "Improves HUD readability."\r
settings.master_volume: "Master Volume"\r
settings.master_volume_help: "Controls all game sound effects."\r
settings.mute_all: "Mute All"\r
settings.mute_all_help: "Instantly silence all sound effects."\r
settings.spatial_audio: "Spatial Audio"\r
settings.spatial_audio_help: "Pan sounds based on their world position."\r
settings.patch_notes: "PATCH NOTES"\r
settings.display: "DISPLAY"\r
settings.screen_mode: "Screen Mode"\r
settings.screen_mode_help: "Steam launches fullscreen by default."\r
settings.resolution: "Resolution"\r
settings.resolution_help: "Choosing a resolution switches to windowed mode."\r
settings.fullscreen: "FULLSCREEN"\r
settings.windowed: "WINDOWED"\r
milestone.ascension: "ASCENSION"\r
milestone.max_cells: "MAX CELLS"\r
milestone.cells: "{cells} CELLS"\r
milestone.next: "NEXT ASCENSION: {cells} CELLS"\r
milestone.ready: "ASCENSION REWARD READY TO CLAIM"\r
milestone.complete: "ASCENSION COMPLETE"\r
milestone.claim: "CLAIM REWARD"\r
milestone.claimed: "Claimed"\r
milestone.secured: "REWARD SECURED"\r
milestone.auto_claimed: "Claimed automatically"\r
milestone.best: "{best}/{target} best cells in Sector {sector}"\r
milestone.reward_claimed: "REWARD CLAIMED · {rewards}"\r
milestone.reward_cash: "+\${amount} cash"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshards"\r
milestone.unlock_sector: "Unlock Sector {sector}"\r
milestone.unlock_feature: "Unlock {feature}"\r
milestone.unlock_research: "Unlock: {researches}"\r
error.server_time_unconfigured: "Server time endpoint is not configured."\r
error.server_time_request: "Server time request failed with {status}."\r
error.server_time_invalid: "Server returned an invalid time."\r
message.round_saved: "Round saved. Continue when you are ready."\r
message.sandbox_closed: "Sandbox closed. No progress was saved."\r
message.run_surrendered: "Run surrendered. No progress was saved."\r
message.killed_by: "KILLED BY {cause}"\r
message.energy_secured: "You secured {count} energy {cellWord}."\r
message.cell_singular: "cell"\r
message.cell_plural: "cells"\r
message.tip: "TIP · {tip}"\r
message.anomaly_reward: "ANOMALY +✦{amount}"\r
artifact.acquired: "ARTIFACT ACQUIRED"\r
artifact.acquired_named: "ARTIFACT ACQUIRED · {artifact}"\r
artifact.locked: "ARTIFACT LOCKED"\r
artifact.unknown: "UNKNOWN ARTIFACT"\r
encyclopedia.unknown_enemy: "Unknown enemy"\r
research.slot: "SLOT {slot}"\r
research.available: "AVAILABLE"\r
research.locked: "LOCKED"\r
research.remaining: "{duration} remaining"\r
research.select_below: "Select a research below."\r
research.unlock_for: "Unlock for {cost}"\r
research.unlock_sector: "Unlock Sector {sector} research in Milestones"\r
research.max_level: "MAX LEVEL"\r
research.in_progress: "IN PROGRESS"\r
research.free_enabled: "FREE RESEARCH ENABLED"\r
research.cost: "Cost {cost}"\r
research.maxed: "MAXED"\r
research.start: "RESEARCH"\r
research.no_search_results: "No research names match your search."\r
research.started: "{research} research started in Slot {slot}."\r
research.upgraded: "{research} upgraded to Level {level}."\r
research.slot_unlocked: "Research Slot {slot} unlocked."\r
research.requires_sector_cells: "Requires {cells} Cells in Sector {sector}"\r
research.requires_banked_cells: "Requires {cells} banked cells"\r
research.requires_research: "Requires {research}"\r
research.requires_research_level: "Requires {research} Lv. {level}"\r
weapon.number: "WEAPON {current} / {total}"\r
weapon.cards: "WEAPON CARDS"\r
weapon.round_loadout: "ROUND LOADOUT"\r
weapon.buy_with_cost: "BUY WEAPON · ✦ {cost}"\r
weapon.buy_five_with_cost: "BUY WEAPON x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "LUCKY FIND · {chance}% · 2 CARDS"\r
weapon.level: "LV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copies to Lv. {level}"\r
weapon.lucky_find_double: "LUCKY FIND · 2 CARDS"\r
weapon.lucky_find_unlock: "Unlocked at Level 1 and received an extra copy."\r
weapon.lucky_find_received: "Received 2 cards. {detail}"\r
artifact.stacks: "{count} stacks"\r
artifact.stack: "{count} STACK"\r
artifact.stacks_label: "{count} STACKS"\r
artifact.dark_core_stack: "{count} DARK CORE STACK"\r
artifact.dark_core_stacks: "{count} DARK CORE STACKS"\r
artifact.to_acquire: "TO ACQUIRE"\r
artifact.permanent_buff: "PERMANENT BUFF"\r
artifact.buff_per_stack: "{buff} per stack · {count} stacks = +{percent}% Chronoshards earned"\r
artifact.requirement_score: "Reach {cells} Cells in Sector {sector}."\r
artifact.requirement_milestone: "Claim the Sector {sector} · {cells} Cells Ascension reward."\r
artifact.requirement_anomaly: "Complete each Anomaly in each Sector. Every unique Anomaly and Sector combination grants one stack."\r
artifact.requirement_hidden: "Hidden condition."\r
artifact.requirement_default: "Complete this artifact achievement."\r
building.choose_offer: "CHOOSE 1 OF {count} · NEXT UNLOCK ✦ {cost}"\r
building.all_unlocked: "ALL BUILDINGS UNLOCKED"\r
building.permanent_unlock: "Permanent building unlock"\r
building.unlock_cost: "UNLOCK · ✦ {cost}"\r
building.upgrade: "UPGRADE"\r
building.slot_limit: "SLOT LIMIT"\r
building.build_cost: "Build cost: \${cost}"\r
building.unlocked: "UNLOCKED"\r
building.none_unlocked: "NO BUILDINGS UNLOCKED YET"\r
building.build_mode_slots: "BUILD MODE · SLOTS {used}/{total}"\r
building.level: "LVL. {level}"\r
building.installed_defense: "INSTALLED DEFENSE"\r
building.choose_upgrade: "Choose an upgrade for this structure."\r
building.upgrade_level: "LV. {current} → {next}"\r
building.demolish_refund: "DEMOLISH · REFUND \${amount}"\r
building.demolish_confirm: "Demolish {building}? You will receive a \${refund} refund."\r
research.active_slots: "ACTIVE SLOTS"\r
research.available_research: "AVAILABLE RESEARCH"\r
research.search: "SEARCH"\r
research.search_placeholder: "Search research names"\r
research.hide_completed: "Hide Completed Researches"\r
research.hide_locked: "Hide Locked Researches"\r
artifact.permanent_achievements: "PERMANENT ACHIEVEMENTS"\r
artifact.intro: "Artifacts are permanent rewards earned by reaching achievement goals."\r
building.permanent_defenses: "PERMANENT DEFENSES"\r
building.system: "BUILDING SYSTEM"\r
building.build_mode: "BUILD MODE"\r
building.unlock_a_building: "UNLOCK A BUILDING"\r
building.unlocked_buildings: "UNLOCKED BUILDINGS"\r
building.draft: "BUILDING DRAFT"\r
weapon.active_arsenal: "ACTIVE ARSENAL"\r
menu.back: "BACK"\r
menu.done: "DONE"\r
encyclopedia.threat_database: "THREAT DATABASE"\r
accessibility.game_canvas: "Asteroid Belt game canvas"\r
accessibility.current_sector: "Current difficulty sector"\r
accessibility.pause_game: "Pause game"\r
accessibility.shield_charges: "Shield charges"\r
accessibility.game_controls: "Game controls"\r
accessibility.build_information: "Build information"\r
accessibility.build_locations: "Build locations"\r
accessibility.pause_menu: "Pause menu"\r
accessibility.debug_console: "Debug console"\r
accessibility.close_debug_console: "Close debug console"\r
accessibility.save_slots: "Save slot selection"\r
accessibility.defeating_enemy: "Defeating enemy 3D model"\r
accessibility.sector_selection: "Difficulty sector selection"\r
accessibility.previous_sector: "Select previous sector"\r
accessibility.next_sector: "Select next sector"\r
accessibility.previous_milestone_sector: "View previous milestone sector"\r
accessibility.next_milestone_sector: "View next milestone sector"\r
accessibility.enemy_model: "{enemy} model"\r
controls.move: "MOVE"\r
controls.navigate: "NAVIGATE"\r
controls.use_weapon: "USE WEAPON"\r
controls.select_weapon: "SELECT / USE WEAPON"\r
patch_notes.version_build: "VERSION {version} · BUILD {build}"\r
patch_notes.artifacts: "ARTIFACTS"\r
patch_notes.artifacts_1: "Introducing Artifact System - An achievements mechanic which rewards the player with permanent buffs and rewards when achieving certain things."\r
patch_notes.artifacts_2: "Artifacts are mostly earned by reaching 500 cells in Tier 2 and onwards."\r
patch_notes.artifacts_3: "There are 10 different artifact right now, more to come in upcoming update."\r
patch_notes.improvements: "IMPROVEMENTS"\r
patch_notes.improvements_1: "Certain UI improvements for better visibility especially in mobile devices."\r
patch_notes.improvements_2: "Small value tweaks regarding Research unlocks and Enemy strengths."\r
tip.1: "You will eventually be overwhelmed no matter what. Try unlocking new researches to push further."\r
tip.2: "Keep moving: standing still makes incoming hazards much harder to read."\r
tip.3: "The final seconds of an enemy lifetime are marked by a blink."\r
tip.4: "Research upgrades persist between runs, so a short run can still move you forward."\r
tip.5: "Use the arena edge to reduce the directions enemies can approach from."\r
tip.6: "Chronoshards are rare, valuable and short-lived. Make sure to grab them before they disappear."\r
tip.7: "Watch enemy range rings before committing to a path through the arena."\r
tip.8: "You can unlock boosters later in the game from Research Lab."\r
tip.9: "After reaching Sector IV, you can unlock the ability to build Buildings to help you in the arena."\r
tip.10: "Purple enemies are called creepers and they speed up gradually over time. They can be slowed down by static collisions with obstacles."\r
tip.11: "Red enemies are called chasers and they will pursue you when you are in their range."\r
tip.12: "Yellow enemies are called bangers and they explode after a few seconds."\r
tip.13: "More cells you collect, the more difficult the game becomes."\r
tip.14: "New enemies and obstacles are introduced as you progress through the game, so be prepared for new challenges."\r
tip.15: "Each sector introduces unique enemies and challenges, so adapt your strategy accordingly."\r
tip.16: "Asteroid Belt is designed to be an endless experience, so focus on improving your skills and strategies to achieve higher scores."\r
cheat.title: "DEBUG CONSOLE"\r
cheat.prompt: "Enter a command."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "You need to reach Sector {sector}."\r
cheat.feature_cells: "You need to collect {cells} Cells in Sector {sector}."\r
cheat.feature_chronoshards: "You need ✦ {amount} Chronoshards."\r
cheat.feature_unavailable: "This system is not available yet."\r
cheat.research_completed: "{research} research completed."\r
status.damage: "{status} DAMAGE"\r
cheat.sandbox_started: "Sandbox Sector I started. Use sandbox [sector], sandbox simulate [cell|enemies|all], or sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "Sandbox difficulty set to Sector {sector}. Spawn simulation remains unchanged."\r
cheat.sandbox_start_first: "Start Sandbox first with: sandbox"\r
cheat.sandbox_simulate_usage: "Usage: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simulation started for Sector {sector}."\r
cheat.sandbox_spawn_usage: "Usage: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Spawned {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Usage: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Usage: spawn <entity_id>. Available: {entities}"\r
cheat.spawn_requires_round: "Start a round before spawning an entity."\r
cheat.spawned: "Spawned {entity} near the player."\r
cheat.anomaly_usage: "Usage: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Unknown Anomaly: {id}. Available: {available}"\r
cheat.anomaly_started: "Anomaly {id} started in Sector {sector}."\r
cheat.cell_usage: "Usage: cell <positive amount>"\r
cheat.cell_requires_round: "Start a round before granting Cells."\r
cheat.cell_granted: "Added {amount} Cells without awarding Cash. Total: {total}."\r
cheat.cell_obtain_usage: "Usage: cell_obtain <whole number from 1 to 10,000>"\r
cheat.cell_obtain_set: "Cell obtain multiplier set to {amount} for this session."\r
cheat.god_usage: "Usage: god <on/off>"\r
cheat.god_state: "God mode {state}."\r
cheat.on: "ON"\r
cheat.off: "OFF"\r
cheat.artifact_usage: "Usage: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Unknown Artifact: {artifact}"\r
cheat.artifact_stack_range: "Stack must be a whole number from 1 to 10,000."\r
cheat.artifact_granted: "Granted {count} {artifact} {stackWord} ({total} total)."\r
cheat.artifact_unique: "{artifact} is a unique Artifact and is now unlocked."\r
cheat.amount_usage: "Usage: {command} [positive amount]"\r
cheat.amount_granted: "Granted {amount}."\r
cheat.free_research: "Free research enabled for this session."\r
cheat.sectors_unlocked: "All sectors and Ascension rewards unlocked.{rewards}"\r
cheat.clear_usage: "Usage: clear_save [{targets}]"\r
cheat.cleared: "Cleared {target} save data."\r
cheat.unknown_command: "Unknown command: {command}"\r
menu.patch_notes: "PATCH NOTES"\r
menu.unlock_feature: "UNLOCK {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
onboarding.drag_to_move: "DRAG TO MOVE"\r
`,Ui=`language.english: "İngilizce"\r
menu.market: "MARKET"\r
missions.title: "GÜNLÜK GÖREVLER"\r
missions.weekly: "HAFTALIK MEYDAN OKUMA"\r
missions.claim: "CLAIM"\r
missions.claimed: "ALINDI"\r
missions.open_chest: "KUTUYU AÇ"\r
missions.return: "OYUNA DÖN"\r
missions.reset_in: "Yenilenmeye {time}"\r
missions.next_in: "{time} sonra 3 yeni görev"\r
missions.active: "{count}/{max} Görev"\r
missions.days: "{amount}g"\r
missions.hours: "{amount}sa"\r
missions.minutes: "{amount}dk"\r
missions.metric.cells: "{target} Hücre topla"\r
missions.metric.chronoPickups: "{target} Chronoshard kristali topla"\r
missions.metric.aetheriumPickups: "{target} Aetherium kristali topla"\r
missions.metric.playSeconds: "{target} dakika oyna"\r
missions.empty: "Tüm ödüller alındı. Yeni görevler gece yarısı gelecek."\r
missions.notifications: "{count} yeni veya tamamlanmış görev"\r
missions.reward_claimed: "Görev ödülleri alındı!"\r
missions.chest_claimed: "Haftalık kutu açıldı: +100 Aetherium ve +100 Chronoshard!"\r
missions.failed: "Ödüller kaydedilemedi. Lütfen tekrar dene."\r
missions.debug_added: "{count} görev eklendi (en fazla 9)."\r
missions.debug_completed: "Rastgele bir görev tamamlandı. Ödülü Günlük Görevler'den alabilirsin."\r
missions.debug_none: "Tamamlanmamış görev yok."\r
market.eyebrow: "YÖRÜNGE PAZARI"\r
market.intro: "Biraz Aetherium. Daha büyük bir sefer."\r
market.categories: "Market kategorileri"\r
market.buy_for: "{price} Aetherium karşılığında {product} satın al"\r
market.discount: "Standart birim fiyatına göre %{percent} indirim"\r
market.empty: "Bu kategoride henüz paket yok."\r
market.purchasing: "Satın alınıyor…"\r
market.purchased: "Paket satın alındı. Yeni seferine hazırsın."\r
market.insufficient: "Yeterli Aetherium yok."\r
market.failed: "Satın alma tamamlanamadı. Lütfen tekrar dene."\r
language.turkish: "Türkçe"\r
language.spanish: "İspanyolca"\r
settings.language: "Dil"\r
settings.language_help: "Oyun arayüzünde kullanılacak dili seçin."\r
save_slots.heading: "KAYIT YUVASI SEÇ"\r
save_slots.archive: "KOMUTA ARŞİVİ"\r
save_slots.description: "Seferinize devam etmek için bir pilot arşivi seçin."\r
save_slots.slot: "YUVA {slot}"\r
save_slots.new_expedition: "YENİ SEFER"\r
save_slots.sector: "SEKTÖR {sector}"\r
save_slots.max_cells: "AZAMİ HÜCRE"\r
save_slots.total_cash: "TOPLAM NAKİT"\r
save_slots.total_chronoshards: "TOPLAM CHRONOSHARD"\r
research.category.player_enhancements: "Oyuncu Geliştirmeleri"\r
research.category.economy: "Ekonomi"\r
research.category.boosters: "Güçlendiriciler"\r
research.category.weapons: "Silahlar"\r
research.category.building_system: "Yapı Sistemi"\r
research.category.enemy_debuff: "Düşman Zayıflatmaları"\r
research.lucky-find.name: "Şanslı Buluntu"\r
research.lucky-find.description: "Silah kartlarının Şanslı Buluntuya dönüşme ve 1 yerine 2 kart verme ihtimali vardır."\r
research.weapon-recharge.name: "Silah Yeniden Dolumu"\r
research.weapon-recharge.description: "Silahlar artık zaman içinde yeniden dolabilir."\r
research.weapon-recharge-rate.name: "Silah Dolum Hızı"\r
research.weapon-recharge-rate.description: "Silahların yeniden dolma süresini azaltır."\r
research.weapon-charge-capacity.name: "Silah Şarj Kapasitesi"\r
research.weapon-charge-capacity.description: "Kuşanılmış her silahın saklayabileceği azami şarj sayısını 1 artırır."\r
research.weapon-slots.name: "Silah Yuvası"\r
research.weapon-slots.description: "Tur donanımınıza bir silah yuvası ekler."\r
research.player-speed-multiplier.name: "Oyuncu Hız Çarpanı"\r
research.player-speed-multiplier.description: "Oyuncunun hareket hızını artırır."\r
research.unlock-slow-aura.name: "Yavaşlatma Aurasını Aç"\r
research.unlock-slow-aura.description: "Menzil içindeki yakındaki düşmanları yavaşlatan Yavaşlatma Aurası yeteneğini açar."\r
research.unlock-orbital-electron.name: "Yörünge Elektronunu Aç"\r
research.unlock-orbital-electron.description: "Etki menzilinizin çevresinde dönen ve elektrik arkının çarptığı düşmanları sersemleten bir Elektron konuşlandırır."\r
research.electron-stun-duration.name: "Elektron Sersemletme Süresi"\r
research.electron-stun-duration.description: "Yörünge Elektronunun vurduğu düşmanların sersemleme süresini artırır."\r
research.electron-speed.name: "Elektron Hızı"\r
research.electron-speed.description: "Yörünge Elektronunun yörünge hızını artırır."\r
research.slow-aura-effect.name: "Yavaşlatma Aurası Etkisi"\r
research.slow-aura-effect.description: "Yavaşlatma Aurası yeteneğinin etkisini artırır."\r
research.slow-aura-range.name: "Etki Menzili"\r
research.slow-aura-range.description: "Menzile dayalı tüm etkin etkilerin menzilini artırır."\r
research.cell-spawn-rate.name: "Hücre Belirme Hızı"\r
research.cell-spawn-rate.description: "Standart Hücrelerin belirme hızını artırır."\r
research.cell-increment-per-cell.name: "Hücre Başına Hücre Artışı"\r
research.cell-increment-per-cell.description: "Toplanan her Hücre, standart Hücrelerin belirme hızını artırır."\r
research.cash-cell-multiplier.name: "Nakit/Hücre Çarpanı"\r
research.cash-cell-multiplier.description: "Her standart Hücreden kazanılan Nakdi artırır."\r
research.initial-cell-count.name: "Başlangıç Hücresi"\r
research.initial-cell-count.description: "Her seferin başında arenaya bir Hücre ekler."\r
research.cell-magnet.name: "Hücre Mıknatısı"\r
research.cell-magnet.description: "Yakındaki Hücreleri size doğru çeker. Her seviye çekme hızını artırır."\r
research.chrono-spawn-rate.name: "Krono Belirme Hızı"\r
research.chrono-spawn-rate.description: "Krono Hücrelerinin daha sık belirmesini sağlar."\r
research.chrono-lifetime-multiplier.name: "Krono Ömür Çarpanı"\r
research.chrono-lifetime-multiplier.description: "Krono Hücrelerinin ömrünü artırır."\r
research.unlock-shockwave.name: "Şok Dalgasını Aç"\r
research.unlock-shockwave.description: "Belirli aralıklarla düşmanları uzağa iten yeşil bir şok dalgası yayar."\r
research.shockwave-frequency.name: "Şok Dalgası Sıklığı"\r
research.shockwave-frequency.description: "Şok Dalgalarının daha sık tetiklenmesini sağlar."\r
research.shield.name: "Kalkan"\r
research.shield.description: "Her seviye, her seferin başında ölümden bir kez kurtulma hakkı verir."\r
research.building-slots.name: "Yapı Yuvaları"\r
research.building-slots.description: "Arenaya yerleştirebileceğiniz yapı sayısını 1 artırır."\r
research.unlock-speed-booster.name: "Hız Güçlendiricilerini Aç"\r
research.unlock-speed-booster.description: "Hareket hızını iki katına çıkaran Hız Güçlendirici nesnelerini açar."\r
research.speed-booster-duration.name: "Hız Güçlendirici Süresi"\r
research.speed-booster-duration.description: "Hız Güçlendiricinin süresini artırır."\r
research.thorn-shield.name: "Diken Kalkan"\r
research.thorn-shield.description: "Dokunulmazlık sağlayan ve temas ettiği düşmanları yok eden Diken Kalkan nesnelerini açar."\r
research.thorn-shield-duration.name: "Diken Kalkan Süresi"\r
research.thorn-shield-duration.description: "Diken Kalkanın süresini artırır."\r
research.freezer.name: "Dondurucu"\r
research.freezer.description: "Tüm düşmanları donduran Dondurucu nesnelerini açar."\r
research.freezer-duration.name: "Dondurucu Süresi"\r
research.freezer-duration.description: "Dondurucunun süresini artırır."\r
research.pushback.name: "Geri İtme"\r
research.pushback.description: "Yakındaki hareketsiz düşmanları uzağa iter. Her seviye itme hızını artırır."\r
research.shield-invulnerability-duration.name: "Kalkan Art Etkisi"\r
research.shield-invulnerability-duration.description: "Kalkan kırıldıktan sonraki dokunulmazlık süresini artırır."\r
research.shield-break-explosion.name: "Kalkan Kırılma Patlaması"\r
research.shield-break-explosion.description: "Kalkan kırıldığında menzil içindeki tüm düşmanları yok eder. Her seviye menzili artırır."\r
research.regular-lifetime-debuff.name: "Sıradan Çürümesi"\r
research.regular-lifetime-debuff.description: "Sıradan düşmanların ömrünü azaltır."\r
research.chaser-range-debuff.name: "Takipçi Menzil Bastırıcı"\r
research.chaser-range-debuff.description: "Takipçilerin algılama menzilini azaltır."\r
research.creeper-speed-debuff.name: "Sinsici Yavaşlatma"\r
research.creeper-speed-debuff.description: "Sinsicilerin hareket hızını azaltır."\r
research.banger-range-debuff.name: "Patlayıcı Menzil Bastırıcı"\r
research.banger-range-debuff.description: "Patlayıcıların patlama menzilini azaltır."\r
research.banger-enemy-destruction.name: "Patlayıcı Bozucu"\r
research.banger-enemy-destruction.description: "Patlayıcının patlamasına, etkilenen düşmanları yok etme ihtimali verir."\r
research.shooter-range-debuff.name: "Atıcı Menzil Bastırıcı"\r
research.shooter-range-debuff.description: "Atıcıların ateş menzilini azaltır."\r
research.shooter-projectile-debuff.name: "Mermi Sürüklenmesi"\r
research.shooter-projectile-debuff.description: "Atıcıların mermi hızını azaltır."\r
research.porter-interval-debuff.name: "Işınlayıcı Gecikme Alanı"\r
research.porter-interval-debuff.description: "Işınlayıcıların ışınlanmaları arasındaki süreyi artırır."\r
research.magnet-strength-debuff.name: "Mıknatıs Yalıtımı"\r
research.magnet-strength-debuff.description: "Mıknatısların çekim gücünü azaltır."\r
research.spore-speed-debuff.name: "Spor Sürüklenmesi"\r
research.spore-speed-debuff.description: "Sporların hareket hızını azaltır."\r
research.poison-creep-clean.name: "Zehir İzi Temizliği"\r
research.poison-creep-clean.description: "Zehirli Sinsicilerin bıraktığı izlerin kalma süresini azaltır."\r
weapon.nuke.name: "Nükleer Bomba"\r
weapon.nuke.description: "Arenadaki düşmanların belirli bir yüzdesini yok eder."\r
weapon.megaMagnet.name: "Mega Mıknatıs"\r
weapon.megaMagnet.description: "Tüm Hücreleri hızla geminize doğru çeker."\r
weapon.atmosphereShield.name: "Atmosfer Kalkanı"\r
weapon.atmosphereShield.description: "Düşen meteorları kısa bir süre boyunca yok eder ve engeller."\r
weapon.phaseDash.name: "Faz Atılımı"\r
weapon.phaseDash.description: "Düşmanların içinden atılın ve yolunuzdaki her düşmanı silin."\r
weapon.chronoFreeze.name: "Krono Dondurma"\r
weapon.chronoFreeze.description: "Tüm düşmanları ve ömür sayaçlarını kısa bir süreliğine dondurur."\r
weapon.plasmaOrbital.name: "Plazma Yörüngesi"\r
weapon.plasmaOrbital.description: "Temas ettiği düşmanları yok eden plazma yörünge cisimleri konuşlandırır."\r
weapon.cellOverdrive.name: "Hücre Aşırı Yükü"\r
weapon.cellOverdrive.description: "Kısa bir süre boyunca toplanan Hücreleri iki katına çıkarır."\r
weapon.demonMode.name: "Şeytan Modu"\r
weapon.demonMode.description: "Daha hızlı hareket edin ve içinden geçtiğiniz düşmanları yok edin."\r
weapon.remove_loadout: "DONANIMDAN ÇIKAR"\r
weapon.add_loadout: "DONANIMA EKLE"\r
weapon.replace_with: "{weapon} İLE DEĞİŞTİR"\r
weapon.replace_selected: "SEÇİLİ SİLAHI DEĞİŞTİR"\r
weapon.buy: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.empty_slot: "BOŞ YUVA"\r
weapon.not_collected: "Henüz alınmadı"\r
weapon.max_level: "AZAMİ SEVİYE"\r
weapon.claim: "AL"\r
weapon.next: "SONRAKİ"\r
weapon.unlocked: "AÇILDI"\r
weapon.unlocked_level: "1. Seviyede açıldı."\r
weapon.level_up: "SEVİYE ATLA · SV. {level}"\r
weapon.upgraded_level: "{level}. Seviyeye yükseltildi."\r
weapon.max_level_copy: "AZAMİ SEVİYE KOPYASI"\r
weapon.max_level_detail: "Bu silah zaten azami seviyede."\r
weapon.copy: "KOPYA · SV. {level}"\r
weapon.copy_progress: "{level}. Seviye için {copies}/{required} kopya."\r
artifact.broken-radar.name: "Bozuk Radar"\r
artifact.broken-radar.buff: "+10% Hücre belirme hızı"\r
artifact.ftl-schematics.name: "FTL Şemaları"\r
artifact.ftl-schematics.buff: "+10% oyuncu hareket hızı"\r
artifact.supply-depot.name: "İkmal Deposu"\r
artifact.supply-depot.buff: "+5 başlangıç Hücresi"\r
artifact.broken-extractor.name: "Bozuk Çıkarıcı"\r
artifact.broken-extractor.buff: "+10% Hücrelerden kazanılan nakit"\r
artifact.construction-bot.name: "İnşaat Botu"\r
artifact.construction-bot.buff: "-10% Yapı fiyatları"\r
artifact.alientech-gizmo.name: "Uzaylı Teknolojisi Aygıtı"\r
artifact.alientech-gizmo.buff: "-20% Araştırma maliyeti"\r
artifact.broken-hard-drive.name: "Bozuk Sabit Disk"\r
artifact.broken-hard-drive.buff: "+1 Silah Yuvası"\r
artifact.hubble-telescope.name: "Hubble Teleskobu"\r
artifact.hubble-telescope.buff: "+20% oyuncu etki menzili"\r
artifact.dark-core.name: "Karanlık Çekirdek"\r
artifact.dark-core.buff: "+1% kazanılan Chronoshard"\r
artifact.map-to-earth.name: "Dünya'ya Giden Harita"\r
artifact.map-to-earth.buff: "+20% her Sektörde arena boyutu"\r
building.chronoGenerator.name: "Krono Jeneratörü"\r
building.autocannon.name: "Otomatik Top"\r
building.droneBay.name: "Drone Hangarı"\r
building.barrierNode.name: "Bariyer Düğümü"\r
building.overclockRelay.name: "Hız Aşırtma Rölesi"\r
building.salvageExtractor.name: "Hurda Çıkarıcı"\r
building.upgrade.range: "Menzil"\r
building.upgrade.effectiveness: "Etkinlik"\r
building.upgrade.frequency: "Sıklık"\r
building.upgrade.period: "Periyot"\r
building.upgrade.count: "Adet"\r
building.upgrade.duration: "Süre"\r
building.upgrade.cash: "Nakit"\r
encyclopedia.category.enemies: "Düşmanlar"\r
encyclopedia.category.meteors: "Meteorlar"\r
encyclopedia.category.ultimate_enemy: "Nihai Düşman"\r
enemy.regular.name: "Normal"\r
enemy.regular.description: "Hareketsiz bir düşman. Hücreleri toplarken gövdesinden uzak durun."\r
enemy.chaser.name: "Kovalayıcı"\r
enemy.chaser.description: "Menziline giren gemiyi algılar ve peşine düşer."\r
enemy.creeper.name: "Takipçi"\r
enemy.creeper.description: "Uzaktan yavaşça yaklaşır ve hayatta kaldıkça hızlanır."\r
enemy.poisonCreeper.name: "Zehirli Takipçi"\r
enemy.poisonCreeper.description: "Arkasında zehirli izler bırakırken mor ile koyu yeşil arasında renk değiştiren bir Sinsici türüdür."\r
enemy.banger.name: "Patlayıcı"\r
enemy.banger.description: "Kendini kurar, uyarı sinyalleri verir ve ardından geniş bir alanda patlar."\r
enemy.shooter.name: "Atıcı"\r
enemy.shooter.description: "Gemi ateş menziline girdiğinde ona mermiler fırlatır."\r
enemy.porter.name: "Işınlayıcı"\r
enemy.porter.description: "Ara sıra rastgele konumlara ışınlanır."\r
enemy.magnet.name: "Mıknatıs"\r
enemy.magnet.description: "Gemi menzilindeyken onu kendine doğru çeker."\r
enemy.spore.name: "Spor"\r
enemy.spore.description: "Kendisinin küçük parçalarına ayrılır, ardından bu parçalar daha da küçük parçalara ayrılır."\r
enemy.voidReaper.name: "Boşluk Biçici"\r
enemy.voidReaper.description: "Arena boyunca ilerlemeden önce ölümcül rotasını işaretleyen korkunç bir uzaylı akıncısı."\r
enemy.stoneRock.name: "Taş Meteor"\r
enemy.stoneRock.description: "Standart bir düşen meteor. İşaretlenmiş çarpma noktasından uzak durun."\r
enemy.fieryRock.name: "Alevli Meteor"\r
enemy.fieryRock.description: "Çarptıktan sonra hasar veren bir ateş alanı bırakan yanan meteor."\r
enemy.splinter.name: "Parçalayıcı"\r
enemy.splinter.description: "Çarpma anında parçalanır ve parçalarını çevreye saçar."\r
status.fire: "Yanma"\r
status.poison: "Zehirlenme"\r
anomaly.cell-scout.name: "Gözcü Rekabeti"\r
anomaly.cell-scout.description: "Uzaktaki kırmızı bir yapay zekâ gemisi sizinle birlikte Hücre toplar. Topladığı Hücreler seferinize sayılmaz ve size zarar veremez."\r
anomaly.tower-defense.name: "Kule Savunması"\r
anomaly.tower-defense.description: "Merkezdeki kuleyi düşman dalgalarına karşı savun. Kule düşmeden önce 1.000 düşman yok et."\r
anomaly.tower_health: "KULE {current}/{maximum}"\r
anomaly.tower_defended: "KULE SAVUNULDU"\r
anomaly.tower_defended_copy: "{cells} düşman yok ettin ve kuleyi güvenceye aldın."\r
anomaly.tower_destroyed: "KULE YIKILDI"\r
anomaly.tower_destroyed_copy: "{cells} düşman yok edildikten sonra kule düştü."\r
anomaly.dark_core_stack: "ARTIFACT · {artifact} YIĞINI"\r
anomaly.run: "ANOMALİ SEFERİ"\r
anomaly.weekly: "HAFTALIK ANOMALİ"\r
anomaly.start: "ANOMALİ SEFERİNİ BAŞLAT"\r
anomaly.verifying_title: "ZAMAN DOĞRULANIYOR"\r
anomaly.verifying_copy: "Mevcut Haftalık Anomali oyun sunucusuyla kontrol ediliyor."\r
anomaly.reward: "{cells} HÜCRE · ÖDÜL ✦ {reward}"\r
anomaly.reset: "(Yeni Anomali: {date})"\r
anomaly.reward_claimed: "Bu sektörün Haftalık Anomali ödülü zaten alındı."\r
anomaly.time_unverified_title: "ZAMAN DOĞRULANAMADI"\r
anomaly.time_unverified_copy: "Mevcut Haftalık Anomali doğrulanamadı."\r
anomaly.time_unverified_error: "Sunucu zamanı doğrulanamadı veya internet bağlantınız kontrol edilemedi. Lütfen bağlantınızı kontrol edip tekrar deneyin."\r
menu.home: "ANA SAYFA"\r
menu.research_lab: "ARAŞTIRMA LABORATUVARI"\r
menu.weaponry: "SİLAHLAR"\r
menu.buildings: "YAPI SİSTEMİ"\r
menu.encyclopedia: "ANSİKLOPEDİ"\r
menu.settings: "AYARLAR"\r
menu.artifacts: "KALINTILAR"\r
menu.exit_game: "OYUNDAN ÇIK"\r
menu.start_run: "SEFERİ BAŞLAT"\r
menu.continue: "DEVAM ET"\r
menu.run_again: "TEKRAR SEFERE ÇIK"\r
menu.back: "GERİ"\r
menu.pause: "DURAKLAT"\r
menu.round_paused: "TUR DURAKLATILDI"\r
menu.reset: "SIFIRLA"\r
menu.surrender: "TESLİM OL"\r
menu.return: "DÖN"\r
menu.main_menu: "ANA MENÜ"\r
hud.cash: "NAKİT"\r
hud.chronoshards: "KRONOPARÇALARI"\r
hud.cells: "HÜCRELER"\r
hud.shields: "KALKANLAR"\r
hud.sector: "SEKTÖR {sector}"\r
hud.sandbox_sector: "SANDBOX SEKTÖR {sector}"\r
hud.anomaly_suffix: " · ANOMALİ"\r
settings.preferences: "TERCİHLER"\r
settings.graphics: "GRAFİKLER"\r
settings.gameplay: "OYNANIŞ"\r
settings.sound: "SES"\r
settings.quality: "Kalite"\r
settings.quality_help: "Görüntü işleme çözünürlüğünü ve gölgeleri değiştirir."\r
settings.low: "DÜŞÜK"\r
settings.medium: "ORTA"\r
settings.high: "YÜKSEK"\r
settings.shadows: "Gölgeler"\r
settings.shadows_help: "Dinamik nesne gölgelerini gösterir."\r
settings.hdr_emission: "HDR Işıma"\r
settings.hdr_emission_help: "Parlak efektlerin modellerinin dışına ne kadar taşacağını belirler."\r
settings.max_fps: "Maksimum FPS"\r
settings.max_fps_help: "Donanım yükünü azaltmak için görüntüleme ve simülasyonu sınırlar."\r
settings.unlimited: "SINIRSIZ"\r
settings.auto_pause: "Otomatik Duraklatma"\r
settings.auto_pause_help: "Oyun odağı kaybettiğinde seferi duraklatır."\r
settings.high_contrast_hud: "Yüksek Kontrastlı HUD"\r
settings.high_contrast_hud_help: "HUD okunabilirliğini artırır."\r
settings.master_volume: "Ana Ses Düzeyi"\r
settings.master_volume_help: "Oyundaki tüm ses efektlerini kontrol eder."\r
settings.mute_all: "Tümünü Sessize Al"\r
settings.mute_all_help: "Tüm ses efektlerini anında sessize alır."\r
settings.spatial_audio: "Uzamsal Ses"\r
settings.spatial_audio_help: "Sesleri dünya konumlarına göre sağa veya sola yönlendirir."\r
settings.patch_notes: "YAMA NOTLARI"\r
settings.display: "EKRAN"\r
settings.screen_mode: "Ekran Modu"\r
settings.screen_mode_help: "Steam oyunu varsayılan olarak tam ekranda başlatır."\r
settings.resolution: "Çözünürlük"\r
settings.resolution_help: "Bir çözünürlük seçildiğinde pencere moduna geçilir."\r
settings.fullscreen: "TAM EKRAN"\r
settings.windowed: "PENCERE"\r
milestone.ascension: "YÜKSELİŞ"\r
milestone.max_cells: "AZAMİ HÜCRE"\r
milestone.cells: "{cells} HÜCRE"\r
milestone.next: "SONRAKİ YÜKSELİŞ: {cells} HÜCRE"\r
milestone.ready: "YÜKSELİŞ ÖDÜLÜ ALINMAYA HAZIR"\r
milestone.complete: "YÜKSELİŞ TAMAMLANDI"\r
milestone.claim: "ÖDÜLÜ AL"\r
milestone.claimed: "Alındı"\r
milestone.secured: "ÖDÜL GÜVENCEDE"\r
milestone.auto_claimed: "Otomatik olarak alındı"\r
milestone.best: "Sektör {sector}: en iyi {best}/{target} Hücre"\r
milestone.reward_claimed: "ÖDÜL ALINDI · {rewards}"\r
milestone.reward_cash: "+\${amount} nakit"\r
milestone.reward_chronoshards: "+✦ {amount} Chronoshard"\r
milestone.unlock_sector: "Sektör {sector} kilidini aç"\r
milestone.unlock_feature: "{feature} kilidini aç"\r
milestone.unlock_research: "Kilidi aç: {researches}"\r
error.server_time_unconfigured: "Sunucu zamanı uç noktası yapılandırılmamış."\r
error.server_time_request: "Sunucu zamanı isteği {status} durumuyla başarısız oldu."\r
error.server_time_invalid: "Sunucu geçersiz bir zaman döndürdü."\r
message.round_saved: "Tur kaydedildi. Hazır olduğunuzda devam edin."\r
message.sandbox_closed: "Sandbox kapatıldı. İlerleme kaydedilmedi."\r
message.run_surrendered: "Seferden vazgeçildi. İlerleme kaydedilmedi."\r
message.killed_by: "ÖLÜM NEDENİ: {cause}"\r
message.energy_secured: "{count} enerji {cellWord} güvenceye aldınız."\r
message.cell_singular: "hücresi"\r
message.cell_plural: "hücresi"\r
message.tip: "İPUCU · {tip}"\r
message.anomaly_reward: "ANOMALİ +✦{amount}"\r
artifact.acquired: "KALINTI EDİNİLDİ"\r
artifact.acquired_named: "KALINTI EDİNİLDİ · {artifact}"\r
artifact.locked: "KALINTI KİLİTLİ"\r
artifact.unknown: "BİLİNMEYEN KALINTI"\r
encyclopedia.unknown_enemy: "Bilinmeyen düşman"\r
research.slot: "YUVA {slot}"\r
research.available: "MEVCUT"\r
research.locked: "KİLİTLİ"\r
research.remaining: "{duration} kaldı"\r
research.select_below: "Aşağıdan bir araştırma seçin."\r
research.unlock_for: "{cost} karşılığında aç"\r
research.unlock_sector: "Sektör {sector} araştırmalarını Yükselişlerde aç"\r
research.max_level: "AZAMİ SEVİYE"\r
research.in_progress: "DEVAM EDİYOR"\r
research.free_enabled: "ÜCRETSİZ ARAŞTIRMA ETKİN"\r
research.cost: "Maliyet {cost}"\r
research.maxed: "AZAMİ SEVİYEDE"\r
research.start: "ARAŞTIR"\r
research.no_search_results: "Aramanızla eşleşen araştırma adı yok."\r
research.started: "{research} araştırması {slot}. Yuvada başlatıldı."\r
research.upgraded: "{research}, {level}. Seviyeye yükseltildi."\r
research.slot_unlocked: "Araştırma Yuvası {slot} açıldı."\r
research.requires_sector_cells: "Sektör {sector} içinde {cells} Hücre gerektirir"\r
research.requires_banked_cells: "Biriktirilmiş {cells} Hücre gerektirir"\r
research.requires_research: "{research} gerektirir"\r
research.requires_research_level: "{research} Sv. {level} gerektirir"\r
weapon.number: "SİLAH {current} / {total}"\r
weapon.cards: "SİLAH KARTLARI"\r
weapon.round_loadout: "TUR DONANIMI"\r
weapon.buy_with_cost: "SİLAH SATIN AL · ✦ {cost}"\r
weapon.buy_five_with_cost: "5x SİLAH SATIN AL · ✦ {cost}"\r
weapon.lucky_find_cards: "ŞANSLI BULUNTU · %{chance} · 2 KART"\r
weapon.level: "SV. {level}"\r
weapon.copy_progress_short: "Sv. {level} için {copies}/{required} kopya"\r
weapon.lucky_find_double: "ŞANSLI BULUNTU · 2 KART"\r
weapon.lucky_find_unlock: "1. Seviyede açıldı ve fazladan bir kopya alındı."\r
weapon.lucky_find_received: "2 kart alındı. {detail}"\r
artifact.stacks: "{count} birikim"\r
artifact.stack: "{count} BİRİKİM"\r
artifact.stacks_label: "{count} BİRİKİM"\r
artifact.dark_core_stack: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.dark_core_stacks: "{count} KARANLIK ÇEKİRDEK BİRİKİMİ"\r
artifact.to_acquire: "EDİNİLECEK"\r
artifact.permanent_buff: "KALICI GÜÇLENDİRME"\r
artifact.buff_per_stack: "Birikim başına {buff} · {count} birikim = +%{percent} kazanılan Chronoshard"\r
artifact.requirement_score: "Sektör {sector} içinde {cells} Hücreye ulaşın."\r
artifact.requirement_milestone: "Sektör {sector} · {cells} Hücre Yükseliş ödülünü alın."\r
artifact.requirement_anomaly: "Her Anomaliyi her Sektörde tamamlayın. Her benzersiz Anomali ve Sektör birleşimi bir birikim kazandırır."\r
artifact.requirement_hidden: "Gizli koşul."\r
artifact.requirement_default: "Bu kalıntı başarımını tamamlayın."\r
building.choose_offer: "{count} SEÇENEKTEN 1'İNİ SEÇ · SONRAKİ KİLİT ✦ {cost}"\r
building.all_unlocked: "TÜM YAPILAR AÇILDI"\r
building.permanent_unlock: "Kalıcı yapı kilidi açma"\r
building.unlock_cost: "KİLİDİ AÇ · ✦ {cost}"\r
building.upgrade: "YÜKSELT"\r
building.slot_limit: "YUVA SINIRI"\r
building.build_cost: "İnşa maliyeti: \${cost}"\r
building.unlocked: "AÇILDI"\r
building.none_unlocked: "HENÜZ HİÇBİR YAPI AÇILMADI"\r
building.build_mode_slots: "İNŞA MODU · YUVALAR {used}/{total}"\r
building.level: "SV. {level}"\r
building.installed_defense: "KURULU SAVUNMA"\r
building.choose_upgrade: "Bu yapı için bir yükseltme seçin."\r
building.upgrade_level: "SV. {current} → {next}"\r
building.demolish_refund: "YIK · İADE \${amount}"\r
building.demolish_confirm: "{building} yıkılsın mı? \${refund} iade alacaksınız."\r
research.active_slots: "ETKİN YUVALAR"\r
research.available_research: "MEVCUT ARAŞTIRMALAR"\r
research.search: "ARA"\r
research.search_placeholder: "Araştırma adlarında ara"\r
research.hide_completed: "Tamamlanan Araştırmaları Gizle"\r
research.hide_locked: "Kilitli Araştırmaları Gizle"\r
artifact.permanent_achievements: "KALICI BAŞARIMLAR"\r
artifact.intro: "Kalıntılar, başarım hedeflerine ulaşarak kazanılan kalıcı ödüllerdir."\r
building.permanent_defenses: "KALICI SAVUNMALAR"\r
building.system: "YAPI SİSTEMİ"\r
building.build_mode: "İNŞA MODU"\r
building.unlock_a_building: "BİR YAPI AÇ"\r
building.unlocked_buildings: "AÇILAN YAPILAR"\r
building.draft: "YAPI SEÇİMİ"\r
weapon.active_arsenal: "ETKİN CEPHANELİK"\r
menu.back: "GERİ"\r
menu.done: "BİTTİ"\r
encyclopedia.threat_database: "TEHDİT VERİTABANI"\r
accessibility.game_canvas: "Asteroid Belt oyun alanı"\r
accessibility.current_sector: "Mevcut zorluk sektörü"\r
accessibility.pause_game: "Oyunu duraklat"\r
accessibility.shield_charges: "Kalkan şarjları"\r
accessibility.game_controls: "Oyun kontrolleri"\r
accessibility.build_information: "Yapı bilgileri"\r
accessibility.build_locations: "Yapı konumları"\r
accessibility.pause_menu: "Duraklatma menüsü"\r
accessibility.debug_console: "Hata ayıklama konsolu"\r
accessibility.close_debug_console: "Hata ayıklama konsolunu kapat"\r
accessibility.save_slots: "Kayıt yuvası seçimi"\r
accessibility.defeating_enemy: "Yenilmekte olan düşmanın 3B modeli"\r
accessibility.sector_selection: "Zorluk sektörü seçimi"\r
accessibility.previous_sector: "Önceki sektörü seç"\r
accessibility.next_sector: "Sonraki sektörü seç"\r
accessibility.previous_milestone_sector: "Önceki Yükseliş sektörünü görüntüle"\r
accessibility.next_milestone_sector: "Sonraki Yükseliş sektörünü görüntüle"\r
accessibility.enemy_model: "{enemy} modeli"\r
controls.move: "HAREKET"\r
controls.navigate: "GEZİN"\r
controls.use_weapon: "SİLAH KULLAN"\r
controls.select_weapon: "SİLAH SEÇ / KULLAN"\r
patch_notes.version_build: "SÜRÜM {version} · DERLEME {build}"\r
patch_notes.artifacts: "KALINTILAR"\r
patch_notes.artifacts_1: "Kalıntı Sistemi eklendi: Belirli hedefleri tamamladığınızda oyuncuyu kalıcı güçlendirmeler ve ödüllerle ödüllendiren bir başarım mekaniği."\r
patch_notes.artifacts_2: "Kalıntılar çoğunlukla 2. Kademe ve sonrasında 500 Hücreye ulaşılarak kazanılır."\r
patch_notes.artifacts_3: "Şu anda 10 farklı Kalıntı bulunuyor; gelecek güncellemelerde yenileri eklenecek."\r
patch_notes.improvements: "İYİLEŞTİRMELER"\r
patch_notes.improvements_1: "Özellikle mobil cihazlarda görünürlüğü artırmak için çeşitli arayüz iyileştirmeleri yapıldı."\r
patch_notes.improvements_2: "Araştırma kilitleri ve düşman güçleriyle ilgili küçük değer ayarlamaları yapıldı."\r
tip.1: "Ne yaparsanız yapın, sonunda düşmanlar sizi bunaltacak. Daha ileri gidebilmek için yeni araştırmaların kilidini açmayı deneyin."\r
tip.2: "Hareket etmeye devam edin: Sabit durmak yaklaşan tehlikeleri okumayı çok daha zor hâle getirir."\r
tip.3: "Bir düşmanın ömrünün son saniyeleri yanıp sönmeyle belirtilir."\r
tip.4: "Araştırma yükseltmeleri seferler arasında kalıcıdır; bu yüzden kısa bir sefer bile ilerlemenizi sağlayabilir."\r
tip.5: "Düşmanların yaklaşabileceği yönleri azaltmak için arena kenarını kullanın."\r
tip.6: "Chronoshard nadir, değerli ve kısa ömürlüdür. Kaybolmadan önce topladığınızdan emin olun."\r
tip.7: "Arenada bir rota seçmeden önce düşmanların menzil halkalarını takip edin."\r
tip.8: "Oyunun ilerleyen bölümlerinde Araştırma Laboratuvarından güçlendiricilerin kilidini açabilirsiniz."\r
tip.9: "Sektör IV'e ulaştıktan sonra arenada size yardımcı olacak Yapılar inşa etme özelliğini açabilirsiniz."\r
tip.10: "Mor düşmanlara Sinsici denir ve zamanla giderek hızlanırlar. Engellere yaptıkları statik çarpışmalarla yavaşlatılabilirler."\r
tip.11: "Kırmızı düşmanlara Takipçi denir ve menzillerine girdiğinizde sizi kovalarlar."\r
tip.12: "Sarı düşmanlara Patlayıcı denir ve birkaç saniye sonra patlarlar."\r
tip.13: "Ne kadar çok Hücre toplarsanız oyun o kadar zorlaşır."\r
tip.14: "Oyunda ilerledikçe yeni düşmanlar ve engeller ortaya çıkar; yeni zorluklara hazırlıklı olun."\r
tip.15: "Her sektör benzersiz düşmanlar ve zorluklar sunar; stratejinizi buna göre uyarlayın."\r
tip.16: "Asteroid Belt sonsuz bir deneyim olacak şekilde tasarlanmıştır; daha yüksek puanlara ulaşmak için becerilerinizi ve stratejilerinizi geliştirmeye odaklanın."\r
cheat.title: "HATA AYIKLAMA KONSOLU"\r
cheat.prompt: "Bir komut girin."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Sektör {sector} seviyesine ulaşmanız gerekiyor."\r
cheat.feature_cells: "Sektör {sector} içinde {cells} Hücre toplamanız gerekiyor."\r
cheat.feature_chronoshards: "✦ {amount} Chronoshardna ihtiyacınız var."\r
cheat.feature_unavailable: "Bu sistem henüz kullanılamıyor."\r
cheat.research_completed: "{research} araştırması tamamlandı."\r
status.damage: "{status} HASARI"\r
cheat.sandbox_started: "Sandbox Sektör I başlatıldı. sandbox [sector], sandbox simulate [cell|enemies|all] veya sandbox spawn [enemy] [count] komutlarını kullanın."\r
cheat.sandbox_sector: "Sandbox zorluğu Sektör {sector} olarak ayarlandı. Doğma simülasyonu değiştirilmedi."\r
cheat.sandbox_start_first: "Önce şu komutla Sandbox'ı başlatın: sandbox"\r
cheat.sandbox_simulate_usage: "Kullanım: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Sandbox {type} simülasyonu Sektör {sector} için başlatıldı."\r
cheat.sandbox_spawn_usage: "Kullanım: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "{count} {enemy}{plural} oluşturuldu."\r
cheat.sandbox_usage: "Kullanım: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Kullanım: spawn <entity_id>. Kullanılabilir: {entities}"\r
cheat.spawn_requires_round: "Varlık oluşturmadan önce bir tur başlatın."\r
cheat.spawned: "{entity}, oyuncunun yakınında oluşturuldu."\r
cheat.anomaly_usage: "Kullanım: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Bilinmeyen Anomaly: {id}. Mevcut: {available}"\r
cheat.anomaly_started: "{id} Anomaly'si Sektör {sector} içinde başlatıldı."\r
cheat.cell_usage: "Kullanım: cell <pozitif miktar>"\r
cheat.cell_requires_round: "Hücre vermeden önce bir tur başlat."\r
cheat.cell_granted: "Nakit vermeden {amount} Hücre eklendi. Toplam: {total}."\r
cheat.cell_obtain_usage: "Kullanım: cell_obtain <1 ile 10.000 arasında tam sayı>"\r
cheat.cell_obtain_set: "Hücre alma çarpanı bu oturum için {amount} olarak ayarlandı."\r
cheat.god_usage: "Kullanım: god <on/off>"\r
cheat.god_state: "God mode {state}."\r
cheat.on: "AÇIK"\r
cheat.off: "KAPALI"\r
cheat.artifact_usage: "Kullanım: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Bilinmeyen Kalıntı: {artifact}"\r
cheat.artifact_stack_range: "Birikim 1 ile 10.000 arasında bir tam sayı olmalıdır."\r
cheat.artifact_granted: "{count} {artifact} {stackWord} verildi (toplam {total})."\r
cheat.artifact_unique: "{artifact} benzersiz bir Kalıntıdır ve artık açıldı."\r
cheat.amount_usage: "Kullanım: {command} [positive amount]"\r
cheat.amount_granted: "{amount} verildi."\r
cheat.free_research: "Bu oturum için ücretsiz araştırma etkinleştirildi."\r
cheat.sectors_unlocked: "Tüm sektörler ve Yükseliş ödülleri açıldı.{rewards}"\r
cheat.clear_usage: "Kullanım: clear_save [{targets}]"\r
cheat.cleared: "{target} kayıt verileri temizlendi."\r
cheat.unknown_command: "Bilinmeyen komut: {command}"\r
menu.patch_notes: "YAMA NOTLARI"\r
menu.unlock_feature: "{feature} KİLİDİNİ AÇ · ✦ {cost}"\r
menu.feature_sector: "{feature} · SEKTÖR {sector}"\r
onboarding.drag_to_move: "HAREKET ETMEK İÇİN SÜRÜKLE"\r
`,Wi=`language.english: "Inglés"\r
menu.market: "MERCADO"\r
missions.title: "MISIONES DIARIAS"\r
missions.weekly: "DESAFÍO SEMANAL"\r
missions.claim: "RECLAMAR"\r
missions.claimed: "RECLAMADO"\r
missions.open_chest: "ABRIR COFRE"\r
missions.return: "VOLVER AL JUEGO"\r
missions.reset_in: "Se reinicia en {time}"\r
missions.next_in: "3 misiones nuevas en {time}"\r
missions.active: "{count}/{max} Misiones"\r
missions.days: "{amount}d"\r
missions.hours: "{amount}h"\r
missions.minutes: "{amount}min"\r
missions.metric.cells: "Recoge {target} Células"\r
missions.metric.chronoPickups: "Recoge {target} cristales de Chronoshard"\r
missions.metric.aetheriumPickups: "Recoge {target} cristales de Aetherium"\r
missions.metric.playSeconds: "Juega durante {target} minutos"\r
missions.empty: "Todas las recompensas recogidas. Las misiones llegan a medianoche."\r
missions.notifications: "{count} misiones nuevas o completadas"\r
missions.reward_claimed: "¡Recompensas de la misión recogidas!"\r
missions.chest_claimed: "¡Cofre abierto: +100 Aetherium y +100 Chronoshards!"\r
missions.failed: "No se pudieron guardar las recompensas. Inténtalo de nuevo."\r
missions.debug_added: "Se añadieron {count} misiones (máximo 9)."\r
missions.debug_completed: "Una misión aleatoria completada. Reclama su recompensa en Misiones Diarias."\r
missions.debug_none: "No hay misiones sin completar."\r
market.eyebrow: "EL MERCADO ORBITAL"\r
market.intro: "Un poco de Aetherium. Una expedición más grande."\r
market.categories: "Categorías del mercado"\r
market.buy_for: "Comprar {product} por {price} Aetherium"\r
market.discount: "{percent}% de descuento sobre el precio unitario estándar"\r
market.empty: "Todavía no hay paquetes aquí."\r
market.purchasing: "Comprando…"\r
market.purchased: "Paquete comprado. Todo listo para tu próxima expedición."\r
market.insufficient: "No tienes suficiente Aetherium."\r
market.failed: "No se pudo completar la compra. Inténtalo de nuevo."\r
language.turkish: "Turco"\r
language.spanish: "Español"\r
settings.language: "Idioma"\r
settings.language_help: "Elige el idioma utilizado por la interfaz del juego."\r
save_slots.heading: "SELECCIONAR RANURA DE GUARDADO"\r
save_slots.archive: "ARCHIVO DE MANDO"\r
save_slots.description: "Elige un archivo de piloto para continuar tu expedición."\r
save_slots.slot: "RANURA {slot}"\r
save_slots.new_expedition: "NUEVA EXPEDICIÓN"\r
save_slots.sector: "SECTOR {sector}"\r
save_slots.max_cells: "MÁX. CÉLULAS"\r
save_slots.total_cash: "DINERO TOTAL"\r
save_slots.total_chronoshards: "CRONOFRAGMENTOS TOTALES"\r
research.category.player_enhancements: "Mejoras del jugador"\r
research.category.economy: "Economía"\r
research.category.boosters: "Potenciadores"\r
research.category.weapons: "Armas"\r
research.category.building_system: "Sistema de construcción"\r
research.category.enemy_debuff: "Debilitamiento de enemigos"\r
research.lucky-find.name: "Hallazgo afortunado"\r
research.lucky-find.description: "Las cartas de arma tienen una probabilidad de convertirse en Hallazgos afortunados y otorgar 2 cartas en lugar de 1."\r
research.weapon-recharge.name: "Recarga de armas"\r
research.weapon-recharge.description: "Las armas ahora pueden recargarse con el tiempo."\r
research.weapon-recharge-rate.name: "Velocidad de recarga de armas"\r
research.weapon-recharge-rate.description: "Reduce el tiempo de recarga de las armas."\r
research.weapon-charge-capacity.name: "Capacidad de cargas del arma"\r
research.weapon-charge-capacity.description: "Aumenta en 1 el máximo de cargas almacenadas de cada arma equipada."\r
research.weapon-slots.name: "Ranura de arma"\r
research.weapon-slots.description: "Añade una ranura de arma a tu equipamiento de partida."\r
research.player-speed-multiplier.name: "Multiplicador de velocidad del jugador"\r
research.player-speed-multiplier.description: "Aumenta la velocidad de movimiento del jugador."\r
research.unlock-slow-aura.name: "Desbloquear Aura ralentizadora"\r
research.unlock-slow-aura.description: "Desbloquea la habilidad Aura ralentizadora, que ralentiza a los enemigos cercanos dentro de su alcance."\r
research.unlock-orbital-electron.name: "Desbloquear Electrón orbital"\r
research.unlock-orbital-electron.description: "Despliega un Electrón que orbita tu alcance efectivo y aturde a los enemigos alcanzados por su arco eléctrico."\r
research.electron-stun-duration.name: "Duración del aturdimiento del Electrón"\r
research.electron-stun-duration.description: "Aumenta el tiempo que permanecen aturdidos los enemigos alcanzados por el Electrón orbital."\r
research.electron-speed.name: "Velocidad del Electrón"\r
research.electron-speed.description: "Aumenta la velocidad orbital del Electrón orbital."\r
research.slow-aura-effect.name: "Efecto del Aura ralentizadora"\r
research.slow-aura-effect.description: "Aumenta el efecto de la habilidad Aura ralentizadora."\r
research.slow-aura-range.name: "Alcance del efecto"\r
research.slow-aura-range.description: "Aumenta el alcance de todos los efectos activos basados en alcance."\r
research.cell-spawn-rate.name: "Frecuencia de aparición de Células"\r
research.cell-spawn-rate.description: "Aumenta la frecuencia de aparición de Células estándar."\r
research.cell-increment-per-cell.name: "Incremento por Célula"\r
research.cell-increment-per-cell.description: "Cada Célula recogida aumenta la frecuencia de aparición de Células estándar."\r
research.cash-cell-multiplier.name: "Multiplicador Dinero/Célula"\r
research.cash-cell-multiplier.description: "Aumenta el Dinero obtenido por cada Célula estándar."\r
research.initial-cell-count.name: "Célula inicial"\r
research.initial-cell-count.description: "Añade una Célula a la arena al comienzo de cada partida."\r
research.cell-magnet.name: "Imán de Células"\r
research.cell-magnet.description: "Atrae hacia ti las Células cercanas. Cada nivel aumenta la velocidad de atracción."\r
research.chrono-spawn-rate.name: "Frecuencia de aparición crono"\r
research.chrono-spawn-rate.description: "Hace que las Células crono aparezcan con mayor frecuencia."\r
research.chrono-lifetime-multiplier.name: "Multiplicador de duración crono"\r
research.chrono-lifetime-multiplier.description: "Aumenta la duración de las Células crono."\r
research.unlock-shockwave.name: "Desbloquear Onda de choque"\r
research.unlock-shockwave.description: "Emite periódicamente una onda de choque verde que empuja a los enemigos."\r
research.shockwave-frequency.name: "Frecuencia de Onda de choque"\r
research.shockwave-frequency.description: "Hace que las Ondas de choque se activen con mayor frecuencia."\r
research.shield.name: "Escudo"\r
research.shield.description: "Otorga una salvación de muerte por nivel al comienzo de cada partida."\r
research.building-slots.name: "Ranuras de edificios"\r
research.building-slots.description: "Aumenta en 1 la cantidad de edificios que puedes colocar en la arena."\r
research.unlock-speed-booster.name: "Desbloquear Potenciadores de velocidad"\r
research.unlock-speed-booster.description: "Desbloquea objetos de Potenciador de velocidad que duplican la velocidad de movimiento."\r
research.speed-booster-duration.name: "Duración del Potenciador de velocidad"\r
research.speed-booster-duration.description: "Aumenta la duración del Potenciador de velocidad."\r
research.thorn-shield.name: "Escudo de espinas"\r
research.thorn-shield.description: "Desbloquea objetos de Escudo de espinas que otorgan inmunidad y destruyen enemigos al contacto."\r
research.thorn-shield-duration.name: "Duración del Escudo de espinas"\r
research.thorn-shield-duration.description: "Aumenta la duración del Escudo de espinas."\r
research.freezer.name: "Congelador"\r
research.freezer.description: "Desbloquea objetos de Congelador que congelan a todos los enemigos."\r
research.freezer-duration.name: "Duración del Congelador"\r
research.freezer-duration.description: "Aumenta la duración del Congelador."\r
research.pushback.name: "Repulsión"\r
research.pushback.description: "Empuja a los enemigos estacionarios cercanos. Cada nivel aumenta la velocidad de empuje."\r
research.shield-invulnerability-duration.name: "Resplandor del escudo"\r
research.shield-invulnerability-duration.description: "Aumenta el tiempo de invulnerabilidad después de que el Escudo se rompe."\r
research.shield-break-explosion.name: "Explosión al romperse el Escudo"\r
research.shield-break-explosion.description: "Destruye a todos los enemigos dentro del alcance cuando el Escudo se rompe. Cada nivel aumenta el alcance."\r
research.regular-lifetime-debuff.name: "Deterioro de Comunes"\r
research.regular-lifetime-debuff.description: "Reduce la duración de los enemigos Comunes."\r
research.chaser-range-debuff.name: "Amortiguador de alcance del Perseguidor"\r
research.chaser-range-debuff.description: "Reduce el alcance de detección del Perseguidor."\r
research.creeper-speed-debuff.name: "Ralentización del Reptante"\r
research.creeper-speed-debuff.description: "Reduce la velocidad de movimiento del Reptante."\r
research.banger-range-debuff.name: "Amortiguador de alcance del Explosivo"\r
research.banger-range-debuff.description: "Reduce el alcance de explosión del Explosivo."\r
research.banger-enemy-destruction.name: "Disrupción del Explosivo"\r
research.banger-enemy-destruction.description: "Otorga a la explosión del Explosivo una probabilidad de destruir a los enemigos afectados."\r
research.shooter-range-debuff.name: "Amortiguador de alcance del Tirador"\r
research.shooter-range-debuff.description: "Reduce el alcance de disparo del Tirador."\r
research.shooter-projectile-debuff.name: "Resistencia de proyectiles"\r
research.shooter-projectile-debuff.description: "Reduce la velocidad de los proyectiles del Tirador."\r
research.porter-interval-debuff.name: "Campo de retraso del Teletransportador"\r
research.porter-interval-debuff.description: "Aumenta el intervalo entre los teletransportes del Teletransportador."\r
research.magnet-strength-debuff.name: "Aislamiento magnético"\r
research.magnet-strength-debuff.description: "Reduce la fuerza de atracción del Imán."\r
research.spore-speed-debuff.name: "Resistencia de la Espora"\r
research.spore-speed-debuff.description: "Reduce la velocidad de movimiento de la Espora."\r
research.poison-creep-clean.name: "Limpieza de rastro venenoso"\r
research.poison-creep-clean.description: "Reduce el tiempo que permanecen los rastros del Reptante venenoso."\r
weapon.nuke.name: "Bomba nuclear"\r
weapon.nuke.description: "Destruye un porcentaje de los enemigos de la arena."\r
weapon.megaMagnet.name: "Megaimán"\r
weapon.megaMagnet.description: "Atrae rápidamente todas las Células hacia tu nave."\r
weapon.atmosphereShield.name: "Escudo atmosférico"\r
weapon.atmosphereShield.description: "Destruye y bloquea meteoros que caen durante un breve periodo."\r
weapon.phaseDash.name: "Impulso de fase"\r
weapon.phaseDash.description: "Atraviesa a los enemigos y elimina a todos los que haya en tu trayectoria."\r
weapon.chronoFreeze.name: "Cronocongelación"\r
weapon.chronoFreeze.description: "Congela a todos los enemigos y su tiempo de vida durante un breve periodo."\r
weapon.plasmaOrbital.name: "Plasma orbital"\r
weapon.plasmaOrbital.description: "Despliega plasmas orbitales que destruyen enemigos al contacto."\r
weapon.cellOverdrive.name: "Sobrecarga de Células"\r
weapon.cellOverdrive.description: "Duplica las Células recogidas durante un breve periodo."\r
weapon.demonMode.name: "Modo demonio"\r
weapon.demonMode.description: "Muévete más rápido y destruye a los enemigos que atravieses."\r
weapon.remove_loadout: "QUITAR DEL EQUIPAMIENTO"\r
weapon.add_loadout: "AÑADIR AL EQUIPAMIENTO"\r
weapon.replace_with: "REEMPLAZAR POR {weapon}"\r
weapon.replace_selected: "REEMPLAZAR ARMA SELECCIONADA"\r
weapon.buy: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.empty_slot: "RANURA VACÍA"\r
weapon.not_collected: "Aún no obtenida"\r
weapon.max_level: "NIVEL MÁXIMO"\r
weapon.claim: "RECLAMAR"\r
weapon.next: "SIGUIENTE"\r
weapon.unlocked: "DESBLOQUEADA"\r
weapon.unlocked_level: "Desbloqueada en el nivel 1."\r
weapon.level_up: "SUBIR DE NIVEL · NV. {level}"\r
weapon.upgraded_level: "Mejorada al nivel {level}."\r
weapon.max_level_copy: "COPIA DE NIVEL MÁXIMO"\r
weapon.max_level_detail: "Esta arma ya está en el nivel máximo."\r
weapon.copy: "COPIA · NV. {level}"\r
weapon.copy_progress: "{copies}/{required} copias para alcanzar el nivel {level}."\r
artifact.broken-radar.name: "Radar averiado"\r
artifact.broken-radar.buff: "+10% a la frecuencia de aparición de Células"\r
artifact.ftl-schematics.name: "Planos FTL"\r
artifact.ftl-schematics.buff: "+10% a la velocidad de movimiento del jugador"\r
artifact.supply-depot.name: "Depósito de suministros"\r
artifact.supply-depot.buff: "+5 Células iniciales"\r
artifact.broken-extractor.name: "Extractor averiado"\r
artifact.broken-extractor.buff: "+10% al Dinero obtenido de Células"\r
artifact.construction-bot.name: "Robot constructor"\r
artifact.construction-bot.buff: "-10% al precio de los Edificios"\r
artifact.alientech-gizmo.name: "Dispositivo de tecnología alienígena"\r
artifact.alientech-gizmo.buff: "-20% al coste de Investigación"\r
artifact.broken-hard-drive.name: "Disco duro averiado"\r
artifact.broken-hard-drive.buff: "+1 Ranura de arma"\r
artifact.hubble-telescope.name: "Telescopio Hubble"\r
artifact.hubble-telescope.buff: "+20% al alcance de efectos del jugador"\r
artifact.dark-core.name: "Núcleo oscuro"\r
artifact.dark-core.buff: "+1% a los Cronofragmentos obtenidos"\r
artifact.map-to-earth.name: "Mapa hacia la Tierra"\r
artifact.map-to-earth.buff: "+20% al tamaño de la arena en cada Sector"\r
building.chronoGenerator.name: "Generador crono"\r
building.autocannon.name: "Cañón automático"\r
building.droneBay.name: "Hangar de drones"\r
building.barrierNode.name: "Nodo de barrera"\r
building.overclockRelay.name: "Relé de overclock"\r
building.salvageExtractor.name: "Extractor de salvamento"\r
building.upgrade.range: "Alcance"\r
building.upgrade.effectiveness: "Eficacia"\r
building.upgrade.frequency: "Frecuencia"\r
building.upgrade.period: "Periodo"\r
building.upgrade.count: "Cantidad"\r
building.upgrade.duration: "Duración"\r
building.upgrade.cash: "Dinero"\r
encyclopedia.category.enemies: "Enemigos"\r
encyclopedia.category.meteors: "Meteoros"\r
encyclopedia.category.ultimate_enemy: "Enemigo definitivo"\r
enemy.regular.name: "Común"\r
enemy.regular.description: "Un enemigo asteroide estacionario. Mantente alejado de su cuerpo mientras recoges Células."\r
enemy.chaser.name: "Perseguidor"\r
enemy.chaser.description: "Detecta la nave dentro de su alcance y la persigue."\r
enemy.creeper.name: "Reptante"\r
enemy.creeper.description: "Se acerca lentamente desde cualquier distancia y se vuelve más rápido cuanto más tiempo sobrevive."\r
enemy.poisonCreeper.name: "Reptante venenoso"\r
enemy.poisonCreeper.description: "Una variante del Reptante que alterna entre púrpura y verde oscuro mientras deja rastros venenosos."\r
enemy.banger.name: "Explosivo"\r
enemy.banger.description: "Se arma, emite pulsos de advertencia y después detona en una amplia zona."\r
enemy.shooter.name: "Tirador"\r
enemy.shooter.description: "Dispara proyectiles contra la nave cuando entra en su alcance de disparo."\r
enemy.porter.name: "Teletransportador"\r
enemy.porter.description: "Se teletransporta ocasionalmente a ubicaciones aleatorias."\r
enemy.magnet.name: "Imán"\r
enemy.magnet.description: "Atrae la nave hacia sí mientras se encuentra dentro de su alcance."\r
enemy.spore.name: "Espora"\r
enemy.spore.description: "Explota en pequeños fragmentos de sí misma y luego vuelve a dividirse en fragmentos aún más pequeños."\r
enemy.voidReaper.name: "Segador del Vacío"\r
enemy.voidReaper.description: "Un aterrador invasor alienígena que marca una ruta letal antes de atravesar la arena."\r
enemy.stoneRock.name: "Roca pétrea"\r
enemy.stoneRock.description: "Un meteoro estándar en caída. Evita su punto de impacto marcado."\r
enemy.fieryRock.name: "Roca ígnea"\r
enemy.fieryRock.description: "Un meteoro en llamas que deja una zona de fuego dañina tras el impacto."\r
enemy.splinter.name: "Esquirla"\r
enemy.splinter.description: "Se hace añicos al impactar y lanza fragmentos hacia el exterior."\r
status.fire: "En llamas"\r
status.poison: "Envenenado"\r
anomaly.cell-scout.name: "Rivalidad de exploradores"\r
anomaly.cell-scout.description: "Una nave de IA roja y distante recoge Células junto a ti. Sus Células no cuentan para tu partida y no puede dañarte."\r
anomaly.tower-defense.name: "Defensa de la torre"\r
anomaly.tower-defense.description: "Defiende la torre central de las oleadas enemigas. Destruye 1.000 enemigos antes de que caiga la torre."\r
anomaly.tower_health: "TORRE {current}/{maximum}"\r
anomaly.tower_defended: "TORRE DEFENDIDA"\r
anomaly.tower_defended_copy: "Destruiste {cells} enemigos y aseguraste la torre."\r
anomaly.tower_destroyed: "TORRE DESTRUIDA"\r
anomaly.tower_destroyed_copy: "La torre cayó después de destruir {cells} enemigos."\r
anomaly.dark_core_stack: "ARTEFACTO · CARGA DE {artifact}"\r
anomaly.run: "PARTIDA DE ANOMALÍA"\r
anomaly.weekly: "ANOMALÍA SEMANAL"\r
anomaly.start: "INICIAR PARTIDA DE ANOMALÍA"\r
anomaly.verifying_title: "VERIFICANDO HORA"\r
anomaly.verifying_copy: "Comprobando la Anomalía semanal actual con el servidor del juego."\r
anomaly.reward: "{cells} CÉLULAS · RECOMPENSA ✦ {reward}"\r
anomaly.reset: "(Nueva Anomalía en {date})"\r
anomaly.reward_claimed: "La recompensa de la Anomalía semanal de este sector ya ha sido reclamada."\r
anomaly.time_unverified_title: "HORA NO VERIFICADA"\r
anomaly.time_unverified_copy: "No se pudo verificar la Anomalía semanal actual."\r
anomaly.time_unverified_error: "No pudimos verificar la hora del servidor ni comprobar tu conexión a Internet. Revisa tu conexión e inténtalo de nuevo."\r
menu.home: "INICIO"\r
menu.research_lab: "LABORATORIO DE INVESTIGACIÓN"\r
menu.weaponry: "ARMAMENTO"\r
menu.buildings: "SISTEMA DE CONSTRUCCIÓN"\r
menu.encyclopedia: "ENCICLOPEDIA"\r
menu.settings: "AJUSTES"\r
menu.artifacts: "ARTEFACTOS"\r
menu.exit_game: "SALIR DEL JUEGO"\r
menu.start_run: "INICIAR PARTIDA"\r
menu.continue: "CONTINUAR"\r
menu.run_again: "JUGAR DE NUEVO"\r
menu.back: "ATRÁS"\r
menu.pause: "PAUSA"\r
menu.round_paused: "PARTIDA EN PAUSA"\r
menu.reset: "REINICIAR"\r
menu.surrender: "RENDIRSE"\r
menu.return: "VOLVER"\r
menu.main_menu: "MENÚ PRINCIPAL"\r
hud.cash: "DINERO"\r
hud.chronoshards: "CRONOFRAGMENTOS"\r
hud.cells: "CÉLULAS"\r
hud.shields: "ESCUDOS"\r
hud.sector: "SECTOR {sector}"\r
hud.sandbox_sector: "SECTOR DE PRUEBAS {sector}"\r
hud.anomaly_suffix: " · ANOMALÍA"\r
settings.preferences: "PREFERENCIAS"\r
settings.graphics: "GRÁFICOS"\r
settings.gameplay: "JUGABILIDAD"\r
settings.sound: "SONIDO"\r
settings.quality: "Calidad"\r
settings.quality_help: "Cambia la resolución de renderizado y las sombras."\r
settings.low: "BAJA"\r
settings.medium: "MEDIA"\r
settings.high: "ALTA"\r
settings.shadows: "Sombras"\r
settings.shadows_help: "Muestra sombras dinámicas de los objetos."\r
settings.hdr_emission: "Emisión HDR"\r
settings.hdr_emission_help: "Controla cuánto se extienden los efectos brillantes más allá de sus modelos."\r
settings.max_fps: "FPS máximos"\r
settings.max_fps_help: "Limita el renderizado y la simulación para reducir la carga de hardware."\r
settings.unlimited: "SIN LÍMITE"\r
settings.auto_pause: "Pausa automática"\r
settings.auto_pause_help: "Pausa la partida cuando el juego pierde el foco."\r
settings.high_contrast_hud: "HUD de alto contraste"\r
settings.high_contrast_hud_help: "Mejora la legibilidad del HUD."\r
settings.master_volume: "Volumen general"\r
settings.master_volume_help: "Controla todos los efectos de sonido del juego."\r
settings.mute_all: "Silenciar todo"\r
settings.mute_all_help: "Silencia instantáneamente todos los efectos de sonido."\r
settings.spatial_audio: "Audio espacial"\r
settings.spatial_audio_help: "Distribuye los sonidos según su posición en el mundo."\r
settings.patch_notes: "NOTAS DEL PARCHE"\r
settings.display: "PANTALLA"\r
settings.screen_mode: "Modo de pantalla"\r
settings.screen_mode_help: "Steam inicia el juego en pantalla completa de forma predeterminada."\r
settings.resolution: "Resolución"\r
settings.resolution_help: "Al elegir una resolución se cambia al modo ventana."\r
settings.fullscreen: "PANTALLA COMPLETA"\r
settings.windowed: "VENTANA"\r
milestone.ascension: "ASCENSIÓN"\r
milestone.max_cells: "MÁX. CÉLULAS"\r
milestone.cells: "{cells} CÉLULAS"\r
milestone.next: "SIGUIENTE ASCENSIÓN: {cells} CÉLULAS"\r
milestone.ready: "RECOMPENSA DE ASCENSIÓN LISTA PARA RECLAMAR"\r
milestone.complete: "ASCENSIÓN COMPLETADA"\r
milestone.claim: "RECLAMAR RECOMPENSA"\r
milestone.claimed: "Reclamada"\r
milestone.secured: "RECOMPENSA ASEGURADA"\r
milestone.auto_claimed: "Reclamada automáticamente"\r
milestone.best: "Mejor marca: {best}/{target} Células en el Sector {sector}"\r
milestone.reward_claimed: "RECOMPENSA RECLAMADA · {rewards}"\r
milestone.reward_cash: "+\${amount} de Dinero"\r
milestone.reward_chronoshards: "+✦ {amount} Cronofragmentos"\r
milestone.unlock_sector: "Desbloquear Sector {sector}"\r
milestone.unlock_feature: "Desbloquear {feature}"\r
milestone.unlock_research: "Desbloquear: {researches}"\r
error.server_time_unconfigured: "El endpoint de hora del servidor no está configurado."\r
error.server_time_request: "La solicitud de hora del servidor falló con {status}."\r
error.server_time_invalid: "El servidor devolvió una hora no válida."\r
message.round_saved: "Partida guardada. Continúa cuando quieras."\r
message.sandbox_closed: "Se cerró el modo de pruebas. No se guardó ningún progreso."\r
message.run_surrendered: "Te rendiste en la partida. No se guardó ningún progreso."\r
message.killed_by: "ELIMINADO POR {cause}"\r
message.energy_secured: "Has asegurado {count} {cellWord} de energía."\r
message.cell_singular: "célula"\r
message.cell_plural: "células"\r
message.tip: "CONSEJO · {tip}"\r
message.anomaly_reward: "ANOMALÍA +✦{amount}"\r
artifact.acquired: "ARTEFACTO OBTENIDO"\r
artifact.acquired_named: "ARTEFACTO OBTENIDO · {artifact}"\r
artifact.locked: "ARTEFACTO BLOQUEADO"\r
artifact.unknown: "ARTEFACTO DESCONOCIDO"\r
encyclopedia.unknown_enemy: "Enemigo desconocido"\r
research.slot: "RANURA {slot}"\r
research.available: "DISPONIBLE"\r
research.locked: "BLOQUEADA"\r
research.remaining: "Quedan {duration}"\r
research.select_below: "Selecciona una investigación abajo."\r
research.unlock_for: "Desbloquear por {cost}"\r
research.unlock_sector: "Desbloquea la investigación del Sector {sector} en Hitos"\r
research.max_level: "NIVEL MÁXIMO"\r
research.in_progress: "EN PROGRESO"\r
research.free_enabled: "INVESTIGACIÓN GRATUITA ACTIVADA"\r
research.cost: "Coste {cost}"\r
research.maxed: "AL MÁXIMO"\r
research.start: "INVESTIGAR"\r
research.no_search_results: "Ningún nombre de investigación coincide con tu búsqueda."\r
research.started: "La investigación {research} ha comenzado en la Ranura {slot}."\r
research.upgraded: "{research} mejorada al nivel {level}."\r
research.slot_unlocked: "Ranura de investigación {slot} desbloqueada."\r
research.requires_sector_cells: "Requiere {cells} Células en el Sector {sector}"\r
research.requires_banked_cells: "Requiere {cells} células almacenadas"\r
research.requires_research: "Requiere {research}"\r
research.requires_research_level: "Requiere {research} Nv. {level}"\r
weapon.number: "ARMA {current} / {total}"\r
weapon.cards: "CARTAS DE ARMA"\r
weapon.round_loadout: "EQUIPAMIENTO DE PARTIDA"\r
weapon.buy_with_cost: "COMPRAR ARMA · ✦ {cost}"\r
weapon.buy_five_with_cost: "COMPRAR ARMA x5 · ✦ {cost}"\r
weapon.lucky_find_cards: "HALLAZGO AFORTUNADO · {chance}% · 2 CARTAS"\r
weapon.level: "NV. {level}"\r
weapon.copy_progress_short: "{copies}/{required} copias para Nv. {level}"\r
weapon.lucky_find_double: "HALLAZGO AFORTUNADO · 2 CARTAS"\r
weapon.lucky_find_unlock: "Desbloqueada en el nivel 1 y recibiste una copia adicional."\r
weapon.lucky_find_received: "Recibiste 2 cartas. {detail}"\r
artifact.stacks: "{count} acumulaciones"\r
artifact.stack: "{count} ACUMULACIÓN"\r
artifact.stacks_label: "{count} ACUMULACIONES"\r
artifact.dark_core_stack: "{count} ACUMULACIÓN DE NÚCLEO OSCURO"\r
artifact.dark_core_stacks: "{count} ACUMULACIONES DE NÚCLEO OSCURO"\r
artifact.to_acquire: "POR OBTENER"\r
artifact.permanent_buff: "BONIFICACIÓN PERMANENTE"\r
artifact.buff_per_stack: "{buff} por acumulación · {count} acumulaciones = +{percent}% de Cronofragmentos obtenidos"\r
artifact.requirement_score: "Alcanza {cells} Células en el Sector {sector}."\r
artifact.requirement_milestone: "Reclama la recompensa de Ascensión de {cells} Células del Sector {sector}."\r
artifact.requirement_anomaly: "Completa cada Anomalía en cada Sector. Cada combinación única de Anomalía y Sector otorga una acumulación."\r
artifact.requirement_hidden: "Condición oculta."\r
artifact.requirement_default: "Completa este logro de artefacto."\r
building.choose_offer: "ELIGE 1 DE {count} · SIGUIENTE DESBLOQUEO ✦ {cost}"\r
building.all_unlocked: "TODOS LOS EDIFICIOS DESBLOQUEADOS"\r
building.permanent_unlock: "Desbloqueo permanente de edificio"\r
building.unlock_cost: "DESBLOQUEAR · ✦ {cost}"\r
building.upgrade: "MEJORAR"\r
building.slot_limit: "LÍMITE DE RANURAS"\r
building.build_cost: "Coste de construcción: \${cost}"\r
building.unlocked: "DESBLOQUEADO"\r
building.none_unlocked: "AÚN NO HAY EDIFICIOS DESBLOQUEADOS"\r
building.build_mode_slots: "MODO CONSTRUCCIÓN · RANURAS {used}/{total}"\r
building.level: "NV. {level}"\r
building.installed_defense: "DEFENSA INSTALADA"\r
building.choose_upgrade: "Elige una mejora para esta estructura."\r
building.upgrade_level: "NV. {current} → {next}"\r
building.demolish_refund: "DEMOLER · REEMBOLSO \${amount}"\r
building.demolish_confirm: "¿Demoler {building}? Recibirás un reembolso de \${refund}."\r
research.active_slots: "RANURAS ACTIVAS"\r
research.available_research: "INVESTIGACIONES DISPONIBLES"\r
research.search: "BUSCAR"\r
research.search_placeholder: "Buscar nombres de investigaciones"\r
research.hide_completed: "Ocultar investigaciones completadas"\r
research.hide_locked: "Ocultar investigaciones bloqueadas"\r
artifact.permanent_achievements: "LOGROS PERMANENTES"\r
artifact.intro: "Los Artefactos son recompensas permanentes obtenidas al alcanzar objetivos de logros."\r
building.permanent_defenses: "DEFENSAS PERMANENTES"\r
building.system: "SISTEMA DE CONSTRUCCIÓN"\r
building.build_mode: "MODO CONSTRUCCIÓN"\r
building.unlock_a_building: "DESBLOQUEAR UN EDIFICIO"\r
building.unlocked_buildings: "EDIFICIOS DESBLOQUEADOS"\r
building.draft: "SELECCIÓN DE EDIFICIO"\r
weapon.active_arsenal: "ARSENAL ACTIVO"\r
menu.back: "ATRÁS"\r
menu.done: "HECHO"\r
encyclopedia.threat_database: "BASE DE DATOS DE AMENAZAS"\r
accessibility.game_canvas: "Lienzo del juego Asteroid Belt"\r
accessibility.current_sector: "Sector de dificultad actual"\r
accessibility.pause_game: "Pausar juego"\r
accessibility.shield_charges: "Cargas de escudo"\r
accessibility.game_controls: "Controles del juego"\r
accessibility.build_information: "Información de construcción"\r
accessibility.build_locations: "Ubicaciones de construcción"\r
accessibility.pause_menu: "Menú de pausa"\r
accessibility.debug_console: "Consola de depuración"\r
accessibility.close_debug_console: "Cerrar consola de depuración"\r
accessibility.save_slots: "Selección de ranura de guardado"\r
accessibility.defeating_enemy: "Modelo 3D de enemigo derrotado"\r
accessibility.sector_selection: "Selección de sector de dificultad"\r
accessibility.previous_sector: "Seleccionar sector anterior"\r
accessibility.next_sector: "Seleccionar sector siguiente"\r
accessibility.previous_milestone_sector: "Ver sector de hito anterior"\r
accessibility.next_milestone_sector: "Ver sector de hito siguiente"\r
accessibility.enemy_model: "Modelo de {enemy}"\r
controls.move: "MOVERSE"\r
controls.navigate: "NAVEGAR"\r
controls.use_weapon: "USAR ARMA"\r
controls.select_weapon: "SELECCIONAR / USAR ARMA"\r
patch_notes.version_build: "VERSIÓN {version} · COMPILACIÓN {build}"\r
patch_notes.artifacts: "ARTEFACTOS"\r
patch_notes.artifacts_1: "Presentamos el Sistema de Artefactos: una mecánica de logros que recompensa al jugador con bonificaciones y recompensas permanentes al cumplir ciertos objetivos."\r
patch_notes.artifacts_2: "Los Artefactos se obtienen principalmente al alcanzar 500 Células en el Nivel 2 y superiores."\r
patch_notes.artifacts_3: "Actualmente hay 10 Artefactos distintos; se añadirán más en próximas actualizaciones."\r
patch_notes.improvements: "MEJORAS"\r
patch_notes.improvements_1: "Diversas mejoras de la interfaz para aumentar la visibilidad, especialmente en dispositivos móviles."\r
patch_notes.improvements_2: "Pequeños ajustes de valores relacionados con los desbloqueos de Investigación y la fuerza de los Enemigos."\r
tip.1: "Tarde o temprano te verás superado, hagas lo que hagas. Intenta desbloquear nuevas investigaciones para llegar más lejos."\r
tip.2: "Sigue moviéndote: quedarte quieto hace que sea mucho más difícil anticipar los peligros entrantes."\r
tip.3: "Los últimos segundos de vida de un enemigo se indican con un parpadeo."\r
tip.4: "Las mejoras de Investigación se conservan entre partidas, así que incluso una partida corta puede hacerte avanzar."\r
tip.5: "Usa el borde de la arena para reducir las direcciones desde las que pueden acercarse los enemigos."\r
tip.6: "Los Cronofragmentos son raros, valiosos y duran poco. Asegúrate de recogerlos antes de que desaparezcan."\r
tip.7: "Observa los anillos de alcance de los enemigos antes de decidir una ruta por la arena."\r
tip.8: "Más adelante en el juego puedes desbloquear potenciadores desde el Laboratorio de Investigación."\r
tip.9: "Tras alcanzar el Sector IV, puedes desbloquear la capacidad de construir Edificios que te ayuden en la arena."\r
tip.10: "Los enemigos púrpura se llaman Reptantes y aumentan gradualmente su velocidad con el tiempo. Las colisiones estáticas con obstáculos pueden ralentizarlos."\r
tip.11: "Los enemigos rojos se llaman Perseguidores y te perseguirán cuando entres en su alcance."\r
tip.12: "Los enemigos amarillos se llaman Explosivos y explotan después de unos segundos."\r
tip.13: "Cuantas más Células recoges, más difícil se vuelve el juego."\r
tip.14: "A medida que avanzas por el juego aparecen nuevos enemigos y obstáculos, así que prepárate para nuevos desafíos."\r
tip.15: "Cada sector presenta enemigos y desafíos únicos, así que adapta tu estrategia en consecuencia."\r
tip.16: "Asteroid Belt está diseñado como una experiencia sin fin, así que céntrate en mejorar tus habilidades y estrategias para lograr puntuaciones más altas."\r
cheat.title: "CONSOLA DE DEPURACIÓN"\r
cheat.prompt: "Introduce un comando."\r
cheat.placeholder: "cash 1000"\r
cheat.feature_sector: "Debes alcanzar el Sector {sector}."\r
cheat.feature_cells: "Debes recoger {cells} Células en el Sector {sector}."\r
cheat.feature_chronoshards: "Necesitas ✦ {amount} Cronofragmentos."\r
cheat.feature_unavailable: "Este sistema aún no está disponible."\r
cheat.research_completed: "Investigación {research} completada."\r
status.damage: "DAÑO DE {status}"\r
cheat.sandbox_started: "Sector de pruebas I iniciado. Usa sandbox [sector], sandbox simulate [cell|enemies|all] o sandbox spawn [enemy] [count]."\r
cheat.sandbox_sector: "La dificultad del modo de pruebas se ha establecido en el Sector {sector}. La simulación de aparición no ha cambiado."\r
cheat.sandbox_start_first: "Primero inicia el modo de pruebas con: sandbox"\r
cheat.sandbox_simulate_usage: "Uso: sandbox simulate [cell|enemies|all]"\r
cheat.sandbox_simulation: "Simulación de {type} del modo de pruebas iniciada para el Sector {sector}."\r
cheat.sandbox_spawn_usage: "Uso: sandbox spawn [{enemies}] [count]"\r
cheat.sandbox_spawned: "Se generaron {count} {enemy}{plural}."\r
cheat.sandbox_usage: "Uso: sandbox [sector] | sandbox simulate [cell|enemies|all] | sandbox spawn [enemy] [count]"\r
cheat.spawn_usage: "Uso: spawn <entity_id>. Disponibles: {entities}"\r
cheat.spawn_requires_round: "Inicia una partida antes de generar una entidad."\r
cheat.spawned: "Se generó {entity} cerca del jugador."\r
cheat.anomaly_usage: "Uso: anomaly <anomaly_id>"\r
cheat.anomaly_unknown: "Anomalía desconocida: {id}. Disponibles: {available}"\r
cheat.anomaly_started: "Anomalía {id} iniciada en el Sector {sector}."\r
cheat.cell_usage: "Uso: cell <cantidad positiva>"\r
cheat.cell_requires_round: "Inicia una partida antes de añadir Células."\r
cheat.cell_granted: "Se añadieron {amount} Células sin otorgar dinero. Total: {total}."\r
cheat.cell_obtain_usage: "Uso: cell_obtain <número entero de 1 a 10.000>"\r
cheat.cell_obtain_set: "Multiplicador de obtención de células establecido en {amount} para esta sesión."\r
cheat.god_usage: "Uso: god <on/off>"\r
cheat.god_state: "Modo dios {state}."\r
cheat.on: "ACTIVADO"\r
cheat.off: "DESACTIVADO"\r
cheat.artifact_usage: "Uso: gain_artifact <artifact_name> <stack>"\r
cheat.artifact_unknown: "Artefacto desconocido: {artifact}"\r
cheat.artifact_stack_range: "La acumulación debe ser un número entero entre 1 y 10.000."\r
cheat.artifact_granted: "Se otorgaron {count} {artifact} {stackWord} ({total} en total)."\r
cheat.artifact_unique: "{artifact} es un Artefacto único y ahora está desbloqueado."\r
cheat.amount_usage: "Uso: {command} [positive amount]"\r
cheat.amount_granted: "Se otorgaron {amount}."\r
cheat.free_research: "Investigación gratuita activada para esta sesión."\r
cheat.sectors_unlocked: "Todos los sectores y recompensas de Ascensión desbloqueados.{rewards}"\r
cheat.clear_usage: "Uso: clear_save [{targets}]"\r
cheat.cleared: "Se borraron los datos de guardado de {target}."\r
cheat.unknown_command: "Comando desconocido: {command}"\r
menu.patch_notes: "NOTAS DEL PARCHE"\r
menu.unlock_feature: "DESBLOQUEAR {feature} · ✦ {cost}"\r
menu.feature_sector: "{feature} · SECTOR {sector}"\r
onboarding.drag_to_move: "ARRASTRA PARA MOVERTE"\r
`;function Gi(e){return Object.fromEntries(e.split(/\r?\n/).map(e=>e.match(/^([\w.-]+):\s*"(.*)"\s*$/)).filter(Boolean).map(([,e,t])=>[e,t.replaceAll(`\\"`,`"`)]))}var Ki=Object.freeze({en:Gi(Hi),tr:Gi(Ui),es:Gi(Wi)});function qi(){return(typeof navigator>`u`?[]:navigator.languages?.length?navigator.languages:[navigator.language]).map(e=>e?.split(`-`)[0].toLowerCase()).find(e=>Ki[e])??`en`}function Ji(){try{let e=Math.max(1,Number.parseInt(localStorage.getItem(`asteroid-belt-active-save-slot`)??`1`,10)||1),t=JSON.parse(localStorage.getItem(`asteroid-belt-slot-${e}-settings`)??localStorage.getItem(`asteroid-belt-settings`)??`null`);return Ki[t?.language]?t.language:qi()}catch{return qi()}}var Yi=Ji();function Xi(e){Yi=Ki[e]?e:`en`}function Zi(){return Object.keys(Ki)}function N(e,t={},n=e){return(Ki[Yi]?.[e]??Ki.en[e]??n).replace(/\{(\w+)\}/g,(e,n)=>String(t[n]??`{${n}}`))}var Qi={durationsEnabled:!1,categoryOrder:[`Player Enhancements`,`Economy`,`Boosters`],featureUnlocks:{researchLab:{minSector:1,chronoshardCost:0,requiredMilestone:`sector-1-10`},buildingSystem:{minSector:4,chronoshardCost:50},weaponry:{minSector:2,chronoshardCost:25}},maxSlots:3,slotUnlocks:[{slot:2,cost:{currency:`chronoshards`,amount:50},requirements:{minSector:2}},{slot:3,cost:{currency:`chronoshards`,amount:200},requirements:{minSector:3}},{slot:4,cost:{currency:`chronoshards`,amount:500},requirements:{minSector:4}},{slot:5,cost:{currency:`chronoshards`,amount:1500},requirements:{minSector:4}}],researches:[{id:`lucky-find`,category:`Weapons`,name:`Lucky Find`,description:`Weapon cards have a chance to become Lucky Finds and grant 2 cards instead of 1.`,maxLevel:10,effect:{stat:`luckyFindChance`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:5e3,multiplier:1.3,jerk:1.001},duration:{baseMs:15e4,multiplier:1.16}},{id:`weapon-recharge`,category:`Weapons`,name:`Weapon Recharge`,description:`Weapons are now capable of recharging over time.`,maxLevel:1,cost:{currency:`cash`,base:6e3,multiplier:1,jerk:1},duration:{baseMs:18e4,multiplier:1}},{id:`weapon-recharge-rate`,category:`Weapons`,name:`Weapon Recharge Rate`,description:`Reduces weapon recharge time.`,maxLevel:10,effect:{stat:`weaponRechargeReductionSeconds`,perLevel:30,format:`flat`},cost:{currency:`cash`,base:3e3,multiplier:1.28,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18},requirements:{researchId:`weapon-recharge`}},{id:`weapon-charge-capacity`,category:`Weapons`,name:`Weapon Charge Capacity`,description:`Increases the maximum stored charges for each equipped weapon by 1.`,maxLevel:4,effect:{stat:`weaponChargeCapacity`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:7500,multiplier:1.42,jerk:1.002},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchId:`weapon-recharge`}},{id:`weapon-slots`,category:`Weapons`,name:`Weapon Slot`,description:`Adds one weapon slot to your round loadout.`,maxLevel:4,effect:{stat:`weaponSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:8e3,multiplier:1.8,jerk:1.01},duration:{baseMs:18e4,multiplier:1.25}},{id:`player-speed-multiplier`,category:`Player Enhancements`,name:`Player Speed Multiplier`,description:`Increases player movement speed.`,maxLevel:50,effect:{stat:`playerSpeedMultiplier`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:75,multiplier:1.14,jerk:1.0003},duration:{baseMs:9e4,multiplier:1.3}},{id:`unlock-slow-aura`,category:`Player Enhancements`,name:`Unlock Slow Aura`,description:`Unlocks the Slow Aura ability, which slows down nearby enemies within the range.`,maxLevel:1,cost:{currency:`cash`,base:600,multiplier:1,jerk:1},duration:{baseMs:9e4,multiplier:1}},{id:`unlock-orbital-electron`,category:`Player Enhancements`,name:`Unlock Orbital Electron`,description:`Deploys an Electron that orbits your effective range and stuns enemies struck by its electric arc.`,maxLevel:1,cost:{currency:`cash`,base:2e3,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`electron-stun-duration`,category:`Player Enhancements`,name:`Electron Stun Duration`,description:`Increases how long enemies hit by the Orbital Electron are stunned.`,maxLevel:20,effect:{stat:`electronStunDuration`,perLevel:.2,format:`flat`},cost:{currency:`cash`,base:2e3,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.18},requirements:{researchId:`unlock-orbital-electron`}},{id:`electron-speed`,category:`Player Enhancements`,name:`Electron Speed`,description:`Increases Orbital Electron orbit speed.`,maxLevel:20,effect:{stat:`electronSpeed`,perLevel:.35,format:`flat`},cost:{currency:`cash`,base:1500,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.16},requirements:{researchId:`unlock-orbital-electron`}},{id:`slow-aura-effect`,category:`Player Enhancements`,name:`Slow Aura Effect`,description:`Increases the effect of the Slow Aura ability.`,maxLevel:50,effect:{stat:`slowAuraEffect`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.14,jerk:1.0003},duration:{baseMs:12e7,multiplier:1.35},requirements:{researchId:`unlock-slow-aura`}},{id:`slow-aura-range`,category:`Player Enhancements`,name:`Effect Range`,description:`Increases the range of every active range-based effect.`,maxLevel:99,effect:{stat:`effectRange`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.09,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35},requirements:{anyResearch:[`unlock-slow-aura`,`cell-magnet`,`pushback`]}},{id:`cell-spawn-rate`,category:`Economy`,name:`Cell Spawn Rate`,description:`Increases the spawn rate of standard cells.`,maxLevel:99,effect:{stat:`cellSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.1,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`cell-increment-per-cell`,category:`Economy`,name:`Cell Increment Per Cell`,description:`Each collected Cell increases the standard Cell spawn rate.`,maxLevel:10,effect:{stat:`cellSpawnRatePerCell`,perLevel:.01,format:`percent`},cost:{currency:`cash`,base:750,multiplier:1.35,jerk:1.003},duration:{baseMs:9e4,multiplier:1.2}},{id:`cash-cell-multiplier`,category:`Economy`,name:`Cash/Cell Multiplier`,description:`Increases the Cash earned from every standard cell.`,maxLevel:99,effect:{stat:`cashMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:60,multiplier:1.1,jerk:1.00015},duration:{baseMs:6e4,multiplier:1.25}},{id:`initial-cell-count`,category:`Economy`,name:`Initial Cell`,description:`Adds one Cell to the arena at the start of every run.`,maxLevel:99,effect:{stat:`initialCellCount`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:15,multiplier:1.08,jerk:1.00005},duration:{baseMs:3e4,multiplier:1.08}},{id:`cell-magnet`,category:`Economy`,name:`Cell Magnet`,description:`Pulls nearby Cells toward you. Each level increases pull speed.`,maxLevel:20,effect:{stat:`cellMagnetSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:500,multiplier:1.2,jerk:1.001},duration:{baseMs:9e4,multiplier:1.16}},{id:`chrono-spawn-rate`,category:`Economy`,name:`Chrono Spawn Rate`,description:`Makes Chrono Cells appear more frequently.`,maxLevel:99,effect:{stat:`chronoSpawnRate`,perLevel:.02,format:`percent`},cost:{currency:`cash`,base:400,multiplier:1.11,jerk:1.00015},duration:{baseMs:12e7,multiplier:1.35}},{id:`chrono-lifetime-multiplier`,category:`Economy`,name:`Chrono Lifetime Multiplier`,description:`Increases the lifetime of Chrono Cells.`,maxLevel:30,effect:{stat:`chronoLifetimeMultiplier`,perLevel:.05,format:`percent`},cost:{currency:`cash`,base:250,multiplier:1.14,jerk:1.0005},duration:{baseMs:12e7,multiplier:1.35}},{id:`unlock-shockwave`,category:`Player Enhancements`,name:`Unlock Shockwave`,description:`Periodically emits a green shockwave that pushes enemies away.`,maxLevel:1,cost:{currency:`cash`,base:900,multiplier:1,jerk:1},duration:{baseMs:12e4,multiplier:1}},{id:`shockwave-frequency`,category:`Player Enhancements`,name:`Shockwave Frequency`,description:`Makes Shockwaves trigger more frequently.`,maxLevel:20,effect:{stat:`shockwaveFrequency`,perLevel:.1,format:`percent`},cost:{currency:`cash`,base:150,multiplier:1.2,jerk:1.001},duration:{baseMs:12e4,multiplier:1.2},requirements:{researchId:`unlock-shockwave`}},{id:`shield`,category:`Player Enhancements`,name:`Shield`,description:`Grants one death save per level at the start of every run.`,maxLevel:10,effect:{stat:`shieldCharges`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:4e3,multiplier:1.38,jerk:1.002},duration:{baseMs:18e4,multiplier:1.25}},{id:`building-slots`,category:`Building System`,name:`Building Slots`,description:`Increases the number of buildings you can place in the arena by 1.`,maxLevel:7,effect:{stat:`buildingSlots`,perLevel:1,format:`flat`},cost:{currency:`cash`,base:5e3,multiplier:1.45,jerk:1.002},duration:{baseMs:12e4,multiplier:1.2}},...[[`unlock-speed-booster`,`Unlock Speed Boosters`,`Unlocks Speed Booster pickups that double movement speed.`,1,null],[`speed-booster-duration`,`Speed Booster Duration`,`Increases Speed Booster duration.`,20,`speedBoosterDuration`,`unlock-speed-booster`],[`thorn-shield`,`Thorn Shield`,`Unlocks Thorn Shield pickups that grant immunity and destroy enemies on contact.`,1,null],[`thorn-shield-duration`,`Thorn Shield Duration`,`Increases Thorn Shield duration.`,20,`thornShieldDuration`,`thorn-shield`],[`freezer`,`Freezer`,`Unlocks Freezer pickups that freeze all enemies.`,1,null],[`freezer-duration`,`Freezer Duration`,`Increases Freezer duration.`,20,`freezerDuration`,`freezer`]].map(([e,t,n,r,i,a])=>({id:e,category:`Boosters`,name:t,description:n,maxLevel:r,...i?{effect:{stat:i,perLevel:.25,format:`flat`}}:{},cost:{currency:`cash`,base:r===1?2500:1500,multiplier:r===1?1:1.18,jerk:r===1?1:1.001},duration:{baseMs:12e4,multiplier:1.18},...a?{requirements:{researchId:a}}:{}})),{id:`pushback`,category:`Player Enhancements`,name:`Pushback`,description:`Pushes nearby stationary enemies away. Each level increases push speed.`,maxLevel:20,effect:{stat:`pushbackSpeed`,perLevel:.25,format:`flat`},cost:{currency:`cash`,base:1e4,multiplier:1.18,jerk:1.001},duration:{baseMs:15e4,multiplier:1.18}},{id:`shield-invulnerability-duration`,category:`Player Enhancements`,name:`Shield Afterglow`,description:`Increases invulnerability time after the Shield breaks.`,maxLevel:20,effect:{stat:`shieldInvulnerabilityDuration`,perLevel:.05,format:`flat`},cost:{currency:`cash`,base:12e3,multiplier:1.18,jerk:1.001},duration:{baseMs:18e4,multiplier:1.2},requirements:{researchLevels:{shield:1}}},{id:`shield-break-explosion`,category:`Player Enhancements`,name:`Shield Break Explosion`,description:`Destroys all enemies within range when the Shield breaks. Each level increases the range.`,maxLevel:20,effect:{stat:`shieldBreakExplosionRadius`,perLevel:.3,format:`flat`},cost:{currency:`cash`,base:2e4,multiplier:1.18,jerk:1.001},duration:{baseMs:21e4,multiplier:1.22},requirements:{researchLevels:{shield:1}}},...[[`regular-lifetime-debuff`,`Regular Decay`,`Reduces Regular enemy lifetime.`,`regularLifetimeDebuff`],[`chaser-range-debuff`,`Chaser Range Dampener`,`Reduces Chaser detection range.`,`chaserRangeDebuff`],[`creeper-speed-debuff`,`Creeper Slowdown`,`Reduces Creeper movement speed.`,`creeperSpeedDebuff`],[`banger-range-debuff`,`Banger Range Dampener`,`Reduces Banger blast range.`,`bangerRangeDebuff`],[`banger-enemy-destruction`,`Banger Disruption`,`Give the banger's blast a chance to destroy affected enemies.`,`bangerEnemyDestroyChance`],[`shooter-range-debuff`,`Shooter Range Dampener`,`Reduces Shooter firing range.`,`shooterRangeDebuff`],[`shooter-projectile-debuff`,`Projectile Drag`,`Reduces Shooter projectile speed.`,`shooterProjectileSpeedDebuff`],[`porter-interval-debuff`,`Porter Delay Field`,`Increases the interval between Porter teleports.`,`porterIntervalBonus`],[`magnet-strength-debuff`,`Magnet Insulation`,`Reduces Magnet pull strength.`,`magnetStrengthDebuff`],[`spore-speed-debuff`,`Spore Drag`,`Reduces Spore movement speed.`,`sporeSpeedDebuff`],[`poison-creep-clean`,`Poison Creep Clean`,`Reduces how long Poison Creeper trails remain.`,`poisonTrailDurationReduction`]].map(([e,t,n,r])=>({id:e,category:`Enemy Debuff`,name:t,description:n,maxLevel:20,effect:{stat:r,perLevel:r===`porterIntervalBonus`||r===`poisonTrailDurationReduction`?.05:.025,format:`percent`},...r===`poisonTrailDurationReduction`?{maxLevel:15}:{},cost:{currency:`cash`,base:6e3,multiplier:1.18,jerk:1.001},duration:{baseMs:24e4,multiplier:1.22}}))]},$i=e=>`research.category.${e.toLowerCase().replaceAll(` `,`_`)}`,ea={...Qi,categoryOrder:Qi.categoryOrder.map(e=>N($i(e),{},e)),researches:Qi.researches.map(e=>({...e,category:N($i(e.category),{},e.category),name:N(`research.${e.id}.name`,{},e.name),description:N(`research.${e.id}.description`,{},e.description)}))},ta={enabled:!0,hotkey:`"`,title:N(`cheat.title`),commands:{cash:`cash`,chrono:`chrono`,freeResearch:`free_research`,unlockSectors:`unlock_sectors`,gainArtifact:`gain_artifact`,clearSave:`clear_save`,sandbox:`sandbox`,spawn:`spawn`,anomaly:`anomaly`,cell:`cell`,cellObtain:`cell_obtain`,god:`god`,triggerMission:`trigger_misison`,completeRandomMission:`complete_random_mission`},clearSaveTargets:[`currency`,`game_progress`,`milestones`,`research`,`buildings`,`weapons`,`artifacts`,`all`]},na={version:`0.9.13`,number:`1176`,date:`October 1, 2026`,label:`EARLY ACCESS`},ra={unlockSector:2,weeklyAnchorDate:`2026-09-02`,rewardCellTarget:250,rewardBaseChronoshards:10,rewardChronoshardStepPerSector:2,challenges:[{id:`cell-scout`,name:`Scout Rivalry`,description:`A distant red AI ship collects Cells alongside you. Its Cells do not count toward your run, and it cannot harm you.`,type:`cell-scout`,rewardCellTarget:250},{id:`tower-defense`,name:`Tower Defense`,description:`Defend the central tower from enemy waves. Destroy 1,000 enemies before the tower falls.`,type:`tower-defense`,rewardCellTarget:1e3,towerHitpoints:100,towerContactDamage:1,towerProjectileDamage:1,towerRadius:1.15,difficultyMultiplier:1,enemyTypes:[`regular`,`chaser`,`creeper`,`shooter`],enemySpawnWeights:{regular:.4,chaser:.25,creeper:.2,shooter:.15},enemyMovementSpeeds:{chaser:2.4,creeper:1.25,shooter:1.1}}]},ia={...ra,challenges:ra.challenges.map(e=>({...e,name:N(`anomaly.${e.id}.name`,{},e.name),description:N(`anomaly.${e.id}.description`,{},e.description)}))},aa={endpoint:``},oa={endpoint:``,publicEndpoint:`https://utctime.app/api/now`},sa=`asteroid-belt-analytics-session-id`;function ca(){try{let e=sessionStorage.getItem(sa);if(e)return e;let t=crypto.randomUUID();return sessionStorage.setItem(sa,t),t}catch{return crypto.randomUUID()}}function la({sector:e,buildVersion:t,platform:n}){aa.endpoint&&fetch(aa.endpoint,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({event:`sector_started`,sessionId:ca(),properties:{sector:e,buildVersion:t,platform:n}}),keepalive:!0}).catch(()=>{})}var ua={placementRadius:10,minimumSpacing:2.2,spawnClearance:2.5,types:{chronoGenerator:{name:`Chrono Generator`,baseCost:180,costMultiplier:1.35,color:`#63f5cd`,effect:{range:4,slow:.22},upgrades:{range:{base:180,step:.2},effectiveness:{base:240,step:.02}}},autocannon:{name:`Autocannon`,baseCost:350,costMultiplier:1.45,color:`#ff795f`,effect:{range:5,interval:2.6},upgrades:{range:{base:360,step:.2},frequency:{base:440,step:-.06}}},droneBay:{name:`Drone Bay`,baseCost:460,costMultiplier:1.48,color:`#79caff`,effect:{period:14,count:1,droneSpeed:5},upgrades:{period:{base:540,step:-.65},count:{base:880,step:1}}},barrierNode:{name:`Barrier Node`,baseCost:520,costMultiplier:1.5,color:`#76eaff`,effect:{range:4.3,period:12,duration:4.5},upgrades:{range:{base:560,step:.28},period:{base:640,step:-.55},duration:{base:700,step:.45}}},overclockRelay:{name:`Overclock Relay`,baseCost:580,costMultiplier:1.52,color:`#ffcf76`,effect:{range:5.2,effectiveness:.14},upgrades:{range:{base:620,step:.3},effectiveness:{base:760,step:.04}}},salvageExtractor:{name:`Salvage Extractor`,baseCost:640,costMultiplier:1.55,color:`#8dff9c`,effect:{range:4.8,period:18,count:1,cash:2},upgrades:{period:{base:720,step:-.7},cash:{base:820,step:1.5},count:{base:980,step:1}}}}},da={...ua,types:Object.fromEntries(Object.entries(ua.types).map(([e,t])=>[e,{...t,name:N(`building.${e}.name`,{},t.name),upgrades:Object.fromEntries(Object.entries(t.upgrades).map(([e,t])=>[e,{...t,name:N(`building.upgrade.${e}`,{},e)}]))}]))};function fa({THREE:e,COLORS:t,ENTITIES:n,GAME:r,opacity:i=1}){let a=new e.Group,o=new e.Mesh(new e.ConeGeometry(.58,1.45,6),new e.MeshStandardMaterial({color:t.player,emissive:`#000000`,emissiveIntensity:0,metalness:.2,roughness:.55}));o.rotation.x=Math.PI/2,o.position.y=.18,o.castShadow=!0,a.add(o);let s=new e.MeshStandardMaterial({color:t.playerWing??`#f6b05c`,emissive:`#000000`,emissiveIntensity:0,metalness:.18,roughness:.58});for(let t of[-1,1]){let n=new e.Mesh(new e.BoxGeometry(.82,.08,.58),s);n.position.set(t*.52,.12,-.08),n.rotation.z=t*-.16,n.castShadow=!0,a.add(n)}let c=new e.Mesh(new e.SphereGeometry(.29,12,8),new e.MeshStandardMaterial({color:`#76ddff`,emissive:`#000000`,emissiveIntensity:0,metalness:.25,roughness:.48}));c.scale.set(.82,.62,1.15),c.position.set(0,.38,.18),a.add(c);let l=new e.Mesh(new e.TorusGeometry(.3,n.playerRingTube*.72,n.playerRingRadialSegments,n.playerRingTubularSegments),new e.MeshBasicMaterial({color:t.playerRing,transparent:!0,opacity:.88}));l.position.set(0,.17,-.67),a.add(l);let u=new e.Group,d=new e.Mesh(new e.ConeGeometry(.27,.82,8),new e.MeshBasicMaterial({color:`#ff5c32`,transparent:!0,opacity:.74,depthWrite:!1})),f=new e.Mesh(new e.ConeGeometry(.14,.57,8),new e.MeshBasicMaterial({color:`#ffe781`,transparent:!0,opacity:.94,depthWrite:!1}));for(let e of[d,f])e.rotation.x=-Math.PI/2;f.position.z=-.08,u.add(d,f),u.position.set(0,.17,-.93),a.add(u);let p=new e.Mesh(new e.RingGeometry(1-n.slowAuraRingWidth,1,n.slowAuraRingSegments),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.35,side:e.DoubleSide,depthWrite:!1}));p.rotation.x=-Math.PI/2,p.position.y=-r.playerStartHeight+.04,p.visible=!1,a.add(p);let m=new e.Mesh(new e.SphereGeometry(r.playerRadius*1.15,20,14),new e.MeshBasicMaterial({color:t.slowAura,transparent:!0,opacity:.18,wireframe:!0,depthWrite:!1}));return m.visible=!1,a.add(m),i<1&&a.traverse(e=>{e.material&&(e.material.transparent=!0,e.material.opacity*=i,e.material.depthWrite=!1)}),a.position.y=r.playerStartHeight,{player:a,playerCore:o,slowAuraRing:p,shieldBubble:m,updateVisuals(e,t,n){l.rotation.z+=e*n;let r=.9+Math.sin(t*20)*.12+Math.sin(t*33)*.06;u.scale.set(1,1,r),d.material.opacity=.62+Math.sin(t*17)*.12,f.material.opacity=.8+Math.sin(t*23)*.14}}}function pa({THREE:e,building:t,config:n,range:r}){let i=new e.Group,a=new e.MeshStandardMaterial({color:`#33465a`,emissive:n.color,emissiveIntensity:.24,metalness:.92,roughness:.14}),o={autocannon:`#ffd36f`,droneBay:`#79caff`,barrierNode:`#76eaff`,overclockRelay:`#ffcf76`,salvageExtractor:`#8dff9c`}[t.type]??`#a6a2ff`,s=new e.MeshStandardMaterial({color:o,emissive:o,emissiveIntensity:1.25,metalness:.78,roughness:.12}),c=new e.Mesh(new e.CylinderGeometry(.53,.64,.26,8),a);if(c.position.y=.13,i.add(c),t.type===`chronoGenerator`){let t=new e.Mesh(new e.IcosahedronGeometry(.32,1),s);t.position.y=.67;let n=new e.Mesh(new e.TorusGeometry(.46,.035,8,24),s);n.position.y=.68,n.rotation.x=Math.PI/2;let r=n.clone();r.rotation.set(Math.PI/3,0,Math.PI/5),i.add(t,n,r)}if(t.type===`autocannon`){let t=new e.Mesh(new e.BoxGeometry(.48,.26,.48),s);t.position.y=.42,i.add(t);for(let t of[-.14,.14]){let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.78,8),s);n.rotation.x=Math.PI/2,n.position.set(t,.51,.38),i.add(n)}}if(t.type===`droneBay`){let t=new e.Mesh(new e.BoxGeometry(.96,.42,.78),a);t.position.y=.47;let n=new e.Mesh(new e.BoxGeometry(.56,.22,.04),s);n.position.set(0,.5,.41),i.add(t,n);for(let t of[-.26,.26]){let n=new e.Mesh(new e.SphereGeometry(.09,8,6),s);n.position.set(t,.82,.08),i.add(n)}}if(t.type===`barrierNode`){let t=new e.Mesh(new e.OctahedronGeometry(.34,0),s);t.position.y=.72,i.add(t);for(let t=0;t<3;t+=1){let n=new e.Mesh(new e.ConeGeometry(.13,.8,6),s),r=t*Math.PI*2/3;n.position.set(Math.cos(r)*.42,.46,Math.sin(r)*.42),i.add(n)}let n=new e.Mesh(new e.SphereGeometry(.72,16,10,0,Math.PI*2,0,Math.PI/2),new e.MeshBasicMaterial({color:`#8ceaff`,transparent:!0,opacity:.15,depthWrite:!1}));n.position.y=.1,i.add(n)}if(t.type===`overclockRelay`){let t=new e.Mesh(new e.TorusGeometry(.34,.06,8,24),s);t.position.y=.62,t.rotation.x=Math.PI/2;let n=new e.Mesh(new e.CylinderGeometry(.035,.05,.72,8),s);n.position.y=.8;let r=new e.Mesh(new e.SphereGeometry(.1,10,8),s);r.position.y=1.18,i.add(t,n,r)}if(t.type===`salvageExtractor`){let t=new e.Mesh(new e.CylinderGeometry(.3,.42,.66,8),s);t.position.y=.55;let n=new e.Mesh(new e.CylinderGeometry(.075,.1,.82,8),a);n.position.set(.36,.82,0),n.rotation.z=-Math.PI/3;let r=new e.Mesh(new e.ConeGeometry(.17,.34,5),s);r.position.set(.72,.55,0),r.rotation.z=-Math.PI/2,i.add(t,n,r)}let l=Number.isFinite(n.effect.range),u=new e.Mesh(new e.RingGeometry(.985,1.005,48),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.28,side:e.DoubleSide,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.y=.03,u.scale.setScalar(l?r:0),u.visible=l,i.add(u);let d=null;if(t.type===`barrierNode`){d=new e.Group;let t=new e.Mesh(new e.CylinderGeometry(1,1,1.6,40,1,!0),new e.MeshBasicMaterial({color:n.color,transparent:!0,opacity:.16,side:e.DoubleSide,depthWrite:!1}));t.position.y=.8;let r=new e.Mesh(new e.TorusGeometry(1,.035,6,40),new e.MeshBasicMaterial({color:`#d5ffff`,transparent:!0,opacity:.85,depthWrite:!1}));r.position.y=1.58,r.rotation.x=Math.PI/2,d.add(t,r),d.visible=!1,i.add(d)}return i.position.set(t.x,0,t.z),{group:i,effectRing:u,barrierField:d}}function ma(e){let t=new e.Group,n=new e.MeshStandardMaterial({color:`#314c63`,emissive:`#79caff`,emissiveIntensity:.8,metalness:.9,roughness:.18}),r=new e.MeshBasicMaterial({color:`#baf8ff`,transparent:!0,opacity:.95,depthWrite:!1}),i=new e.Mesh(new e.SphereGeometry(.14,10,7),n);i.scale.set(1.25,.55,1.5),t.add(i);let a=[];for(let[i,o]of[[-.22,-.2],[.22,-.2],[-.22,.2],[.22,.2]]){let s=new e.Mesh(new e.BoxGeometry(.13,.035,.13),n);s.position.set(i,0,o);let c=new e.Mesh(new e.CylinderGeometry(.12,.12,.018,12),r);c.position.set(i,.045,o),t.add(s,c),a.push(c)}let o=new e.Mesh(new e.SphereGeometry(.055,8,6),r);return o.position.set(0,.015,.2),t.add(o),t.userData.rotors=a,t}function ha({THREE:e,ENTITIES:t}){let n=new e.IcosahedronGeometry(t.obstacleCoreRadius,1),r=new e.ConeGeometry(t.obstacleSpikeRadius,t.obstacleSpikeHeight,t.obstacleSpikeSegments),i=new e.ConeGeometry(t.obstacleSpikeRadius*.72,t.obstacleSpikeHeight*.7,t.obstacleSpikeSegments),a=new e.ConeGeometry(t.obstacleSpikeRadius*.27,t.obstacleSpikeHeight*.22,t.obstacleSpikeSegments),o=new e.ConeGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeHeight*.27,t.obstacleSpikeSegments),s=new e.CylinderGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeRadius,t.obstacleSpikeHeight*.82,t.obstacleSpikeSegments),c=new e.CircleGeometry(t.obstacleSpikeRadius*.32,t.obstacleSpikeSegments),l=new e.MeshStandardMaterial({color:`#ff3b30`,emissive:`#8c0b06`,emissiveIntensity:1.7,metalness:.35,roughness:.28}),u=new e.MeshStandardMaterial({color:`#c88cff`,emissive:`#7a18ff`,emissiveIntensity:1.75,metalness:.2,roughness:.22}),d=new e.MeshBasicMaterial({color:`#050505`,side:e.DoubleSide}),f=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1],[0,1,2],[0,1,-2],[0,-1,2],[0,-1,-2],[1,2,0],[-1,2,0],[1,-2,0],[-1,-2,0],[2,0,1],[-2,0,1],[2,0,-1],[-2,0,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),p=[[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[1,1,1],[-1,1,1],[1,1,-1],[-1,1,-1],[1,-1,1],[-1,-1,1],[1,-1,-1],[-1,-1,-1]].map(([t,n,r])=>new e.Vector3(t,n,r).normalize()),m=new e.Vector3(0,1,0);return function(h,g=`regular`){let _=new e.Group,v=new e.Mesh(n,h);v.castShadow=!0,_.add(v);let y=[],b=[],x=g===`chaser`?f:p;for(let[n,f]of x.entries()){let p=g===`chaser`?t.obstacleSpikeHeight*.7:t.obstacleSpikeHeight,v=new e.Group;v.position.copy(f).multiplyScalar(t.obstacleCoreRadius+p*.28),v.quaternion.setFromUnitVectors(m,f);let x=v.quaternion.clone(),S=new e.Mesh(g===`chaser`?i:g===`shooter`?s:r,h);if(S.castShadow=!0,v.add(S),g===`chaser`){let t=new e.Mesh(a,l);t.position.y=p*.43,t.castShadow=!0,v.add(t)}if(g===`creeper`||g===`poisonCreeper`){let t=u.clone(),n=new e.Mesh(o,t);n.position.y=p*.47,n.castShadow=!0,v.add(n),b.push(t)}if(g===`shooter`){let t=new e.Mesh(c,d);t.rotation.x=-Math.PI/2,t.position.y=p*.41+.002,v.add(t)}y.push({root:v,baseQuaternion:x,phase:n*1.71}),_.add(v)}return _.userData.material=h,_.userData.spikes=y,_.userData.creeperTipMaterials=b,_}}function ga(e){let t=new e.Group,n=new e.MeshStandardMaterial({color:`#151021`,emissive:`#3b0d72`,emissiveIntensity:1.8,metalness:.82,roughness:.2}),r=new e.MeshStandardMaterial({color:`#372052`,emissive:`#6b1caa`,emissiveIntensity:1.3,metalness:.6,roughness:.26}),i=new e.MeshStandardMaterial({color:`#d9ff6a`,emissive:`#9dff15`,emissiveIntensity:3.8,metalness:.18,roughness:.18}),a=new e.MeshBasicMaterial({color:`#06030a`}),o=new e.Mesh(new e.SphereGeometry(.66,12,8),n);o.scale.set(1.5,.62,1.05),o.castShadow=!0,t.add(o);let s=new e.Mesh(new e.ConeGeometry(.72,.64,6),r);s.rotation.x=Math.PI/2,s.position.z=-.23,s.castShadow=!0,t.add(s);let c=new e.Mesh(new e.SphereGeometry(.26,10,7),a);c.scale.set(1.45,.72,.3),c.position.set(0,.04,.72),t.add(c);let l=new e.Mesh(new e.SphereGeometry(.14,10,8),i);l.scale.set(1.55,.7,.32),l.position.set(0,.04,.79),t.add(l);let u=[];for(let n of[-1,1]){let a=new e.Mesh(new e.ConeGeometry(.38,1.45,4),r);a.position.set(n*.93,-.04,-.08),a.rotation.set(0,n*Math.PI/2,n*.48),a.castShadow=!0,t.add(a);let o=new e.Mesh(new e.ConeGeometry(.11,.92,5),i);o.position.set(n*.5,-.16,.78),o.rotation.set(n*.42,0,n*.26),t.add(o),u.push(o)}for(let n=0;n<4;n+=1){let i=new e.Mesh(new e.ConeGeometry(.12,.58,5),r);i.position.set((n-1.5)*.3,.34,-.42),i.rotation.x=-Math.PI/2.9,t.add(i)}return t.userData.eyeMaterial=i,t.userData.mandibles=u,t}function _a({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.OctahedronGeometry(n.cellRadius),i=new e.IcosahedronGeometry(n.chronoCellRadius,1),a=new e.OctahedronGeometry(.42),o={speed:`#ffcf76`,thorn:`#ff795f`,freezer:`#7bdcff`};return{createCell(){return new e.Mesh(r,new e.MeshStandardMaterial({color:t.cell,emissive:t.cellEmissive,emissiveIntensity:n.cellEmissiveIntensity,metalness:n.cellMetalness,roughness:n.cellRoughness}))},createChronoCell(){return new e.Mesh(i,new e.MeshStandardMaterial({color:t.chronoCell,emissive:t.chronoCellEmissive,emissiveIntensity:n.chronoCellEmissiveIntensity,metalness:.12,roughness:.42,transparent:!0}))},createBooster(t){let n=o[t];return new e.Mesh(a,new e.MeshStandardMaterial({color:n,emissive:n,emissiveIntensity:1.7,metalness:.25,roughness:.2}))}}}function va({THREE:e,SCENE:t,count:n,size:r,opacity:i}){let a=new Float32Array(n*3),o=new Float32Array(n*3);for(let r=0;r<n;r+=1){let n=e.MathUtils.randFloatSpread(2),i=Math.sqrt(1-n*n),s=Math.random()*Math.PI*2,c=r*3;a[c]=Math.cos(s)*i*t.starfieldRadius,a[c+1]=n*t.starfieldRadius,a[c+2]=Math.sin(s)*i*t.starfieldRadius;let l=Math.random();o[c]=.72+l*.28,o[c+1]=.82+l*.18,o[c+2]=1}let s=new e.BufferGeometry;s.setAttribute(`position`,new e.BufferAttribute(a,3)),s.setAttribute(`color`,new e.BufferAttribute(o,3));let c=new e.Points(s,new e.PointsMaterial({size:r,sizeAttenuation:!1,transparent:!0,opacity:i,vertexColors:!0,depthWrite:!1,fog:!1}));return c.frustumCulled=!1,c}function ya(e,t){let n=[];for(let r=2;r<t;r+=2)for(let t=0;t<80;t+=1){let i=t/80*Math.PI*2,a=(t+1)/80*Math.PI*2;n.push(new e.Vector3(Math.cos(i)*r,.01,Math.sin(i)*r),new e.Vector3(Math.cos(a)*r,.01,Math.sin(a)*r))}for(let r=0;r<12;r+=1){let i=r/12*Math.PI*2;n.push(new e.Vector3,new e.Vector3(Math.cos(i)*t,.01,Math.sin(i)*t))}return new e.BufferGeometry().setFromPoints(n)}function ba(e,t){return new e.BufferGeometry().setFromPoints(Array.from({length:96},(n,r)=>{let i=r/96*Math.PI*2;return new e.Vector3(Math.cos(i)*t,.04,Math.sin(i)*t)}))}function xa({THREE:e,scene:t,COLORS:n,GAME:r,SCENE:i,LIGHTING:a,quality:o=`high`}){let s=new e.Group;function c(t){let n={low:.35,medium:.65,high:1}[t]??1;s.clear(),s.add(va({THREE:e,SCENE:i,count:Math.round(i.starCount*n),size:i.starSize,opacity:.84})),s.add(va({THREE:e,SCENE:i,count:Math.round(i.brightStarCount*n),size:i.brightStarSize,opacity:.96}))}c(o),t.add(s),t.add(new e.HemisphereLight(a.hemisphereSky,a.hemisphereGround,a.hemisphereIntensity));let l=new e.DirectionalLight(a.key,a.keyIntensity);l.position.set(-7,13,5),l.castShadow=!0,l.shadow.mapSize.set(1024,1024),t.add(l);let u=new e.Mesh(new e.CircleGeometry(r.arenaSize/2,96),new e.MeshStandardMaterial({color:n.floor,metalness:i.floorMetalness,roughness:i.floorRoughness,transparent:!0,opacity:i.floorOpacity,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.receiveShadow=!0,t.add(u);let d=new e.LineSegments(ya(e,r.arenaLimit),new e.LineBasicMaterial({color:n.gridMinor,transparent:!0,opacity:.8}));d.position.y=.01,t.add(d);let f=new e.LineLoop(ba(e,r.arenaLimit),new e.LineDashedMaterial({color:n.arenaBoundary,dashSize:.45,gapSize:.2}));return f.computeLineDistances(),t.add(f),{starfield:s,floor:u,grid:d,arenaBoundary:f,keyLight:l,setQuality:c,resize(t,n=1){let i=(r.arenaLimit+t)*n;u.geometry.dispose(),u.geometry=new e.CircleGeometry((r.arenaSize/2+t)*n,96),d.geometry.dispose(),d.geometry=ya(e,i),f.geometry.dispose(),f.geometry=ba(e,i),f.computeLineDistances()}}}function Sa({THREE:e,COLORS:t,ENTITIES:n}){let r=new e.IcosahedronGeometry(n.shooterProjectileRadius,1);return{createShooterProjectile(){return new e.Mesh(r,new e.MeshStandardMaterial({color:`#7dff9d`,emissive:`#00ff5a`,emissiveIntensity:4,metalness:.25,roughness:.16}))},createAutocannonProjectile(){return new e.Mesh(new e.SphereGeometry(.16,10,8),new e.MeshBasicMaterial({color:`#fff1a6`,transparent:!0,opacity:.95}))},createSplinter(){return new e.Mesh(new e.TetrahedronGeometry(.32),new e.MeshStandardMaterial({color:t.splinter,emissive:t.splinterEmissive,emissiveIntensity:1.3,metalness:.4,roughness:.3}))}}}function Ca({THREE:e,Quarks:t,particleRenderer:n,COLORS:r,getQuality:i=()=>`high`}){let a=()=>({low:.45,medium:.7,high:1})[i()]??1,o=e=>Math.max(1,Math.round(e*a())),s=(n,r=1)=>{let i=new e.Color(n);return new t.Vector4(i.r,i.g,i.b,r)},c=n=>{let r=new e.Color(n);return new t.Vector3(r.r,r.g,r.b)},l=(()=>{let t=document.createElement(`canvas`);t.width=128,t.height=128;let n=t.getContext(`2d`),r=n.createRadialGradient(64,64,9,64,64,64);r.addColorStop(0,`rgba(255,255,255,0.9)`),r.addColorStop(.58,`rgba(255,255,255,0.68)`),r.addColorStop(1,`rgba(255,255,255,0)`),n.fillStyle=r,n.fillRect(0,0,128,128);let i=new e.CanvasTexture(t);return i.colorSpace=e.SRGBColorSpace,i})();function u({position:r,color:i,count:a,life:l,size:u,speed:d,radius:f=0,gravity:p=0,duration:m=.05,texture:h=null,renderMode:g=t.RenderMode.BillBoard,instancingGeometry:_,sizeOverLife:v,looping:y=!1,emissionRate:b=0,force:x=null}){let S=new e.MeshBasicMaterial({color:i,map:h,transparent:!0,opacity:1,blending:e.AdditiveBlending,depthWrite:!1,depthTest:!0}),C=new t.ParticleSystem({autoDestroy:!y,looping:y,duration:m,shape:new t.SphereEmitter({radius:f,thickness:1}),startLife:new t.IntervalValue(l*.72,l),startSpeed:new t.IntervalValue(d*.65,d),startSize:new t.IntervalValue(u*.55,u),startColor:new t.ColorRange(s(i,.95),s(`#ffffff`,.7)),emissionOverTime:b?new t.ConstantValue(o(b)):void 0,emissionBursts:b?[]:[{time:0,count:new t.ConstantValue(o(a)),cycle:1,interval:.01,probability:1}],behaviors:[new t.ColorOverLife(new t.Gradient([[c(i),0],[c(i),.55],[c(i),1]],[[.95,0],[.55,.55],[0,1]])),...p?[new t.ApplyForce(new t.Vector3(0,-1,0),new t.ConstantValue(p))]:[],...x?[new t.ApplyForce(x.direction,new t.ConstantValue(x.magnitude))]:[],...v?[new t.SizeOverLife(v)]:[]],material:S,renderMode:g,..._?{instancingGeometry:_}:{},worldSpace:!0});return C.emitter.position.copy(r),n.addSystem(C),C.emitter}function d(t,n,r,i){let a=new e.PointLight(n,r,i);return a.position.copy(t),a}return{createExplosion(n,i){let a=new t.PiecewiseBezier([[new t.Bezier(.05,i,i,i),0],[new t.Bezier(i,i,i,i),.18]]);return{emitters:[u({position:n,color:r.banger,count:1,life:.65,size:1,speed:0,instancingGeometry:new e.SphereGeometry(1,16,12),renderMode:t.RenderMode.Mesh,sizeOverLife:a})],light:d(n,r.banger,10,i*2)}},createBangerPulse(t){let n=new e.Mesh(new e.RingGeometry(.22,.42,48),new e.MeshBasicMaterial({color:r.banger,transparent:!0,opacity:.9,side:e.DoubleSide,depthWrite:!1}));return n.rotation.x=-Math.PI/2,n.position.set(t.x,.06,t.z),n},createShockwave(t){let n=new e.Mesh(new e.RingGeometry(.2,.42,64),new e.MeshBasicMaterial({color:r.slowAura,transparent:!0,opacity:.95,side:e.DoubleSide,depthWrite:!1}));return n.rotation.x=-Math.PI/2,n.position.set(t.x,.07,t.z),n},createShieldBreak(e){return{emitters:[u({position:e,color:`#8cfff0`,count:38,life:.55,size:.19,speed:5.4,radius:.22})],light:d(e,`#63f5cd`,12,10)}},createPoisonTrail(e,n,i){let a=e.clone();return a.y=.045,{emitters:[u({position:a,color:r.poisonTrail,count:7,life:i,size:n*1.35,speed:0,radius:n*.56,duration:.05,texture:l,renderMode:t.RenderMode.HorizontalBillBoard})]}},createPlayerDeath(e){return{emitters:[u({position:e,color:r.playerRing,count:64,life:.9,size:.22,speed:8.8,radius:.2,gravity:5}),u({position:e,color:`#fff4cf`,count:22,life:.32,size:.4,speed:3.2,radius:.05})],light:d(e,`#fff4cf`,22,18)}},createFieryRockFire(n,i){let a=n.clone();return a.y=.08,{emitters:[u({position:a,color:r.fire,count:0,life:.7,size:i*.55,speed:.28,radius:i*.55,duration:1,looping:!0,emissionRate:14,force:{direction:new t.Vector3(0,1,0),magnitude:1.25}}),u({position:a,color:`#ffe19a`,count:0,life:1.15,size:.075,speed:.62,radius:i*.48,duration:1,looping:!0,emissionRate:7,force:{direction:new t.Vector3(0,1,0),magnitude:.72}})],light:d(new e.Vector3(n.x,1.2,n.z),r.fire,5.5,i*3)}},createFallingRockImpact(n,r,i){let a=n.clone();return a.y=.08,{emitters:[u({position:a,color:`#d9c7a0`,count:26,life:.62,size:r*.42,speed:r*2.8,radius:r*.24,force:{direction:new t.Vector3(0,1,0),magnitude:.28}}),u({position:a,color:i,count:18,life:.48,size:r*.13,speed:r*5,radius:r*.12,gravity:7,instancingGeometry:new e.TetrahedronGeometry(1,0),renderMode:t.RenderMode.Mesh})]}}}}var wa=Object.freeze({cellBank:`asteroid-belt-banked-cells`,sector:`asteroid-belt-selected-sector`,sectorHighScores:`asteroid-belt-sector-high-scores`,cash:`asteroid-belt-cash`,chronoshards:`asteroid-belt-chronoshards`,aetherium:`asteroid-belt-aetherium`,aetheriumAdClaimAt:`asteroid-belt-aetherium-ad-claim-at`,researchLab:`asteroid-belt-research-lab`,savedRound:`asteroid-belt-saved-round`,buildings:`asteroid-belt-buildings`,featureUnlocks:`asteroid-belt-feature-unlocks`,milestones:`asteroid-belt-milestones`,settings:`asteroid-belt-settings`,weaponry:`asteroid-belt-weaponry`,anomalyRewards:`asteroid-belt-anomaly-rewards`,artifacts:`asteroid-belt-artifacts`,dailyMissions:`asteroid-belt-daily-missions`}),Ta=[`t`,`i`,`e`,`r`].join(``),Ea=`asteroid-belt-selected-${Ta}`,Da=`asteroid-belt-${Ta}-high-scores`,Oa=[[`astroid-belt-banked-cells`,wa.cellBank],[Ea,wa.sector],[Da,wa.sectorHighScores],[`astroid-belt-selected-${Ta}`,wa.sector],[`astroid-belt-${Ta}-high-scores`,wa.sectorHighScores],[`astroid-belt-cash`,wa.cash],[`astroid-belt-chronoshards`,wa.chronoshards],[`astroid-belt-research-lab`,wa.researchLab],[`astroid-belt-saved-round`,wa.savedRound],[`astroid-belt-buildings`,wa.buildings],[`astroid-belt-feature-unlocks`,wa.featureUnlocks]];function ka(e=window.localStorage){for(let[t,n]of Oa)try{e.getItem(n)===null&&e.getItem(t)!==null&&e.setItem(n,e.getItem(t))}catch{}try{let t=`${Ta}-`,n=JSON.parse(e.getItem(wa.sectorHighScores)??`null`);if(n&&typeof n==`object`){let t=Object.fromEntries(Object.entries(n).map(([e,t])=>[e.startsWith(Ta)?`sector${e.slice(Ta.length)}`:e,t]));e.setItem(wa.sectorHighScores,JSON.stringify(t))}let r=JSON.parse(e.getItem(wa.milestones)??`null`);r&&Array.isArray(r.claimed)&&(r.claimed=r.claimed.map(e=>typeof e==`string`&&e.startsWith(t)?`sector-${e.slice(t.length)}`:e),e.setItem(wa.milestones,JSON.stringify(r)));let i=JSON.parse(e.getItem(wa.savedRound)??`null`),a=`${Ta}Index`;i&&typeof i==`object`&&Number.isFinite(i[a])&&!Number.isFinite(i.sectorIndex)&&(i.sectorIndex=i[a],e.setItem(wa.savedRound,JSON.stringify(i)));let o=JSON.parse(e.getItem(wa.anomalyRewards)??`null`),s=`claimed${Ta[0].toUpperCase()}${Ta.slice(1)}s`;o?.[s]&&!o.claimedSectors&&(o.claimedSectors=o[s],e.setItem(wa.anomalyRewards,JSON.stringify(o)))}catch{}}function Aa(e,t=0,n=window.localStorage){try{let r=Number(n.getItem(e));return Number.isFinite(r)&&r>=0?r:t}catch{return t}}function ja(e,t,n=window.localStorage){try{n.setItem(e,String(t))}catch{}}function Ma(e,t=null,n=window.localStorage){try{return JSON.parse(n.getItem(e))??t}catch{return t}}function Na(e,t,n=window.localStorage){try{t==null?n.removeItem(e):n.setItem(e,JSON.stringify(t))}catch{}}function Pa({THREE:e,SOUND:t,getSettings:n,getPlayer:r,getCamera:i}){let a,o,s=new Map,c;async function l(e,t){try{let n=await fetch(t);if(!n.ok)return;s.set(e,await a.decodeAudioData(await n.arrayBuffer()))}catch{}}function u(){if(!a){let e=window.AudioContext||window.webkitAudioContext;if(!e)return Promise.resolve();a=new e,o=a.createGain(),d(!0),o.connect(a.destination),c=Promise.all(Object.entries(t.assets).map(([e,t])=>l(e,t)))}let e=a.state===`suspended`?a.resume():Promise.resolve();return Promise.all([e,c])}function d(e=!1){if(!o||!a)return;let r=n(),i=t.masterVolume*(r.sound.muted?0:r.sound.masterVolume/100);e?o.gain.value=i:o.gain.setTargetAtTime(i,a.currentTime,.03)}function f(n){let a=n.clone().sub(r().position);a.y=0;let o=a.length(),s=e.MathUtils.lerp(t.spatialMinGain,1,(1-e.MathUtils.clamp(o/t.spatialMaxDistance,0,1))**2);if(o===0)return{attenuation:s,pan:0};let c=new e.Vector3(1,0,0).applyQuaternion(i().quaternion);return c.y=0,c.normalize(),{attenuation:s,pan:e.MathUtils.clamp(a.normalize().dot(c),-1,1)}}function p(e,t,r){let i=a.createGain(),s=a.createGain(),c=a.createStereoPanner?.(),l=a.currentTime,{attenuation:u,pan:d}=n().sound.spatialAudio?f(r):{attenuation:1,pan:0};i.gain.setValueAtTime(t,l),s.gain.setValueAtTime(u,l),e.connect(i),i.connect(s),c?(c.pan.setValueAtTime(d,l),s.connect(c),c.connect(o)):s.connect(o)}function m(e,t,n,r,i,o){if(!a||a.state!==`running`)return;let s=a.createOscillator(),c=a.currentTime;s.type=o,s.frequency.setValueAtTime(e,c),s.frequency.linearRampToValueAtTime(t,c+n),p(s,r,i),s.start(c),s.stop(c+n)}function h(e,t,n){if(!a||a.state!==`running`)return;let r=a.currentTime,i=a.createBuffer(1,Math.ceil(a.sampleRate*e),a.sampleRate),o=i.getChannelData(0);for(let e=0;e<o.length;e+=1)o[e]=Math.random()*2-1;let s=a.createBufferSource(),c=a.createBiquadFilter(),l=a.createGain();s.buffer=i,c.type=`bandpass`,c.Q.value=.65,c.frequency.setValueAtTime(180,r),c.frequency.exponentialRampToValueAtTime(720,r+e),l.gain.setValueAtTime(1e-4,r),l.gain.exponentialRampToValueAtTime(1,r+.18),l.gain.exponentialRampToValueAtTime(1e-4,r+e),s.connect(c),c.connect(l),p(l,t,n),s.start(r)}function g(e,t){if(!a||a.state!==`running`)return;let n=a.currentTime,r=a.createBuffer(1,Math.ceil(a.sampleRate*.24),a.sampleRate),i=r.getChannelData(0);for(let e=0;e<i.length;e+=1)i[e]=(Math.random()*2-1)*(1-e/i.length);let o=a.createBufferSource(),s=a.createBiquadFilter(),c=a.createGain();o.buffer=r,s.type=`lowpass`,s.Q.value=1.2,s.frequency.setValueAtTime(1500,n),s.frequency.exponentialRampToValueAtTime(110,n+.24),c.gain.setValueAtTime(1e-4,n),c.gain.exponentialRampToValueAtTime(1,n+.012),c.gain.exponentialRampToValueAtTime(1e-4,n+.24),o.connect(s),s.connect(c),p(c,e,t),o.start(n)}function _(e,t,n,r){if(!a||a.state!==`running`)return;let i=s.get(e);if(!i){r();return}let o=a.createBufferSource();o.buffer=i,p(o,t,n),o.start()}return{initialize:u,setMasterVolume:d,playBangerPulse(n,r){let i=t.fallback.bangerPulse,a=e.MathUtils.lerp(i.startFrequency,i.endFrequency,n);_(`bangerPulse`,t.bangerPulseVolume,r,()=>m(a,a,i.duration,t.bangerPulseVolume,r,i.type))},playFallingObstacle(e){let n=t.fallback.fallingObstacle;_(`fallingObstacle`,t.fallingObstacleVolume,e,()=>h(n.duration,t.fallingObstacleVolume,e))},playCellCollect(e){let n=t.fallback.cellCollect;_(`cellCollect`,t.cellCollectVolume,e,()=>m(n.startFrequency,n.endFrequency,n.duration,t.cellCollectVolume,e,n.type))},playBoosterPickup(e,t){let[n,r]={speed:[480,900],thorn:[220,620],freezer:[720,260]}[t];m(n,r,.22,.3,e,t===`freezer`?`sine`:`triangle`)},playShieldBreak(e){g(.52,e),m(180,58,.2,.24,e,`sawtooth`)},playBuildingEffect(e,t){let[n,r]={chronoGenerator:[280,360],autocannon:[220,90],droneBay:[520,760],barrierNode:[260,440],overclockRelay:[440,600],salvageExtractor:[180,300]}[t];m(n,r,.12,.16,e,`sine`)},playObstacleSummon(e){let n=t.fallback.obstacleSummon;_(`obstacleSummon`,t.obstacleSummonVolume,e,()=>m(n.startFrequency,n.endFrequency,n.duration,t.obstacleSummonVolume,e,n.type))},playButtonClick(){let e=t.fallback.buttonClick,n=r().position;_(`buttonClick`,t.buttonClickVolume,n,()=>m(e.startFrequency,e.endFrequency,e.duration,t.buttonClickVolume,n,e.type))}}}var Fa=[[1e3,`M`],[900,`CM`],[500,`D`],[400,`CD`],[100,`C`],[90,`XC`],[50,`L`],[40,`XL`],[10,`X`],[9,`IX`],[5,`V`],[4,`IV`],[1,`I`]];function Ia(e){let t=Math.max(1,Math.floor(Number(e)||1)),n=``;for(let[e,r]of Fa)for(;t>=e;)n+=r,t-=e;return n}function La({config:e,milestones:t,getResearchState:n,getMilestoneState:r,getBankedCells:i}){let a=t=>e.researches.find(e=>e.id===t),o=e=>n().levels[e]??0,s=e=>t.find(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)));function c(e){let n=r();return n.researchUnlocks.includes(e)||t.some(t=>n.claimed.includes(t.id)&&t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))}function l(t){return e.researches.filter(e=>e.effect?.stat===t).reduce((e,t)=>e+o(t.id)*t.effect.perLevel,0)}function u(e,t){let n=e.cost.jerk??1,r=e.cost.base*e.cost.multiplier**t*n**(t*(t-1)/2);return e.cost.currency===`cash`?Math.round(r*100)/100:Math.ceil(r)}function d(e){let t=e.requirements??{},n=s(e.id);if(n&&!r().debugAscensionsGranted&&!c(e.id))return N(`research.requires_sector_cells`,{cells:n.cells,sector:Ia(n.sector)});if(t.minBankedCells&&i()<t.minBankedCells)return N(`research.requires_banked_cells`,{cells:t.minBankedCells});if(t.researchId&&o(t.researchId)<1)return N(`research.requires_research`,{research:a(t.researchId).name});for(let[e,n]of Object.entries(t.researchLevels??{}))if(o(e)<n)return N(`research.requires_research_level`,{research:a(e).name,level:n});return``}function f(e,t=new Set){let n=s(e.id)?.sector??0;if(t.has(e.id))return{sector:n,depth:0};let r=e.requirements??{},i=[...r.researchId?[r.researchId]:[],...Object.keys(r.researchLevels??{})].map(a).filter(Boolean).map(n=>f(n,new Set(t).add(e.id)));return{sector:Math.max(n,...i.map(e=>e.sector)),depth:i.length?Math.max(...i.map(e=>e.depth))+1:0}}function p(e,t){let n=f(e),r=f(t);return n.sector-r.sector||n.depth-r.depth||e.name.localeCompare(t.name)}return{getResearchById:a,getResearchLevel:o,getResearchStatBonus:l,getResearchCost:u,getResearchDuration:(e,t)=>Math.round(e.duration.baseMs*e.duration.multiplier**t),getResearchLockReason:d,isResearchVisible:e=>!e.visibleWhen?.anyResearch||e.visibleWhen.anyResearch.some(e=>o(e)>0),compareResearchProgression:p}}var Ra=[{id:`regular`,category:`Enemies`,name:`Regular`,model:`spiked-enemy`,firstSector:1,description:`A stationary asteroid enemy. Keep clear of its body while collecting Cells.`},{id:`chaser`,category:`Enemies`,name:`Chaser`,model:`spiked-enemy`,firstSector:2,description:`Detects the ship within its range and pursues it.`},{id:`creeper`,category:`Enemies`,name:`Creeper`,model:`spiked-enemy`,firstSector:1,description:`Slowly closes in from any distance and becomes faster as it survives.`},{id:`poisonCreeper`,category:`Enemies`,name:`Poison Creeper`,model:`spiked-enemy`,firstSector:9,description:`A Creeper variant that shifts between purple and dark green while leaving poisonous trails behind.`},{id:`banger`,category:`Enemies`,name:`Banger`,model:`spiked-enemy`,firstSector:3,description:`Arms itself, pulses a warning, then detonates over a wide area.`},{id:`shooter`,category:`Enemies`,name:`Shooter`,model:`spiked-enemy`,firstSector:3,description:`Fires projectiles at the ship when it enters firing range.`},{id:`porter`,category:`Enemies`,name:`Porter`,model:`spiked-enemy`,firstSector:5,description:`Occasionally teleports itself to random locations.`},{id:`magnet`,category:`Enemies`,name:`Magnet`,model:`spiked-enemy`,firstSector:6,description:`Pulls the ship toward itself while it is within range.`},{id:`spore`,category:`Enemies`,name:`Spore`,model:`spiked-enemy`,firstSector:7,description:`Bursts into small pieces of itself, then burst into even smaller pieces again.`},{id:`voidReaper`,category:`Ultimate Enemy`,categoryKey:`ultimate_enemy`,name:`Void Reaper`,model:`ultimate-enemy`,firstSector:1/0,description:`A horrifying alien raider that marks a lethal path before tearing across the arena.`},{id:`stoneRock`,category:`Meteors`,name:`Stone Rock`,model:`falling-rock`,firstSector:1,description:`A standard falling meteor. Avoid its marked impact point.`},{id:`fieryRock`,category:`Meteors`,name:`Fiery Rock`,model:`falling-rock`,firstSector:3,description:`A burning meteor that leaves a damaging fire hazard after impact.`},{id:`splinter`,category:`Meteors`,name:`Splinter`,model:`falling-rock`,firstSector:2,description:`Shatters on impact and sends fragments outward.`}].map(e=>({...e,category:N(`encyclopedia.category.${e.categoryKey??e.category.toLowerCase()}`,{},e.category),name:N(`enemy.${e.id}.name`,{},e.name),description:N(`enemy.${e.id}.description`,{},e.description)})),za=[{heading:N(`patch_notes.artifacts`),changes:[N(`patch_notes.artifacts_1`),N(`patch_notes.artifacts_2`),N(`patch_notes.artifacts_3`)]},{heading:N(`patch_notes.improvements`),changes:[N(`patch_notes.improvements_1`),N(`patch_notes.improvements_2`)]}];function Ba(e,t){if(!e.effect)return t>0?`UNLOCKED`:`LOCKED`;let n=t*e.effect.perLevel;return e.effect.format===`percent`?`+${(n*100).toFixed(n*100%1?1:0)}%`:String(n)}function Va(e){let t=Math.max(0,Math.ceil(e/1e3)),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60;return n>0?`${n}h ${r}m`:r>0?`${r}m ${i}s`:`${i}s`}function P(e){let t=Math.abs(e),n=t>=0xe8d4a51000?[`T`,0xe8d4a51000]:t>=1e9?[`B`,1e9]:t>=1e6?[`M`,1e6]:t>=1e3?[`K`,1e3]:null;if(!n)return e.toLocaleString(void 0,{maximumFractionDigits:2});let r=e/n[1];return`${r.toFixed(Math.abs(r)<10?2:1)}${n[0]}`}function Ha(e,t){return e===`cash`?`$${P(t)}`:`✦ ${P(t)}`}var Ua=Array.from({length:16},(e,t)=>N(`tip.${t+1}`)),Wa=[10,25,50,100,250,500],F=(e,t,n)=>({id:`sector-${e}-${Wa[t]}`,sector:e,cells:Wa[t],rewards:n}),I=e=>({type:`cash`,amount:e}),L=e=>({type:`chronoshards`,amount:e}),R=(...e)=>({type:`research`,researchIds:e}),Ga=e=>({type:`feature`,featureId:e}),Ka=e=>({type:`sector`,sector:e}),qa=[F(1,0,[I(25),Ga(`researchLab`),R(`player-speed-multiplier`)]),F(1,1,[I(50),R(`cash-cell-multiplier`),Ka(2)]),F(1,2,[I(75),L(1)]),F(1,3,[I(100)]),F(1,4,[I(150)]),F(1,5,[I(250),L(3)]),F(2,0,[I(150),R(`cell-magnet`)]),F(2,1,[I(250),R(`unlock-speed-booster`),R(`unlock-shockwave`)]),F(2,2,[I(400),L(3),R(`speed-booster-duration`),Ka(3)]),F(2,3,[I(650)]),F(2,4,[I(900),L(6),R(`shockwave-frequency`)]),F(2,5,[I(1250),L(10)]),F(3,0,[I(500),R(`unlock-slow-aura`,`unlock-orbital-electron`,`weapon-slots`)]),F(3,1,[I(750),L(5),R(`slow-aura-effect`,`electron-speed`)]),F(3,2,[I(1e3),R(`cell-increment-per-cell`),Ka(4)]),F(3,3,[I(1500),L(10),R(`electron-stun-duration`)]),F(3,4,[I(2e3),R(`slow-aura-range`)]),F(3,5,[I(3e3),L(15)]),F(4,0,[I(1e3),R(`chrono-lifetime-multiplier`)]),F(4,1,[I(1500),L(10),R(`building-slots`)]),F(4,2,[I(2e3),R(`shield`)]),F(4,3,[I(3e3),L(15),R(`thorn-shield`),Ka(5)]),F(4,4,[I(4500),R(`thorn-shield-duration`,`pushback`)]),F(4,5,[I(6e3),L(25),R(`shield-invulnerability-duration`,`shield-break-explosion`)]),F(5,0,[I(2e3),R(`freezer`,`weapon-recharge`,`lucky-find`)]),F(5,1,[I(3e3),L(15),R(`freezer-duration`,`weapon-recharge-rate`)]),F(5,2,[I(4e3),R(`regular-lifetime-debuff`,`weapon-charge-capacity`)]),F(5,3,[I(6e3),L(20),R(`chaser-range-debuff`),Ka(6)]),F(5,4,[I(8e3),R(`creeper-speed-debuff`)]),F(5,5,[I(1e4),L(30)]),F(6,0,[I(4e3),R(`banger-range-debuff`)]),F(6,1,[I(6e3),L(20),R(`banger-enemy-destruction`)]),F(6,2,[I(8e3),R(`shooter-range-debuff`)]),F(6,3,[I(12e3),L(30),R(`shooter-projectile-debuff`),Ka(7)]),F(6,4,[I(16e3),L(40)]),F(6,5,[I(2e4),L(50)]),F(7,0,[I(8e3),R(`porter-interval-debuff`)]),F(7,1,[I(12e3),L(30),R(`magnet-strength-debuff`)]),F(7,2,[I(16e3),R(`spore-speed-debuff`)]),F(7,3,[I(24e3),L(45),Ka(8)]),F(7,4,[I(32e3),L(60)]),F(7,5,[I(4e4),L(80)]),F(8,0,[I(16e3),L(25)]),F(8,1,[I(24e3),L(40)]),F(8,2,[I(32e3),L(60)]),F(8,3,[I(48e3),L(80),Ka(9)]),F(8,4,[I(64e3),L(120)]),F(8,5,[I(1e5),L(200)]),F(9,0,[I(32e3),R(`poison-creep-clean`)]),F(9,1,[I(48e3),L(50)]),F(9,2,[I(64e3),L(75)]),F(9,3,[I(96e3),L(100)]),F(9,4,[I(128e3),L(150)]),F(9,5,[I(2e5),L(250)])],Ja={purchaseCost:15,levelCopyRequirements:[3,5,10,25],weapons:{nuke:{name:`Nuke`,key:`1`,color:`#ff795f`,description:`Destroys a percentage of enemies in the arena.`,baseEffect:.3,effectPerLevel:.1},megaMagnet:{name:`Mega Magnet`,key:`2`,color:`#63f5cd`,description:`Pulls every Cell rapidly toward your ship.`,baseEffect:2.5,effectPerLevel:.8,duration:!0},atmosphereShield:{name:`Atmosphere Shield`,key:`3`,color:`#b59aff`,description:`Destroys and blocks falling meteors for a short time.`,baseEffect:4,effectPerLevel:1.2,duration:!0},phaseDash:{name:`Phase Dash`,key:`4`,color:`#78eaff`,description:`Dash through enemies and erase every enemy in your path.`,baseEffect:6.5,effectPerLevel:1.1},chronoFreeze:{name:`Chrono Freeze`,key:`5`,color:`#74bfff`,description:`Freezes every enemy and their lifetime for a short time.`,baseEffect:2.5,effectPerLevel:.65,duration:!0},plasmaOrbital:{name:`Plasma Orbital`,key:`6`,color:`#ff8cff`,description:`Deploys plasma orbitals that destroy enemies on contact.`,baseEffect:4,effectPerLevel:.8,duration:!0},cellOverdrive:{name:`Cell Overdrive`,key:`7`,color:`#ffd36f`,description:`Doubles Cells collected for a short time.`,baseEffect:4,effectPerLevel:.8,duration:!0},demonMode:{name:`Demon Mode`,key:`8`,color:`#ff465d`,description:`Move faster and destroy enemies you pass through.`,baseEffect:4,effectPerLevel:.8,duration:!0}}},Ya={...Ja,weapons:Object.fromEntries(Object.entries(Ja.weapons).map(([e,t])=>[e,{...t,name:N(`weapon.${e}.name`,{},t.name),description:N(`weapon.${e}.description`,{},t.description)}]))},Xa={artifacts:[{id:`broken-radar`,name:`Broken Radar`,icon:`broken-radar.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-2-500`,sector:2,cells:500},buff:{stat:`cellSpawnRate`,amount:.1,label:`+10% Cell spawn rate`}},{id:`ftl-schematics`,name:`FTL Schematics`,icon:`ftl-schematics.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-3-500`,sector:3,cells:500},buff:{stat:`playerSpeedMultiplier`,amount:.1,label:`+10% player movement speed`}},{id:`supply-depot`,name:`Supply Depot`,icon:`supply-depot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-4-500`,sector:4,cells:500},buff:{stat:`initialCellCount`,amount:5,label:`+5 initial Cells`}},{id:`broken-extractor`,name:`Broken Extractor`,icon:`broken-extractor.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-5-500`,sector:5,cells:500},buff:{stat:`cashMultiplier`,amount:.1,label:`+10% cash earned from Cells`}},{id:`construction-bot`,name:`Construction Bot`,icon:`construction-bot.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-6-500`,sector:6,cells:500},buff:{stat:`buildingCostReduction`,amount:.1,label:`-10% Building prices`}},{id:`alientech-gizmo`,name:`Alientech Gizmo`,icon:`alientech-gizmo.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-7-500`,sector:7,cells:500},buff:{stat:`researchCostReduction`,amount:.2,label:`-20% Research cost`}},{id:`broken-hard-drive`,name:`Broken Hard-Drive`,icon:`broken-hard-drive.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-8-500`,sector:8,cells:500},buff:{stat:`weaponSlotCount`,amount:1,label:`+1 Weapon Slot`}},{id:`hubble-telescope`,name:`Hubble Telescope`,icon:`hubble-telescope.svg`,requirement:{type:`milestone-claimed`,milestoneId:`sector-9-500`,sector:9,cells:500},buff:{stat:`effectRange`,amount:.2,label:`+20% player effect range`}},{id:`dark-core`,name:`Dark Core`,icon:`dark-core.svg`,repeatable:!0,requirement:{type:`anomaly-run-success`,cells:250},buff:{stat:`chronoshardGainMultiplier`,amount:.01,label:`+1% Chronoshards earned`}},{id:`map-to-earth`,name:`Map To Earth`,icon:`map-to-earth.svg`,requirement:{type:`hidden-world-map`,minSector:6,chance:.01},buff:{stat:`arenaSizeMultiplier`,amount:.2,label:`+20% arena size in every Sector`}}]},Za={...Xa,artifacts:Xa.artifacts.map(e=>({...e,name:N(`artifact.${e.id}.name`,{},e.name),buff:{...e.buff,label:N(`artifact.${e.id}.buff`,{},e.buff.label)}}))},Qa=Object.freeze({"broken-radar":`ARTIFACT_BROKEN_RADAR`,"ftl-schematics":`ARTIFACT_FTL_SCHEMATICS`,"supply-depot":`ARTIFACT_SUPPLY_DEPOT`,"broken-extractor":`ARTIFACT_BROKEN_EXTRACTOR`,"construction-bot":`ARTIFACT_CONSTRUCTION_BOT`,"alientech-gizmo":`ARTIFACT_ALIENTECH_GIZMO`,"broken-hard-drive":`ARTIFACT_BROKEN_HARD_DRIVE`,"hubble-telescope":`ARTIFACT_HUBBLE_TELESCOPE`,"dark-core":`ARTIFACT_DARK_CORE`,"map-to-earth":`ARTIFACT_MAP_TO_EARTH`});function $a(e){let t=Qa[e];!t||!window.steamShell?.unlockAchievement||window.steamShell.unlockAchievement(t).catch(e=>console.warn(`[Steamworks] achievement unlock failed:`,e))}async function eo(){if(!window.steamShell?.getAchievementStates)return{};try{return await window.steamShell.getAchievementStates(Object.values(Qa))}catch(e){return console.warn(`[Steamworks] achievement sync failed:`,e),{}}}var z=e=>`./assets/${e}`,to={chronoGenerator:z(`buildings/chrono-generator.svg`),autocannon:z(`buildings/autocannon.svg`),droneBay:z(`buildings/drone-bay.svg`),barrierNode:z(`buildings/barrier-node.svg`),overclockRelay:z(`buildings/overclock-relay.svg`),salvageExtractor:z(`buildings/salvage-extractor.svg`)},no={nuke:z(`weapons/nuke.svg`),megaMagnet:z(`weapons/mega-magnet.svg`),atmosphereShield:z(`weapons/atmosphere-shield.svg`),phaseDash:z(`weapons/phase-dash.svg`),chronoFreeze:z(`weapons/chrono-freeze.svg`),plasmaOrbital:z(`weapons/plasma-orbital.svg`),cellOverdrive:z(`weapons/cell-overdrive.svg`),demonMode:z(`weapons/demon-mode.svg`)},ro={researchLab:z(`ui/research-lab.svg`),buildingSystem:z(`ui/building-system.svg`),weaponry:z(`ui/weaponry.svg`),home:z(`ui/home.svg`),encyclopedia:z(`ui/encyclopedia.svg`),settings:z(`ui/settings.svg`),artifacts:z(`ui/artifacts.svg`),shield:z(`ui/shield-charge.svg`),pause:z(`ui/pause.svg`),aetherium:z(`ui/aetherium.svg`),adReward:z(`ui/ad-reward.svg`),market:z(`ui/market.svg`),chronoshards:z(`ui/chronoshards.svg`),marketSpecial:z(`ui/market-special.svg`),dailyMissions:z(`ui/daily-missions.svg`),missionChest:z(`ui/mission-chest.svg`),missionCell:z(`ui/mission-cell.svg`),missionClock:z(`ui/mission-clock.svg`)};function io(e){return z(`artifacts/${e}`)}function ao(e){return to[e]??``}function oo(e){return no[e]??``}function so(e){return ro[e]??``}var co={fire:{label:N(`status.fire`,{},`Burning`),duration:1.5,color:`#ff4f3e`,immunityResearchId:`fire-immunity`,requiresExposure:!0,refreshOnReapply:!1},poison:{label:N(`status.poison`,{},`Poisoned`),duration:3,color:`#91e85a`,immunityResearchId:`poison-immunity`,requiresExposure:!0,refreshOnReapply:!0}},lo;(function(e){e.General=`General`,e.ParentalGuidance=`ParentalGuidance`,e.Teen=`Teen`,e.MatureAudience=`MatureAudience`})(lo||={});var uo;(function(e){e.SizeChanged=`bannerAdSizeChanged`,e.Loaded=`bannerAdLoaded`,e.FailedToLoad=`bannerAdFailedToLoad`,e.Opened=`bannerAdOpened`,e.Closed=`bannerAdClosed`,e.AdImpression=`bannerAdImpression`,e.AdPaid=`bannerAdPaid`})(uo||={});var fo;(function(e){e.TOP_CENTER=`TOP_CENTER`,e.CENTER=`CENTER`,e.BOTTOM_CENTER=`BOTTOM_CENTER`})(fo||={});var po;(function(e){e.BANNER=`BANNER`,e.FULL_BANNER=`FULL_BANNER`,e.LARGE_BANNER=`LARGE_BANNER`,e.MEDIUM_RECTANGLE=`MEDIUM_RECTANGLE`,e.LEADERBOARD=`LEADERBOARD`,e.ADAPTIVE_BANNER=`ADAPTIVE_BANNER`,e.SMART_BANNER=`SMART_BANNER`})(po||={});var mo;(function(e){e.Loaded=`interstitialAdLoaded`,e.FailedToLoad=`interstitialAdFailedToLoad`,e.Showed=`interstitialAdShowed`,e.FailedToShow=`interstitialAdFailedToShow`,e.Dismissed=`interstitialAdDismissed`,e.AdImpression=`interstitialAdImpression`})(mo||={});var ho;(function(e){e.Loaded=`onRewardedInterstitialAdLoaded`,e.FailedToLoad=`onRewardedInterstitialAdFailedToLoad`,e.Showed=`onRewardedInterstitialAdShowed`,e.FailedToShow=`onRewardedInterstitialAdFailedToShow`,e.Dismissed=`onRewardedInterstitialAdDismissed`,e.Rewarded=`onRewardedInterstitialAdReward`,e.AdImpression=`onRewardedInterstitialAdImpression`})(ho||={});var go;(function(e){e.Loaded=`onRewardedVideoAdLoaded`,e.FailedToLoad=`onRewardedVideoAdFailedToLoad`,e.Showed=`onRewardedVideoAdShowed`,e.FailedToShow=`onRewardedVideoAdFailedToShow`,e.Dismissed=`onRewardedVideoAdDismissed`,e.Rewarded=`onRewardedVideoAdReward`,e.AdImpression=`onRewardedVideoAdImpression`})(go||={});var _o;(function(e){e.NOT_REQUIRED=`NOT_REQUIRED`,e.OBTAINED=`OBTAINED`,e.REQUIRED=`REQUIRED`,e.UNKNOWN=`UNKNOWN`})(_o||={});var vo;(function(e){e[e.DISABLED=0]=`DISABLED`,e[e.EEA=1]=`EEA`,e[e.NOT_EEA=2]=`NOT_EEA`,e[e.US=3]=`US`,e[e.OTHER=4]=`OTHER`})(vo||={});var yo;(function(e){e[e.Unknown=0]=`Unknown`,e[e.Estimated=1]=`Estimated`,e[e.PublisherProvided=2]=`PublisherProvided`,e[e.Precise=3]=`Precise`})(yo||={});var bo;(function(e){e.Loaded=`appOpenAdLoaded`,e.FailedToLoad=`appOpenAdFailedToLoad`,e.Opened=`appOpenAdOpened`,e.Closed=`appOpenAdClosed`,e.FailedToShow=`appOpenAdFailedToShow`,e.AdImpression=`appOpenAdImpression`})(bo||={});var xo=`modulepreload`,So=function(e,t){return new URL(e,t).href},Co={},wo=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=So(t,n),t=s(t),t in Co)return;Co[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:xo,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},To=xi(`AdMob`,{web:()=>wo(()=>import(`./web-CSegNT8b.js`).then(e=>new e.AdMobWeb),[],import.meta.url)}),Eo=class extends Error{constructor(e,t=e){super(t),this.name=`MarketError`,this.code=e}};function B(e,t){if(!e)throw new Eo(t)}function Do(e){return Number.isSafeInteger(e)&&e>0}function Oo({products:e,categories:t,repository:n,rewardHandlers:r,paymentProviders:i={},onCommit:a=()=>{}}){let o=structuredClone(e),s=structuredClone(t),c=e=>e.every(e=>typeof e.id==`string`&&e.id.length>0)&&new Set(e.map(e=>e.id)).size===e.length;B(c(s)&&c(o),`INVALID_CATALOG`);for(let e of o){B(s.some(t=>t.id===e.categoryId),`INVALID_CATEGORY`),B(Do(e.maxQuantity)&&(!e.purchaseLimit||Do(e.purchaseLimit)),`INVALID_LIMIT`),B(e.payments?.length&&c(e.payments)&&e.rewards?.length,`INVALID_PRODUCT`);for(let t of e.rewards)B(Do(t.amount)&&r[t.type],`INVALID_REWARD`);for(let t of e.payments)B(typeof t.provider==`string`,`INVALID_PAYMENT`),t.provider===`wallet`&&B(typeof t.currency==`string`&&Number.isFinite(t.amount)&&t.amount>0,`INVALID_PRICE`)}let l=Promise.resolve(),u=new Set,d=e=>{for(let t of u)try{t(structuredClone(e))}catch{}},f=e=>{let t=l.then(()=>globalThis.window?.navigator?.locks?navigator.locks.request(n.lockName??`asteroid-market`,e):e());return l=t.catch(()=>{}),t},p=(e,t=!1)=>{let n=o.find(t=>t.id===e);return B(n&&(t||n.enabled===!0),`PRODUCT_UNAVAILABLE`),n},m=(e,t,n)=>{B(Do(t)&&t<=e.maxQuantity,`INVALID_QUANTITY`),B(!e.purchaseLimit||(n.purchases[e.id]??0)+t<=e.purchaseLimit,`PURCHASE_LIMIT`);let i=structuredClone(n);for(let n of e.rewards)r[n.type].validate?.(i,n,t),r[n.type].apply(i,n,t)},h=(e,t,n)=>{for(let i of t.rewards)r[i.type].apply(e,i,n);e.purchases[t.id]=(e.purchases[t.id]??0)+n},g=e=>{try{a(n.read())}catch{d({type:`refresh-failed`})}d({type:`fulfilled`,...e})};return Object.freeze({listCategories:()=>structuredClone(s).sort((e,t)=>(e.order??0)-(t.order??0)),listProducts:({categoryId:e,includeDisabled:t=!1}={})=>structuredClone(o.filter(n=>(t||n.enabled===!0)&&(!e||n.categoryId===e))),getState:()=>n.read(),subscribe(e){return u.add(e),()=>u.delete(e)},registerPaymentProvider(e,t){B(e!==`wallet`&&t?.purchase,`INVALID_PROVIDER`),i[e]=t},registerRewardHandler(e,t){B(t?.apply,`INVALID_HANDLER`),r[e]=t},quote(e,{paymentId:t,quantity:r=1}={}){let i=p(e),a=i.payments.find(e=>e.id===t)??(t?null:i.payments[0]);return B(a,`PAYMENT_UNAVAILABLE`),m(i,r,n.read()),structuredClone({productId:e,quantity:r,payment:a,total:a.provider===`wallet`?Math.round(a.amount*r*100)/100:null,rewards:i.rewards.map(e=>({...e,amount:e.amount*r}))})},purchase(e,t={}){return f(async()=>{if(t.requestId&&n.read().transactions[`wallet:${t.requestId}`]){let r=n.read().transactions[`wallet:${t.requestId}`],i=p(e,!0),a=t.paymentId??i.payments[0].id;return B(r.fingerprint===JSON.stringify([e,a,t.quantity??1]),`IDEMPOTENCY_CONFLICT`),structuredClone(r)}let r=this.quote(e,t),a=p(e);if(r.payment.provider!==`wallet`){let e=i[r.payment.provider];return B(e,`PROVIDER_NOT_CONFIGURED`),e.purchase(r)}let o=n.read(),s=t.requestId??globalThis.crypto.randomUUID();B(typeof s==`string`&&s.length>0&&s.length<=200,`INVALID_REQUEST_ID`);let c=`wallet:${s}`,l=JSON.stringify([e,r.payment.id,r.quantity]);if(o.transactions[c])return B(o.transactions[c].fingerprint===l,`IDEMPOTENCY_CONFLICT`),structuredClone(o.transactions[c]);m(a,r.quantity,o);let u=o.balances[r.payment.currency];B(Number.isFinite(u)&&u>=r.total,`INSUFFICIENT_FUNDS`),o.balances[r.payment.currency]=Math.round((u-r.total)*100)/100,h(o,a,r.quantity);let d={id:c,productId:e,quantity:r.quantity,fingerprint:l,status:`fulfilled`};return o.transactions[c]=d,n.commit(o),g(d),structuredClone(d)})},fulfillVerifiedGrant(e){return f(()=>{B(typeof e?.provider==`string`&&e.provider!==`wallet`&&typeof e.id==`string`&&e.id.length>0,`INVALID_GRANT`);let t=n.read(),i=`${e.provider}:${e.id}`;if(t.transactions[i])return structuredClone(t.transactions[i]);let a=p(e.productId,!0);B(a.payments.some(t=>t.provider===e.provider&&t.productId===e.storeProductId),`PRODUCT_MISMATCH`),B(Do(e.quantity)&&Array.isArray(e.rewards),`INVALID_GRANT`);let o={...a,maxQuantity:2**53-1,rewards:e.rewards.filter(e=>!(e.type===`entitlement`&&t.entitlements[e.entitlementId]))};for(let t of e.rewards)B(Do(t.amount)&&r[t.type],`INVALID_REWARD`);o.purchaseLimit&&(t.purchases[a.id]??0)>=o.purchaseLimit||(m(o,e.quantity,t),h(t,o,e.quantity));let s={id:i,productId:a.id,quantity:e.quantity,status:`fulfilled`};return t.transactions[i]=s,n.commit(t),g(s),structuredClone(s)})}})}var ko=`asteroid-belt-market-ledger-v1`,Ao=`asteroid-belt-market-journal-v1`,jo=`asteroid-belt-market-entitlements-v1`;function Mo(e=globalThis.localStorage){let t=e.getItem(Ao);if(!t)return;let n=JSON.parse(t);B(n.version===1&&Array.isArray(n.writes),`INVALID_JOURNAL`);for(let[t,r]of n.writes)e.setItem(t,r);e.removeItem(Ao)}function No(e,t=globalThis.localStorage){try{return JSON.parse(t.getItem(`asteroid-belt-market-entitlements-v1`)??`{}`)[e]===!0}catch{return!1}}function Po({storage:e,currencyKeys:t,artifactsKey:n,scope:r=`default`}){let i=(t,n)=>JSON.parse(e.getItem(t)??JSON.stringify(n));return{lockName:`asteroid-market`,read(){Mo(e);let a=i(ko,{transactions:{},scopes:{}}),o=Object.fromEntries(Object.entries(t).map(([t,n])=>[t,Number(e.getItem(n)??0)]));for(let e of Object.values(o))B(Number.isFinite(e)&&e>=0,`INVALID_BALANCE`);return{balances:o,artifacts:i(n,{unlocked:[],stackCounts:{},resetAtScores:{}}),entitlements:i(jo,{}),transactions:a.transactions,purchases:a.scopes[r]??{}}},commit(a){let o=i(ko,{transactions:{},scopes:{}}),s=[...Object.entries(t).map(([e,t])=>[t,String(a.balances[e])]),[n,JSON.stringify(a.artifacts)],[jo,JSON.stringify(a.entitlements)],[ko,JSON.stringify({transactions:a.transactions,scopes:{...o.scopes,[r]:a.purchases}})]];e.setItem(Ao,JSON.stringify({version:1,writes:s})),Mo(e)}}}var Fo=`ca-app-pub-3940256099942544/1033173712`,Io=`ca-app-pub-3940256099942544/5224354917`,Lo=!1,Ro=!1,zo=!1,Bo=!1,Vo=!1;async function Ho(){if(No(`remove-ads`)||!Lo||!Ro||zo||Bo||Vo)return!1;zo=!0;try{return await To.prepareInterstitial({adId:Fo}),Bo=!0,!0}catch{return!1}finally{zo=!1}}async function Uo(){if(Lo=bi.isNativePlatform()&&[`android`,`ios`].includes(bi.getPlatform()),!Lo)return!1;try{await To.initialize();let e=await To.requestConsentInfo();return!e.canRequestAds&&e.isConsentFormAvailable&&(e=await To.showConsentForm()),e.canRequestAds?(Ro=!0,Ho()):!1}catch{return!1}}async function Wo(){if(No(`remove-ads`)||!Lo||!Ro||!Bo||Vo)return!1;Vo=!0,Bo=!1;try{return await To.showInterstitial({adId:Fo}),!0}catch{return!1}finally{Vo=!1,Ho()}}async function Go({debug:e=!1}={}){if(!Lo)return e;if(!Ro||Vo)return!1;Vo=!0;try{return await To.prepareRewardVideoAd({adId:Io}),!!await To.showRewardVideoAd()}catch{return!1}finally{Vo=!1}}var Ko=[{id:`currency`,name:`Currency`,order:10},{id:`artifacts`,name:`Artifacts`,order:20},{id:`special`,name:`Special`,order:30}],qo=[...[{amount:100,price:100},{amount:250,price:200},{amount:400,price:300}].map(({amount:e,price:t})=>({id:`chronoshards-${e}`,categoryId:`currency`,name:`${e} Chronoshards`,enabled:!0,maxQuantity:100,referenceUnitPrice:1,rewards:[{type:`currency`,currency:`chronoshards`,amount:e}],payments:[{id:`aetherium`,provider:`wallet`,currency:`aetherium`,amount:t}]})),{id:`chronoshards-pack`,categoryId:`currency`,name:`Chronoshards pack`,enabled:!1,maxQuantity:100,rewards:[{type:`currency`,currency:`chronoshards`,amount:10}],payments:[{id:`aetherium`,provider:`wallet`,currency:`aetherium`,amount:10},{id:`cash`,provider:`wallet`,currency:`cash`,amount:1e3}]},{id:`aetherium-pack`,categoryId:`currency`,name:`Aetherium pack`,enabled:!1,maxQuantity:1,rewards:[{type:`currency`,currency:`aetherium`,amount:100}],payments:[{id:`google-play`,provider:`google-play`,productId:`aetherium_100`,consumable:!0}]},{id:`dark-core`,categoryId:`artifacts`,name:`Dark Core`,enabled:!1,maxQuantity:10,rewards:[{type:`artifact`,artifactId:`dark-core`,amount:1}],payments:[{id:`chronoshards`,provider:`wallet`,currency:`chronoshards`,amount:100}]},{id:`remove-ads`,categoryId:`special`,name:`Remove automatic ads`,enabled:!1,maxQuantity:1,purchaseLimit:1,rewards:[{type:`entitlement`,entitlementId:`remove-ads`,amount:1}],payments:[{id:`aetherium`,provider:`wallet`,currency:`aetherium`,amount:1e3},{id:`google-play`,provider:`google-play`,productId:`remove_ads`,consumable:!1}]}];function Jo(e){let t=new Map(e.map(e=>[e.id,e]));return{currency:{validate(e,t,n){B(Object.hasOwn(e.balances,t.currency),`UNKNOWN_CURRENCY`),B(Do(t.amount*n)&&Number.isFinite(e.balances[t.currency]+t.amount*n)&&e.balances[t.currency]+t.amount*n<=2**53-1,`AMOUNT_OVERFLOW`)},apply(e,t,n){e.balances[t.currency]+=t.amount*n}},artifact:{validate(e,n,r){let i=t.get(n.artifactId);B(i,`UNKNOWN_ARTIFACT`),B(Do(n.amount*r),`AMOUNT_OVERFLOW`),i.repeatable&&B(Number.isSafeInteger((e.artifacts.stackCounts?.[i.id]??0)+n.amount*r),`AMOUNT_OVERFLOW`),i.repeatable||B(n.amount*r===1&&!e.artifacts.unlocked.includes(i.id),`ALREADY_OWNED`)},apply(e,n,r){let i=t.get(n.artifactId);e.artifacts.stackCounts??={},i.repeatable&&(e.artifacts.stackCounts[i.id]=(e.artifacts.stackCounts[i.id]??0)+n.amount*r),e.artifacts.unlocked.includes(i.id)||e.artifacts.unlocked.push(i.id)}},entitlement:{validate(e,t,n){B(typeof t.entitlementId==`string`&&t.entitlementId.length>0&&t.amount*n===1&&!e.entitlements[t.entitlementId],`ALREADY_OWNED`)},apply(e,t){e.entitlements[t.entitlementId]=!0}}}}xi(`PurchasePlugin`);var Yo;function Xo({storage:e,currencyKeys:t,artifactsKey:n,artifacts:r,scope:i,onCommit:a}){return Yo=Oo({products:qo,categories:Ko,repository:Po({storage:e,currencyKeys:t,artifactsKey:n,scope:i}),rewardHandlers:Jo(r),onCommit:a}),Yo}function Zo(){if(!Yo)throw Error(`Game market is not initialized`);return Yo}var Qo=e=>String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),$o={currency:`chronoshards`,artifacts:`artifacts`,special:`marketSpecial`};function es(){return`<section class="market-panel hidden" id="market-panel" aria-labelledby="market-heading">
    <div class="lab-header market-header"><div><p class="eyebrow">${N(`market.eyebrow`)}</p><h2 id="market-heading">${N(`menu.market`)}</h2></div><button class="secondary-button" id="close-market-button" type="button">${N(`menu.back`)}</button></div>
    <div class="market-topline"><p>${N(`market.intro`)}</p><div class="market-wallet" aria-label="Aetherium"><img src="${so(`aetherium`)}" alt=""><span id="market-aetherium">0</span><small>AETHERIUM</small></div></div>
    <div class="market-tabs" id="market-tabs" role="tablist" aria-label="${N(`market.categories`)}"></div>
    <div id="market-bundles" class="market-grid" role="tabpanel" tabindex="0"></div>
    <p class="market-status" id="market-status" role="status" aria-live="polite"></p>
  </section>`}function ts({panel:e,getMarket:t,artifacts:n}){let r=e.querySelector(`#market-tabs`),i=e.querySelector(`#market-bundles`),a=e.querySelector(`#market-status`),o=`currency`,s=!1,c=e=>e.type===`artifact`?io(n.find(t=>t.id===e.artifactId)?.icon??``):so(e.type===`currency`?e.currency:`marketSpecial`),l=(e,t=!1)=>{a.textContent=e,a.classList.toggle(`is-error`,t)};function u(){let n=t(),a=n.getState(),l=n.listCategories();r.innerHTML=l.map(e=>`<button type="button" role="tab" id="market-tab-${Qo(e.id)}" aria-controls="market-bundles" aria-selected="${e.id===o}" tabindex="${e.id===o?0:-1}" data-market-category="${Qo(e.id)}"><img src="${so($o[e.id])}" alt=""><span>${Qo(e.name)}</span></button>`).join(``),i.setAttribute(`aria-labelledby`,`market-tab-${o}`),e.querySelector(`#market-aetherium`).textContent=P(a.balances.aetherium);let u=n.listProducts({categoryId:o}).filter(e=>e.payments.some(e=>e.provider===`wallet`&&e.currency===`aetherium`));i.classList.toggle(`is-empty`,u.length===0),i.innerHTML=u.length?u.map(e=>{let t=e.payments.find(e=>e.provider===`wallet`&&e.currency===`aetherium`),n=e.rewards.find(e=>e.type===`currency`),r=e.referenceUnitPrice*(n?.amount??0),i=r>t.amount?Math.round((1-t.amount/r)*100):0,o=a.balances.aetherium>=t.amount;return`<article class="market-bundle${i?` has-discount`:``}">
        ${i?`<div class="market-discount" aria-label="${N(`market.discount`,{percent:i})}"><span>✦</span> ${i}% OFF</div>`:``}
        <div class="market-bundle-rewards">${e.rewards.map(e=>`<div class="market-reward"><img src="${c(e)}" alt="${Qo(e.currency??e.artifactId??e.entitlementId)}"><strong><span class="market-times">×</span>${P(e.amount)}</strong></div>`).join(``)}</div>
        <p class="market-bundle-name">${Qo(n?.currency===`chronoshards`?`CHRONOSHARDS`:e.name)}</p>
        <button class="market-buy" type="button" data-market-buy="${Qo(e.id)}" data-market-payment="${Qo(t.id)}" ${s||!o?`disabled`:``} aria-label="${Qo(N(`market.buy_for`,{product:e.name,price:t.amount}))}" title="${Qo(o?N(`market.buy_for`,{product:e.name,price:t.amount}):N(`market.insufficient`))}"><img src="${so(`aetherium`)}" alt="Aetherium"><span>×${P(t.amount)}</span></button>
      </article>`}).join(``):`<div class="market-empty"><img src="${so($o[o])}" alt=""><p>${N(`market.empty`)}</p></div>`}function d(e){o=e,l(``),u(),r.querySelector(`[aria-selected="true"]`).focus()}return r.addEventListener(`click`,e=>{let t=e.target.closest(`[data-market-category]`);t&&d(t.dataset.marketCategory)}),r.addEventListener(`keydown`,e=>{let t=[...r.querySelectorAll(`[role="tab"]`)],n=t.findIndex(e=>e.dataset.marketCategory===o);if(e.key===`ArrowRight`)n=(n+1)%t.length;else if(e.key===`ArrowLeft`)n=(n+t.length-1)%t.length;else if(e.key===`Home`)n=0;else if(e.key===`End`)n=t.length-1;else return;e.preventDefault(),d(t[n].dataset.marketCategory)}),i.addEventListener(`click`,async e=>{let n=e.target.closest(`[data-market-buy]`);if(!n||n.disabled||s)return;s=!0;let r=n.dataset.marketBuy,a=n.dataset.marketPayment;l(N(`market.purchasing`)),u();try{await t().purchase(r,{paymentId:a,requestId:crypto.randomUUID()}),l(N(`market.purchased`))}catch(e){l(N(e.code===`INSUFFICIENT_FUNDS`?`market.insufficient`:`market.failed`),!0)}finally{s=!1,u(),i.querySelector(`[data-market-buy="${r}"]:not(:disabled)`)?.focus()}}),{render:u,open(){l(``),u()}}}function ns(e){return 1+Math.min(8,Math.max(0,e))/8*.25}function rs(e){return .5+Math.min(8,Math.max(0,e))/8*.5}var is=864e5,as=108e5,os=[{id:`cells-20`,metric:`cells`,target:20},{id:`cells-40`,metric:`cells`,target:40},{id:`cells-60`,metric:`cells`,target:60},{id:`chrono-2`,metric:`chronoPickups`,target:2},{id:`chrono-4`,metric:`chronoPickups`,target:4},{id:`chrono-6`,metric:`chronoPickups`,target:6},{id:`aetherium-1`,metric:`aetheriumPickups`,target:1},{id:`aetherium-2`,metric:`aetheriumPickups`,target:2},{id:`aetherium-3`,metric:`aetheriumPickups`,target:3},{id:`play-120`,metric:`playSeconds`,target:120},{id:`play-300`,metric:`playSeconds`,target:300},{id:`play-600`,metric:`playSeconds`,target:600}];function ss(e){let t=Math.floor((e+as)/is),n=t-(new Date(t*is).getUTCDay()+6)%7;return{day:t,week:n,nextDayAt:(t+1)*is-as,nextWeekAt:(n+7)*is-as}}function cs(e){return{aetherium:5,chronoshards:5+(Math.min(9,Math.max(1,Math.floor(e)||1))-1)*3}}function ls({storage:e,stateKey:t,aetheriumKey:n,chronoshardsKey:r,onReward:i=()=>{}}){return{read(){let n=e.getItem(Ao)!==null;if(Mo(e),n)try{i()}catch{}return JSON.parse(e.getItem(t)??`null`)},commit(a,o){Mo(e);let s=[[t,JSON.stringify(a)]];if(o)for(let[t,i]of[[`aetherium`,n],[`chronoshards`,r]]){let n=Number(e.getItem(i)??0);if(!Number.isFinite(n)||n<0)throw Error(`Invalid mission reward balance`);s.push([i,String(n+o[t])])}if(e.setItem(Ao,JSON.stringify({version:1,writes:s})),Mo(e),o)try{i()}catch{}}}}function us({repository:e,now:t=Date.now,random:n=Math.random,getMaxTier:r=()=>1}){let i=e.read(),a=i?.version===1?i:{version:1,lastDay:null,serial:0,missions:[],weekly:{week:null,completed:0,claimed:!1}},o=new Set,s=()=>{for(let e of o)try{e()}catch{}},c=(t,n)=>{e.commit(t,n),a=t,s()},l=e=>e[Math.min(e.length-1,Math.floor(Math.max(0,n())*e.length))],u=(e,t)=>{let n=Math.min(t,9-e.missions.length);for(let t=0;t<n;t++){let t=os.filter(t=>!e.missions.some(e=>e.templateId===t.id)),n=l(t);e.serial++,e.missions.push({id:`mission-${e.serial}`,templateId:n.id,metric:n.metric,target:n.target,progress:0,isNew:!0,completedWeek:null})}return n},d=(e,t)=>{t.progress>=t.target&&t.completedWeek===null&&(t.completedWeek=e.weekly.week,e.weekly.completed++)},f={subscribe(e){return o.add(e),()=>o.delete(e)},refresh(){let n=e.read();n?.version===1&&(a=n);let r=ss(t()),i=structuredClone(a),o=!1;(i.weekly.week===null||r.week>i.weekly.week)&&(i.weekly={week:r.week,completed:0,claimed:!1},o=!0);let s=0;if(i.lastDay===null||r.day>i.lastDay){let e=i.lastDay===null?1:r.day-i.lastDay;s=u(i,Math.min(9,e*3)),i.lastDay=r.day,o=!0}return o&&c(i),s},getState(){return{...structuredClone(a),calendar:ss(t()),reward:cs(r())}},getNotificationCount(){return a.missions.filter(e=>e.isNew||e.progress>=e.target).length},markSeen(){if(f.refresh(),!a.missions.some(e=>e.isNew))return;let e=structuredClone(a);for(let t of e.missions)t.isNew=!1;c(e)},record(e,t=1){if(!Number.isFinite(t)||t<=0)return;f.refresh();let n=structuredClone(a),r=!1;for(let i of n.missions)i.metric!==e||i.progress>=i.target||(i.progress=Math.min(i.target,i.progress+t),d(n,i),r=!0);r&&c(n)},triggerMidnight(){f.refresh();let e=structuredClone(a),t=u(e,3);return t&&c(e),t},completeRandom(){f.refresh();let e=structuredClone(a),t=e.missions.filter(e=>e.progress<e.target);if(!t.length)return null;let n=l(t);return n.progress=n.target,d(e,n),c(e),structuredClone(n)},claimMission(e){f.refresh();let t=a.missions.find(t=>t.id===e);if(!t||t.progress<t.target)return!1;let n=structuredClone(a);return n.missions=n.missions.filter(t=>t.id!==e),c(n,cs(r())),!0},claimWeekly(){if(f.refresh(),a.weekly.claimed||a.weekly.completed<15)return!1;let e=structuredClone(a);return e.weekly.claimed=!0,c(e,{aetherium:100,chronoshards:100}),!0}};return f.refresh(),f}function ds(){return`<button class="daily-missions-button" id="open-daily-missions" type="button" aria-label="${N(`missions.title`)}"><img src="${so(`dailyMissions`)}" alt=""><span class="missions-badge" id="missions-badge" hidden></span></button>
  <div class="daily-missions-overlay hidden" id="daily-missions-overlay" role="dialog" aria-modal="true" aria-labelledby="daily-missions-heading">
    <section class="daily-missions-panel">
      <header class="missions-header"><div class="missions-balances"><span><img src="${so(`aetherium`)}" alt="Aetherium"><b id="missions-aetherium">0</b></span><span><img src="${so(`chronoshards`)}" alt="Chronoshards"><b id="missions-chronoshards">0</b></span></div><button class="missions-close" id="close-daily-missions" type="button" aria-label="${N(`menu.back`)}">×</button><h2 id="daily-missions-heading">${N(`missions.title`)}</h2></header>
      <section class="missions-weekly" aria-labelledby="missions-weekly-title"><div class="missions-weekly-meta"><span id="missions-week-reset"></span><strong id="missions-week-count"></strong></div><h3 id="missions-weekly-title">${N(`missions.weekly`)}</h3><div class="missions-weekly-route"><div class="missions-weekly-track" role="progressbar" aria-valuemin="0" aria-valuemax="15" aria-label="${N(`missions.weekly`)}"><i id="missions-weekly-fill"></i></div><button class="missions-chest" id="claim-weekly-missions" type="button"><img src="${so(`missionChest`)}" alt=""><span id="missions-chest-label"></span></button></div><div class="missions-chest-rewards"><span><img src="${so(`aetherium`)}" alt="Aetherium">×100</span><span><img src="${so(`chronoshards`)}" alt="Chronoshards">×100</span></div></section>
      <div class="missions-list-heading"><strong id="missions-active-count"></strong><span id="missions-next-reset"></span></div>
      <div class="missions-list" id="missions-list"></div>
      <p class="missions-status" id="missions-status" role="status"></p>
      <button class="missions-return" id="return-from-missions" type="button">${N(`missions.return`)}</button>
    </section>
  </div>`}function fs(e){let t=Math.max(0,Math.ceil((e-Date.now())/6e4)),n=Math.floor(t/1440),r=Math.floor(t%1440/60);return[n?N(`missions.days`,{amount:n}):``,r?N(`missions.hours`,{amount:r}):``,N(`missions.minutes`,{amount:t%60})].filter(Boolean).join(` `)}function ps({service:e,overlay:t,button:n,getBalances:r,onOpen:i,onClose:a}){let o=document.querySelector(`#missions-badge`),s=t.querySelector(`#missions-list`),c=t.querySelector(`#claim-weekly-missions`),l=t.querySelector(`#missions-status`),u=e=>e.progress>=e.target,d,f=()=>{let t=e.getNotificationCount();o.hidden=t===0,o.textContent=t,n.setAttribute(`aria-label`,`${N(`missions.title`)}${t?` · ${N(`missions.notifications`,{count:t})}`:``}`)};function p(){if(f(),t.classList.contains(`hidden`))return;let{missions:n,weekly:i,calendar:a,reward:o}=e.getState(),l=r();t.querySelector(`#missions-aetherium`).textContent=P(l.aetherium),t.querySelector(`#missions-chronoshards`).textContent=P(l.chronoshards),t.querySelector(`#missions-week-reset`).textContent=N(`missions.reset_in`,{time:fs(a.nextWeekAt)}),t.querySelector(`#missions-next-reset`).textContent=N(`missions.next_in`,{time:fs(a.nextDayAt)}),t.querySelector(`#missions-active-count`).textContent=N(`missions.active`,{count:n.length,max:9}),t.querySelector(`#missions-week-count`).textContent=`${i.completed}/15`;let d=Math.min(i.completed/15,1)*100;t.querySelector(`#missions-weekly-fill`).style.width=`${d}%`,t.querySelector(`.missions-weekly-track`).setAttribute(`aria-valuenow`,Math.min(i.completed,15)),c.disabled=i.claimed||i.completed<15,c.classList.toggle(`is-ready`,!i.claimed&&i.completed>=15),c.classList.toggle(`is-claimed`,i.claimed),t.querySelector(`#missions-chest-label`).textContent=i.claimed?N(`missions.claimed`):i.completed>=15?N(`missions.open_chest`):`15`;let p=document.activeElement?.dataset?.claimMission;s.innerHTML=n.map(e=>{let t=N(`missions.metric.${e.metric}`,{target:e.metric===`playSeconds`?e.target/60:e.target}),n=Math.min(100,e.progress/e.target*100),r=e.metric===`playSeconds`?`${Math.floor(e.progress/60)}:${String(Math.floor(e.progress%60)).padStart(2,`0`)} / ${e.target/60}:00`:`${Math.floor(e.progress)} / ${e.target}`;return`<article class="mission-node${u(e)?` is-complete`:``}"><div class="mission-description"><img class="mission-type-icon" src="${so({cells:`missionCell`,chronoPickups:`chronoshards`,aetheriumPickups:`aetherium`,playSeconds:`missionClock`}[e.metric])}" alt=""><h4>${t}</h4></div><div class="mission-rewards"><span><img src="${so(`aetherium`)}" alt="Aetherium">×${o.aetherium}</span><span><img src="${so(`chronoshards`)}" alt="Chronoshards">×${o.chronoshards}</span></div>${u(e)?`<button class="mission-claim" type="button" data-claim-mission="${e.id}">${N(`missions.claim`)}</button>`:`<div class="mission-progress" role="progressbar" aria-label="${t}" aria-valuemin="0" aria-valuemax="${e.target}" aria-valuenow="${Math.floor(e.progress)}"><i style="width:${n}%"></i><span>${r}</span></div>`}</article>`}).join(``)||`<p class="missions-empty">${N(`missions.empty`)}</p>`,p&&s.querySelector(`[data-claim-mission="${p}"]`)?.focus({preventScroll:!0})}function m(){t.classList.add(`hidden`),a(),d?.focus({preventScroll:!0})}return n.addEventListener(`click`,n=>{n.stopPropagation(),d=document.activeElement,i(),t.classList.remove(`hidden`),e.markSeen(),l.textContent=``,p(),t.querySelector(`#close-daily-missions`).focus()}),n.addEventListener(`pointerdown`,e=>e.stopPropagation()),t.addEventListener(`pointerdown`,e=>e.stopPropagation()),t.querySelector(`#close-daily-missions`).addEventListener(`click`,m),t.querySelector(`#return-from-missions`).addEventListener(`click`,m),t.addEventListener(`click`,e=>{e.stopPropagation(),e.target===t&&m()}),t.addEventListener(`keydown`,e=>{if(e.key!==`"`&&(e.stopPropagation(),e.key===`Escape`&&(e.preventDefault(),m()),e.key===`Tab`)){let n=[...t.querySelectorAll(`button:not(:disabled)`)],r=n[0],i=n.at(-1);e.shiftKey&&document.activeElement===r?(e.preventDefault(),i.focus()):!e.shiftKey&&document.activeElement===i&&(e.preventDefault(),r.focus())}}),s.addEventListener(`click`,t=>{let n=t.target.closest(`[data-claim-mission]`);if(n)try{e.claimMission(n.dataset.claimMission)&&(l.textContent=N(`missions.reward_claimed`))}catch{l.textContent=N(`missions.failed`)}}),c.addEventListener(`click`,()=>{try{e.claimWeekly()&&(l.textContent=N(`missions.chest_claimed`))}catch{l.textContent=N(`missions.failed`)}}),e.subscribe(p),f(),{render:p,close:m,isOpen:()=>!t.classList.contains(`hidden`)}}var ms=`asteroid-belt-onboarding-progress`,hs=Object.freeze([{id:`quick-start`,trigger:`launch`,shouldRun:({isSteamBuild:e})=>!e,run:async({startTutorialRun:e})=>e()},{id:`first-loss-guidance`,trigger:`first-loss`,shouldRun:({isSteamBuild:e})=>!e,run:async({startFirstLossGuidance:e})=>e()},{id:`sector-2-guidance`,trigger:`sector-2-unlocked`,shouldRun:({isSteamBuild:e})=>!e,run:async({startSecondSectorGuidance:e})=>e()},{id:`first-research-guidance`,trigger:`research-first-loss`,shouldRun:({isSteamBuild:e})=>!e,run:async({startFirstResearchGuidance:e})=>e()}]);function gs(e){try{let t=JSON.parse(e.getItem(ms)??`null`);return{completed:new Set(Array.isArray(t?.completed)?t.completed.filter(e=>typeof e==`string`):[])}}catch{return{completed:new Set}}}function _s(e,t){try{e.setItem(ms,JSON.stringify({completed:[...t.completed]}))}catch{}}function vs(e=window.localStorage){try{e.removeItem(ms)}catch{}}function ys({isSteamBuild:e,startTutorialRun:t,startFirstLossGuidance:n,startSecondSectorGuidance:r,startFirstResearchGuidance:i,onStepStarted:a,onStepCompleted:o,storage:s=window.localStorage}){let c=gs(s),l=null;return{async start(o=`launch`){if(l)return!1;for(let s of hs)if(!(s.trigger!==o||c.completed.has(s.id)||!s.shouldRun({isSteamBuild:e})))return l=s,await s.run({startTutorialRun:t,startFirstLossGuidance:n,startSecondSectorGuidance:r,startFirstResearchGuidance:i}),a?.(s),!0;return!1},completeActiveStep(){if(!l)return!1;let e=l;return l=null,c.completed.add(e.id),_s(s,c),o?.(e),!0},isActiveStep(e){return l?.id===e}}}var bs=!1,xs=bi.isNativePlatform()&&bi.getPlatform()===`android`;function Ss(e,t){return`<span class="menu-button-icon" aria-hidden="true"><img data-menu-icon src="${so(e)}" alt=""><span class="menu-icon-fallback" hidden>${t}</span></span>`}function Cs({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button${e===`home-button`?` menu-home-button`:``}" id="${e}" type="button" aria-label="${r}" title="${r}">${Ss(t,n)}<span class="menu-button-label">${r}</span><span class="menu-button-lock" hidden></span></button>`}function ws({id:e,iconId:t,fallback:n,label:r}){return`<button class="menu-system-button menu-utility-button" id="${e}" type="button" aria-label="${r}" title="${r}">${Ss(t,n)}<span class="menu-button-label">${r}</span></button>`}var Ts=so(`shield`),Es=so(`pause`);document.querySelector(`#app`).innerHTML=`
  <main class="game-shell">
    <canvas id="game" aria-label="Asteroid Belt game canvas"></canvas>
    <header class="hud">
      <div class="hud-left">
        <div class="cash-balance"><span class="currency-label">CASH</span><span id="cash">$000</span></div>
        <div class="chronoshard-balance"><span class="currency-label">CHRONOSHARDS</span><span id="chronoshards">✦ 0</span></div>
        <div class="aetherium-balance"><span id="aetherium"><img src="${so(`aetherium`)}" alt="Aetherium">0</span></div>
      </div>
      <div class="hud-sector" id="hud-sector" aria-label="Current difficulty sector"></div>
      <dl class="run-cell-counter"><div><dt>CELLS</dt><dd id="score">000</dd></div></dl>
      <button class="pause-button" id="pause-button" type="button" aria-label="Pause game"><img src="${Es}" alt=""></button>
    </header>
    <div class="shield-indicators" id="shield-indicators" aria-label="Shield charges"></div>
    <div class="tower-health-hud hidden" id="tower-health-hud" role="status" aria-live="polite"><strong id="tower-health-label"></strong><div class="tower-health-track"><i id="tower-health-fill"></i></div></div>
    <div class="weapon-hud hidden" id="weapon-hud"></div>
    <aside class="instructions" aria-label="Game controls"><span class="controls-desktop"><span><b>MOVE</b> WASD</span><span><b>NAVIGATE</b> ↑↓</span><span><b>USE WEAPON</b> SPACE</span></span><span class="controls-mobile"><span><b>MOVE</b> JOYSTICK</span><span><b>SELECT / USE WEAPON</b> TAP A CARD</span></span></aside>
    <p class="onboarding-directive hidden" id="onboarding-directive" role="status"><span aria-hidden="true">↔</span>${N(`onboarding.drag_to_move`)}</p>
    <footer class="build-footer" aria-label="Build information">
      <span>v${na.version}</span><span>BUILD ${na.number}</span>
    </footer>
    <div class="virtual-joystick" id="virtual-joystick" aria-hidden="true">
      <div class="virtual-joystick-knob"></div>
    </div>
    <div class="cash-indicators" id="cash-indicators" aria-live="polite"></div>
    ${ds()}
    <button class="aetherium-ad-claim${xs?``:` hidden`}" id="aetherium-ad-claim" type="button" aria-label="Watch an ad to claim 5 Aetherium"><img class="ad-badge" src="${so(`adReward`)}" alt=""><span>CLAIM 5</span><img src="${so(`aetherium`)}" alt="Aetherium"></button>
    <section class="debug-reward-screen hidden" id="debug-reward-screen" aria-live="polite"><p>DEBUG REWARDED AD</p><strong>WHITE SCREEN TEST</strong><span id="debug-reward-countdown">10</span><button id="debug-reward-granted" type="button" disabled hidden>REWARD GRANTED</button></section>
    <div class="build-grid-ui hidden" id="build-grid-ui" aria-label="Build locations"></div>
    <div class="milestone-claim-toast hidden" id="milestone-claim-toast" role="status" aria-live="polite"></div>
    <div class="feature-lock-toast hidden" id="feature-lock-toast" role="status" aria-live="polite"></div>
    <div class="artifact-unlock-toast hidden" id="artifact-unlock-toast" role="status" aria-live="polite"></div>
    <section class="pause-menu hidden" id="pause-menu" aria-label="Pause menu">
      <p class="eyebrow">ROUND PAUSED</p>
      <h2>PAUSE</h2>
      <div class="pause-actions">
        <button id="reset-round-button" type="button">RESET</button>
        <button id="surrender-button" type="button">SURRENDER</button>
        <button class="secondary-button" id="resume-game-button" type="button">RETURN</button>
        <button id="return-menu-button" type="button">MAIN MENU</button>
      </div>
    </section>
    <section class="cheat-console hidden" id="cheat-console" aria-label="Debug console">
      <header><strong>${ta.title}</strong><button id="close-cheat-console" type="button" aria-label="Close debug console">×</button></header>
      <p id="cheat-output">Enter a command.</p>
      <label><span>›</span><input id="cheat-input" type="text" autocomplete="off" spellcheck="false" placeholder="cash 1000"></label>
    </section>
    <section class="overlay" id="overlay" aria-live="polite">
      
      <div class="menu-content" id="menu-content">
        <div class="death-killer-heading">
          <h1 id="overlay-title">ASTEROID BELT</h1>
          <div class="death-killer-preview" id="death-killer-preview" hidden>
            <canvas id="death-killer-canvas" aria-label="Defeating enemy 3D model"></canvas>
          </div>
        </div>
        <p id="overlay-copy"></p>
        <p class="game-over-tip" id="game-over-tip" hidden></p>
        <div class="sector-selection" aria-label="Difficulty sector selection">
          <div class="sector-heading">Difficulty</div>
          <div class="sector-carousel">
            <button class="sector-nav" id="previous-sector" type="button" aria-label="Select previous sector">‹</button>
            <span class="sector-options" id="sector-options" aria-live="polite"></span>
            <button class="sector-nav" id="next-sector" type="button" aria-label="Select next sector">›</button>
          </div>
          <p class="highest-cell">HIGHEST CELL: <span id="highest-cells">000</span></p>
          <p class="sector-requirement" id="sector-requirement"></p>
          <button class="milestone-button" id="open-milestones-button" type="button">VIEW ASCENSION <span class="milestone-claim-count" id="milestone-claim-count" hidden>0</span></button>
        </div>
      </div>
      <div class="menu-actions">
          <button class="menu-start-button" id="start-button" type="button">START RUN</button>
          <button class="menu-start-button anomaly-run-button" id="anomaly-run-button" type="button">ANOMALY RUN</button>
          ${Cs({id:`home-button`,iconId:`home`,fallback:`H`,label:N(`menu.home`)})}
          ${Cs({id:`open-lab-button`,iconId:`researchLab`,fallback:`RL`,label:N(`menu.research_lab`)})}
          ${Cs({id:`open-weaponry-button`,iconId:`weaponry`,fallback:`W`,label:N(`menu.weaponry`)})}
          ${Cs({id:`open-building-button`,iconId:`buildingSystem`,fallback:`BS`,label:N(`menu.buildings`)})}
          ${Cs({id:`open-market-button`,iconId:`market`,fallback:`M`,label:N(`menu.market`)})}
          ${ws({id:`open-encyclopedia-button`,iconId:`encyclopedia`,fallback:`E`,label:N(`menu.encyclopedia`)})}
          ${ws({id:`open-settings-button`,iconId:`settings`,fallback:`S`,label:N(`menu.settings`)})}
          ${ws({id:`open-artifacts-button`,iconId:`artifacts`,fallback:`A`,label:N(`menu.artifacts`)})}
          
      </div>
      ${es()}
      <section class="milestones-panel hidden" id="milestones-panel" aria-label="Ascension">
        <div class="milestones-header"><div><p class="eyebrow">BEST SINGLE RUN</p><h2>ASCENSION</h2><p>MAX CELLS <strong id="milestone-max-cells">000</strong></p></div><button class="secondary-button" id="close-milestones-button" type="button">BACK</button></div>
        <div class="milestone-sector-nav"><button id="previous-milestone-sector" type="button" aria-label="View previous milestone sector">‹</button><strong id="milestone-sector-label">SECTOR I</strong><button id="next-milestone-sector" type="button" aria-label="View next milestone sector">›</button></div>
        <div class="milestone-track" id="milestone-track"></div>
      </section>
      <section class="lab-panel hidden" id="lab-panel" aria-label="Research Lab">
        <div class="lab-header"><div><p class="eyebrow">PERMANENT UPGRADES</p><h2>RESEARCH LAB</h2></div><button class="secondary-button" id="close-lab-button" type="button">BACK</button></div>
        <p class="lab-balance">CASH <span id="lab-cash">$0</span><span id="lab-chronoshard-balance"> · CHRONOSHARDS <span id="lab-chronoshards">✦ 0</span></span></p>
        <p class="lab-message" id="lab-message" aria-live="polite"></p>
        <h3 id="research-slots-heading">ACTIVE SLOTS</h3><div class="research-slots" id="research-slots"></div>
        <h3>AVAILABLE RESEARCH</h3><label class="research-search"><span>SEARCH</span><input id="research-search" type="search" placeholder="Search research names" autocomplete="off"></label><div class="research-filters"><label><input id="hide-completed-researches" type="checkbox"> <span>Hide Completed Researches</span></label><label><input id="hide-locked-researches" type="checkbox"> <span>Hide Locked Researches</span></label></div><div class="research-list" id="research-list"></div>
      </section>
      <section class="encyclopedia-panel hidden" id="encyclopedia-panel" aria-label="Encyclopedia"><div class="lab-header"><div><p class="eyebrow">THREAT DATABASE</p><h2>ENCYCLOPEDIA</h2></div><button class="secondary-button" id="close-encyclopedia-button" type="button">BACK</button></div><div class="encyclopedia-list" id="encyclopedia-list"></div></section>
      <section class="artifact-panel hidden" id="artifact-panel" aria-label="Artifacts"><div class="lab-header"><div><p class="eyebrow">PERMANENT ACHIEVEMENTS</p><h2>ARTIFACTS</h2></div><button class="secondary-button" id="close-artifacts-button" type="button">BACK</button></div><p class="artifact-intro">Artifacts are permanent rewards earned by reaching achievement goals.</p><div class="artifact-grid" id="artifact-grid"></div></section>
      <section class="artifact-detail-modal hidden" id="artifact-detail-modal" aria-label="Artifact detail"><div id="artifact-detail-content"></div><button class="secondary-button" id="close-artifact-detail-button" type="button">BACK</button></section>
      <section class="building-panel hidden" id="building-panel"><div class="lab-header"><div><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING SYSTEM</h2></div><button class="secondary-button" id="close-building-button" type="button">BACK</button></div><p class="lab-balance">CASH <span id="building-cash"></span> · CHRONOSHARDS <span id="building-chronoshards"></span> · SLOTS <span id="building-slots"></span></p><div class="building-actions"><button id="enter-build-mode" type="button">BUILD MODE</button><button id="open-building-draft" type="button">UNLOCK A BUILDING</button></div><h3>UNLOCKED BUILDINGS</h3><div class="building-list" id="building-list"></div></section>
      <section class="building-draft-modal hidden" id="building-draft-modal" aria-label="Building Draft"><button class="upgrade-close" id="close-building-draft" type="button" aria-label="Close building draft">×</button><p class="eyebrow">PERMANENT DEFENSES</p><h2>BUILDING DRAFT</h2><p class="building-draft-balance">CHRONOSHARDS <span id="building-draft-chronoshards"></span></p><div class="building-list" id="building-draft-list"></div></section>
      <section class="weaponry-panel hidden" id="weaponry-panel" aria-label="Weaponry"><div class="lab-header"><div><p class="eyebrow">ACTIVE ARSENAL</p><h2>WEAPONRY</h2></div><button class="secondary-button" id="close-weaponry-button" type="button">BACK</button></div><p class="lab-balance">CHRONOSHARDS <span id="weaponry-chronoshards"></span></p><div class="weapon-buy-actions"><button class="weapon-buy-button" id="buy-weapon-button" type="button">BUY WEAPON · ✦ 35</button><button class="weapon-buy-button" id="buy-weapons-five-button" type="button">BUY WEAPON x5 · ✦ 175</button></div><p class="weapon-lucky-find-chance" id="weapon-lucky-find-chance" hidden>LUCKY FIND · 0% · 2 CARDS</p><h3>ROUND LOADOUT <span id="weapon-slot-count"></span></h3><div class="weapon-loadout" id="weapon-loadout"></div><h3>WEAPON CARDS</h3><div class="weapon-card-list" id="weapon-card-list"></div></section>
      <section class="weapon-reveal-modal hidden" id="weapon-reveal-modal" aria-label="Weapon purchase result" aria-live="polite"><div class="weapon-reveal-card"><p class="eyebrow" id="weapon-reveal-count"></p><p class="weapon-lucky-find-badge" aria-hidden="true">✦ LUCKY FIND · DOUBLE CARD ✦</p><p class="weapon-reveal-status" id="weapon-reveal-status"></p><img class="asset-card-art" id="weapon-reveal-art" alt=""><h2 id="weapon-reveal-name"></h2><p id="weapon-reveal-detail"></p><button id="weapon-reveal-continue" type="button">CLAIM</button></div></section>
      <section class="settings-panel hidden" id="settings-panel" aria-label="Settings"><div class="lab-header"><div><p class="eyebrow">PREFERENCES</p><h2>SETTINGS</h2></div><button class="secondary-button" id="close-settings-button" type="button">BACK</button></div><div class="settings-section"><h3>GRAPHICS</h3><div class="settings-row"><div><strong>Quality</strong><small>Changes render resolution and shadows.</small></div><div class="settings-options" id="graphics-quality-options"></div></div><label class="settings-row settings-toggle"><span><strong>Shadows</strong><small>Show dynamic object shadows.</small></span><input id="setting-shadows" type="checkbox"></label><label class="settings-row"><span><strong>HDR Emission</strong><small>Controls how far bright effects bloom beyond their models.</small></span><output id="hdr-emission-value"></output><input id="setting-hdr-emission" type="range" min="0" max="100" step="1"></label><label class="settings-row"><span><strong>Maximum FPS</strong><small>Limits rendering and simulation to reduce hardware load.</small></span><output id="max-fps-value"></output><input id="setting-max-fps" type="range" min="0" max="240" step="30"></label></div><div class="settings-section"><h3>GAMEPLAY</h3><label class="settings-row settings-toggle"><span><strong>Auto Pause</strong><small>Pause the run when the game loses focus.</small></span><input id="setting-auto-pause" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>High Contrast HUD</strong><small>Improves HUD readability.</small></span><input id="setting-high-contrast" type="checkbox"></label></div><div class="settings-section"><h3>SOUND</h3><label class="settings-row"><span><strong>Master Volume</strong><small>Controls all game sound effects.</small></span><output id="master-volume-value"></output><input id="setting-master-volume" type="range" min="0" max="100" step="1"></label><label class="settings-row settings-toggle"><span><strong>Mute All</strong><small>Instantly silence all sound effects.</small></span><input id="setting-muted" type="checkbox"></label><label class="settings-row settings-toggle"><span><strong>Spatial Audio</strong><small>Pan sounds based on their world position.</small></span><input id="setting-spatial-audio" type="checkbox"></label></div><div class="settings-section settings-actions"><button id="open-patch-notes-button" type="button">PATCH NOTES</button></div></section>
      <section class="patch-notes-panel hidden" id="patch-notes-panel" aria-label="Patch notes"><div class="lab-header"><div><p class="eyebrow">VERSION ${na.version} · BUILD ${na.number}</p><h2>PATCH NOTES</h2></div><button class="secondary-button" id="close-patch-notes-button" type="button">BACK</button></div>${za.map(e=>`<article class="patch-notes-entry"><h3>${e.heading}</h3><ul>${e.changes.map(e=>`<li>${e}</li>`).join(``)}</ul></article>`).join(``)}</section>
    </section>
    <section class="anomaly-run-modal hidden" id="anomaly-run-modal" aria-label="Anomaly Run challenge"><div class="anomaly-run-card"><p class="eyebrow">WEEKLY ANOMALY</p><h2 id="anomaly-challenge-name"></h2><p id="anomaly-challenge-description"></p><p class="anomaly-reward" id="anomaly-reward"></p><p class="anomaly-reset" id="anomaly-reset"></p><p class="anomaly-time-warning hidden" id="anomaly-time-warning" role="alert"></p><div><button class="secondary-button" id="cancel-anomaly-run" type="button">BACK</button><button id="confirm-anomaly-run" type="button">START ANOMALY RUN</button></div></div></section>
    <div class="build-bar hidden" id="build-bar"><span id="build-status">SELECT A BUILDING</span><div id="build-options"></div><button id="exit-build-mode" type="button">DONE</button></div>
    <section class="building-upgrade hidden" id="building-upgrade"></section>
  </main>
`;var Ds=document.querySelector(`#game`);for(let e of document.querySelectorAll(`[data-menu-icon]`))e.addEventListener(`error`,()=>{e.hidden=!0;let t=e.nextElementSibling;t&&(t.hidden=!1)});var Os=document.querySelector(`#score`),ks=document.querySelector(`#hud-sector`),As=document.querySelector(`#shield-indicators`),js=document.querySelector(`#tower-health-hud`),Ms=document.querySelector(`#tower-health-label`),Ns=document.querySelector(`#tower-health-fill`),Ps=document.querySelector(`#pause-button`),Fs=document.querySelector(`#overlay`),Is=document.querySelector(`#save-slot-select`),Ls=document.querySelector(`#save-slot-grid`),Rs=document.querySelector(`#overlay-title`),zs=document.querySelector(`#death-killer-preview`),Bs=document.querySelector(`#death-killer-canvas`),Vs=document.querySelector(`#overlay-copy`),Hs=document.querySelector(`#game-over-tip`),Us=document.querySelector(`#start-button`),Ws=document.querySelector(`#anomaly-run-button`),Gs=document.querySelector(`#anomaly-run-modal`),Ks=document.querySelector(`#anomaly-challenge-name`),qs=document.querySelector(`#anomaly-challenge-description`),Js=document.querySelector(`#anomaly-reward`),Ys=document.querySelector(`#anomaly-reset`),Xs=document.querySelector(`#anomaly-time-warning`),Zs=document.querySelector(`#confirm-anomaly-run`),Qs=document.querySelector(`#cancel-anomaly-run`),$s=document.querySelector(`#menu-content`),ec=document.querySelector(`#market-panel`),tc=document.querySelector(`#open-market-button`),nc=ts({panel:ec,getMarket:Zo,artifacts:Za.artifacts}),rc,ic,ac=0,oc=!1,sc=document.querySelector(`#open-milestones-button`),cc=document.querySelector(`#milestones-panel`),lc=document.querySelector(`#close-milestones-button`),uc=document.querySelector(`#milestone-max-cells`),dc=document.querySelector(`#milestone-track`),fc=document.querySelector(`#milestone-claim-count`),pc=document.querySelector(`#milestone-claim-toast`),mc=document.querySelector(`#feature-lock-toast`),hc=document.querySelector(`#artifact-unlock-toast`),gc=document.querySelector(`#previous-milestone-sector`),_c=document.querySelector(`#next-milestone-sector`),vc=document.querySelector(`#milestone-sector-label`),yc=document.querySelector(`#lab-panel`),bc=document.querySelector(`#open-lab-button`),xc=document.querySelector(`#home-button`),Sc=document.querySelector(`#open-building-button`),Cc=document.querySelector(`#open-weaponry-button`),wc=document.querySelector(`#open-encyclopedia-button`),Tc=document.querySelector(`#encyclopedia-panel`),Ec=document.querySelector(`#close-encyclopedia-button`),Dc=document.querySelector(`#encyclopedia-list`),Oc=document.querySelector(`#open-artifacts-button`),kc=document.querySelector(`#artifact-panel`),Ac=document.querySelector(`#close-artifacts-button`),jc=document.querySelector(`#artifact-grid`),Mc=document.querySelector(`#artifact-detail-modal`),Nc=document.querySelector(`#artifact-detail-content`),Pc=document.querySelector(`#close-artifact-detail-button`),Fc=document.querySelector(`#weaponry-panel`),Ic=document.querySelector(`#close-weaponry-button`),Lc=document.querySelector(`#weaponry-chronoshards`),Rc=document.querySelector(`#buy-weapon-button`),zc=document.querySelector(`#buy-weapons-five-button`),Bc=document.querySelector(`#weapon-lucky-find-chance`),Vc=document.querySelector(`#weapon-reveal-modal`),Hc=document.querySelector(`#weapon-reveal-count`),Uc=document.querySelector(`#weapon-reveal-status`),Wc=document.querySelector(`#weapon-reveal-art`),Gc=document.querySelector(`#weapon-reveal-name`),Kc=document.querySelector(`#weapon-reveal-detail`),qc=document.querySelector(`#weapon-reveal-continue`),Jc=document.querySelector(`#weapon-slot-count`),Yc=document.querySelector(`#weapon-loadout`),Xc=document.querySelector(`#weapon-card-list`),Zc=document.querySelector(`#weapon-hud`),Qc=document.querySelector(`#open-settings-button`),$c=document.querySelector(`#exit-game-button`),el=document.querySelector(`#settings-panel`),tl=document.createElement(`div`);tl.className=`settings-section`,tl.innerHTML=`<h3>${N(`settings.language`)}</h3><div class="settings-row"><div><strong>${N(`settings.language`)}</strong><small>${N(`settings.language_help`)}</small></div><select id="language-select" class="language-select" aria-label="${N(`settings.language`)}"></select></div>`,el.querySelector(`.lab-header`)?.after(tl);var nl=document.querySelector(`#language-select`),rl=document.querySelector(`#display-mode-options`),il=document.querySelector(`#display-resolution-options`),al=document.querySelector(`#close-settings-button`),ol=document.querySelector(`#open-patch-notes-button`),sl=document.querySelector(`#patch-notes-panel`),cl=document.querySelector(`#close-patch-notes-button`),ll=document.querySelector(`#graphics-quality-options`),ul=document.querySelector(`#setting-shadows`),dl=document.querySelector(`#setting-hdr-emission`),fl=document.querySelector(`#hdr-emission-value`),pl=document.querySelector(`#setting-max-fps`),ml=document.querySelector(`#max-fps-value`),hl=document.querySelector(`#setting-auto-pause`),gl=document.querySelector(`#setting-high-contrast`),_l=document.querySelector(`#setting-master-volume`),vl=document.querySelector(`#master-volume-value`),yl=document.querySelector(`#setting-muted`),bl=document.querySelector(`#setting-spatial-audio`),xl=document.querySelector(`#building-panel`),Sl=document.querySelector(`#close-building-button`),Cl=document.querySelector(`#building-list`),wl=document.querySelector(`#building-cash`),Tl=document.querySelector(`#building-chronoshards`),El=document.querySelector(`#building-slots`),Dl=document.querySelector(`#enter-build-mode`),Ol=document.querySelector(`#open-building-draft`),kl=document.querySelector(`#building-draft-modal`),Al=document.querySelector(`#close-building-draft`),jl=document.querySelector(`#building-draft-chronoshards`),Ml=document.querySelector(`#building-draft-list`),Nl=document.querySelector(`#build-bar`),Pl=document.querySelector(`#build-status`),Fl=document.querySelector(`#build-options`),Il=document.querySelector(`#build-grid-ui`),Ll=document.querySelector(`#exit-build-mode`),Rl=document.querySelector(`#building-upgrade`),zl=document.querySelector(`#close-lab-button`),Bl=document.querySelector(`#lab-cash`),Vl=document.querySelector(`#lab-chronoshard-balance`),Hl=document.querySelector(`#lab-chronoshards`),Ul=document.querySelector(`#lab-message`);function Wl(){let e=(e,t)=>{let n=document.querySelector(e);n&&(n.textContent=N(t))};e(`.cash-balance .currency-label`,`hud.cash`),e(`.chronoshard-balance .currency-label`,`hud.chronoshards`),e(`.run-cell-counter dt`,`hud.cells`),e(`#pause-menu .eyebrow`,`menu.round_paused`),e(`#pause-menu h2`,`menu.pause`),e(`#reset-round-button`,`menu.reset`),e(`#surrender-button`,`menu.surrender`),e(`#resume-game-button`,`menu.return`),e(`#return-menu-button`,`menu.main_menu`),e(`#start-button`,`menu.start_run`),e(`#anomaly-run-button`,`anomaly.run`),e(`#cancel-anomaly-run`,`menu.back`),e(`#confirm-anomaly-run`,`anomaly.start`),e(`#close-settings-button`,`menu.back`),e(`#open-patch-notes-button`,`settings.patch_notes`),e(`#close-milestones-button`,`menu.back`),e(`#close-lab-button`,`menu.back`),e(`#close-encyclopedia-button`,`menu.back`),e(`#encyclopedia-panel .eyebrow`,`encyclopedia.threat_database`),e(`#encyclopedia-panel h2`,`menu.encyclopedia`),e(`#close-artifacts-button`,`menu.back`),e(`#close-artifact-detail-button`,`menu.back`),e(`#close-building-button`,`menu.back`),e(`#close-weaponry-button`,`menu.back`),e(`#close-patch-notes-button`,`menu.back`),e(`#patch-notes-panel h2`,`menu.patch_notes`);let t=document.querySelector(`#patch-notes-panel .eyebrow`);t&&(t.textContent=N(`patch_notes.version_build`,{version:na.version,build:na.number})),e(`#research-slots-heading`,`research.active_slots`),e(`#lab-panel h3:not(#research-slots-heading)`,`research.available_research`),e(`.research-search > span`,`research.search`);let n=document.querySelector(`#research-search`);n&&(n.placeholder=N(`research.search_placeholder`)),e(`#hide-completed-researches + span`,`research.hide_completed`),e(`#hide-locked-researches + span`,`research.hide_locked`),e(`#artifact-panel .eyebrow`,`artifact.permanent_achievements`),e(`#artifact-panel .artifact-intro`,`artifact.intro`),e(`#building-panel .eyebrow`,`building.permanent_defenses`),e(`#building-panel h2`,`building.system`),e(`#enter-build-mode`,`building.build_mode`),e(`#open-building-draft`,`building.unlock_a_building`),e(`#building-panel h3`,`building.unlocked_buildings`),e(`#building-draft-modal .eyebrow`,`building.permanent_defenses`),e(`#building-draft-modal h2`,`building.draft`),e(`#weaponry-panel .eyebrow`,`weapon.active_arsenal`),e(`#weaponry-panel h2`,`menu.weaponry`);let r=document.querySelectorAll(`#weaponry-panel h3`);r[0]&&(r[0].childNodes[0].textContent=`${N(`weapon.round_loadout`)} `),r[1]&&(r[1].textContent=N(`weapon.cards`)),e(`.controls-desktop span:nth-child(1) b`,`controls.move`),e(`.controls-desktop span:nth-child(2) b`,`controls.navigate`),e(`.controls-desktop span:nth-child(3) b`,`controls.use_weapon`),e(`.controls-mobile span:nth-child(1) b`,`controls.move`),e(`.controls-mobile span:nth-child(2) b`,`controls.select_weapon`);let i=(e,t)=>{let n=document.querySelector(e);n&&n.setAttribute(`aria-label`,N(t))};i(`#game`,`accessibility.game_canvas`),i(`#hud-sector`,`accessibility.current_sector`),i(`#pause-button`,`accessibility.pause_game`),i(`#shield-indicators`,`accessibility.shield_charges`),i(`.instructions`,`accessibility.game_controls`),i(`.build-footer`,`accessibility.build_information`),i(`#build-grid-ui`,`accessibility.build_locations`),i(`#pause-menu`,`accessibility.pause_menu`),i(`#cheat-console`,`accessibility.debug_console`),i(`#close-cheat-console`,`accessibility.close_debug_console`),i(`#save-slot-select`,`accessibility.save_slots`),i(`#death-killer-canvas`,`accessibility.defeating_enemy`),i(`.sector-selection`,`accessibility.sector_selection`),i(`#previous-sector`,`accessibility.previous_sector`),i(`#next-sector`,`accessibility.next_sector`),i(`#previous-milestone-sector`,`accessibility.previous_milestone_sector`),i(`#next-milestone-sector`,`accessibility.next_milestone_sector`);let a=document.querySelector(`#cheat-output`);a&&(a.textContent=N(`cheat.prompt`));let o=document.querySelector(`#cheat-input`);o&&(o.placeholder=N(`cheat.placeholder`)),[[`#graphics-quality-options`,`settings.graphics`],[`#setting-max-fps`,`settings.graphics`],[`#setting-master-volume`,`settings.sound`]].forEach(([e,t])=>{let n=document.querySelector(e)?.closest(`.settings-section`);n&&(n.querySelector(`h3`).textContent=N(t))}),[[`#graphics-quality-options`,`settings.quality`,`settings.quality_help`],[`#setting-shadows`,`settings.shadows`,`settings.shadows_help`],[`#setting-hdr-emission`,`settings.hdr_emission`,`settings.hdr_emission_help`],[`#setting-max-fps`,`settings.max_fps`,`settings.max_fps_help`],[`#setting-auto-pause`,`settings.auto_pause`,`settings.auto_pause_help`],[`#setting-high-contrast`,`settings.high_contrast_hud`,`settings.high_contrast_hud_help`],[`#setting-master-volume`,`settings.master_volume`,`settings.master_volume_help`],[`#setting-muted`,`settings.mute_all`,`settings.mute_all_help`],[`#setting-spatial-audio`,`settings.spatial_audio`,`settings.spatial_audio_help`]].forEach(([e,t,n])=>{let r=document.querySelector(e)?.closest(`.settings-row`);if(!r)return;let i=r.querySelector(`strong`),a=r.querySelector(`small`);i&&(i.textContent=N(t)),a&&(a.textContent=N(n))})}Wl();var Gl=document.querySelector(`#research-slots`),Kl=document.querySelector(`#research-slots-heading`),ql=document.querySelector(`#research-list`),Jl=document.querySelector(`#research-search`),Yl=document.querySelector(`#hide-completed-researches`),Xl=document.querySelector(`#hide-locked-researches`),Zl=document.querySelector(`#cheat-console`),Ql=document.querySelector(`#cheat-input`),$l=document.querySelector(`#cheat-output`),eu=document.querySelector(`#close-cheat-console`),tu=document.querySelector(`#pause-menu`),nu=document.querySelector(`#reset-round-button`),ru=document.querySelector(`#surrender-button`),iu=document.querySelector(`#resume-game-button`),au=document.querySelector(`#return-menu-button`),ou=document.querySelector(`#cash`),su=document.querySelector(`#chronoshards`),cu=document.querySelector(`#aetherium`),lu=document.querySelector(`#aetherium-ad-claim`);document.querySelector(`#debug-reward-screen`),document.querySelector(`#debug-reward-countdown`),document.querySelector(`#debug-reward-granted`);var uu=document.querySelector(`#cash-indicators`),du=document.querySelector(`#highest-cells`),fu=document.querySelector(`#sector-requirement`),pu=document.querySelector(`#sector-options`),mu=document.querySelector(`#previous-sector`),hu=document.querySelector(`#next-sector`),gu=document.querySelector(`#virtual-joystick`),_u=document.querySelector(`#onboarding-directive`),vu=null,yu=null,bu=null,xu=null,Su=new Map;function Cu(){_u.classList.remove(`hidden`),requestAnimationFrame(()=>_u.classList.add(`is-visible`))}function wu(){_u.classList.remove(`is-visible`),window.setTimeout(()=>_u.classList.add(`hidden`),260)}function Tu(){document.querySelectorAll(`.onboarding-highlight`).forEach(e=>e.classList.remove(`onboarding-highlight`));for(let[e,t]of Su)e.disabled=t,e.classList.remove(`onboarding-disabled`);Su.clear()}function Eu(e){e&&e.classList.add(`onboarding-highlight`)}function Du(){return qa.filter(e=>!V.claimed.includes(e.id)&&(gd[od[e.sector-1]]??0)>=e.cells).map(e=>e.id)}function Ou(){let e=yu??bu??xu;if(!e)return;let t=t=>e.mode===`run-again`||e.mode===`start-run`?t===Us:e.mode===`next-sector`?t===hu:e.mode===`research-entry`?t===bc:e.mode===`research-category`?t.matches(`[data-toggle-research-category="Player Enhancements"]`):e.mode===`research-upgrade`?t.matches(`[data-start-research="player-speed-multiplier"]`):e.mode===`ascension-entry`?t===sc:t.matches(`[data-claim-milestone]`);document.querySelectorAll(`button`).forEach(e=>{t(e)||(Su.has(e)||Su.set(e,e.disabled),e.disabled=!0,e.classList.add(`onboarding-disabled`))})}function ku(){if(yu?.mode!==`ascension-claims`)return;Tu();let e=[...dc.querySelectorAll(`[data-claim-milestone]`)];e.forEach(e=>e.classList.add(`onboarding-highlight`)),Eu(e[0]),Ou()}function Au(){let e=Du();yu=e.length>0?{mode:`ascension-entry`,claimableMilestoneIds:e}:{mode:`run-again`},Tu(),Eu(yu.mode===`run-again`?Us:sc),Ou()}function ju(){yu=null,Tu(),vu?.completeActiveStep(),pd()>=1&&(cc.classList.add(`hidden`),$s.classList.remove(`hidden`),vu?.start(`sector-2-unlocked`))}function Mu(){bu={mode:`next-sector`},Tu(),hu.disabled=!1,Eu(hu),Ou()}function Nu(){bu=null,Tu(),vu?.completeActiveStep()}function Pu(){xu={mode:`research-entry`},Tu(),Eu(bc),Ou()}function Fu(e,t){xu&&(xu.mode=e,Tu(),Eu(t),Ou())}function Iu(){xu=null,Tu(),yc.classList.add(`hidden`),$s.classList.remove(`hidden`),Fv(),vu?.completeActiveStep()}document.addEventListener(`click`,e=>{let t=yu??bu??xu;if(!t)return;let n=e.target.closest(`button`);(t.mode===`run-again`||t.mode===`start-run`?n===Us:t.mode===`next-sector`?n===hu:t.mode===`research-entry`?n===bc:t.mode===`research-category`?n?.matches(`[data-toggle-research-category="Player Enhancements"]`):t.mode===`research-upgrade`?n?.matches(`[data-start-research="player-speed-multiplier"]`):t.mode===`ascension-entry`?n===sc:n?.matches(`[data-claim-milestone]`))||(e.preventDefault(),e.stopImmediatePropagation())},!0);var Lu=``;function Ru(){let e=Ua.filter(e=>e!==Lu),t=e[Math.floor(Math.random()*e.length)]??Ua[0];return Lu=t,t}var zu=`asteroid-belt-active-save-slot`,Bu=`asteroid-belt-save-slot-session`,Vu=3;Mo(localStorage),ka(),Uo();var Hu=1,{cellBank:Uu,sector:Wu,sectorHighScores:Gu,cash:Ku,chronoshards:qu,aetherium:Ju,aetheriumAdClaimAt:Yu,researchLab:Xu,savedRound:Zu,buildings:Qu,featureUnlocks:$u,milestones:ed,settings:td,weaponry:nd,anomalyRewards:rd,artifacts:id,dailyMissions:ad}=wa,od=Object.keys(Pi);function sd(){let e=Ma(Zu);return e&&typeof e==`object`?e:null}function cd(e){Na(Zu,e)}function ld(){let e=Ma(Gu,{});return!e||typeof e!=`object`?{}:Object.fromEntries(od.map(t=>[t,Number.isFinite(e[t])&&e[t]>=0?e[t]:0]))}function ud(){Na(Gu,gd)}function dd(){try{let e=JSON.parse(window.localStorage.getItem(ed));return!e||typeof e!=`object`?{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}:{version:Number(e.version)||0,claimed:Array.isArray(e.claimed)?e.claimed.filter(e=>qa.some(t=>t.id===e)):[],researchUnlocks:Array.isArray(e.researchUnlocks)?e.researchUnlocks.filter(e=>qa.some(t=>t.rewards.some(t=>t.type===`research`&&t.researchIds.includes(e)))):[],debugAscensionsGranted:!!e.debugAscensionsGranted}}catch{return{version:0,claimed:[],researchUnlocks:[],debugAscensionsGranted:!1}}}function fd(){Na(ed,V)}function pd(){return qa.filter(e=>V.claimed.includes(e.id)).flatMap(e=>e.rewards.filter(e=>e.type===`sector`).map(e=>e.sector-1)).reduce((e,t)=>Math.max(e,t),0)}function md(e){return pd()+1>=e}var hd=Aa(Uu),gd=ld(),_d=(()=>{let e=Ma(id,{}),t=new Set(Za.artifacts.map(e=>e.id));return{unlocked:Array.isArray(e?.unlocked)?e.unlocked.filter(e=>t.has(e)):[],resetAtScores:e?.resetAtScores&&typeof e.resetAtScores==`object`?e.resetAtScores:{},stackCounts:e?.stackCounts&&typeof e.stackCounts==`object`?e.stackCounts:null}})(),V=dd();V.version!==3&&(V.claimed=qa.filter(e=>(gd[od[e.sector-1]]??0)>=e.cells).map(e=>e.id),V.version=3,fd());var H=Math.min(Aa(Wu),pd()),vd=H,yd=Aa(Ku),bd=Aa(qu),xd=Aa(Ju),Sd=Aa(Yu),U=sd(),Cd=null,wd=(()=>{let e=Ma(rd,{}),t=e&&typeof e.claimedSectors==`object`?e.claimedSectors:{},n=Object.entries(t).flatMap(([e,t])=>(Array.isArray(t)?t:[]).map(t=>`${ia.challenges[Number(e)%ia.challenges.length]?.id??`cell-scout`}:sector${Number(t)+1}`));return{claimedSectors:t,darkCoreClaims:Array.isArray(e?.darkCoreClaims)?e.darkCoreClaims:[...new Set(n)]}})();if(!_d.stackCounts){let e=Object.values(wd.claimedSectors).reduce((e,t)=>e+(Array.isArray(t)?new Set(t).size:0),0);_d.stackCounts={"dark-core":e},e>0&&!_d.unlocked.includes(`dark-core`)&&_d.unlocked.push(`dark-core`),Na(id,_d)}var Td=null,Ed=!1,Dd=0;function Od(){return ia.challenges.find(e=>e.id===Td?.challengeId)??null}function kd(){return Od()?.type===`tower-defense`}var Ad=(()=>{try{let e=JSON.parse(localStorage.getItem($u));return{researchLab:!!e?.researchLab,buildingSystem:!!e?.buildingSystem,weaponry:!!e?.weaponry}}catch{return{researchLab:!1,buildingSystem:!1,weaponry:!1}}})();V.claimed.includes(`sector-1-10`)&&!Ad.researchLab&&(Ad.researchLab=!0,yf());var W=(()=>{try{let e=JSON.parse(localStorage.getItem(nd));return{cards:e?.cards??{},loadout:Array.isArray(e?.loadout)?e.loadout:[],selected:e?.selected??0}}catch{return{cards:{},loadout:[],selected:0}}})(),jd=[],Md=0,G=(()=>{try{let e=JSON.parse(localStorage.getItem(Qu));return e?.unlocked?e:{unlocked:[],placed:[]}}catch{return{unlocked:[],placed:[]}}})(),Nd=G.placed.filter(e=>e.type===`gapGenerator`);if(Nd.length){yd+=Nd.reduce((e,t)=>e+(t.spent??260),0),G.placed=G.placed.filter(e=>e.type!==`gapGenerator`),G.unlocked=G.unlocked.filter(e=>e!==`gapGenerator`);try{localStorage.setItem(Ku,String(yd)),localStorage.setItem(Qu,JSON.stringify(G))}catch{}}function Pd(){let e={language:qi(),graphics:{quality:`high`,shadows:!0,hdrEmissionIntensity:.5},gameplay:{maxFps:120,autoPause:!0,highContrastHud:!1},sound:{masterVolume:100,muted:!1,spatialAudio:!0}};try{let t=JSON.parse(localStorage.getItem(td)),n=t?.graphics??{},r=t?.gameplay??{},i=Number.isFinite(n.hdrEmissionIntensity)?C.clamp(n.hdrEmissionIntensity,0,1):n.hdrEmission===!1?0:.5,a=Number.isFinite(r.maxFps)?C.clamp(r.maxFps,0,240):e.gameplay.maxFps;return{language:Zi().includes(t?.language)?t.language:e.language,graphics:{...e.graphics,...n,hdrEmissionIntensity:i},gameplay:{...e.gameplay,...r,maxFps:a},sound:{...e.sound,...t?.sound}}}catch{return e}}var K=Pd();Xi(K.language);function Fd(){Na(td,K)}var Id=Object.keys(da.types);G.unlocked=[...new Set(G.unlocked.filter(e=>Id.includes(e)))],G.placed=G.placed.filter(e=>Id.includes(e.type)),G.unlockCount=Number.isFinite(G.unlockCount)?G.unlockCount:G.unlocked.length,G.unlockOffers=Array.isArray(G.unlockOffers)?G.unlockOffers.filter(e=>Id.includes(e)&&!G.unlocked.includes(e)):[];var Ld=new Map,Rd=new Map,zd=!1,Bd=null,Vd=``,Hd=!1,Ud=!1,Wd=new Set;function Gd(){return{unlockedSlots:1,levels:{},slots:Array(ea.maxSlots).fill(null)}}function Kd(){try{let e=JSON.parse(window.localStorage.getItem(Xu));return!e||typeof e!=`object`?Gd():{unlockedSlots:C.clamp(Number.parseInt(e.unlockedSlots,10)||1,1,ea.maxSlots),levels:e.levels&&typeof e.levels==`object`?e.levels:{},slots:Array.from({length:ea.maxSlots},(t,n)=>e.slots?.[n]??null)}}catch{return Gd()}}var qd=Kd(),Jd=!1;function Yd(){Na(Xu,qd)}var{getResearchById:Xd,getResearchLevel:Zd,getResearchStatBonus:Qd,getResearchCost:$d,getResearchDuration:ef,getResearchLockReason:tf,isResearchVisible:nf,compareResearchProgression:rf}=La({config:ea,milestones:qa,getResearchState:()=>qd,getMilestoneState:()=>V,getBankedCells:()=>hd});function af(e){return Za.artifacts.filter(t=>_d.unlocked.includes(t.id)&&t.buff.stat===e).reduce((e,t)=>e+t.buff.amount*of(t),0)}function of(e){return e.repeatable?Math.max(0,Number(_d.stackCounts?.[e.id])||0):1}function q(e){return Qd(e)+af(e)}function sf(e,t){if(e.id===`player-speed-multiplier`&&t===0)return 0;let n=$d(e,t)*Math.max(0,1-af(`researchCostReduction`));return e.cost.currency===`cash`?Math.round(n*100)/100:Math.ceil(n)}function cf(e,t){let n={chaser:`chaserRangeDebuff`,banger:`bangerRangeDebuff`,shooter:`shooterRangeDebuff`}[e];return n?t*Math.max(.5,1-q(n)):t}function lf(){let e=Date.now(),t=!1,n=[];for(let r=0;r<qd.unlockedSlots;r+=1){let i=qd.slots[r];if(!i||ea.durationsEnabled&&i.completesAt>e)continue;let a=Xd(i.researchId);qd.levels[i.researchId]=Math.min(Zd(i.researchId)+1,a.maxLevel),qd.slots[r]=null,n.push(a.name),t=!0}return t&&Yd(),n.length&&uf(n.map(e=>N(`cheat.research_completed`,{research:e})).join(` `)),t}function uf(e=``){Ul.textContent=e}function df(){lf(),Bl.textContent=`$${P(yd)}`,Hl.textContent=`✦ ${P(bd)}`,Vl.hidden=!ea.durationsEnabled;let e=Date.now();Kl.hidden=!ea.durationsEnabled,Gl.hidden=!ea.durationsEnabled,Gl.innerHTML=ea.durationsEnabled?qd.slots.map((t,n)=>{let r=n+1;if(t){let n=Xd(t.researchId),i=ef(n,t.level),a=Math.max(0,t.completesAt-e),o=C.clamp(1-a/i,0,1)*100;return`<article class="research-slot active"><span>${N(`research.slot`,{slot:r})}</span><strong>${n.name} · ${N(`weapon.level`,{level:t.level+1})}</strong><div class="research-progress"><i style="width:${o}%"></i></div><small>${N(`research.remaining`,{duration:Va(a)})}</small></article>`}if(r<=qd.unlockedSlots)return`<article class="research-slot"><span>${N(`research.slot`,{slot:r})}</span><strong>${N(`research.available`)}</strong><small>${N(`research.select_below`)}</small></article>`;let i=ea.slotUnlocks.find(e=>e.slot===r),a=!i.requirements?.minSector||md(i.requirements.minSector),o=i.cost.currency===`cash`?yd>=i.cost.amount:bd>=i.cost.amount,s=a&&o?``:`disabled`,c=a?N(`research.unlock_for`,{cost:Ha(i.cost.currency,i.cost.amount)}):N(`research.unlock_sector`,{sector:Ia(i.requirements.minSector)});return`<article class="research-slot locked"><span>${N(`research.slot`,{slot:r})}</span><strong>${N(`research.locked`)}</strong><button data-unlock-slot="${r}" type="button" ${s}>${c}</button></article>`}).join(``):``;let t=new Map;for(let e of ea.researches.filter(nf)){let n=e.category??`General`;t.set(n,[...t.get(n)??[],e])}let n=Vd.trim().toLocaleLowerCase(),r=[...t.entries()].sort(([e],[t])=>{let n=ea.categoryOrder.indexOf(e),r=ea.categoryOrder.indexOf(t);return(n<0?1e3:n)-(r<0?1e3:r)}).map(([e,t])=>[e,t.filter(e=>`${e.name} ${e.description}`.toLocaleLowerCase().includes(n)).filter(e=>!Hd||Zd(e.id)<e.maxLevel).filter(e=>!Ud||!tf(e)).sort(rf)]).filter(([,e])=>e.length);ql.innerHTML=r.length?r.map(([e,t])=>{let r=n||Wd.has(e);return`<section class="research-category ${r?`open`:``}"><button class="research-category-toggle" data-toggle-research-category="${e}" type="button" aria-expanded="${r}"><span>${e}</span><i aria-hidden="true">›</i></button><div class="research-grid">${t.map(e=>{let t=Zd(e.id),n=tf(e),r=ea.durationsEnabled&&qd.slots.some(t=>t?.researchId===e.id),i=t>=e.maxLevel,a=sf(e,t),o=ef(e,t),s=Jd||(e.cost.currency===`cash`?yd>=a:bd>=a),c=ea.durationsEnabled&&!qd.slots.slice(0,qd.unlockedSlots).some(e=>!e),l=n||r||i||!s||c,u=n||r||i||c?`research-locked`:s?`research-affordable`:`research-unaffordable`,d=e.id===`player-speed-multiplier`&&t===0,f=i?N(`research.max_level`):r?N(`research.in_progress`):n||(Jd||d?N(`research.free_enabled`):N(`research.cost`,{cost:`${Ha(e.cost.currency,a)}${ea.durationsEnabled?` · ${Va(o)}`:``}`}));return`<article class="research-card"><div><span class="research-level">${N(`weapon.level`,{level:t})}/${e.maxLevel}</span><h4>${e.name}</h4><p>${e.description}</p><p class="research-effect">${Ba(e,t)} → ${Ba(e,Math.min(t+1,e.maxLevel))}</p><small>${f}</small></div><button class="${u}" data-start-research="${e.id}" type="button" ${l?`disabled`:``}>${N(i?`research.maxed`:`research.start`)}</button></article>`}).join(``)}</div></section>`}).join(``):`<p class="research-empty">${N(`research.no_search_results`)}</p>`}function ff(e){lf();let t=Xd(e),n=Zd(e),r=tf(t),i=qd.slots.slice(0,qd.unlockedSlots).findIndex(e=>!e),a=sf(t,n),o=t.cost.currency===`cash`?yd:bd,s=ea.durationsEnabled&&qd.slots.some(t=>t?.researchId===e);return r||n>=t.maxLevel||ea.durationsEnabled&&i<0||s||!Jd&&o<a?!1:(Jd||(t.cost.currency===`cash`?Rf(-a):zf(-a)),ea.durationsEnabled?qd.slots[i]={researchId:e,level:n,completesAt:Date.now()+ef(t,n)}:(qd.levels[e]=Math.min(n+1,t.maxLevel),e===`shield`&&Q&&(Mh+=1,vm.visible=!0)),Yd(),uf(ea.durationsEnabled?N(`research.started`,{research:t.name,slot:i+1}):N(`research.upgraded`,{research:t.name,level:n+1})),df(),!0)}function pf(e){let t=ea.slotUnlocks.find(t=>t.slot===e);!t||e!==qd.unlockedSlots+1||t.requirements?.minSector&&!md(t.requirements.minSector)||(t.cost.currency===`cash`?yd:bd)<t.cost.amount||(t.cost.currency===`cash`?Rf(-t.cost.amount):zf(-t.cost.amount),qd.unlockedSlots=e,Yd(),uf(N(`research.slot_unlocked`,{slot:e})),df())}function J(e){$l.textContent=e}function mf(e){if(!ta.enabled)return;let t=e??Zl.classList.contains(`hidden`);Zl.classList.toggle(`hidden`,!t),t&&(Rm.clear(),Ql.focus(),Ql.select())}function hf(){yd=0,bd=0,Rf(),zf()}function gf(){hd=0,H=0,V.claimed=[],V.researchUnlocks=[],V.debugAscensionsGranted=!1;for(let e of od)gd[e]=0;ja(Uu,hd),ja(Wu,H),ud(),fd(),fm(),lp(),mp(),lv()}function _f(){V.claimed=[],V.researchUnlocks=[],V.debugAscensionsGranted=!1,V.version=3;for(let e of od)gd[e]=0;H=0,ja(Wu,H),ud(),fd(),fm(),lp(),mp(),df(),lv()}function vf(){qd.unlockedSlots=1,qd.levels={},qd.slots=Array(ea.maxSlots).fill(null),Jd=!1,Yd(),df()}function yf(){Na($u,Ad)}function bf(){Ad={researchLab:!1,buildingSystem:!1,weaponry:!1},yf(),Ef()}function xf(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches&&window.innerHeight>=window.innerWidth}var Sf;function Cf(e,t){mc.textContent=t;let n=Us.getBoundingClientRect(),r=Ws.getBoundingClientRect();mc.style.left=`${window.innerWidth/2}px`,mc.style.top=`${Math.min(window.innerHeight-12,Math.max(n.bottom,r.bottom)+12)}px`,mc.classList.remove(`hidden`),window.clearTimeout(Sf),Sf=window.setTimeout(()=>mc.classList.add(`hidden`),4e3)}function wf(e){let t=ea.featureUnlocks[e];if(pd()+1<t.minSector)return N(`cheat.feature_sector`,{sector:Ia(t.minSector)});if(t.requiredMilestone&&!V.claimed.includes(t.requiredMilestone)){let e=qa.find(e=>e.id===t.requiredMilestone);if(e)return N(`cheat.feature_cells`,{cells:e.cells,sector:Ia(e.sector)})}return bd<t.chronoshardCost?N(`cheat.feature_chronoshards`,{amount:t.chronoshardCost}):N(`cheat.feature_unavailable`)}function Tf(e,t){return Ad[e]||Df(e)?!0:(Cf(t,wf(e)),!1)}function Ef(){let e=!!U;for(let[t,n]of[[`researchLab`,bc],[`buildingSystem`,Sc],[`weaponry`,Cc]]){let r=ea.featureUnlocks[t],i=Ad[t],a=pd()+1>=r.minSector&&(!r.requiredMilestone||V.claimed.includes(r.requiredMilestone)),o=N(t===`researchLab`?`menu.research_lab`:t===`buildingSystem`?`menu.buildings`:`menu.weaponry`);n.className=`menu-system-button ${i?`is-unlocked`:a?`is-unlockable`:`is-locked`}${e?` is-round-locked`:``}${n.classList.contains(`is-active`)?` is-active`:``}`,n.disabled=e,n.querySelector(`.menu-button-label`).textContent=i?o:a?N(`menu.unlock_feature`,{feature:o,cost:r.chronoshardCost}):N(`menu.feature_sector`,{feature:o,sector:Ia(r.minSector)});let s=n.querySelector(`.menu-button-lock`);s.hidden=i||!xf(),s.innerHTML=a?`<span class="chronoshard-symbol" aria-hidden="true">✦</span><span>${r.chronoshardCost}</span>`:`<span>SECTOR ${Ia(r.minSector)}</span>`}}function Df(e){let t=ea.featureUnlocks[e];return Ad[e]||pd()+1<t.minSector||t.requiredMilestone&&!V.claimed.includes(t.requiredMilestone)||bd<t.chronoshardCost?!1:(zf(-t.chronoshardCost),Ad[e]=!0,yf(),Ef(),!0)}function Of(){G={unlocked:[],placed:[],unlockCount:0,unlockOffers:[]},Bd=null,Hg(),e_(),s_()}function kf(e=0){Cd={sectorIndex:C.clamp(e,0,od.length-1),simulation:new Set},Td=null,fv(),fm(),lv(!1),Q=!0,yh=!1,$=!1,X.visible=!0,$s.classList.remove(`hidden`),Fs.classList.add(`hidden`),tu.classList.add(`hidden`),Hp(),bv()}function Af(e){let t=ia.challenges.find(t=>t.id===e);return t?(Cd=null,fv(),Td={challengeId:t.id,weekId:`debug-${t.id}`},fm(),lv(),Q=!0,yh=!1,$=!1,X.visible=!0,Fs.classList.add(`hidden`),tu.classList.add(`hidden`),Hp(),bv(),!0):!1}function jf(e){let[t,n]=e;if(!t){kf(),J(N(`cheat.sandbox_started`));return}let r=Number(t);if(Number.isInteger(r)){Cd?(Cd.sectorIndex=C.clamp(r-1,0,od.length-1),fm(),bv()):kf(r-1),J(N(`cheat.sandbox_sector`,{sector:Ia(Cd.sectorIndex+1)}));return}if(!Cd){J(N(`cheat.sandbox_start_first`));return}if(t===`simulate`){if(![`cell`,`enemies`,`all`].includes(n)){J(N(`cheat.sandbox_simulate_usage`));return}Cd.simulation=n===`all`?new Set([`cell`,`enemies`,`boosters`]):new Set([n]),J(N(`cheat.sandbox_simulation`,{type:n,sector:Ia(Cd.sectorIndex+1)}));return}if(t===`spawn`){let t=Object.keys(zi).find(e=>e.toLocaleLowerCase()===n?.toLocaleLowerCase()),r=Number(e[2]??1),i=Number.isInteger(r)?C.clamp(r,1,100):0;if(!t||!i){J(N(`cheat.sandbox_spawn_usage`,{enemies:Object.keys(zi).join(`, `)}));return}for(let e=0;e<i;e+=1)D_(Vg(k.obstacleMinDistance),t);J(N(`cheat.sandbox_spawned`,{count:i,enemy:t,plural:i===1?``:` enemies`}));return}J(N(`cheat.sandbox_usage`))}function Mf(e){if(e.length<2){J(N(`cheat.artifact_usage`));return}let t=Number(e.at(-1)),n=e.slice(0,-1).join(`-`).replaceAll(`_`,`-`).toLowerCase(),r=Za.artifacts.find(e=>e.id.toLowerCase()===n||e.name.replaceAll(` `,`-`).toLowerCase()===n);if(!r){J(N(`cheat.artifact_unknown`,{artifact:e.slice(0,-1).join(` `)}));return}if(!Number.isInteger(t)||t<=0||t>1e4){J(N(`cheat.artifact_stack_range`));return}if(r.repeatable){_d.stackCounts[r.id]=of(r)+t,_d.unlocked.includes(r.id)||(_d.unlocked=[..._d.unlocked,r.id]),Zf(),sp(),J(N(`cheat.artifact_granted`,{count:t,artifact:r.name,stackWord:t===1?`stack`:`stacks`,total:of(r)}));return}_d.unlocked.includes(r.id)||np(r),J(N(`cheat.artifact_unique`,{artifact:r.name}))}function Nf(e){if(!Q||yh){J(N(`cheat.spawn_requires_round`));return}let t=_h.get(e[0]?.toLocaleLowerCase());if(!t||e.length!==1){J(N(`cheat.spawn_usage`,{entities:[..._h.values()].map(e=>e.id).join(`, `)}));return}t.spawn(),J(N(`cheat.spawned`,{entity:t.id}))}function Pf(e){let[t,...n]=e.trim().toLowerCase().split(/\s+/),r=n[0];if(!t)return;if(t===ta.commands.triggerMission||t===`trigger_mission`){J(N(`missions.debug_added`,{count:rc.triggerMidnight()}));return}if(t===ta.commands.completeRandomMission){J(N(rc.completeRandom()?`missions.debug_completed`:`missions.debug_none`));return}if(t===ta.commands.sandbox){jf(n);return}if(t===ta.commands.gainArtifact){Mf(n);return}if(t===ta.commands.spawn){Nf(n);return}if(t===ta.commands.anomaly){let e=n.join(`-`);if(!e){J(N(`cheat.anomaly_usage`));return}if(!Af(e)){J(N(`cheat.anomaly_unknown`,{id:e,available:ia.challenges.map(e=>e.id).join(`, `)}));return}J(N(`cheat.anomaly_started`,{id:e,sector:Ia(H+1)})),mf(!1);return}if(t===ta.commands.cell){let e=Number(n[0]);if(!Number.isInteger(e)||e<=0){J(N(`cheat.cell_usage`));return}if(!Q||yh){J(N(`cheat.cell_requires_round`));return}Sh+=e,bv(),Og(),kd()&&Sh>=(Od()?.rewardCellTarget??1e3)&&yv(!0),J(N(`cheat.cell_granted`,{amount:e,total:Sh}));return}if(t===ta.commands.cellObtain){let e=Number(n[0]);if(!Number.isInteger(e)||e<=0||e>1e4){J(N(`cheat.cell_obtain_usage`));return}Ch=e,J(N(`cheat.cell_obtain_set`,{amount:e}));return}if(t===ta.commands.god){let e=n[0];if(![`on`,`off`].includes(e)){J(N(`cheat.god_usage`));return}Ed=e===`on`,J(N(`cheat.god_state`,{state:N(Ed?`cheat.on`:`cheat.off`)}));return}let i=Number(r);if(t===ta.commands.cash||t===ta.commands.chrono){if(!Number.isFinite(i)||i<=0){J(N(`cheat.amount_usage`,{command:t}));return}t===ta.commands.cash?Rf(i):zf(i),J(N(`cheat.amount_granted`,{amount:`${t===ta.commands.cash?`$`:`✦ `}${i.toLocaleString()}`}));return}if(t===ta.commands.freeResearch){Jd=!0,df(),J(N(`cheat.free_research`));return}if(t===ta.commands.unlockSectors){let e=qa.filter(e=>!V.claimed.includes(e.id)),t=V.debugAscensionsGranted?e:qa;V.claimed=qa.map(e=>e.id),V.researchUnlocks=[...new Set(qa.flatMap(e=>e.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)))],V.debugAscensionsGranted=!0;let n=t.flatMap(e=>e.rewards).filter(e=>e.type===`cash`).reduce((e,t)=>e+t.amount,0),r=t.flatMap(e=>e.rewards).filter(e=>e.type===`chronoshards`).reduce((e,t)=>e+t.amount,0);n&&Rf(n),r&&zf(r),fd(),lp(),df(),mp(),J(N(`cheat.sectors_unlocked`,{rewards:n||r?` +$${P(n)} · +✦ ${P(r)}`:``}));return}if(t===ta.commands.clearSave){if(!ta.clearSaveTargets.includes(r)){J(N(`cheat.clear_usage`,{targets:ta.clearSaveTargets.join(`, `)}));return}(r===`currency`||r===`all`)&&hf(),(r===`game_progress`||r===`all`)&&gf(),(r===`milestones`||r===`all`)&&_f(),(r===`research`||r===`all`)&&vf(),(r===`buildings`||r===`all`)&&Of(),(r===`weapons`||r===`all`)&&qg(),(r===`artifacts`||r===`all`)&&Qf(),r===`all`&&(localStorage.removeItem(ad),bf(),vs()),window.location.reload();return}J(N(`cheat.unknown_command`,{command:t}))}function Ff(){return Pi[od[Cd?.sectorIndex??H]]}function If(){let e=Ff();if(e.maxActiveEnemies===void 0)return 1/0;let t=Math.max(0,Math.floor((e.maxActiveEnemies+Sh*(e.maxActiveEnemiesIncrementPerCell??0))*ns(Cd?.sectorIndex??H)));return kd()?Math.max(1,Math.floor(t*(Od()?.difficultyMultiplier??1))):t}function Lf(e=0){hd+=e,ja(Uu,hd),lp()}function Rf(e=0){yd=Math.round((yd+e)*100)/100,ja(Ku,yd),ou.textContent=`$${P(yd)}`,df()}function zf(e=0){let t=e>0?e*(1+af(`chronoshardGainMultiplier`)):e;return bd+=t,ja(qu,bd),su.textContent=`✦ ${P(bd)}`,df(),t}function Bf(e=0){return xd=Math.max(0,xd+e),ja(Ju,xd),cu.innerHTML=`<img src="${so(`aetherium`)}" alt="">${P(xd)}`,e}var Vf=5,Hf=2,Uf=9e5,Wf=!1;function Gf(){return Math.max(0,Uf-(Date.now()-Sd))}function Kf(){if(!xs)return;let e=Gf(),t=Math.ceil(e/1e3);lu.classList.toggle(`hidden`,e>0),lu.disabled=Wf,lu.title=e>0?`Next Aetherium reward in ${Va(t)}`:`Watch an ad to claim 5 Aetherium`}function qf(e=Vf){let t=lu.getBoundingClientRect(),n=cu.getBoundingClientRect(),r=t.left+t.width/2,i=t.top+t.height/2,a=n.left+n.width/2,o=n.top+n.height/2,s=document.querySelector(`.game-shell`);for(let t=0;t<e;t+=1){let e=document.createElement(`img`);e.className=`aetherium-fly-token`,e.src=so(`aetherium`),e.alt=``,e.style.left=`${r}px`,e.style.top=`${i}px`,s.append(e);let n=t*90,c=Math.min(i,o)-42-t%2*18;e.animate([{opacity:0,transform:`translate(-50%, -50%) scale(0.5)`},{offset:.16,opacity:1,transform:`translate(-50%, -50%) scale(1.05)`},{offset:.62,opacity:1,transform:`translate(calc(-50% + ${(a-r)*.62}px), calc(-50% + ${c-i}px)) scale(1.12)`},{opacity:0,transform:`translate(calc(-50% + ${a-r}px), calc(-50% + ${o-i}px)) scale(0.42)`}],{duration:680,delay:n,easing:`cubic-bezier(.2,.78,.26,1)`,fill:`forwards`}).finished.then(()=>e.remove()).catch(()=>e.remove())}}lu.addEventListener(`click`,async()=>{if(!xs||Wf||Gf()>0)return;Wf=!0;let e=Q&&!$;e&&($=!0),Kf();try{if(!await Go({debug:!1}))return;Bf(Vf),qf(Vf),Sd=Date.now(),ja(Yu,Sd)}finally{e&&($=!1),Wf=!1,Kf()}}),Kf(),xs&&window.setInterval(Kf,1e3);function Jf(e,t){Yf(e,`+$${t}`,`cash-indicator`)}function Yf(e,t,n){let r=e.clone().project(tm),i=document.createElement(`span`);i.className=n,i.textContent=t,i.style.left=`${(r.x*.5+.5)*window.innerWidth}px`,i.style.top=`${(-r.y*.5+.5)*window.innerHeight}px`,i.addEventListener(`animationend`,()=>i.remove()),uu.append(i)}function Xf(){if(Cd)return;let e=od[H];Sh>(gd[e]??0)&&(gd[e]=Sh,ud()),tp(),fd(),lp(),df(),mp()}function Zf(){Na(id,_d)}function Qf(){_d={unlocked:[],resetAtScores:Object.fromEntries(Za.artifacts.map(e=>[e.id,e.requirement.type===`sector-high-score`?gd[od[e.requirement.sector-1]]??0:0])),stackCounts:{}},Zf(),sp()}function $f(e){let{requirement:t}=e;return t.type===`sector-high-score`?N(`artifact.requirement_score`,{cells:t.cells,sector:Ia(t.sector)}):t.type===`milestone-claimed`?N(`artifact.requirement_milestone`,{sector:Ia(t.sector),cells:t.cells}):t.type===`anomaly-run-success`?N(`artifact.requirement_anomaly`,{cells:t.cells}):t.type===`hidden-world-map`?N(`artifact.requirement_hidden`):N(`artifact.requirement_default`)}function ep(e){let{requirement:t}=e;if(t.type===`sector-high-score`){let n=gd[od[t.sector-1]]??0;return n>=t.cells&&n>(_d.resetAtScores[e.id]??-1)}return t.type===`milestone-claimed`&&V.claimed.includes(t.milestoneId)}function tp(){return Za.artifacts.filter(e=>ep(e)).reduce((e,t)=>np(t)||e,!1)}function np(e){return!e||_d.unlocked.includes(e.id)?!1:(_d.unlocked=[..._d.unlocked,e.id],Zf(),sp(),op(e),$a(e.id),e.buff.stat===`arenaSizeMultiplier`&&fm(),!0)}function rp(e){return e?.repeatable?(_d.stackCounts[e.id]=of(e)+1,_d.unlocked.includes(e.id)||(_d.unlocked=[..._d.unlocked,e.id]),Zf(),sp(),op(e),$a(e.id),!0):!1}async function ip(){let e=await eo();for(let t of Za.artifacts)e[Qa[t.id]]&&!_d.unlocked.includes(t.id)&&np(t);for(let e of _d.unlocked)$a(e)}var ap;function op(e){hc.textContent=N(`artifact.acquired_named`,{artifact:e.name.toUpperCase()}),hc.classList.remove(`hidden`),window.clearTimeout(ap),ap=window.setTimeout(()=>hc.classList.add(`hidden`),4e3)}function sp(){jc.innerHTML=Za.artifacts.map(e=>{let t=_d.unlocked.includes(e.id),n=of(e),r=t&&e.repeatable?`<b class="artifact-stack-count" aria-label="${N(`artifact.stacks`,{count:n})}">${n}</b>`:``,i=N(n===1?`artifact.stack`:`artifact.stacks_label`,{count:n});return`<button class="artifact-card ${t?`is-unlocked`:`is-locked`}" data-artifact-id="${e.id}" type="button"><span class="artifact-icon-wrap"><img src="${io(e.icon)}" alt="">${r}</span><span>${t?e.name:N(`artifact.unknown`)}</span><small>${t?e.repeatable?i:N(`weapon.unlocked`):N(`artifact.locked`)}</small></button>`}).join(``)}function cp(e){let t=Za.artifacts.find(t=>t.id===e);if(!t)return;let n=_d.unlocked.includes(t.id),r=of(t),i=t.repeatable&&n?N(`artifact.buff_per_stack`,{buff:t.buff.label,count:r,percent:Math.round(t.buff.amount*r*100)}):t.buff.label,a=N(r===1?`artifact.dark_core_stack`:`artifact.dark_core_stacks`,{count:r});Nc.innerHTML=`<img class="artifact-detail-icon ${n?``:`is-locked`}" src="${io(t.icon)}" alt=""><p class="eyebrow">${n?t.repeatable?a:N(`artifact.acquired`):N(`artifact.locked`)}</p><h2>${n?t.name:N(`artifact.unknown`)}</h2><div class="artifact-detail-section"><strong>${N(`artifact.to_acquire`)}</strong><p>${$f(t)}</p></div><div class="artifact-detail-section"><strong>${N(`artifact.permanent_buff`)}</strong><p>${i}</p></div>`,Mc.classList.remove(`hidden`)}function lp(){let e=pd();H>e&&(H=e),pu.textContent=N(`hud.sector`,{sector:Ia(H+1)}),du.textContent=String(gd[od[H]]??0).padStart(3,`0`);let t=qa.find(e=>e.sector===H+1&&!V.claimed.includes(e.id)),n=gd[od[H]]??0;fu.textContent=t?n>=t.cells?N(`milestone.ready`):N(`milestone.next`,{cells:t.cells}):N(`milestone.complete`);let r=!!U;mu.disabled=r||H===0,hu.disabled=r||H>=e;let i=qa.filter(e=>!V.claimed.includes(e.id)&&(gd[od[e.sector-1]]??0)>=e.cells).length;fc.textContent=String(i),fc.hidden=i===0,Ef(),mv()}function up(e){U||e<0||e>pd()||(H=e,ja(Wu,H),fm(),lp())}mu.addEventListener(`click`,()=>up(H-1)),hu.addEventListener(`click`,()=>{up(H+1),bu?.mode===`next-sector`&&H>=1&&(bu.mode=`start-run`,Tu(),Eu(Us),Ou())}),sc.addEventListener(`click`,()=>{vd=H,Lv(cc,mp),yu?.mode===`ascension-entry`&&(yu.mode=`ascension-claims`,ku())}),lc.addEventListener(`click`,()=>{cc.classList.add(`hidden`),$s.classList.remove(`hidden`)}),gc.addEventListener(`click`,()=>{vd=Math.max(0,vd-1),mp()}),_c.addEventListener(`click`,()=>{vd=Math.min(pd(),vd+1),mp()}),dc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-claim-milestone]`);t&&pp(t.dataset.claimMilestone)});function dp(e){return e.type===`cash`?N(`milestone.reward_cash`,{amount:e.amount.toLocaleString()}):e.type===`chronoshards`?N(`milestone.reward_chronoshards`,{amount:e.amount}):e.type===`sector`?N(`milestone.unlock_sector`,{sector:Ia(e.sector)}):e.type===`feature`?N(`milestone.unlock_feature`,{feature:e.featureId===`researchLab`?N(`menu.research_lab`):e.featureId}):e.type===`research`?N(`milestone.unlock_research`,{researches:e.researchIds.map(e=>Xd(e)?.name??e).join(`, `)}):N(`milestone.reward`,{},`Reward`)}var fp;function pp(e){let t=qa.find(t=>t.id===e),n=t?gd[od[t.sector-1]]??0:0;if(!(!t||V.claimed.includes(t.id)||n<t.cells)){V.claimed.push(t.id),V.researchUnlocks=[...new Set([...V.researchUnlocks,...t.rewards.filter(e=>e.type===`research`).flatMap(e=>e.researchIds)])];for(let e of t.rewards)e.type===`cash`&&Rf(e.amount),e.type===`chronoshards`&&zf(e.amount),e.type===`feature`&&e.featureId in Ad&&(Ad[e.featureId]=!0);if(yf(),tp(),fd(),pc.textContent=N(`milestone.reward_claimed`,{rewards:t.rewards.map(dp).join(` · `)}),pc.classList.remove(`hidden`),clearTimeout(fp),fp=setTimeout(()=>pc.classList.add(`hidden`),3600),lp(),df(),mp(),yu?.mode===`ascension-claims`){let e=Du();if(e.length===0)ju();else{let t=qa.find(t=>t.id===e[0]);t&&(vd=t.sector-1),mp(),ku()}}}}function mp(){let e=vd+1,t=gd[od[vd]]??0;uc.textContent=String(t).padStart(3,`0`),vc.textContent=N(`hud.sector`,{sector:Ia(e)}),gc.disabled=vd===0,_c.disabled=vd>=pd(),dc.innerHTML=qa.filter(t=>t.sector===e).map(n=>{let r=V.claimed.includes(n.id),i=t>=n.cells,a=Math.min(100,t/n.cells*100);return`<article class="milestone-card ${r?`claimed`:i?`reached`:``}"><div class="milestone-node">${r?`✓`:n.cells}</div><div><strong>${r?N(`milestone.secured`):N(`milestone.cells`,{cells:n.cells})}</strong><p>${n.rewards.map(dp).join(` · `)}</p><div class="milestone-progress"><i style="width:${a}%"></i></div><small>${r?N(`milestone.auto_claimed`):N(`milestone.best`,{best:t,target:n.cells,sector:Ia(e)})}</small></div></article>`}).join(``);let n=qa.filter(t=>t.sector===e);for(let[e,r]of n.entries()){let n=V.claimed.includes(r.id),i=t>=r.cells,a=dc.children[e];if(a&&(n&&(a.querySelector(`small`).textContent=N(`milestone.claimed`)),i&&!n)){let e=document.createElement(`button`);e.className=`claim-milestone-button`,e.dataset.claimMilestone=r.id,e.type=`button`,e.textContent=N(`milestone.claim`),a.lastElementChild.append(e)}}}var hp=Pa({THREE:je,SOUND:Ri,getSettings:()=>K,getPlayer:()=>X,getCamera:()=>tm}),gp=new oe({canvas:Ds,antialias:K.graphics.quality!==`low`}),_p,vp,yp=null,bp=null,xp=null,Sp={low:{pixelRatioCap:1,textureFilter:f},medium:{pixelRatioCap:1.5,textureFilter:Ye},high:{pixelRatioCap:k.maxPixelRatio,textureFilter:Ye}};function Cp(){return Sp[K.graphics.quality]??Sp.high}function wp(){let e=Cp(),t=K.graphics.quality!==`low`;_p&&gp.getContext().getContextAttributes().antialias!==t&&nm(t);let n=C.clamp(K.graphics.hdrEmissionIntensity??.5,0,1)*.5;gp.setPixelRatio(Math.min(window.devicePixelRatio,e.pixelRatioCap)),_p?.setPixelRatio(gp.getPixelRatio());let r=K.graphics.shadows&&K.graphics.quality!==`low`;yp&&(yp.castShadow=r),gp.shadowMap.enabled=r,gp.shadowMap.needsUpdate=r,bp&&(bp.magFilter=e.textureFilter,bp.minFilter=e.textureFilter,bp.needsUpdate=!0),xp?.(K.graphics.quality),gp.toneMapping=n>0?4:0,gp.toneMappingExposure=.9+n*.2,vp&&(vp.enabled=n>0,vp.strength=1.35*n)}function Tp(){Na(nd,W)}function Ep(){return 1+Zd(`weapon-slots`)+af(`weaponSlotCount`)}function Dp(e){return W.cards[e]}var Op=480,kp=30,Ap=180;function jp(){return Zd(`weapon-recharge`)>0}function Mp(){return jp()?1+Zd(`weapon-charge-capacity`):1}function Np(){return Math.max(Ap,Op-Zd(`weapon-recharge-rate`)*kp)}function Pp(e){return Jh.get(e)??1}function Fp(){Jh.clear(),Yh.clear();for(let e of W.loadout.filter(e=>Dp(e)))Jh.set(e,1),Yh.set(e,0)}function Ip(e){if(!jp())return;let t=Mp(),n=Np(),r=!1;for(let i of W.loadout.filter(e=>Dp(e))){let a=Pp(i);if(a>=t){Yh.set(i,0);continue}let o=(Yh.get(i)??0)+e,s=a;for(;o>=n&&s<t;)o-=n,s+=1,r=!0;Jh.set(i,s),Yh.set(i,s>=t?0:o)}r&&Hp()}function Lp(e){if(W.loadout.includes(e))return N(`weapon.remove_loadout`);if(W.loadout.length<Ep())return N(`weapon.add_loadout`);let t=W.loadout[W.selected],n=Ya.weapons[t];return n?N(`weapon.replace_with`,{weapon:n.name.toUpperCase()}):N(`weapon.replace_selected`)}function Rp(e){return Ya.levelCopyRequirements[e-1]??1/0}function zp(e){let t=Dp(e),n=Ya.weapons[e];return t&&n?n.baseEffect+n.effectPerLevel*(t.level-1):0}function Bp(e){return{megaMagnet:Bh,atmosphereShield:Vh,chronoFreeze:Hh,plasmaOrbital:Uh,cellOverdrive:Wh,demonMode:Gh}[e]??0}function Vp(){for(let e of Zc.querySelectorAll(`[data-weapon-duration]`)){let t=e.dataset.weaponDuration,n=zp(t);e.style.setProperty(`--weapon-progress`,String(n>0?C.clamp(Bp(t)/n,0,1):0))}}function Hp(){let e=W.loadout.filter(e=>Dp(e));Zc.classList.toggle(`hidden`,!Q||!e.length),Zc.innerHTML=e.map((e,t)=>{let n=Pp(e),r=Mp(),i=String(n);return`<button class="${t===W.selected?`selected`:``} ${n===0?`spent`:``} ${n>=r?`is-charge-full`:``}" data-use-weapon="${e}" type="button" ${n===0?`disabled`:``}><span class="weapon-hud-icon ${Ya.weapons[e].duration?`has-duration`:``}" data-weapon-duration="${Ya.weapons[e].duration?e:``}"><img class="weapon-hud-art" src="${oo(e)}" alt=""></span><b>${t+1}</b><span class="weapon-hud-name">${Ya.weapons[e].name}</span><i>${i}</i></button>`}).join(``),Vp()}function Up(){Lc.textContent=`✦ ${P(bd)}`,Rc.textContent=N(`weapon.buy_with_cost`,{cost:P(Ya.purchaseCost)}),zc.textContent=N(`weapon.buy_five_with_cost`,{cost:P(Ya.purchaseCost*5)}),Rc.disabled=bd<Ya.purchaseCost,zc.disabled=bd<Ya.purchaseCost*5;let e=Kp();Bc.hidden=e<=0,Bc.textContent=N(`weapon.lucky_find_cards`,{chance:Math.round(e*100)});let t=Ep();Jc.textContent=String(W.loadout.length),Jc.classList.toggle(`is-full`,W.loadout.length>=t),Yc.innerHTML=Array.from({length:Ep()},(e,t)=>{let n=W.loadout[t];return`<button data-select-weapon-slot="${t}" type="button" class="${t===W.selected?`selected`:``}">${n?Ya.weapons[n].name:N(`weapon.empty_slot`)}</button>`}).join(``),Xc.innerHTML=Object.entries(Ya.weapons).map(([e,t])=>{let n=Dp(e),r=`<img class="asset-card-art" src="${oo(e)}" alt="">`;if(!n)return`<article class="weapon-card locked">${r}<strong>${t.name}</strong><small>${N(`weapon.not_collected`)}</small></article>`;let i=Rp(n.level);return`<article class="weapon-card ${W.loadout.includes(e)?`selected`:``}">${r}<strong>${t.name} · ${N(`weapon.level`,{level:n.level})}</strong><small>${t.description}</small><em>${n.level>=5?N(`weapon.max_level`):N(`weapon.copy_progress_short`,{copies:n.copies,required:i,level:n.level+1})}</em><button data-toggle-weapon="${e}" type="button">${Lp(e)}</button></article>`}).join(``),Hp()}function Wp(){let e=jd[Md];e&&(Vc.dataset.revealType=e.type,Hc.textContent=N(`weapon.number`,{current:Md+1,total:jd.length}),Uc.textContent=e.status,Wc.src=oo(e.id),Wc.alt=e.name,Gc.textContent=e.name,Kc.textContent=e.detail,qc.textContent=Md===jd.length-1?N(`weapon.claim`):N(`weapon.next`),Vc.classList.remove(`hidden`),Vc.classList.remove(`is-revealing`),Vc.offsetWidth,Vc.classList.add(`is-revealing`))}function Gp(e){let t=Ya.weapons[e],n=Dp(e);if(!n)return n={level:1,copies:0},W.cards[e]=n,{id:e,name:t.name,type:`unlock`,status:N(`weapon.unlocked`),detail:N(`weapon.unlocked_level`)};n.copies+=1;let r=Rp(n.level);return n.copies>=r&&n.level<5?(n.copies-=r,n.level+=1,{id:e,name:t.name,type:`level-up`,status:N(`weapon.level_up`,{level:n.level}),detail:N(`weapon.upgraded_level`,{level:n.level})}):n.level>=5?{id:e,name:t.name,type:`max-copy`,status:N(`weapon.max_level_copy`),detail:N(`weapon.max_level_detail`)}:{id:e,name:t.name,type:`copy`,status:N(`weapon.copy`,{level:n.level}),detail:N(`weapon.copy_progress`,{copies:n.copies,required:r,level:n.level+1})}}function Kp(){return C.clamp(q(`luckyFindChance`),0,1)}function qp(e){let t=Ya.purchaseCost*e;if(bd<t)return;zf(-t);let n=[],r=Object.keys(Ya.weapons);for(let t=0;t<e;t+=1){let e=r[Math.floor(Math.random()*r.length)],t=Math.random()<Kp(),i=Gp(e);if(!t){n.push(i);continue}let a=Gp(e);n.push({...a,type:`lucky-find`,status:N(`weapon.lucky_find_double`),detail:i.type===`unlock`?N(`weapon.lucky_find_unlock`):N(`weapon.lucky_find_received`,{detail:a.detail})})}jd=n,Md=0,Tp(),Up(),Wp()}function Jp(){if(Md<jd.length-1){Md+=1,Wp();return}jd=[],Md=0,delete Vc.dataset.revealType,Vc.classList.remove(`is-revealing`),Vc.classList.add(`hidden`),Up()}function Yp(e){if(Q||!Dp(e))return;let t=W.loadout.indexOf(e);t>=0?W.loadout.splice(t,1):W.loadout.length<Ep()?(W.loadout.push(e),W.selected=W.loadout.length-1):W.loadout[W.selected]=e,W.selected=Math.min(W.selected,Math.max(W.loadout.length-1,0)),Tp(),Up()}function Xp(e=W.loadout[W.selected]){let t=Dp(e);if(!Q||$||!t||!W.loadout.includes(e))return;let n=Pp(e);if(n<=0)return;Ya.weapons[e];let r=zp(e);if(e===`nuke`){let e=[...Z].sort(()=>Math.random()-.5).slice(0,Math.ceil(Z.length*Math.min(r,.9)));Dv(X.position,e)}if(e===`megaMagnet`&&(Bh=r),e===`atmosphereShield`){Vh=r;for(let e of $m)Y.remove(e.obstacle,e.shadow,e.targetRing);$m.length=0}e===`phaseDash`&&Zp(r),e===`chronoFreeze`&&(Hh=r),e===`plasmaOrbital`&&(Uh=r),e===`cellOverdrive`&&(Wh=r),e===`demonMode`&&(Gh=r),Jh.set(e,n-1),Yh.has(e)||Yh.set(e,0),Hp(),hp.playBuildingEffect(X.position,`overclockRelay`)}function Zp(e){let t=new w(zm.x,0,zm.y);t.lengthSq()===0?t.set(Math.sin(X.rotation.y),0,Math.cos(X.rotation.y)):t.normalize();let n=X.position.clone(),r=dm(n.clone().addScaledVector(t,e),k.playerRadius);for(let e of[...Z])Q_(e.position,n,r)>e.userData.colliderRadius+.8||(ev(e.position,.5),m_(e));let i=new s(new ye().setFromPoints([n.clone().setY(.25),r.clone().setY(.25)]),new u({color:`#78eaff`,transparent:!0,opacity:.95,depthWrite:!1}));Y.add(i),Kh.push({trail:i,age:0}),X.position.copy(r),mm=Math.atan2(t.x,t.z)}gp.setSize(window.innerWidth,window.innerHeight),gp.outputColorSpace=Le;var Y=new Se;Y.background=new Je(A.background);var Qp=new di;Y.add(Qp);function $p(){let e=new o,n=new c({color:`#29375c`,emissive:`#101936`,emissiveIntensity:.45,metalness:.78,roughness:.28}),r=new c({color:`#ffcf76`,emissive:`#ff9f43`,emissiveIntensity:1,metalness:.52,roughness:.2}),i=new l(new qe(1.15,1.4,.65,10),n);i.position.y=.33;let a=new l(new qe(.56,.82,5.8,10),n);a.position.y=3.45;let s=new l(new qe(.88,.58,1.05,10),r);s.position.y=6.55;let u=new t(`#ffcf76`,.8,6,2);return u.position.y=7.15,e.add(i,a,s,u),e.traverse(e=>{e.isMesh&&(e.castShadow=!0,e.receiveShadow=!0)}),e.visible=!1,e}var em=$p();Y.add(em);var tm=new re(Fi.fov,window.innerWidth/window.innerHeight,Fi.near,Fi.far);tm.position.set(0,Wv(),Uv()),tm.lookAt(0,0,0),_p=new Ie(gp),_p.addPass(new ke(Y,tm)),vp=new Be(new Ge(window.innerWidth,window.innerHeight),.675,.48,1.1),_p.addPass(vp),_p.setSize(window.innerWidth,window.innerHeight);function nm(e){gp.dispose(),gp=new oe({canvas:Ds,antialias:e}),gp.setSize(window.innerWidth,window.innerHeight),gp.outputColorSpace=Le,_p=new Ie(gp),_p.addPass(new ke(Y,tm)),vp=new Be(new Ge(window.innerWidth,window.innerHeight),.675,.48,1.1),_p.addPass(vp),_p.setSize(window.innerWidth,window.innerHeight)}var{starfield:rm,floor:im,grid:am,arenaBoundary:om,keyLight:sm,setQuality:cm,resize:lm}=xa({THREE:je,scene:Y,COLORS:A,GAME:k,SCENE:Ii,LIGHTING:Li,quality:K.graphics.quality});yp=sm,xp=cm,wp();function um(){return(k.arenaLimit+Ff().extraArenaPadding)*(1+af(`arenaSizeMultiplier`))}function dm(e,t=0){let n=Math.max(0,um()-t),r=Math.hypot(e.x,e.z);if(r>n){let t=n/r;e.x*=t,e.z*=t}return e}function fm(){lm(Ff().extraArenaPadding,1+af(`arenaSizeMultiplier`))}var pm=new Je(A.slowAura),mm=0,hm=fa({THREE:je,COLORS:A,ENTITIES:j,GAME:k}),{player:X,playerCore:gm,slowAuraRing:_m,shieldBubble:vm}=hm;Y.add(X);var ym={...fa({THREE:je,COLORS:{...A,player:`#ff4d4d`,playerEmissive:`#9d1010`,playerWing:`#ff6767`,playerWingEmissive:`#9d1010`,playerRing:`#ffaaa0`,slowAura:`#ff4d4d`},ENTITIES:j,GAME:k,opacity:.72}),active:!1};ym.player.visible=!1;var bm=new o,xm=new l(new be(1.3,.055,10,48),new S({color:`#b59aff`,transparent:!0,opacity:.9,depthWrite:!1}));xm.rotation.x=Math.PI/2;var Sm=new l(new Ae(.95,1.28,48),new S({color:`#d5c9ff`,transparent:!0,opacity:.18,side:2,depthWrite:!1}));Sm.rotation.x=-Math.PI/2;var Cm=new l(new de(1.42,32,16,0,Math.PI*2,0,Math.PI/2),new S({color:`#a998ff`,transparent:!0,opacity:.15,wireframe:!0,depthWrite:!1}));bm.position.y=.92,bm.add(xm,Sm,Cm),bm.visible=!1,X.add(bm);var wm=Array.from({length:3},()=>{let e=new l(new de(.2,14,10),new c({color:`#ffb5ff`,emissive:`#ff45e9`,emissiveIntensity:3,metalness:.2,roughness:.15}));return e.visible=!1,X.add(e),e}),Tm=new l(new be(1.25,.07,8,40),new S({color:`#ff465d`,transparent:!0,opacity:.8,depthWrite:!1}));Tm.rotation.x=Math.PI/2,Tm.position.y=.1,Tm.visible=!1,X.add(Tm);var Em=new o;for(let e=0;e<12;e+=1){let t=e*Math.PI*2/12,n=new l(new ce(.12,1.05+e%3*.16,5),new S({color:`#ff465d`,transparent:!0,opacity:.46,depthWrite:!1})),r=new w(Math.cos(t),.1+e%2*.12,Math.sin(t));n.position.copy(r.clone().multiplyScalar(.95)),n.quaternion.setFromUnitVectors(new w(0,1,0),r.normalize()),Em.add(n)}Em.visible=!1,X.add(Em);var Dm=document.createElement(`canvas`);Dm.width=128,Dm.height=128;var Om=Dm.getContext(`2d`);Om.font=`900 108px Arial`,Om.textAlign=`center`,Om.textBaseline=`middle`,Om.lineWidth=8,Om.strokeStyle=`#6b4710`,Om.strokeText(`$`,64,65),Om.fillStyle=`#ffd36f`,Om.fillText(`$`,64,65),bp=new _e(Dm),bp.magFilter=Cp().textureFilter,bp.minFilter=Cp().textureFilter,bp.needsUpdate=!0;var km=new pe(new ge({map:bp,transparent:!0,depthWrite:!1}));km.position.set(0,2.2,0),km.scale.set(.7,.7,1),km.visible=!1,X.add(km);var Am=new Map;for(let[e,[t,n]]of Object.entries(Ya.weapons).filter(([,e])=>e.duration).entries()){let r=new l(new Ae(1.42+e*.11,1.49+e*.11,96),new S({color:n.color,transparent:!0,opacity:.9,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.userData.height=.2+e*.025,r.position.y=r.userData.height,r.visible=!1,r.geometry.setDrawRange(0,0),Y.add(r),Am.set(t,r)}var jm=new l(new de(.19,16,12),new c({color:`#d9ffff`,emissive:`#42eaff`,emissiveIntensity:3.2,metalness:.2,roughness:.12})),Mm=new l(new de(.33,14,10),new S({color:`#4eeeff`,transparent:!0,opacity:.24,depthWrite:!1}));jm.add(Mm);var Nm=new ye;Nm.setAttribute(`position`,new De(new Float32Array(27),3).setUsage(i));var Pm=new s(Nm,new u({color:`#a9ffff`,transparent:!0,opacity:.8,depthWrite:!1}));Pm.frustumCulled=!1,jm.visible=!1,Pm.visible=!1,Y.add(jm,Pm);var Fm=0,Im=new w,Lm=new w,Rm=new Set,zm=new Ge,Bm=null,Vm=null,Hm=58,Um=12,Wm=36,Gm=new Ge,Km=28,qm=new Map,Jm=null,Ym=!1,Xm=[],Zm=[],Qm=[],Z=[],$m=[],eh=[],th=[],nh=[],rh=[],ih=[],ah=[],oh=[],sh=[],ch=[],lh=[],uh=[],dh=[],fh=[],ph=[],mh=[],hh=[],gh=[],_h=new Map,vh=new Oe,Q=!1,$=!1,yh=!1,bh=!1,xh=!1,Sh=0,Ch=1,wh=0,Th=0,Eh=0,Dh=0,Oh=0,kh=0,Ah=0,jh=null,Mh=0,Nh=0,Ph=.5,Fh=0,Ih=0,Lh=0,Rh=0,zh=0,Bh=0,Vh=0,Hh=0,Uh=0,Wh=0,Gh=0,Kh=[],qh=new Map,Jh=new Map,Yh=new Map,Xh=new g(j.obstacleRadius,j.fallingRockDetail),{createShooterProjectile:Zh,createAutocannonProjectile:Qh,createSplinter:$h}=Sa({THREE:je,COLORS:A,ENTITIES:j}),{createCell:eg,createChronoCell:tg,createBooster:ng}=_a({THREE:je,COLORS:A,ENTITIES:j}),rg=ha({THREE:je,ENTITIES:j}),{createExplosion:ig,createBangerPulse:ag,createShockwave:og,createShieldBreak:sg,createPoisonTrail:cg,createPlayerDeath:lg,createFieryRockFire:ug,createFallingRockImpact:dg}=Ca({THREE:je,Quarks:Ar,particleRenderer:Qp,COLORS:A,getQuality:()=>K.graphics.quality}),fg=new Je(A.creeper),pg=new Je(A.poisonCreeper),mg=new Je(A.creeperEmissive),hg=new Je(A.poisonCreeperEmissive);function gg(e,t){let n=new oe({canvas:t,alpha:!0,antialias:!0});n.setPixelRatio(Math.min(window.devicePixelRatio,2)),n.setSize(210,150,!1);let r=new Se,i=new re(32,210/150,.1,20);i.position.set(0,1.3,4.8),i.lookAt(0,0,0),r.add(new a(`#d9f9ff`,`#07141d`,2.6));let o=new b(`#fff4cf`,2.8);o.position.set(2,3,4),r.add(o);let s=e.model===`spiked-enemy`?zi[e.id]:e.model===`ultimate-enemy`?Vi[e.id]:Bi[e.id],u=new c({color:s.color,emissive:s.emissive,emissiveIntensity:s.emissiveIntensity??1.35,metalness:j.obstacleMetalness,roughness:j.obstacleRoughness}),d=e.model===`spiked-enemy`?rg(u,e.id):e.model===`ultimate-enemy`?ga(je):new l(Xh,u);e.model===`ultimate-enemy`&&d.scale.setScalar(s.scale),d.rotation.set(.28,-.55,.14),r.add(d),n.render(r,i),u.dispose(),n.dispose()}var _g=null,vg=!1;function yg(){if(oa.endpoint)return oa.endpoint;if(aa.endpoint)try{return new URL(`/time`,aa.endpoint).toString()}catch{}return oa.publicEndpoint}async function bg(){let e=yg();if(!e)throw Error(N(`error.server_time_unconfigured`));let t=new AbortController,n=window.setTimeout(()=>t.abort(),8e3),r=performance.now();try{let n=await fetch(e,{cache:`no-store`,signal:t.signal});if(!n.ok)throw Error(N(`error.server_time_request`,{status:n.status}));let i=await n.json(),a=Date.parse(i?.now??i?.utc_iso);if(!Number.isFinite(a))throw Error(N(`error.server_time_invalid`));return new Date(a+(performance.now()-r)/2)}finally{window.clearTimeout(n)}}function xg(e=_g??new Date){let t=new Date(`${ia.weeklyAnchorDate}T00:00:00Z`),n=Date.UTC(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate());return Math.max(0,Math.floor((n-t.getTime())/6048e5))}function Sg(e=_g??new Date){return String(xg(e))}function Cg(e=_g??new Date){let t=new Date(`${ia.weeklyAnchorDate}T00:00:00Z`);return t.setUTCDate(t.getUTCDate()+(xg(e)+1)*7),t}function wg(e){return`${String(e.getUTCDate()).padStart(2,`0`)}.${String(e.getUTCMonth()+1).padStart(2,`0`)}.${e.getUTCFullYear()}`}function Tg(e=Sg()){return ia.challenges[Number(e)%ia.challenges.length]}function Eg(e){return ia.rewardBaseChronoshards+e*ia.rewardChronoshardStepPerSector}function Dg(e=Sg(),t=H){return(wd.claimedSectors[e]??[]).includes(String(t))}function Og(){let e=Od(),t=e?.rewardCellTarget??ia.rewardCellTarget;if(!Td||!e||Sh<t)return;let n=String(H),r=`${e.id}:sector${H+1}`;if(!wd.darkCoreClaims.includes(r)){wd.darkCoreClaims.push(r);let e=Za.artifacts.find(e=>e.requirement.type===`anomaly-run-success`);e&&(rp(e),Yf(X.position,N(`anomaly.dark_core_stack`,{artifact:e.name.toUpperCase()}),`chronoshard-indicator`))}let i=wd.claimedSectors[Td.weekId]??[];if(!i.includes(n)){wd.claimedSectors[Td.weekId]=[...i,n];let e=zf(Eg(H));Yf(X.position,N(`message.anomaly_reward`,{amount:P(e)}),`chronoshard-indicator`)}Na(rd,wd),mv()}function kg(e){!kd()||!Q||yh||(Od(),Dd=Math.max(0,Dd-e),bv(),Dd===0&&yv(!1))}function Ag(){if(!kd()||!Q||yh)return;Sh+=1,Og();let e=Od()?.rewardCellTarget??1e3;Sh>=e&&yv(!0)}function jg(){let e=pd()+1,t=e=>[...e].map(e=>e===` `?` `:`?`).join(``),n=n=>{let r=n.firstSector<=e,i=r?`<canvas data-encyclopedia-model="${n.id}" width="210" height="150" aria-label="${n.name} model"></canvas>`:`<div class="encyclopedia-unknown-icon" role="img" aria-label="${N(`encyclopedia.unknown_enemy`)}">?</div>`;return`<article class="encyclopedia-entry ${r?``:`locked`}"><h3>${n.name}</h3>${i}<p>${r?n.description:t(n.description)}</p></article>`},r=new Map;for(let e of Ra)r.set(e.category,[...r.get(e.category)??[],e]);Dc.innerHTML=[...r.entries()].map(([e,t])=>`<section class="encyclopedia-category"><h3>${e}</h3><div class="encyclopedia-category-grid">${t.map(n).join(``)}</div></section>`).join(``);for(let e of Dc.querySelectorAll(`[data-encyclopedia-model]`)){let t=Ra.find(t=>t.id===e.dataset.encyclopediaModel);t&&gg(t,e)}}var Mg=new Se,Ng=new re(34,1,.1,20);Ng.position.set(0,.1,3.25);var Pg=new oe({canvas:Bs,alpha:!0,antialias:!0});Pg.setPixelRatio(Math.min(window.devicePixelRatio,2)),Pg.setSize(76,60,!1),Mg.add(new a(`#d9f9ff`,`#07141d`,2.5));var Fg=new b(`#fff4cf`,3);Fg.position.set(2,3,4),Mg.add(Fg);var Ig=null;function Lg(e){let t=e.toLowerCase();return Object.keys(zi).find(e=>t.includes(e))??null}function Rg(){Ig&&=(Mg.remove(Ig),Ig.userData.material?.dispose(),null),zs.hidden=!0,$s.classList.remove(`is-death-screen`)}function zg(e){let t=Lg(e);if(!t)return Rg(),!1;Rg();let n=zi[t];return Ig=rg(new c({color:n.color,emissive:n.emissive,emissiveIntensity:1.35,metalness:j.obstacleMetalness,roughness:j.obstacleRoughness}),t),Ig.rotation.set(.25,0,-.16),Mg.add(Ig),Bs.setAttribute(`aria-label`,N(`accessibility.enemy_model`,{enemy:t})),zs.hidden=!1,$s.classList.add(`is-death-screen`),!0}function Bg(e){!Ig||zs.hidden||(Ig.rotation.y+=e*1.8,Ig.rotation.x+=e*.24,Pg.render(Mg,Ng))}function Vg(e=0){let t=um(),n;do{let e=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*t;n=new w(Math.cos(e)*r,0,Math.sin(e)*r)}while(n.distanceTo(X.position)<e);return n}function Hg(){Na(Qu,G)}function Ug(e,t=Math.ceil){return t(e*Math.max(0,1-af(`buildingCostReduction`)))}function Wg(){return Ug(60+G.unlockCount*30)}function Gg(){let e=Object.keys(da.types).filter(e=>!G.unlocked.includes(e)),t=G.unlockOffers.filter(t=>e.includes(t));return t.length?t:(G.unlockOffers=[...e].sort(()=>Math.random()-.5).slice(0,3),Hg(),G.unlockOffers)}function Kg(e){let t=Gg(),n=Wg();!t.includes(e)||bd<n||(zf(-n),G.unlocked.push(e),G.unlockCount+=1,G.unlockOffers=[],Hg(),s_())}function qg(){W={cards:{},loadout:[],selected:0},jd=[],Md=0,Vc.classList.add(`hidden`),Tp(),Up()}function Jg(){let e=Gg(),t=Wg(),n=bd>=t;jl.textContent=`✦ ${P(bd)}`,Ml.innerHTML=e.length?`<p class="building-draft-copy">${N(`building.choose_offer`,{count:e.length,cost:P(t)})}</p>${e.map(e=>{let r=da.types[e];return`<article class="building-card building-offer"><img class="asset-card-art" src="${ao(e)}" alt=""><strong>${r.name}</strong><small>${N(`building.permanent_unlock`)}</small><button data-building-offer="${e}" ${n?``:`disabled`}>${N(`building.unlock_cost`,{cost:P(t)})}</button></article>`}).join(``)}`:`<p class="building-draft-copy">${N(`building.all_unlocked`)}</p>`}function Yg(){return 3+Zd(`building-slots`)}function Xg(e){return 1+G.placed.filter(t=>t.type===e).reduce((e,t)=>e+Object.values(t.upgrades).reduce((e,t)=>e+t,0),0)}function Zg(e,t){let n=da.types[e.type].upgrades[t],r=e.upgrades[t]??0;return Ug(n.base*1.65**r)}function Qg(e){return Math.round((e.spent??da.types[e.type].baseCost)*100)/100}function $g(e){let t=da.types[e.type],{group:n,effectRing:r,barrierField:i}=pa({THREE:je,building:e,config:t,range:p_(e,`range`)});n.userData.buildingId=e.id,Y.add(n),Ld.set(e.id,n),Rd.set(e.id,{timer:0,active:0,effectRing:r,barrierField:i})}function e_(){for(let e of Ld.values())Y.remove(e);Ld.clear(),Rd.clear();for(let e of G.placed)$g(e)}function t_(e){let t=da.types[e];return Ug(t.baseCost*t.costMultiplier**G.placed.filter(t=>t.type===e).length)}function n_(){let e=[];for(let t=-10;t<=10;t+=2)for(let n=-10;n<=10;n+=2)Math.hypot(t,n)<=da.placementRadius&&Math.hypot(t,n)>=da.spawnClearance&&e.push({x:t,z:n});return e}function r_(){if(!zd){Il.replaceChildren(),Il.classList.add(`hidden`);return}let e=Bd?t_(Bd):0,t=G.placed.length>=Yg();Il.innerHTML=n_().map(({x:n,z:r})=>{let i=G.placed.find(e=>e.x===n&&e.z===r),a=i?`<span class="build-name" data-build-x="${n}" data-build-z="${r}">${da.types[i.type].name}</span>`:``;return`<button class="build-site ${i?`occupied`:``}" data-build-x="${n}" data-build-z="${r}" type="button" ${!i&&!t||i?``:`disabled`}>${i?N(`building.upgrade`):t?N(`building.slot_limit`):`$${e}`}</button>${a}`}).join(``),Il.classList.remove(`hidden`),requestAnimationFrame(i_)}function i_(){if(zd)for(let e of Il.querySelectorAll(`[data-build-x]`)){let t=e.classList.contains(`build-name`),n=new w(Number(e.dataset.buildX),t?1.25:.08,Number(e.dataset.buildZ)).project(tm);e.style.left=`${(n.x*.5+.5)*window.innerWidth}px`;let r=e.classList.contains(`occupied`)?38:0;e.style.top=`${(-n.y*.5+.5)*window.innerHeight+r}px`}}function a_(e){X.visible=!e&&!yh,jm.visible=!e&&Zd(`unlock-orbital-electron`)>0&&!yh,Pm.visible=!e&&Zd(`unlock-orbital-electron`)>0&&!yh;for(let t of Xm)t.visible=!e;for(let t of Zm)t.visible=!e;for(let t of uh)t.visible=!e;for(let t of Z)t.visible=!e,t.userData.rangeIndicator&&(t.userData.rangeIndicator.visible=!e),t.userData.magnetPulse&&(t.userData.magnetPulse.visible=!e);for(let t of lh)t.spore.visible=!e;for(let t of sh)t.projectile.visible=!e;for(let t of mh)t.mesh.visible=!e;for(let t of $m)t.obstacle.visible=!e,t.shadow.visible=!e,t.targetRing.visible=!e;for(let t of gh)t.ring.visible=!e,t.glow.visible=!e,t.beam.visible=!e;for(let t of ih){for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of hh){for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of Qm)t.visible=!e;for(let t of th){t.ground.visible=!e;for(let n of t.emitters)n.visible=!e;t.light.visible=!e}for(let t of nh)for(let n of t.emitters)n.visible=!e;for(let t of rh)t.piece.visible=!e;for(let t of oh)t.pulse.visible=!e;for(let t of dh)t.shockwave.visible=!e;for(let t of ph)t.ring.visible=!e,t.glow.visible=!e;for(let t of Am.values())e&&(t.visible=!1)}function o_(e,t){let n=G.placed.find(n=>n.x===e&&n.z===t);if(n){u_(n);return}let r=t_(Bd);if(G.placed.length>=Yg()||yd<r)return;Rf(-r);let i={id:crypto.randomUUID(),type:Bd,x:e,z:t,upgrades:{},spent:r};G.placed.push(i),Hg(),$g(i),s_()}function s_(){Dl.disabled=Q,wl.textContent=`$${P(yd)}`,Tl.textContent=`✦ ${P(bd)}`,El.textContent=`${G.placed.length}/${Yg()}`,Cl.innerHTML=G.unlocked.length?G.unlocked.map(e=>`<article class="building-card"><img class="asset-card-art" src="${ao(e)}" alt=""><strong>${da.types[e].name}</strong><small>${N(`building.build_cost`,{cost:P(t_(e))})}</small><span class="building-unlocked-state">${N(`building.unlocked`)}</span></article>`).join(``):`<p class="building-draft-copy">${N(`building.none_unlocked`)}</p>`,Jg(),Fl.innerHTML=G.unlocked.map(e=>`<button data-select-building="${e}" class="${Bd===e?`selected`:``}" type="button" aria-label="${da.types[e].name} · ${N(`building.level`,{level:Xg(e)})}"><img src="${ao(e)}" alt=""><small>${N(`building.level`,{level:Xg(e)})}</small></button>`).join(``),Pl.textContent=Rv()?`${G.placed.length}/${Yg()}`:N(`building.build_mode_slots`,{used:G.placed.length,total:Yg()}),r_()}function c_(){Q||!G.unlocked.length||(Gm.set(0,0),Km=28,zd=!0,Bd=G.unlocked[0],a_(!0),Fs.classList.add(`hidden`),Nl.classList.remove(`hidden`),s_())}function l_(){zd=!1,qm.clear(),Jm=null,Bd=null,a_(!1),Il.classList.add(`hidden`),Nl.classList.add(`hidden`),Fs.classList.remove(`hidden`),Rl.classList.add(`hidden`)}function u_(e){let t=da.types[e.type];Rl.innerHTML=`<button class="upgrade-close" data-close-building-upgrade="1" type="button" aria-label="${N(`building.upgrade`)}">×</button><p class="eyebrow">${N(`building.installed_defense`)}</p><h3>${t.name}</h3><p class="building-upgrade-summary">${N(`building.choose_upgrade`)}</p><div class="upgrade-grid">${Object.entries(t.upgrades).map(([t,n])=>{let r=e.upgrades[t]??0,i=Zg(e,t);return`<button data-upgrade-building="${e.id}" data-upgrade-key="${t}" type="button"><span>${n.name}</span><strong>${N(`building.upgrade_level`,{current:r,next:r+1})}</strong><small>$${P(i)}</small></button>`}).join(``)}</div><button data-destroy-building="${e.id}" class="demolish-button" type="button">${N(`building.demolish_refund`,{amount:P(Qg(e))})}</button>`,Rl.classList.remove(`hidden`)}function d_(e,t){let n=da.types[e.type],r=t===`interval`?`frequency`:t,i=(n.upgrades[r]?.step??0)*(e.upgrades[r]??0),a=t===`slow`?(n.upgrades.effectiveness?.step??0)*(e.upgrades.effectiveness??0):0;return(n.effect[t]??0)+i+a}function f_(e,t){return e.type===`overclockRelay`||t===`count`?1:1+G.placed.filter(t=>t.type===`overclockRelay`&&t.id!==e.id&&Z_(e,t)<=d_(t,`range`)).reduce((e,t)=>e+d_(t,`effectiveness`),0)}function p_(e,t){let n=d_(e,t),r=f_(e,t);return t===`interval`||t===`period`?n/r:n*r}function m_(e,t=!0){Y.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),A_(e);let n=Z.indexOf(e);n>=0&&Z.splice(n,1),n>=0&&t&&Ag()}function h_(){let e=Math.random()*Math.PI*2,t=Math.max(1,um()-k.obstacleColliderRadius);return new w(Math.cos(e)*t,k.obstacleGroundHeight,Math.sin(e)*t)}function g_(){return ma(je)}function __(e,t,n){let r=g_(),i=new w(e.x,1.4,e.z),a=t.position.clone().setY(.48),o=a.clone().sub(i).setY(0).normalize(),s=new w(-o.z,0,o.x).multiplyScalar((Math.random()-.5)*2.2),c=i.clone().lerp(a,.48).add(s);c.y=3.2+Math.random()*1.1,r.position.copy(i),Y.add(r),mh.push({mesh:r,target:t,start:i,control:c,speed:n,age:0,duration:Math.max(1.35,Math.min(4.5,i.distanceTo(a)/Math.max(n,1)))})}function v_(e){for(let t of G.placed){if(t.type!==`barrierNode`||Rd.get(t.id)?.active<=0)continue;let n=p_(t,`range`)+e.userData.colliderRadius+.08,r=e.position.x-t.x,i=e.position.z-t.z,a=Math.hypot(r,i);if(a>=n)continue;let o=a>.001?r/a:1,s=a>.001?i/a:0;e.position.x=t.x+o*n,e.position.z=t.z+s*n,dm(e.position)}}function y_(e,t){for(let t=mh.length-1;t>=0;--t){let n=mh[t];if(n.age+=e,!Z.includes(n.target)){Y.remove(n.mesh),mh.splice(t,1);continue}let r=n.target.position.clone().setY(.48),i=Math.min(n.age/n.duration,1),a=1-i,o=n.start.clone().multiplyScalar(a*a).addScaledVector(n.control,2*a*i).addScaledVector(r,i*i),s=Math.min(i+.025,1),c=1-s,l=n.start.clone().multiplyScalar(c*c).addScaledVector(n.control,2*c*s).addScaledVector(r,s*s);n.mesh.position.copy(o),n.mesh.lookAt(l);for(let t of n.mesh.userData.rotors)t.rotation.y+=e*38;i>=1&&(Z.includes(n.target)&&(ev(n.target.position,.52),m_(n.target)),Y.remove(n.mesh),mh.splice(t,1))}for(let t=ch.length-1;t>=0;--t){let n=ch[t];if(n.age+=e,!Z.includes(n.target)){Y.remove(n.mesh),ch.splice(t,1);continue}let r=n.target.position.clone().sub(n.mesh.position);r.y=0;let i=r.length();i>.001&&n.direction.lerp(r.multiplyScalar(1/i),1-Math.exp(-12*e)).normalize(),n.mesh.position.addScaledVector(n.direction,14*e),n.mesh.rotation.x+=e*12,n.mesh.scale.setScalar(.85+Math.sin(n.age*28)*.12),i<=k.obstacleColliderRadius+.24?(Y.remove(n.mesh),Z.indexOf(n.target)>=0&&(ev(n.target.position,.58),m_(n.target)),ch.splice(t,1)):n.age>2.5&&(Y.remove(n.mesh),ch.splice(t,1))}for(let n of G.placed){let r=Rd.get(n.id);if(!r)continue;let i=Ld.get(n.id),a=da.types[n.type];r.timer+=e,r.effectRing.rotation.z+=e*1.4;let o=a.effect.range?p_(n,`range`):0;if(r.effectRing.scale.setScalar(o),r.effectRing.material.opacity=.12+Math.sin(t*3)*.06,n.type===`overclockRelay`&&(r.effectRing.material.opacity=.3+Math.sin(t*6)*.12,i.rotation.y+=e*.7),n.type===`droneBay`&&r.timer>=Math.max(2,p_(n,`period`))){r.timer=0;let e=[...Z].sort(()=>Math.random()-.5).slice(0,Math.floor(p_(n,`count`)));for(let t of e)__(n,t,p_(n,`droneSpeed`));e.length&&hp.playBuildingEffect(i.position,n.type)}if(n.type===`barrierNode`){let a=Math.max(2,p_(n,`period`));r.timer>=a&&(r.timer=0,r.active=p_(n,`duration`),hp.playBuildingEffect(i.position,n.type)),r.active=Math.max(0,r.active-e),r.barrierField&&(r.barrierField.visible=r.active>0,r.barrierField.scale.set(o,1,o),r.barrierField.rotation.y+=e*1.8,r.barrierField.children[0].material.opacity=r.active>0?.14+Math.sin(t*10)*.05:0),r.effectRing.material.opacity=r.active>0?.58:.12}if(n.type===`salvageExtractor`&&r.timer>=Math.max(3,p_(n,`period`))){r.timer=0;let e=Z.filter(e=>Z_(e.position,n)<=o).sort(()=>Math.random()-.5).slice(0,Math.floor(p_(n,`count`)));for(let t of e){let e=k.cellCashValue*Ff().cashValueMultiplier*(1+q(`cashMultiplier`))+p_(n,`cash`);kd()||b_({position:{x:t.position.x,y:k.playerStartHeight,z:t.position.z},cashValue:e}),ev(t.position,.42),m_(t)}e.length&&hp.playBuildingEffect(i.position,n.type)}if(n.type===`autocannon`&&r.timer>=Math.max(.35,p_(n,`interval`))){r.timer=0;let e=Z.filter(e=>Z_(e.position,n)<=o).sort((e,t)=>Z_(e.position,n)-Z_(t.position,n))[0];if(e){let t=e.position.clone().sub(i.position);t.y=0,t.normalize(),i.rotation.y=Math.atan2(t.x,t.z);let r=Qh();r.position.copy(i.position).addScaledVector(t,.95),r.position.y=.7,Y.add(r),ch.push({mesh:r,direction:t,destination:e.position.clone().setY(.7),target:e,age:0}),hp.playBuildingEffect(i.position,n.type)}}}}function b_(e){let t=eg();e?t.position.set(e.position.x,e.position.y,e.position.z):t.position.copy(Vg(k.cellMinDistance)),e||(t.position.y=k.playerStartHeight),t.userData.phase=e?.phase??Math.random()*Math.PI*2,t.userData.cashValue=e?.cashValue??k.cellCashValue*Ff().cashValueMultiplier*(1+q(`cashMultiplier`)),Y.add(t),Xm.push(t)}function x_(e){if(Zm.length>0)return;let t=Za.artifacts.find(e=>e.requirement.type===`hidden-world-map`),n=!!e?.isMapToEarth||!!(!e&&t&&H+1>=t.requirement.minSector&&!_d.unlocked.includes(t.id)&&Math.random()<t.requirement.chance),r=n?S_():tg();e?r.position.set(e.position.x,e.position.y,e.position.z):r.position.copy(Vg(k.chronoCellMinDistance)),e||(r.position.y=k.playerStartHeight),r.userData.phase=e?.phase??Math.random()*Math.PI*2,r.userData.age=e?.age??0,r.userData.isMapToEarth=n,Y.add(r),Zm.push(r)}function S_(){let e=new l(new de(j.chronoCellRadius*1.18,20,14),new c({color:`#378ac3`,emissive:`#0b385d`,emissiveIntensity:2.4,metalness:.28,roughness:.48,transparent:!0}));return e.add(new y(new le(new de(j.chronoCellRadius*1.21,10,7)),new u({color:`#83e9cf`,transparent:!0,opacity:.72}))),e}function C_(e,t){let n=ng(e);t?n.position.set(t.position.x,t.position.y,t.position.z):(n.position.copy(Vg(k.cellMinDistance)),n.position.y=k.playerStartHeight),n.userData.type=e,Y.add(n),uh.push(n)}function w_(e,t){e===`speed`&&(Lh=k.speedBoosterBaseDuration+q(`speedBoosterDuration`)),e===`thorn`&&(Rh=k.thornShieldBaseDuration+q(`thornShieldDuration`)),e===`freezer`&&(zh=k.freezerBaseDuration+q(`freezerDuration`)),hp.playBoosterPickup(t,e)}function T_(e){D_(Vg(k.obstacleMinDistance),e)}function E_(e){let t=kd()?Od():null,n=Ff(),r=(t?.enemyTypes??n.availableObstacleTypes).map(e=>({type:e,weight:t?.enemySpawnWeights?.[e]??n[`${e}SpawnWeight`]??0})),i=r.reduce((e,t)=>e+t.weight,0),a=Math.random()*i,o=e?.type??r[r.length-1].type;for(let t of e?[]:r)if(a-=t.weight,a<=0){o=t.type;break}for(let e of eh)e.mesh.visible=!hidden,e.arrow.visible=!hidden&&e.phase===`telegraph`,e.trail.visible=!hidden;let s=e?.position??(t&&o!==`regular`?h_():Vg(k.obstacleMinDistance)),c=zi[o],u=new l(new Ae(j.spawnRingInnerRadius,j.spawnRingOuterRadius,j.spawnRingSegments),new S({color:c.color,transparent:!0,opacity:M.spawnRingBaseOpacity,side:2,depthWrite:!1}));u.rotation.x=-Math.PI/2,u.position.set(s.x,.03,s.z);let d=new l(new ie(j.spawnCueGlowRadius,j.spawnRingSegments),new S({color:c.color,transparent:!0,opacity:M.spawnCueGlowBaseOpacity,depthWrite:!1}));d.rotation.x=-Math.PI/2,d.position.set(s.x,.02,s.z);let f=new l(new qe(.42,1.12,j.spawnCueBeamHeight,j.spawnRingSegments,1,!0),new S({color:c.color,transparent:!0,opacity:M.spawnCueBeamBaseOpacity,side:2,depthWrite:!1}));f.position.set(s.x,j.spawnCueBeamHeight/2,s.z),Y.add(u,d,f),gh.push({ring:u,glow:d,beam:f,position:s,type:o,age:e?.age??0}),e||hp.playObstacleSummon(s)}function D_(e,t,n){let r=zi[t],i=rg(new c({color:r.color,emissive:r.emissive,emissiveIntensity:t===`spore`?2.3:1,metalness:j.obstacleMetalness,roughness:j.obstacleRoughness}),t);i.position.copy(e),i.position.y=k.obstacleGroundHeight,i.userData.type=t,i.userData.id=n?.id??crypto.randomUUID(),i.userData.age=n?.age??0,i.userData.lifetimeAge=n?.lifetimeAge??0,i.userData.speed=n?.speed??C.randFloat(.8,1.45),i.userData.pulseTimer=n?.pulseTimer??0,i.userData.bangerFlash=0,i.userData.shotCooldown=n?.shotCooldown??0,i.userData.teleportTimer=n?.teleportTimer??0,i.userData.poisonTrailTimer=n?.poisonTrailTimer??0,i.userData.teleportTarget=n?.teleportTarget?new w(n.teleportTarget.x,n.teleportTarget.y,n.teleportTarget.z):null,i.userData.colliderRadius=k.obstacleColliderRadius,i.userData.electronStunnedOnce=!!n?.electronStunnedOnce;let a=new o,s=new S({color:`#fff3a6`,transparent:!0,opacity:.9,depthWrite:!1});for(let e=0;e<3;e+=1){let t=new l(new Pe(.13,0),s.clone()),n=e*Math.PI*2/3;t.position.set(Math.cos(n)*.42,Math.sin(e*2.2)*.09,Math.sin(n)*.42),t.rotation.set(Math.PI/4,n,Math.PI/4),a.add(t)}a.position.y=1.08,a.visible=!1,i.add(a),i.userData.stunStars=a;let u=new o,d=new S({color:`#c59cff`,transparent:!0,opacity:.76,depthWrite:!1}),f=new l(new be(.28,.028,6,18),d);f.rotation.x=Math.PI/2,u.add(f);for(let e of[Math.PI/4,-Math.PI/4]){let t=new l(new Ne(.48,.04,.035),d.clone());t.rotation.y=e,u.add(t)}if(u.position.y=1.08,u.visible=i.userData.electronStunnedOnce,i.add(u),i.userData.electronImmunityMarker=u,t===`chaser`||t===`banger`||t===`shooter`||t===`magnet`){let t=new l(new Ae(r.range-j.chaserRangeIndicatorWidth,r.range,j.chaserRangeIndicatorSegments),new S({color:r.color,transparent:!0,opacity:M.chaserRangeIndicatorBaseOpacity,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.025,e.z),i.userData.rangeIndicator=t,Y.add(t)}if(t===`magnet`){let t=new l(new Ae(.18,.3,j.chaserRangeIndicatorSegments),new S({color:A.slowAura,transparent:!0,opacity:.5,side:2,depthWrite:!1}));t.rotation.x=-Math.PI/2,t.position.set(e.x,.035,e.z),i.userData.magnetPulse=t,i.userData.magnetPulsePhase=n?.magnetPulsePhase??Math.random(),Y.add(t)}Y.add(i),Z.push(i),t===`porter`&&i.userData.teleportTarget&&k_(i)}function O_(){let e=Math.random()*Math.PI*2,t=C.randFloat(j.porterTeleportMinDistance,j.porterTeleportMaxDistance);return dm(new w(X.position.x+Math.cos(e)*t,k.obstacleGroundHeight,X.position.z+Math.sin(e)*t))}function k_(e){let t=e.userData.teleportTarget,n=new l(new Ae(.4,.65,32),new S({color:A.porter,transparent:!0,opacity:.8,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(t.x,.04,t.z);let r=new l(new qe(.18,.7,2.8,20,1,!0),new S({color:A.porter,transparent:!0,opacity:.25,side:2,depthWrite:!1}));r.position.set(t.x,1.4,t.z),e.userData.teleportEffect={ring:n,beam:r},Y.add(n,r)}function A_(e){let t=e.userData.teleportEffect;t&&Y.remove(t.ring,t.beam),e.userData.teleportEffect=null}function j_(e,t,n=1,r={}){let i=n===1?.6:.4,a=rg(new c({color:A.spore,emissive:A.sporeEmissive,emissiveIntensity:3*i,metalness:j.obstacleMetalness,roughness:j.obstacleRoughness}),`spore`);a.userData.hdrEmissionScale=i,a.scale.setScalar(n===1?j.sporeFragmentScale:j.sporeFragmentChildScale),a.position.copy(e),Y.add(a),lh.push({spore:a,direction:t.clone(),generation:n,age:r.age??0})}function M_(e,t=1){let n=t===1?j.sporeFragmentCount:j.sporeFragmentChildCount,r=Math.random()*Math.PI*2;for(let i=0;i<n;i+=1){let a=r+i*(Math.PI*2/n);j_(new w(e.x,k.playerStartHeight,e.z),new w(Math.cos(a),0,Math.sin(a)),t)}}function N_(e){let t=e.position.clone();Y.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),A_(e);let n=Z.indexOf(e);n>=0&&Z.splice(n,1),M_(t)}function P_(e){let t=Zh();t.position.set(e.position.x,k.playerStartHeight,e.position.z);let n=kd(),r=(n?em.position:X.position).clone().sub(t.position);r.y=0,r.lengthSq()===0?r.set(0,0,1):r.normalize(),t.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),Y.add(t),sh.push({projectile:t,direction:r,age:0,distanceTravelled:0,maxRange:cf(`shooter`,zi.shooter.range),targetTower:n})}function F_(){for(let e=0;e<k.obstacleColliderIterations;e+=1)for(let e=0;e<Z.length-1;e+=1){let t=Z[e];for(let n=e+1;n<Z.length;n+=1){let r=Z[n],i=t.userData.colliderRadius+r.userData.colliderRadius,a=r.position.x-t.position.x,o=r.position.z-t.position.z,s=a*a+o*o;if(s>=i*i)continue;let c=zi[t.userData.type],l=zi[r.userData.type];t.userData.type===`creeper`&&l.speed===0&&(t.userData.staticCollisionSlow=k.creeperStaticCollisionSlowDuration),r.userData.type===`creeper`&&c.speed===0&&(r.userData.staticCollisionSlow=k.creeperStaticCollisionSlowDuration);let u=Math.sqrt(s),d=u>.001?a/u:(e+n)%2?1:-1,f=u>.001?o/u:0,p=(i-u)/2;t.position.x-=d*p,t.position.z-=f*p,r.position.x+=d*p,r.position.z+=f*p,dm(t.position),dm(r.position)}}}function I_(){if(Vh>0)return;let e=Ff(),t=e.availableFallingRockTypes.map(t=>({type:t,weight:e[`${t}SpawnWeight`]??0})),n=t.reduce((e,t)=>e+t.weight,0),r=Math.random()*n,i=t[t.length-1].type;for(let e of t)if(r-=e.weight,r<=0){i=e.type;break}let a=X.position.clone();a.x+=C.randFloatSpread(k.fallingRockImpactOffset*2),a.z+=C.randFloatSpread(k.fallingRockImpactOffset*2),dm(a),L_(a,void 0,i)}function L_(e,t,n=t?.type??`stoneRock`){let r=Bi[n],i=new l(Xh,new c({color:r.color,emissive:r.emissive,emissiveIntensity:r.emissiveIntensity,metalness:j.fallingObstacleMetalness,roughness:j.fallingObstacleRoughness}));i.position.set(e.x,k.fallingBlockStartHeight,e.z),i.castShadow=!0;let a=new l(new ie(1.15,32),new S({color:A.targetShadow,transparent:!0,opacity:.7,depthWrite:!1}));a.rotation.x=-Math.PI/2,a.position.set(e.x,.025,e.z);let o=new l(new Ae(1.18,1.3,32),new S({color:A.targetRing,transparent:!0,opacity:.95,side:2,depthWrite:!1}));o.rotation.x=-Math.PI/2,o.position.set(e.x,.03,e.z),Y.add(i,a,o),$m.push({obstacle:i,shadow:a,targetRing:o,target:e.clone(),type:n,age:t?.age??0,landed:t?.landed??!1,impactTriggered:t?.impactTriggered??!1}),t||hp.playFallingObstacle(e)}function R_(e){let t=Vi[e];if(!t)return;let n=Math.random()*Math.PI*2,r=new w(Math.cos(n),0,Math.sin(n)),i=um()+t.edgeOffset,a=r.clone().multiplyScalar(-i).setY(k.playerStartHeight),o=r.clone().multiplyScalar(i).setY(k.playerStartHeight),s=o.clone().sub(a).normalize(),c=a.distanceTo(o),u=ga(je);u.scale.setScalar(t.scale),u.position.copy(a),u.rotation.y=Math.atan2(s.x,s.z);let d=new Te(s,new w(a.x,.08,a.z),c,t.eyeColor,1.1,.54);d.line.material.transparent=!0,d.line.material.opacity=.82,d.cone.material.transparent=!0,d.cone.material.opacity=.94;let f=new l(new qe(t.sweepRadius,t.sweepRadius,c,12,1,!0),new S({color:t.emissive,transparent:!0,opacity:.05,depthWrite:!1}));f.position.copy(a).add(o).multiplyScalar(.5),f.position.y=.13,f.quaternion.setFromUnitVectors(new w(0,1,0),s),Y.add(u,d,f),eh.push({type:e,config:t,mesh:u,arrow:d,trail:f,start:a,end:o,direction:s,phase:`telegraph`,age:0,draggingPlayer:!1})}function z_(e){Y.remove(e.mesh,e.arrow,e.trail);let t=eh.indexOf(e);t>=0&&eh.splice(t,1)}function B_(e,t,n){for(let r=Xm.length-1;r>=0;--r)Q_(Xm[r].position,e,t)>n||(Y.remove(Xm[r]),Xm.splice(r,1));for(let r=Zm.length-1;r>=0;--r)Q_(Zm[r].position,e,t)>n||(Y.remove(Zm[r]),Zm.splice(r,1));for(let r=Qm.length-1;r>=0;--r){let i=Qm[r];Q_(i.position,e,t)>n||(Y.remove(i),Qm.splice(r,1))}}function V_(e,t){for(let n of[...eh]){if(n.age+=e,n.phase===`telegraph`){let e=.65+(Math.sin(t*11)+1)*.18;n.arrow.line.material.opacity=e,n.arrow.cone.material.opacity=Math.min(1,e+.2),n.trail.material.opacity=.04+(Math.sin(t*8)+1)*.025,n.age>=n.config.telegraphDuration&&(n.phase=`charge`,n.arrow.visible=!1,n.trail.material.opacity=.48);continue}let r=n.mesh.position.clone();n.mesh.position.addScaledVector(n.direction,n.config.speed*e),n.mesh.rotation.z=Math.sin(t*18)*.1;let i=n.mesh.userData.eyeMaterial;i&&(i.emissiveIntensity=3.2+Math.sin(t*24)*1.4);for(let r of n.mesh.userData.mandibles??[])r.rotation.z+=Math.sin(t*16+r.position.x)*e*.7;if(B_(r,n.mesh.position,n.config.sweepRadius),Q&&Q_(X.position,r,n.mesh.position)<=n.config.sweepRadius+k.playerRadius*.4){let e=Mh>0||Nh>0;vv(`VOID REAPER`),n.draggingPlayer||=e&&Q}n.draggingPlayer&&Q&&(X.position.copy(n.mesh.position).addScaledVector(n.direction,-n.config.sweepRadius*.4),X.position.y=k.playerStartHeight,dm(X.position)),n.mesh.position.clone().sub(n.end).dot(n.direction)>=0&&z_(n)}}function H_(e,t){_h.set(e.toLocaleLowerCase(),{id:e,spawn:t})}function U_(){for(let e of Object.keys(zi))H_(e,()=>D_(O_(),e));for(let e of Object.keys(Bi))H_(e,()=>L_(O_(),void 0,e));for(let e of Object.keys(Vi))H_(e,()=>R_(e))}U_();function W_(e,t){let n=new l(new qe(k.fieryRockFireRadius,k.fieryRockFireRadius*.82,.06,32),new S({color:A.fire,transparent:!0,opacity:.34,depthWrite:!1}));n.position.set(e.x,.05,e.z);let r=ug(e,k.fieryRockFireRadius);Y.add(n,...r.emitters,r.light),th.push({ground:n,...r,position:e.clone(),age:t?.age??0})}function G_(){let e=new o,n=new l(new ne(.38,1),new c({color:`#9af8ff`,emissive:`#4f5dff`,emissiveIntensity:2.8,metalness:.5,roughness:.14})),r=new l(new ne(.52,1),new S({color:`#b9faff`,transparent:!0,opacity:.24,wireframe:!0,depthWrite:!1})),i=new l(new be(.58,.025,8,28),new S({color:`#c8ffff`,transparent:!0,opacity:.9,depthWrite:!1}));i.rotation.x=Math.PI/2;let a=new t(`#74eaff`,3.5,5);return e.add(n,r,i,a),e.userData.ring=i,e}function K_(e){let t=G_();t.position.set(e?.position?.x??0,k.playerStartHeight,e?.position?.z??0),t.userData.phase=e?.phase??Math.random()*Math.PI*2,Y.add(t),Qm.push(t)}function q_(e,t){let n=k.poisonTrailDuration*(1-q(`poisonTrailDurationReduction`)),r=cg(e,j.poisonCreeperTrailRadius,n);Y.add(...r.emitters),nh.push({...r,position:e.clone(),age:t?.age??0})}function J_(e,t,n=0){let r=$h();r.position.copy(e),Y.add(r),rh.push({piece:r,direction:t,age:n})}function Y_(e){let t=Math.random()*Math.PI*2;for(let n=0;n<k.splinterPieceCount;n+=1){let r=t+n*(Math.PI*2/k.splinterPieceCount)+C.randFloatSpread(.35);J_(new w(e.x,.72,e.z),new w(Math.cos(r),0,Math.sin(r)))}}function X_(e){for(let t of e)Y.remove(t);e.length=0}function Z_(e,t){return Math.hypot(e.x-t.x,e.z-t.z)}function Q_(e,t,n){let r=n.x-t.x,i=n.z-t.z,a=r*r+i*i;if(a===0)return Math.hypot(e.x-t.x,e.z-t.z);let o=C.clamp(((e.x-t.x)*r+(e.z-t.z)*i)/a,0,1);return Math.hypot(e.x-(t.x+r*o),e.z-(t.z+i*o))}function $_(e,t,n){let r=Zd(`unlock-orbital-electron`)>0&&!zd&&!yh;if(jm.visible=r,Pm.visible=r,!r)return!1;Fm+=e*(k.orbitalElectronBaseSpeed+q(`electronSpeed`));let i=k.orbitalElectronOrbitRadius*n;jm.position.set(X.position.x+Math.cos(Fm)*i,X.position.y+.12+Math.sin(t*9)*.08,X.position.z+Math.sin(Fm)*i),jm.rotation.y+=e*8,Mm.scale.setScalar(.9+Math.sin(t*12)*.18);let a=Nm.attributes.position.array;for(let e=0;e<=8;e+=1){let n=e/8,r=e===0||e===8?0:Math.sin(t*34+e*4.7)*.12;a[e*3]=C.lerp(X.position.x,jm.position.x,n)+Math.sin(Fm)*r,a[e*3+1]=C.lerp(X.position.y,jm.position.y,n)+(e%2?.08:-.06)+r*.3,a[e*3+2]=C.lerp(X.position.z,jm.position.z,n)-Math.cos(Fm)*r}return Nm.attributes.position.needsUpdate=!0,Pm.material.opacity=.55+Math.sin(t*18)*.22,Im.copy(jm.position),!0}function ev(e,t){let n=ig(e,t);Y.add(...n.emitters,n.light),ih.push({...n,radius:t,age:0})}function tv(e,t,n){let r=ag(e);Y.add(r),oh.push({pulse:r,radius:t,age:0}),hp.playBangerPulse(n,e)}function nv(e,t,n=0,r=[]){let i=og(e);Y.add(i),dh.push({shockwave:i,origin:e.clone(),radius:t,age:n,affected:new Set(Z.filter(e=>r.includes(e.userData.id)))})}function rv(){let e=k.shockwaveBaseRadius*(1+q(`effectRange`));nv(X.position,e)}function iv(e){let t=lg(e);Y.add(...t.emitters,t.light),hh.push({...t,age:0})}function av(e){for(let t=hh.length-1;t>=0;--t){let n=hh[t];n.age+=e;let r=Math.min(n.age/k.playerDeathVfxDuration,1);n.light.intensity=22*(1-r),r===1&&(Y.remove(...n.emitters,n.light),hh.splice(t,1))}}function ov(e){let t=e.position.clone(),n=cf(`banger`,zi.banger.range),r=q(`bangerEnemyDestroyChance`),i=Z_(X.position,t)<=n;for(let i=Z.length-1;i>=0;--i){let a=Z[i];(a===e||Z_(a.position,t)<=n&&Math.random()<r)&&(Y.remove(a,a.userData.rangeIndicator,a.userData.magnetPulse),Z.splice(i,1))}ev(t,n),i&&vv(`BANGER DETONATION`)}function sv(e){let t=ia.challenges.find(e=>e.id===Td?.challengeId);if(!t||t.type!==`cell-scout`)return;let n=e?new w(e.x,e.y,e.z):new w().setFromCylindricalCoords(Math.min(um()-1.2,7.5),Math.random()*Math.PI*2,k.playerStartHeight);ym.player.position.copy(n),ym.player.rotation.y=e?.heading??0,ym.player.visible=!0,ym.slowAuraRing.visible=!1,ym.shieldBubble.visible=!1,ym.active=!0,Y.add(ym.player)}function cv(e,t){if(!ym.active)return;let n=Xm.reduce((e,t)=>!e||Z_(t.position,ym.player.position)<Z_(e.position,ym.player.position)?t:e,null);if(n){let t=n.position.clone().sub(ym.player.position);if(t.y=0,t.lengthSq()>0&&(t.normalize(),ym.player.position.addScaledVector(t,Sv()*.65*e),ym.player.rotation.y=Math.atan2(t.x,t.z)),ym.player.position.distanceTo(n.position)<k.cellPickupRadius){let e=Xm.indexOf(n);e>=0&&(Y.remove(n),Xm.splice(e,1))}}ym.updateVisuals(e,t,M.playerRingSpinSpeed)}function lv(e=!0){X_(Xm),X_(Zm),X_(Qm),X_(uh);for(let e of Z)Y.remove(e,e.userData.rangeIndicator,e.userData.magnetPulse),A_(e);Z.length=0;for(let e of lh)Y.remove(e.spore);lh.length=0;for(let e of $m)Y.remove(e.obstacle,e.shadow,e.targetRing);$m.length=0;for(let e of eh)Y.remove(e.mesh,e.arrow,e.trail);eh.length=0;for(let e of th)Y.remove(e.ground,...e.emitters,e.light);th.length=0;for(let e of nh)Y.remove(...e.emitters);nh.length=0;for(let e of rh)Y.remove(e.piece);rh.length=0;for(let e of ih)Y.remove(...e.emitters,e.light);ih.length=0;for(let e of ah)Y.remove(...e.emitters,e.light);ah.length=0;for(let e of oh)Y.remove(e.pulse);oh.length=0;for(let e of sh)Y.remove(e.projectile);sh.length=0;for(let e of ch)Y.remove(e.mesh);ch.length=0;for(let e of mh)Y.remove(e.mesh);mh.length=0;for(let e of dh)Y.remove(e.shockwave);dh.length=0;for(let e of ph)Y.remove(e.ring,e.glow);ph.length=0,fh.length=0;for(let e of hh)Y.remove(...e.emitters,e.light);hh.length=0;for(let e of gh)Y.remove(e.ring,e.glow,e.beam);gh.length=0,Y.remove(ym.player),ym.player.visible=!1,ym.active=!1,X.position.set(0,k.playerStartHeight,kd()?3:0),X.rotation.y=0,mm=0,X.visible=!0,Fm=0,jm.visible=!1,Pm.visible=!1,Sh=0,wh=0,Th=0,Eh=0,Dh=0,Oh=0,kh=0,Ah=0,Mh=Zd(`shield`),Nh=0,Ih=0,Lh=0,Rh=0,zh=0,Bh=0,Vh=0,Hh=0,Uh=0,Wh=0,Gh=0,bm.visible=!1,Tm.visible=!1,Em.visible=!1,km.visible=!1;for(let e of Am.values())e.visible=!1,e.geometry.setDrawRange(0,0);for(let e of wm)e.visible=!1;for(let e of Kh)Y.remove(e.trail);Kh.length=0,qh.clear();let t=kd()?Od():null;if(Dd=t?.towerHitpoints??0,em.visible=!!t,js.classList.toggle(`hidden`,!t),Fp(),vm.visible=Mh>0,Os.textContent=`000`,e){if(!t){for(let e=0;e<k.initialCellCount+q(`initialCellCount`);e+=1)b_();for(let e of k.initialObstacleTypes)Ff().availableObstacleTypes.includes(e)&&T_(e)}sv()}}function uv(e){return{x:e.x,y:e.y,z:e.z}}function dv(){U={sectorIndex:H,anomalyRun:Td,anomalyScout:ym.active?{...uv(ym.player.position),heading:ym.player.rotation.y}:null,player:uv(X.position),playerHeading:X.rotation.y,score:Sh,elapsed:wh,spawnTimer:Th,chronoCellTimer:Eh,aetheriumSpawnTimer:Dh,obstacleSpawnTimer:Oh,hazardTimer:kh,shockwaveTimer:Ah,shieldCharges:Mh,shieldInvulnerability:Nh,towerHealth:Dd,boosterTimer:Ih,speedBoosterTime:Lh,thornShieldTime:Rh,freezerTime:zh,weaponCharges:Object.fromEntries(Jh),weaponRechargeTimers:Object.fromEntries(Yh),cells:Xm.map(e=>({position:uv(e.position),phase:e.userData.phase,cashValue:e.userData.cashValue})),chronoCells:Zm.map(e=>({position:uv(e.position),phase:e.userData.phase,age:e.userData.age,isMapToEarth:!!e.userData.isMapToEarth})),aetheriumPickups:Qm.map(e=>({position:uv(e.position),phase:e.userData.phase})),boosters:uh.map(e=>({type:e.userData.type,position:uv(e.position)})),obstacles:Z.map(e=>({id:e.userData.id,position:uv(e.position),type:e.userData.type,age:e.userData.age,lifetimeAge:e.userData.lifetimeAge,speed:e.userData.speed,pulseTimer:e.userData.pulseTimer,shotCooldown:e.userData.shotCooldown,teleportTimer:e.userData.teleportTimer,poisonTrailTimer:e.userData.poisonTrailTimer,teleportTarget:e.userData.teleportTarget&&uv(e.userData.teleportTarget),magnetPulsePhase:e.userData.magnetPulsePhase,electronStunnedOnce:e.userData.electronStunnedOnce})),spores:lh.map(e=>({position:uv(e.spore.position),direction:uv(e.direction),generation:e.generation,age:e.age})),shooterProjectiles:sh.map(e=>({position:uv(e.projectile.position),direction:uv(e.direction),age:e.age,distanceTravelled:e.distanceTravelled,maxRange:e.maxRange,targetTower:!!e.targetTower})),fallingObstacles:$m.map(e=>({target:uv(e.target),type:e.type,age:e.age,landed:e.landed,impactTriggered:e.impactTriggered})),fireHazards:th.map(e=>({position:uv(e.position),age:e.age})),poisonTrails:nh.map(e=>({position:uv(e.position),age:e.age})),splinterPieces:rh.map(e=>({position:uv(e.piece.position),direction:uv(e.direction),age:e.age})),buildingRuntime:G.placed.map(e=>({id:e.id,timer:Rd.get(e.id)?.timer??0,active:Rd.get(e.id)?.active??0})),autocannonProjectiles:ch.map(e=>({position:uv(e.mesh.position),direction:uv(e.direction),destination:uv(e.destination),targetId:e.target.userData.id,age:e.age})),shockwaves:dh.map(e=>({origin:uv(e.origin),radius:e.radius,age:e.age,affectedIds:[...e.affected].map(e=>e.userData.id)})),shockwavePushes:fh.map(e=>({obstacleId:e.obstacle.userData.id,direction:uv(e.direction),distance:e.distance,remaining:e.remaining})),warnings:gh.map(e=>({position:uv(e.position),type:e.type,age:e.age}))},cd(U),lp()}function fv(){U=null,cd(null),lp()}function pv(){if(!U)return!1;H=Math.min(U.sectorIndex??0,pd()),Td=ia.challenges.some(e=>e.id===U.anomalyRun?.challengeId)?U.anomalyRun:null,fm(),lv(!1),X.position.set(U.player.x,U.player.y,U.player.z),X.rotation.y=U.playerHeading??0,mm=X.rotation.y,Sh=U.score??0,wh=U.elapsed??0,Th=U.spawnTimer??0,Eh=U.chronoCellTimer??0,Dh=U.aetheriumSpawnTimer??0,Oh=U.obstacleSpawnTimer??0,kh=U.hazardTimer??0,Ah=U.shockwaveTimer??0,Mh=U.shieldCharges??Zd(`shield`),Nh=U.shieldInvulnerability??0,Dd=U.towerHealth??Od()?.towerHitpoints??0,em.visible=kd(),Ih=U.boosterTimer??0,Lh=U.speedBoosterTime??0,Rh=U.thornShieldTime??0,zh=U.freezerTime??0;for(let e of W.loadout.filter(e=>Dp(e))){let t=Number(U.weaponCharges?.[e]);Jh.set(e,C.clamp(Number.isFinite(t)?t:1,0,Mp()));let n=Number(U.weaponRechargeTimers?.[e]);Yh.set(e,Number.isFinite(n)?Math.max(0,n):0)}vm.visible=Mh>0,sv(U.anomalyScout);for(let e of U.cells??[])b_(e);for(let e of U.chronoCells??[])x_(e);for(let e of U.aetheriumPickups??[])K_(e);for(let e of U.obstacles??[])D_(new w(e.position.x,e.position.y,e.position.z),e.type,e);for(let e of U.boosters??[])C_(e.type,e);for(let e of U.spores??[])j_(new w(e.position.x,e.position.y,e.position.z),new w(e.direction.x,e.direction.y,e.direction.z),e.generation??1,e);for(let e of U.shooterProjectiles??[]){let t=Zh();t.position.set(e.position.x,e.position.y,e.position.z),Y.add(t),sh.push({projectile:t,direction:new w(e.direction.x,e.direction.y,e.direction.z),age:e.age??0,distanceTravelled:e.distanceTravelled??0,maxRange:e.maxRange??cf(`shooter`,zi.shooter.range),targetTower:!!e.targetTower})}for(let e of U.fallingObstacles??[])L_(new w(e.target.x,e.target.y,e.target.z),e);for(let e of U.fireHazards??[])W_(new w(e.position.x,e.position.y,e.position.z),e);for(let e of U.poisonTrails??[])q_(new w(e.position.x,e.position.y,e.position.z),e);for(let e of U.splinterPieces??[])J_(new w(e.position.x,e.position.y,e.position.z),new w(e.direction.x,e.direction.y,e.direction.z),e.age);for(let e of U.buildingRuntime??[]){let t=Rd.get(e.id);t&&(t.timer=e.timer??0,t.active=e.active??0)}for(let e of U.autocannonProjectiles??[]){let t=Z.find(t=>t.userData.id===e.targetId);if(!t)continue;let n=Qh();n.position.set(e.position.x,e.position.y,e.position.z),Y.add(n),ch.push({mesh:n,direction:new w(e.direction.x,e.direction.y,e.direction.z),destination:new w(e.destination.x,e.destination.y,e.destination.z),target:t,age:e.age??0})}for(let e of U.shockwaves??[])nv(new w(e.origin.x,e.origin.y,e.origin.z),e.radius,e.age??0,e.affectedIds??[]);for(let e of U.shockwavePushes??[]){let t=Z.find(t=>t.userData.id===e.obstacleId);t&&fh.push({obstacle:t,direction:new w(e.direction.x,e.direction.y,e.direction.z),distance:e.distance,remaining:e.remaining})}for(let e of U.warnings??[])E_({...e,position:new w(e.position.x,e.position.y,e.position.z)});return bv(),!0}function mv(){Us.textContent=N(U?`menu.continue`:`menu.start_run`);let e=Dg(),t=md(ia.unlockSector);Ws.textContent=t?e?`${N(`anomaly.run`)} (${N(`anomaly.reward_claimed`)})`:N(`anomaly.run`):`${N(`anomaly.run`)} · ${N(`hud.sector`,{sector:Ia(ia.unlockSector)})}`,Ws.title=t?N(e?`anomaly.reward_claimed`:`anomaly.weekly`):N(`milestone.unlock_sector`,{sector:Ia(ia.unlockSector)}),Ws.disabled=!!U||e||!t||vg}async function hv(){if(!vg){vg=!0,_g=null,Ks.textContent=N(`anomaly.verifying_title`),qs.textContent=N(`anomaly.verifying_copy`),Js.hidden=!0,Ys.hidden=!0,Xs.hidden=!0,Zs.hidden=!0,Gs.classList.remove(`hidden`),mv();try{_g=await bg();let e=Sg(_g),t=Tg(e);Ks.textContent=`${t.name} (${N(`hud.sector`,{sector:Ia(H+1)})})`,qs.textContent=t.description,Js.textContent=N(`anomaly.reward`,{cells:t.rewardCellTarget??ia.rewardCellTarget,reward:Eg(H)}),Ys.textContent=N(`anomaly.reset`,{date:wg(Cg(_g))}),Js.hidden=!1,Ys.hidden=!1,Dg(e)?(Xs.textContent=N(`anomaly.reward_claimed`),Xs.hidden=!1):Zs.hidden=!1}catch{Ks.textContent=N(`anomaly.time_unverified_title`),qs.textContent=N(`anomaly.time_unverified_copy`),Xs.textContent=N(`anomaly.time_unverified_error`),Xs.hidden=!1}finally{vg=!1,mv()}}}function gv(){if(bh=!1,xh=!1,Cd){fv(),$=!1,Q=!1,tu.classList.add(`hidden`),Rs.textContent=`ASTEROID BELT`,Rs.classList.remove(`death-title`),Rg(),Vs.textContent=N(`message.sandbox_closed`),Hs.hidden=!0,$s.classList.remove(`hidden`),yc.classList.add(`hidden`),Fs.classList.remove(`hidden`);return}dv(),$=!1,Q=!1,tu.classList.add(`hidden`),Rs.textContent=`ASTEROID BELT`,Rs.classList.remove(`death-title`),Rg(),Vs.textContent=N(`message.round_saved`),Hs.hidden=!0,$s.classList.remove(`hidden`),yc.classList.add(`hidden`),Fs.classList.remove(`hidden`)}function _v(){let e=X.position.clone(),t=sg(e);Y.add(...t.emitters,t.light),ah.push({...t,age:0}),hp.playShieldBreak(e),Fh=Ph;let n=q(`shieldBreakExplosionRadius`);if(n<=0)return;let r=3+n;ev(e,r);for(let t=Z.length-1;t>=0;--t){let n=Z[t];Z_(n.position,e)>r||m_(n)}}function vv(e=`SIGNAL LOST`){if(!Q||yh||Ed||Nh>0)return;if(Mh>0){--Mh,Nh=k.shieldInvulnerabilityDuration+q(`shieldInvulnerabilityDuration`),_v(),vm.visible=Mh>0,vm.scale.setScalar(1.7);return}Q=!1,bh=!1,xh=!1,yh=!0,$=!1,vm.visible=!1,iv(X.position),X.visible=!1,jm.visible=!1,Pm.visible=!1,Zc.classList.add(`hidden`),tu.classList.add(`hidden`),fv(),Xf();let t=zg(e),n=e.toLocaleLowerCase().replace(/\s+(collision|detonation|projectile|impact|damage)$/,``);Rs.textContent=t?N(`message.killed_by`,{cause:``}).trim():N(`message.killed_by`,{cause:n.toUpperCase()}),Rs.classList.add(`death-title`),Vs.textContent=N(`message.energy_secured`,{count:Sh,cellWord:N(Sh===1?`message.cell_singular`:`message.cell_plural`)}),Hs.textContent=N(`message.tip`,{tip:Ru()}),Hs.hidden=!1,Us.textContent=N(`menu.run_again`),Fs.classList.remove(`hidden`),vu?.start(`first-loss`),Ad.researchLab&&Zd(`player-speed-multiplier`)===0&&vu?.start(`research-first-loss`),Wo()}function yv(e){!kd()||!Q||yh||(e&&Og(),Q=!1,bh=!1,xh=!1,yh=!0,$=!1,fv(),Xf(),Zc.classList.add(`hidden`),js.classList.add(`hidden`),tu.classList.add(`hidden`),Rs.textContent=N(e?`anomaly.tower_defended`:`anomaly.tower_destroyed`),Rs.classList.toggle(`death-title`,!e),Vs.textContent=N(e?`anomaly.tower_defended_copy`:`anomaly.tower_destroyed_copy`,{cells:Sh}),Hs.hidden=!0,Us.textContent=N(`menu.run_again`),Fs.classList.remove(`hidden`))}function bv(){Os.textContent=String(Sh).padStart(3,`0`),ks.textContent=Cd?N(`hud.sandbox_sector`,{sector:Ia(Cd.sectorIndex+1)}):`${N(`hud.sector`,{sector:Ia(H+1)})}${Td?N(`hud.anomaly_suffix`):``}`,As.innerHTML=`<span class="shield-indicators-label">${N(`hud.shields`)}</span>${Array.from({length:Mh},()=>`<img src="${Ts}" alt="">`).join(``)}`,As.hidden=Mh===0,As.setAttribute(`aria-label`,`${Mh} shield ${Mh===1?`charge`:`charges`} remaining`);let e=kd()?Od():null;js.classList.toggle(`hidden`,!Q||!e),e&&(Ms.textContent=N(`anomaly.tower_health`,{current:Dd,maximum:e.towerHitpoints}),Ns.style.transform=`scaleX(${C.clamp(Dd/e.towerHitpoints,0,1)})`)}function xv(){return Gh>0||kd()}function Sv(){return k.playerSpeed*(1+q(`playerSpeedMultiplier`))*(Lh>0?2:1)*(xv()?1.8:1)}function Cv(e,t){for(let e of qh.values())e.exposed=!1;let n=Ff(),r=kd()?Od()?.difficultyMultiplier??1:1,i=ns(Cd?.sectorIndex??H),a=C.lerp(.16,.03,H/Math.max(od.length-1,1)),o=(k.regularObstacleLifetime+n.obstacleLifetimeOffset+Sh*(k.regularObstacleLifetimeIncreasePerCell+n.obstacleLifetimeIncreasePerCellOffset))*Math.max(.5,1-q(`regularLifetimeDebuff`)),s=Math.max(1,o-Z.length*.1),c=Math.max(k.obstacleSpawnWarningDuration,(k.obstacleSpawnInterval+n.obstacleSpawnIntervalOffset-Sh*(k.obstacleSpawnDecreasePerCell+n.obstacleSpawnDecreasePerCellOffset))*(1-a)/r)/i,l=Math.max(1,Math.floor((k.obstacleSpawnCount+n.obstacleSpawnCountOffset+Sh*n.obstacleSpawnCountIncreasePerCell)*k.difficultyPressureMultiplier*r)),u=new w(!!Rm.has(`KeyD`)-+!!Rm.has(`KeyA`)+zm.x,0,!!Rm.has(`KeyS`)-+!!Rm.has(`KeyW`)+zm.y);u.lengthSq()>0&&(u.normalize(),X.position.addScaledVector(u,Sv()*e),mm=Math.atan2(u.x,u.z));let d=Math.atan2(Math.sin(mm-X.rotation.y),Math.cos(mm-X.rotation.y));X.rotation.y+=d*(1-Math.exp(-10*e)),dm(X.position),hm.updateVisuals(e,t,M.playerRingSpinSpeed);let f=Zd(`unlock-slow-aura`)>0,p=1+q(`effectRange`),m=k.slowAuraBaseRange*p,h=C.clamp(k.slowAuraBaseEffect+q(`slowAuraEffect`),0,.9);_m.visible=f,f&&(_m.scale.setScalar(m),_m.material.opacity=.22+Math.sin(t*3.5)*.08,_m.rotation.z+=e*.35);let g=$_(e,t,p);Nh>0&&(Nh=Math.max(0,Nh-e)),Lh=Math.max(0,Lh-e),Rh=Math.max(0,Rh-e),zh=Math.max(0,zh-e),Bh=Math.max(0,Bh-e),Vh=Math.max(0,Vh-e),Hh=Math.max(0,Hh-e),Uh=Math.max(0,Uh-e),Wh=Math.max(0,Wh-e),Gh=Math.max(0,Gh-e),Ip(e);let _=zp(`atmosphereShield`);if(bm.visible=Vh>0,Vh>0){let n=_>0?Vh/_:0;xm.rotation.z+=e*2.7,Sm.rotation.z-=e*1.5,bm.scale.setScalar(1+Math.sin(t*9)*.08),xm.material.opacity=.52+n*.38,Sm.material.opacity=.08+n*.18,Cm.material.opacity=.06+n*.18}if(Tm.visible=xv(),Em.visible=xv(),xv()){Tm.rotation.z+=e*5,Tm.scale.setScalar(1+Math.sin(t*14)*.12),Tm.material.opacity=.55+Math.sin(t*18)*.2,Em.rotation.y-=e*1.7,Em.scale.setScalar(1+Math.sin(t*16)*.14);for(let e of Em.children)e.material.opacity=.26+Math.sin(t*12+e.position.x*4)*.16}km.visible=Wh>0,Wh>0&&(km.material.rotation+=e*2.8,km.position.y=2.2+Math.sin(t*5)*.15,km.scale.setScalar(.65+Math.sin(t*7)*.08));for(let[e,n]of wm.entries()){if(n.visible=Uh>0,!n.visible)continue;let r=t*5+e*Math.PI*2/wm.length;n.position.set(Math.cos(r)*2.2,.55+Math.sin(r*2)*.18,Math.sin(r)*2.2),n.scale.setScalar(.9+Math.sin(t*12+e)*.18),n.getWorldPosition(Lm);for(let e of[...Z])e.position.distanceTo(Lm)<=e.userData.colliderRadius+.3&&(ev(e.position,.42),m_(e))}for(let t=Kh.length-1;t>=0;--t){let n=Kh[t];n.age+=e,n.trail.material.opacity=Math.max(0,.95-n.age*2.5),n.age>=.4&&(Y.remove(n.trail),Kh.splice(t,1))}for(let[t,n]of Am){let r=zp(t),i=Bp(t),a=r>0?C.clamp(i/r,0,1):0;if(n.visible=a>0,!n.visible){n.geometry.setDrawRange(0,0);continue}n.position.set(X.position.x,n.userData.height,X.position.z);let o=n.geometry.index?.count??0;n.geometry.setDrawRange(0,Math.max(3,Math.floor(o*a/3)*3)),n.rotation.z-=e*(1.1+a),n.material.opacity=.28+a*.65}if(Vp(),gm.material.emissive.set(`#000000`),gm.material.emissiveIntensity=0,Mh>0||Nh>0||Rh>0?(vm.visible=!0,vm.scale.setScalar(1+Math.sin(t*12)*.08+(Nh>0?.2:0)),vm.material.color.set(Rh>0?`#ff795f`:A.slowAura),vm.material.opacity=Rh>0||Nh>0?.65:.18):vm.visible=!1,Zd(`unlock-shockwave`)>0){Ah+=e;let t=k.shockwaveBaseInterval/(1+q(`shockwaveFrequency`));Ah>=t&&(rv(),Ah=0)}y_(e,t),cv(e,t);for(let n=Xm.length-1;n>=0;--n){let r=Xm[n];r.rotation.y+=e*M.cellSpinSpeed,r.position.y=M.cellBobBaseHeight+Math.sin(t*M.cellBobSpeed+r.userData.phase)*M.cellBobAmplitude;let i=q(`cellMagnetSpeed`),a=X.position.clone().sub(r.position);if(a.y=0,Bh>0?a.lengthSq()>0&&r.position.addScaledVector(a.normalize(),22*e):i>0&&a.length()<=k.cellMagnetRange*p&&r.position.addScaledVector(a.normalize(),(k.cellMagnetBaseSpeed+i)*e),r.position.distanceTo(X.position)<k.cellPickupRadius){hp.playCellCollect(r.position),Y.remove(r),Xm.splice(n,1);let e=(Wh>0?2:1)*Ch;Sh+=e,Cd||(rc?.record(`cells`),Lf(e),Rf(r.userData.cashValue*e),Jf(r.position,r.userData.cashValue*e)),Og()}}for(let n=uh.length-1;n>=0;--n){let r=uh[n];r.rotation.y+=e*3,r.position.y=k.playerStartHeight+Math.sin(t*4+n)*.16,r.position.distanceTo(X.position)<k.cellPickupRadius&&(w_(r.userData.type,r.position),Y.remove(r),uh.splice(n,1))}for(let n=Zm.length-1;n>=0;--n){let r=Zm[n];r.userData.age+=e;let i=k.chronoCellLifetime*(1+q(`chronoLifetimeMultiplier`)),a=r.userData.age/i;if(r.rotation.x+=e*M.chronoCellSpinSpeed,r.rotation.y+=e*M.chronoCellSpinSpeed*.7,r.position.y=M.cellBobBaseHeight+Math.sin(t*M.chronoCellBobSpeed+r.userData.phase)*M.chronoCellBobAmplitude,r.material.emissiveIntensity=j.chronoCellEmissiveIntensity+Math.sin(t*8)*.8,r.material.opacity=a>.7?1-(a-.7)/.3:1,r.userData.isMapToEarth)for(let e of r.children)e.material.opacity=r.material.opacity*.72;if(r.position.distanceTo(X.position)<k.cellPickupRadius){if(hp.playCellCollect(r.position),r.userData.isMapToEarth){np(Za.artifacts.find(e=>e.requirement.type===`hidden-world-map`))&&Yf(r.position,N(`artifact.acquired`),`chronoshard-indicator`),Y.remove(r),Zm.splice(n,1);continue}let e=zf(k.chronoCellChronoshardValue);Cd||rc?.record(`chronoPickups`),Yf(r.position,`+✦${P(e)}`,`chronoshard-indicator`),Y.remove(r),Zm.splice(n,1);continue}a>=1&&(Y.remove(r),Zm.splice(n,1))}for(let n=Qm.length-1;n>=0;--n){let r=Qm[n];r.rotation.y+=e*1.7,r.position.y=k.playerStartHeight+Math.sin(t*3.4+r.userData.phase)*.18,r.userData.ring.rotation.z+=e*2.5,!(r.position.distanceTo(X.position)>=k.cellPickupRadius)&&(hp.playCellCollect(r.position),Bf(Hf),Cd||rc?.record(`aetheriumPickups`),Yf(r.position,`+${Hf} AETHERIUM`,`aetherium-indicator`),Y.remove(r),Qm.splice(n,1))}V_(e,t);let v=[],y=[];for(let n=Z.length-1;n>=0;--n){let r=Z[n],i=zi[r.userData.type],a=cf(r.userData.type,i.range);if(Hh>0){r.userData.material.emissive.set(`#77c8ff`),r.userData.material.emissiveIntensity=2+Math.sin(t*12)*.5,r.rotation.y+=e*.35;continue}if(r.userData.lifetimeAge+=e,r.userData.lifetimeAge>s){m_(r,!1);continue}let o=s-r.userData.lifetimeAge;if(o<=k.obstacleDespawnWarningDuration){let e=1-o/k.obstacleDespawnWarningDuration,t=C.lerp(k.obstacleDespawnWarningStartFrequency,k.obstacleDespawnWarningEndFrequency,e);r.visible=Math.sin(r.userData.lifetimeAge*t*Math.PI*2)>-.1}else r.visible=!0;let c=X.position.clone().sub(r.position);c.y=0;let l=kd()?Od():null,u=em.position.clone().sub(r.position);u.y=0;let d=l?u:c,_=r.userData.type===`creeper`||r.userData.type===`poisonCreeper`;_&&(r.userData.staticCollisionSlow=Math.max(0,(r.userData.staticCollisionSlow??0)-e));let b=G.placed.filter(e=>e.type===`chronoGenerator`&&Z_(r.position,e)<=p_(e,`range`)).reduce((e,t)=>Math.max(e,p_(t,`slow`)),0);if(r.userData.material.emissive.set(i.emissive),r.userData.type===`poisonCreeper`){let e=(Math.sin(t*2.7+r.userData.speed)+1)/2;r.userData.material.color.lerpColors(fg,pg,e),r.userData.material.emissive.lerpColors(mg,hg,e),r.userData.material.emissiveIntensity=1.2+e*.75}if(b>0&&r.userData.material.emissive.lerp(pm,C.clamp(b*1.6,0,.82)),Rh>0&&c.length()<k.playerRadius){m_(r);continue}if(xv()&&c.length()<k.playerRadius+.3){ev(r.position,.5),m_(r);continue}r.userData.electronStun=Math.max(0,(r.userData.electronStun??0)-e),r.userData.electronHitCooldown=Math.max(0,(r.userData.electronHitCooldown??0)-e),g&&!r.userData.electronStunnedOnce&&r.userData.electronHitCooldown===0&&Q_(r.position,X.position,Im)<=k.orbitalElectronHitRadius+r.userData.colliderRadius&&(r.userData.electronStun=k.orbitalElectronBaseStunDuration+q(`electronStunDuration`),r.userData.electronStunMax=r.userData.electronStun,r.userData.electronHitCooldown=.18,r.userData.electronStunnedOnce=!0);let x=r.userData.electronImmunityMarker;if(x.visible=r.userData.electronStunnedOnce,x.visible&&(x.rotation.y+=e*1.8),r.userData.electronStun>0){let n=C.clamp(r.userData.electronStun/(r.userData.electronStunMax||1),0,1),i=r.userData.stunStars;i.visible=!0,i.rotation.y+=e*(5+n*7),i.scale.setScalar(.55+n*.45);for(let t of i.children)t.rotation.x+=e*8,t.rotation.z+=e*5,t.material.opacity=.08+n*.32;r.userData.material.emissive.set(`#5eeeff`),r.userData.material.emissiveIntensity=.8+Math.sin(t*26)*.3,r.rotation.y+=e*1.5;continue}if(r.userData.stunStars.visible=!1,r.userData.material.emissiveIntensity=1,zh>0)continue;let S=(f&&c.length()<=m?1-h:1)*(1-b),ee=q(`pushbackSpeed`);if(ee>0&&i.speed===0&&c.length()<=k.pushbackBaseRange*p){let t=r.position.clone().sub(X.position);t.y=0,t.lengthSq()>0&&r.position.addScaledVector(t.normalize(),(k.pushbackBaseSpeed+ee)*e)}let te=l&&r.userData.type===`regular`;if(!te&&(l||d.length()<=a)&&(i.speed>0||l)){let t=_?Math.max(.5,1-q(`creeperSpeedDebuff`)):1,n=_?Math.min(r.userData.lifetimeAge/s,1):0,a=l?.enemyMovementSpeeds?.[r.userData.type],o=l?a??Math.max(i.speed,1):_?C.lerp(i.speed,k.playerSpeed*.9,n):i.speed,c=_&&r.userData.staticCollisionSlow>0?k.creeperStaticCollisionSpeedMultiplier:1;r.position.addScaledVector(d.clone().normalize(),o*t*S*c*e)}if(r.userData.rangeIndicator){let e=r.userData.rangeIndicator,n=l||c.length()<=a,i=1+Math.sin(t*M.chaserRangeIndicatorPulseSpeed)*M.chaserRangeIndicatorPulseAmount;e.position.set(r.position.x,.025,r.position.z),e.scale.setScalar(n?i:1),e.material.opacity=n?M.chaserRangeIndicatorActiveOpacity:M.chaserRangeIndicatorBaseOpacity}if(r.userData.magnetPulse){let e=r.userData.magnetPulse,n=(t*.85+r.userData.magnetPulsePhase)%1;e.position.set(r.position.x,.035,r.position.z),e.scale.setScalar(a*(1.1-n*.9)),e.material.opacity=.5*(1-n)}let ne=r.userData.type;if(ne===`creeper`||ne===`poisonCreeper`)for(let e of r.userData.spikes??[])e.root.quaternion.copy(e.baseQuaternion),e.root.rotateX(Math.sin(t*4.6+e.phase)*.1),e.root.rotateZ(Math.cos(t*3.8+e.phase)*.075);if(ne===`porter`)for(let e of r.userData.spikes??[]){let n=.86+(Math.sin(t*4.4+e.phase)+1)*.12;e.root.scale.set(1,n,1)}if(r.rotation.y+=e*(ne===`chaser`?4.2:r.userData.speed*S),r.position.y=M.obstacleBobBaseHeight+Math.sin(t*M.obstacleBobSpeed+r.position.x)*M.obstacleBobAmplitude,r.userData.type===`poisonCreeper`&&(r.userData.poisonTrailTimer+=e,r.userData.poisonTrailTimer>=j.poisonCreeperTrailInterval&&(r.userData.poisonTrailTimer=0,q_(r.position))),r.userData.type===`creeper`||r.userData.type===`poisonCreeper`){let e=1.7+(Math.sin(t*5.4+r.userData.id.length)+1)*1.4;for(let t of r.userData.creeperTipMaterials??[])t.emissiveIntensity=e}if(r.userData.type===`banger`){r.userData.age+=e*S;let t=Math.min(r.userData.age/j.bangerFuseDuration,1),n=(Math.sin(r.userData.age*M.bangerFusePulseSpeed)+1)/2;r.userData.bangerFlash=Math.max(0,(r.userData.bangerFlash??0)-e*4.8),r.userData.material.emissive.set(`#ff160d`),r.userData.material.emissiveIntensity=M.bangerFuseEmissiveBaseIntensity+n*M.bangerFuseEmissivePulseAmount+r.userData.bangerFlash*4,r.userData.pulseTimer=(r.userData.pulseTimer??0)+e*S;let i=C.lerp(k.bangerPulseStartInterval,k.bangerPulseEndInterval,t);r.userData.pulseTimer>=i&&(tv(r.position,a,t),r.userData.bangerFlash=1,r.userData.pulseTimer=0),r.userData.age>=j.bangerFuseDuration&&v.push(r);continue}if(r.userData.type===`shooter`&&(r.userData.shotCooldown=Math.max(0,r.userData.shotCooldown-e),(l?u.length():c.length())<=a&&r.userData.shotCooldown===0&&(P_(r),r.userData.shotCooldown=j.shooterProjectileCooldown)),r.userData.type===`magnet`&&c.length()<=a){let t=r.position.clone().sub(X.position);t.y=0,t.lengthSq()>0&&X.position.addScaledVector(t.normalize(),j.magnetPullSpeed*Math.max(.5,1-q(`magnetStrengthDebuff`))*e)}if(r.userData.type===`porter`){r.userData.teleportTimer+=e;let n=j.porterTeleportInterval*(1+q(`porterIntervalBonus`)),i=n-j.porterWarningDuration;if(r.userData.teleportTimer>=i&&!r.userData.teleportTarget&&(r.userData.teleportTarget=O_(),k_(r)),r.userData.teleportTarget){let e=(Math.sin(t*22)+1)/2;r.userData.material.emissiveIntensity=.8+e*3,r.userData.teleportEffect.ring.scale.setScalar(1+e*.35),r.userData.teleportEffect.ring.material.opacity=.45+e*.5,r.userData.teleportEffect.beam.material.opacity=.14+e*.3}r.userData.teleportTimer>=n&&(r.position.copy(r.userData.teleportTarget),A_(r),r.userData.teleportTarget=null,r.userData.teleportTimer=0,r.userData.material.emissiveIntensity=1)}if(r.userData.type===`spore`){r.userData.age+=e;let t=r.userData.hdrEmissionScale??.5;r.userData.material.emissiveIntensity=(2.2+(Math.sin(r.userData.age*10)+1)*1.5)*t,r.userData.age>=j.sporeFuseDuration&&y.push(r)}if(!te&&l&&u.length()<=l.towerRadius+r.userData.colliderRadius){kg(l.towerContactDamage),m_(r,!1);continue}v_(r),r.position.distanceTo(X.position)<k.playerRadius&&(xv()?(ev(r.position,.5),m_(r)):vv(`${r.userData.type.toUpperCase()} COLLISION`))}F_();for(let e of v)Z.includes(e)&&ov(e);for(let e of y)Z.includes(e)&&N_(e);for(let t=lh.length-1;t>=0;--t){let n=lh[t];n.age+=e;let r=Math.min(n.age/j.sporeFragmentDuration,1),i=j.sporeFragmentSpeed*(1-r)*Math.max(.5,1-q(`sporeSpeedDebuff`));if(n.spore.position.addScaledVector(n.direction,i*e),n.spore.rotation.x+=e*7,n.spore.rotation.z+=e*5,r>=1){n.generation===1&&M_(n.spore.position,2),Y.remove(n.spore),n.spore.userData.material?.dispose(),lh.splice(t,1);continue}Math.hypot(n.spore.position.x,n.spore.position.z)>um()&&(Y.remove(n.spore),n.spore.userData.material?.dispose(),lh.splice(t,1))}for(let t=sh.length-1;t>=0;--t){let n=sh[t];n.age+=e;let r=j.shooterProjectileSpeed*Math.max(.5,1-q(`shooterProjectileSpeedDebuff`))*e;n.projectile.position.addScaledVector(n.direction,r),n.distanceTravelled+=r,n.projectile.rotation.x+=e*9,n.projectile.rotation.y+=e*12;let i=n.targetTower?em.position:X.position,a=n.targetTower?Od()?.towerRadius??1.15:k.playerRadius;if(n.projectile.position.distanceTo(i)<a+j.shooterProjectileRadius){Y.remove(n.projectile),sh.splice(t,1),n.targetTower?kg(Od()?.towerProjectileDamage??1):vv(`SHOOTER PROJECTILE`);continue}n.distanceTravelled>=n.maxRange&&(Y.remove(n.projectile),sh.splice(t,1))}for(let t=ih.length-1;t>=0;--t){let n=ih[t];n.age+=e;let r=Math.min(n.age/k.bangerExplosionVfxDuration,1);n.light.intensity=10*(1-r),r===1&&(Y.remove(...n.emitters,n.light),ih.splice(t,1))}for(let t=ah.length-1;t>=0;--t){let n=ah[t];n.age+=e;let r=Math.min(n.age/.42,1);n.light.intensity=12*(1-r),r===1&&(Y.remove(...n.emitters,n.light),ah.splice(t,1))}for(let t=oh.length-1;t>=0;--t){let n=oh[t];n.age+=e;let r=Math.min(n.age/k.bangerPulseVfxDuration,1);n.pulse.scale.setScalar(C.lerp(.2,n.radius/.42,r)),n.pulse.material.opacity=.9*(1-r),r===1&&(Y.remove(n.pulse),oh.splice(t,1))}for(let t=dh.length-1;t>=0;--t){let n=dh[t];n.age+=e;let r=Math.min(n.age/k.shockwaveVfxDuration,1);n.shockwave.scale.setScalar(C.lerp(.25,n.radius/.42,r)),n.shockwave.material.opacity=.95*(1-r);let i=n.radius*r;for(let e of Z){if(n.affected.has(e))continue;let t=e.position.clone().sub(n.origin);t.y=0;let r=t.length();r>i||(n.affected.add(e),r<.01?t.set(Math.random()-.5,0,Math.random()-.5).normalize():t.normalize(),fh.push({obstacle:e,direction:t,distance:k.shockwavePushDistance*(1-r/n.radius),remaining:.28}))}r===1&&(Y.remove(n.shockwave),dh.splice(t,1))}for(let t=ph.length-1;t>=0;--t){let n=ph[t];n.age+=e;let r=Math.min(n.age/n.duration,1),i=n.radius*r;n.ring.scale.setScalar(C.lerp(.2,n.radius/.58,r)),n.glow.scale.setScalar(C.lerp(.08,n.radius,r)),n.ring.material.opacity=.98*(1-r*.38),n.glow.material.opacity=.24*(1-r);for(let e of n.targets)n.hit.has(e)||!Z.includes(e)||Math.hypot(e.position.x-n.origin.x,e.position.z-n.origin.z)>i||(n.hit.add(e),ev(e.position,.82),m_(e));r===1&&(Y.remove(n.ring,n.glow),ph.splice(t,1))}for(let t=fh.length-1;t>=0;--t){let n=fh[t];if(!Z.includes(n.obstacle)){fh.splice(t,1);continue}let r=Math.min(e/n.remaining,1);n.obstacle.position.addScaledVector(n.direction,n.distance*r),dm(n.obstacle.position),n.distance*=1-r,n.remaining-=e,n.remaining<=0&&fh.splice(t,1)}let b=k.fallingBlockDuration/rs(Cd?.sectorIndex??H),x=b+(k.fallingBlockLifetime-k.fallingBlockDuration);for(let t=$m.length-1;t>=0;--t){let n=$m[t];n.age+=e;let r=n.landed?1:Math.min(n.age/b,1),i=1-(1-r)**3;n.obstacle.position.y=C.lerp(k.fallingBlockStartHeight,k.fallingBlockGroundHeight,i),n.obstacle.rotation.x+=e*M.fallingObstacleSpinXSpeed,n.obstacle.rotation.z+=e*M.fallingObstacleSpinZSpeed,n.shadow.scale.setScalar(M.targetShadowBaseScale+r*M.targetShadowScaleGrowth),n.shadow.material.opacity=M.targetShadowBaseOpacity+r*M.targetShadowOpacityGrowth;let a=1+Math.sin(n.age*M.targetRingPulseSpeed)*M.targetRingPulseAmount;n.targetRing.scale.setScalar((M.targetRingBaseScale+r*M.targetRingScaleGrowth)*a),n.targetRing.material.opacity=M.targetRingBaseOpacity-r*M.targetRingOpacityFade;let o=X.position.distanceTo(n.target);if(!n.landed&&r>.82&&o<k.playerRadius&&(n.type===`fieryRock`?Tv(`fire`,`fiery-rock-impact`):vv(`METEOR IMPACT`)),r===1){if(n.landed=!0,!n.impactTriggered){n.impactTriggered=!0;let e=dg(n.target,.9,Bi[n.type].color);Y.add(...e.emitters),n.type===`fieryRock`&&W_(n.target),n.type===`splinter`&&Y_(n.target)}n.obstacle.position.y=k.fallingBlockGroundHeight,n.shadow.material.opacity=Math.max(0,.88-(n.age-b)*1.8),n.targetRing.material.opacity=Math.max(0,.55-(n.age-b)*1.5),n.age>x&&(Y.remove(n.obstacle,n.shadow,n.targetRing),$m.splice(t,1))}}for(let t=th.length-1;t>=0;--t){let n=th[t];n.age+=e;let r=n.age/k.fieryRockFireDuration,i=1+Math.sin(n.age*9)*.1,a=Math.max(0,1-r);n.ground.scale.setScalar(i*(.9+r*.2)),n.ground.material.opacity=.34*a,n.light.intensity=Math.max(0,(5.5+Math.sin(n.age*14))*a),Z_(X.position,n.position)<k.fieryRockFireRadius&&Tv(`fire`,`fiery-rock`),r>=1&&(Y.remove(n.ground,...n.emitters,n.light),th.splice(t,1))}for(let t=nh.length-1;t>=0;--t){let n=nh[t];n.age+=e;let r=k.poisonTrailDuration*(1-q(`poisonTrailDurationReduction`)),i=n.age/r;Math.max(0,1-i),Z_(X.position,n.position)<j.poisonCreeperTrailRadius&&Tv(`poison`,`poison-creeper-trail`),i>=1&&(Y.remove(...n.emitters),nh.splice(t,1))}let S=Ev(e,t);if(S){let e=.3+(Math.sin(t*18)+1)*.2;gm.material.emissive.set(S.color),gm.material.emissiveIntensity=e}for(let t=rh.length-1;t>=0;--t){let n=rh[t];n.age+=e;let r=k.splinterPieceDistance/k.splinterPieceDuration;n.piece.position.addScaledVector(n.direction,r*e),n.piece.rotation.x+=e*8,n.piece.rotation.z+=e*6,n.piece.position.distanceTo(X.position)<k.playerRadius*.7&&vv(`SPLINTER IMPACT`),n.age>=k.splinterPieceDuration&&(Y.remove(n.piece),rh.splice(t,1))}for(let t=gh.length-1;t>=0;--t){let n=gh[t];n.age+=e;let r=n.age/k.obstacleSpawnWarningDuration,i=1+Math.sin(n.age*M.spawnRingPulseSpeed)*M.spawnRingPulseAmount;n.ring.scale.setScalar((M.spawnRingBaseScale+r*M.spawnRingScaleGrowth)*i),n.ring.material.opacity=M.spawnRingBaseOpacity*(1-r),n.ring.rotation.z-=e*2;let a=1+Math.sin(n.age*M.spawnRingPulseSpeed*.55)*M.spawnCueGlowPulseAmount;n.glow.scale.setScalar(a*(.85+r*.25)),n.glow.material.opacity=M.spawnCueGlowBaseOpacity*(1-r*.3),n.beam.scale.set(.8+r*.2,1,.8+r*.2),n.beam.material.opacity=M.spawnCueBeamBaseOpacity*(1-r*.45),n.beam.rotation.y+=e*1.6,r>=1&&(Z.length<If()&&D_(n.position,n.type),Y.remove(n.ring,n.glow,n.beam),gh.splice(t,1))}Th+=e,Ih+=e,Eh+=e,Dh+=e,Oh+=e,kh+=e;let ee=q(`cellSpawnRate`)+Sh*q(`cellSpawnRatePerCell`),te=!kd()&&(!Cd||Cd.simulation.has(`cell`)),ne=!Cd||Cd.simulation.has(`enemies`),re=!Cd||Cd.simulation.has(`boosters`);if(te&&Th>k.cellSpawnInterval/(1+ee)&&(b_(),Th=0),re&&Ih>k.boosterSpawnInterval){let e=[Zd(`unlock-speed-booster`)>0&&`speed`,Zd(`thorn-shield`)>0&&`thorn`,Zd(`freezer`)>0&&`freezer`].filter(Boolean);e.length&&C_(e[Math.floor(Math.random()*e.length)]),Ih=0}if(te&&Eh>k.chronoCellSpawnInterval/(1+q(`chronoSpawnRate`))&&(x_(),Eh=0),Dh>=120&&(K_(),Dh=0),ne&&Oh>c){let e=Math.max(0,If()-Z.length-gh.length);for(let t=0;t<Math.min(l,e);t+=1)E_();Oh=0}let ie=Math.max(k.fallingBlockMinInterval/k.fallingRockSpawnFrequencyMultiplier,(k.fallingBlockBaseInterval+n.fallingRockSpawnIntervalOffset-Sh*(k.fallingBlockIntervalPerCell+n.fallingRockSpawnDecreasePerCellOffset))*(1-a)/k.fallingRockSpawnFrequencyMultiplier)/i;if(!kd()&&ne&&kh>ie&&(I_(),kh=0),wh+=e,Q&&!Cd&&(ac+=e,ac>=1)){let e=Math.floor(ac);ac-=e,rc?.record(`playSeconds`,e)}bv()}function wv(e){requestAnimationFrame(wv);let t=K.gameplay.maxFps;if(t>0){let n=1e3/t;if(jh!==null&&e<jh)return;let r=jh??e;jh=r+(Math.floor(Math.max(0,e-r)/n)+1)*n}else jh=null;vh.update(e);let n=Math.min(vh.getDelta(),.05),r=vh.getElapsed();if(Q&&!$&&!bh&&Cv(n,r),av(n),Qp.update(n),zd)tm.position.set(Gm.x,Km,Gm.y+.01),tm.lookAt(Gm.x,0,Gm.y);else{if(tm.position.set(X.position.x,Wv(),X.position.z+Uv()),Fh>0){let e=(Fh/Ph)**1.5;tm.position.x+=C.randFloatSpread(.22)*e,tm.position.y+=C.randFloatSpread(.14)*e,tm.position.z+=C.randFloatSpread(.22)*e,Fh=Math.max(0,Fh-n)}tm.lookAt(X.position.x,0,X.position.z)}zd&&i_(),rm.position.copy(tm.position),K.graphics.hdrEmissionIntensity>0?_p.render():gp.render(Y,tm),Bg(n)}function Tv(e,t=`unknown`){let n=co[e];if(!n||!Q||yh||Nh>0||n.immunityResearchId&&Zd(n.immunityResearchId)>0)return!1;if(Mh>0)return vv(),!1;let r=qh.get(e);return r?(r.exposed=!0,!n.requiresExposure&&n.refreshOnReapply&&(r.remaining=n.duration),!0):(qh.set(e,{type:e,source:t,remaining:n.duration,maxDuration:n.duration,exposed:!0}),!0)}function Ev(e,t){let n=null;for(let[t,r]of qh){let i=co[t];if(i.requiresExposure&&!r.exposed){qh.delete(t);continue}if(r.remaining-=e,r.remaining<=0){qh.delete(t),vv(N(`status.damage`,{status:i.label.toUpperCase()}));continue}(!n||r.remaining/r.maxDuration>n.remaining/n.maxDuration)&&(n=r)}return n?co[n.type]:null}function Dv(e,t){let n=new l(new Ae(.2,.58,96),new S({color:`#ff795f`,transparent:!0,opacity:1,side:2,depthWrite:!1}));n.rotation.x=-Math.PI/2,n.position.set(e.x,.1,e.z);let r=new l(new Ae(.01,1,96),new S({color:`#ffbe75`,transparent:!0,opacity:.22,side:2,depthWrite:!1}));r.rotation.x=-Math.PI/2,r.position.set(e.x,.075,e.z),Y.add(n,r),ph.push({origin:e.clone(),ring:n,glow:r,radius:um()*1.1,age:0,duration:2.2,targets:new Set(t),hit:new Set}),ev(e,2.1)}function Ov(){Wl();let e={en:`language.english`,tr:`language.turkish`,es:`language.spanish`};nl.innerHTML=Zi().map(t=>`<option value="${t}">${N(e[t]??`language.${t}`,{},t)}</option>`).join(``),nl.value=K.language,ll.innerHTML=[`low`,`medium`,`high`].map(e=>`<button data-graphics-quality="${e}" class="${K.graphics.quality===e?`selected`:``}" type="button">${N(`settings.${e}`)}</button>`).join(``),ul.checked=K.graphics.shadows;let t=Math.round(K.graphics.hdrEmissionIntensity*100);dl.value=String(t),fl.value=`${t}%`,pl.value=K.gameplay.maxFps,ml.value=K.gameplay.maxFps===0?N(`settings.unlimited`):`${K.gameplay.maxFps} FPS`,hl.checked=K.gameplay.autoPause,gl.checked=K.gameplay.highContrastHud,_l.value=K.sound.masterVolume,vl.value=`${K.sound.masterVolume}%`,yl.checked=K.sound.muted,bl.checked=K.sound.spatialAudio,document.querySelector(`.game-shell`).classList.toggle(`high-contrast-hud`,K.gameplay.highContrastHud),kv()}async function kv(){if(!rl||!il||!window.steamShell?.getDisplaySettings)return;let e=await window.steamShell.getDisplaySettings();rl.innerHTML=`<button data-display-mode="fullscreen" class="${e.fullscreen?`selected`:``}" type="button">${N(`settings.fullscreen`)}</button><button data-display-mode="windowed" class="${e.fullscreen?``:`selected`}" type="button">${N(`settings.windowed`)}</button>`,il.innerHTML=[[1280,720],[1600,900],[1920,1080],[2560,1440]].filter(([t,n])=>t<=e.maxWidth&&n<=e.maxHeight).map(([t,n])=>`<button data-display-resolution="${t}x${n}" class="${!e.fullscreen&&e.width===t&&e.height===n?`selected`:``}" type="button">${t}×${n}</button>`).join(``)}function Av(){Fd(),hp.setMasterVolume(),Ov()}function jv(){return bh?(xh&&lv(),bh=!1,xh=!1,vu?.completeActiveStep(),Q=!0,$=!1,hp.initialize(),U||la({sector:H+1,buildVersion:na.version,platform:window.steamShell?`steam`:`web`}),!0):!1}function Mv(e=!1,{waitForFirstInput:t=!0}={}){if(e&&!_g)return;hp.initialize().catch(()=>{}),hp.playButtonClick();let n=!!U,r=t;n?pv():(Cd=null,Td=e?{challengeId:Tg().id,weekId:Sg()}:null,lv(!r)),Q=!r,bh=r,xh=r&&!n,yh=!1,$=!1,Rs.classList.remove(`death-title`),Rg(),yc.classList.add(`hidden`),$s.classList.remove(`hidden`),Fs.classList.add(`hidden`),Gs.classList.add(`hidden`),Hp(),!n&&!r&&la({sector:H+1,buildVersion:na.version,platform:window.steamShell?`steam`:`web`})}Us.addEventListener(`click`,()=>{yu?.mode===`run-again`&&ju(),bu?.mode===`start-run`&&Nu(),Mv()}),Ws.addEventListener(`click`,hv),Qs.addEventListener(`click`,()=>Gs.classList.add(`hidden`)),Zs.addEventListener(`click`,()=>Mv(!0));function Nv(){ec.classList.add(`hidden`),yc.classList.add(`hidden`),xl.classList.add(`hidden`),kl.classList.add(`hidden`),Rl.classList.add(`hidden`),Fc.classList.add(`hidden`),Vc.classList.add(`hidden`),Tc.classList.add(`hidden`),kc.classList.add(`hidden`),Mc.classList.add(`hidden`),el.classList.add(`hidden`),sl.classList.add(`hidden`),cc.classList.add(`hidden`),Gs.classList.add(`hidden`),mc.classList.add(`hidden`)}var Pv=new Map([[ec,tc],[yc,bc],[xl,Sc],[Fc,Cc],[Tc,wc],[kc,Oc],[el,Qc]]);function Fv(e=xc){document.querySelectorAll(`.menu-system-button`).forEach(t=>t.classList.toggle(`is-active`,t===e))}function Iv(){Nv(),$s.classList.remove(`hidden`),Fv()}function Lv(e,t){Nv(),$s.classList.add(`hidden`),e.classList.remove(`hidden`),Fv(Pv.get(e)),t?.()}xc.addEventListener(`click`,e=>{e.stopPropagation(),Iv()}),tc.addEventListener(`click`,e=>{e.stopPropagation(),Lv(ec,nc.open)}),document.querySelector(`#close-market-button`).addEventListener(`click`,Iv),bc.addEventListener(`click`,e=>{e.stopPropagation(),!U&&Tf(`researchLab`,bc)&&(uf(),Lv(yc,df),xu?.mode===`research-entry`&&Fu(`research-category`,ql.querySelector(`[data-toggle-research-category="Player Enhancements"]`)))}),Qc.addEventListener(`click`,e=>{e.stopPropagation(),Lv(el,Ov)}),ol.addEventListener(`click`,()=>Lv(sl)),$c?.addEventListener(`click`,()=>{if(window.dispatchEvent(new Event(`asteroid-belt:exit-requested`)),window.steamShell?.quit){window.steamShell.quit();return}window.close()}),al.addEventListener(`click`,()=>{el.classList.add(`hidden`),$s.classList.remove(`hidden`)}),cl.addEventListener(`click`,()=>{sl.classList.add(`hidden`),el.classList.remove(`hidden`)}),el.addEventListener(`click`,e=>{let t=e.target.closest(`[data-graphics-quality]`);t&&(K.graphics.quality=t.dataset.graphicsQuality,wp(),Av())}),nl.addEventListener(`change`,()=>{K.language=nl.value,Xi(K.language),Fd(),window.location.reload()}),el.addEventListener(`click`,async e=>{let t=e.target.closest(`[data-display-mode]`)?.dataset.displayMode,n=e.target.closest(`[data-display-resolution]`)?.dataset.displayResolution;if(t&&window.steamShell?.setFullscreen&&await window.steamShell.setFullscreen(t===`fullscreen`),n&&window.steamShell?.setResolution){let[e,t]=n.split(`x`).map(Number);await window.steamShell.setResolution(e,t)}(t||n)&&kv()}),ul.addEventListener(`change`,()=>{K.graphics.shadows=ul.checked,wp(),Av()}),dl.addEventListener(`input`,()=>{K.graphics.hdrEmissionIntensity=Number(dl.value)/100,wp(),Av()}),pl.addEventListener(`input`,()=>{K.gameplay.maxFps=Number(pl.value),Av()}),hl.addEventListener(`change`,()=>{K.gameplay.autoPause=hl.checked,Av()}),gl.addEventListener(`change`,()=>{K.gameplay.highContrastHud=gl.checked,Av()}),_l.addEventListener(`input`,()=>{K.sound.masterVolume=Number(_l.value),Av()}),yl.addEventListener(`change`,()=>{K.sound.muted=yl.checked,Av()}),bl.addEventListener(`change`,()=>{K.sound.spatialAudio=bl.checked,Av()}),zl.addEventListener(`click`,()=>{yc.classList.add(`hidden`),$s.classList.remove(`hidden`)}),Fs.addEventListener(`click`,e=>{let t=e.composedPath();!yc.classList.contains(`hidden`)&&!t.includes(yc)&&(yc.classList.add(`hidden`),$s.classList.remove(`hidden`)),!el.classList.contains(`hidden`)&&!t.includes(el)&&(el.classList.add(`hidden`),$s.classList.remove(`hidden`)),!xl.classList.contains(`hidden`)&&!t.includes(xl)&&!t.includes(kl)&&(kl.classList.add(`hidden`),xl.classList.add(`hidden`),$s.classList.remove(`hidden`)),!Fc.classList.contains(`hidden`)&&Vc.classList.contains(`hidden`)&&!t.includes(Fc)&&(Fc.classList.add(`hidden`),$s.classList.remove(`hidden`)),!Tc.classList.contains(`hidden`)&&!t.includes(Tc)&&(Tc.classList.add(`hidden`),$s.classList.remove(`hidden`)),!kc.classList.contains(`hidden`)&&!t.includes(kc)&&!t.includes(Mc)&&(Mc.classList.add(`hidden`),kc.classList.add(`hidden`),$s.classList.remove(`hidden`),Fv())}),Sc.addEventListener(`click`,e=>{e.stopPropagation(),!(U||!Tf(`buildingSystem`,Sc))&&Lv(xl,s_)}),Cc.addEventListener(`click`,e=>{e.stopPropagation(),!(U||Q||!Tf(`weaponry`,Cc))&&Lv(Fc,Up)}),wc.addEventListener(`click`,e=>{e.stopPropagation(),Lv(Tc,jg)}),Oc.addEventListener(`click`,e=>{e.stopPropagation(),Lv(kc,sp)}),Ec.addEventListener(`click`,()=>{Tc.classList.add(`hidden`),$s.classList.remove(`hidden`)}),Ac.addEventListener(`click`,()=>{Mc.classList.add(`hidden`),kc.classList.add(`hidden`),$s.classList.remove(`hidden`),Fv()}),jc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-artifact-id]`);t&&cp(t.dataset.artifactId)}),Pc.addEventListener(`click`,()=>Mc.classList.add(`hidden`)),Ic.addEventListener(`click`,()=>{Fc.classList.add(`hidden`),$s.classList.remove(`hidden`)}),Rc.addEventListener(`click`,()=>qp(1)),zc.addEventListener(`click`,()=>qp(5)),qc.addEventListener(`click`,Jp),Xc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-weapon]`);t&&Yp(t.dataset.toggleWeapon)}),Yc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-weapon-slot]`);Q||!t||(W.selected=Number(t.dataset.selectWeaponSlot),Tp(),Up())}),Zc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-use-weapon]`);t&&Xp(t.dataset.useWeapon)}),Sl.addEventListener(`click`,()=>{kl.classList.add(`hidden`),xl.classList.add(`hidden`),$s.classList.remove(`hidden`)}),Ol.addEventListener(`click`,()=>{Jg(),kl.classList.remove(`hidden`)}),Al.addEventListener(`click`,()=>kl.classList.add(`hidden`)),Dl.addEventListener(`click`,c_),Ll.addEventListener(`click`,l_),kl.addEventListener(`click`,e=>{let t=e.target.closest(`[data-building-offer]`);t&&Kg(t.dataset.buildingOffer)}),Nl.addEventListener(`click`,e=>{let t=e.target.closest(`[data-select-building]`);t&&(Bd=t.dataset.selectBuilding,s_())}),Il.addEventListener(`click`,e=>{if(Ym){Ym=!1;return}let t=e.target.closest(`[data-build-x]`);t&&o_(Number(t.dataset.buildX),Number(t.dataset.buildZ))}),Rl.addEventListener(`click`,e=>{let t=e.target.closest(`[data-upgrade-building]`),n=e.target.closest(`[data-destroy-building]`);if(e.target.closest(`[data-close-building-upgrade]`)){Rl.classList.add(`hidden`);return}if(n){let e=G.placed.find(e=>e.id===n.dataset.destroyBuilding);if(!e||!window.confirm(N(`building.demolish_confirm`,{building:da.types[e.type].name,refund:P(Qg(e))})))return;Rf(Qg(e)),G.placed=G.placed.filter(t=>t.id!==e.id),Hg(),e_(),s_(),Rl.classList.add(`hidden`);return}if(t){let e=G.placed.find(e=>e.id===t.dataset.upgradeBuilding);if(!e)return;let n=Zg(e,t.dataset.upgradeKey);if(yd<n)return;Rf(-n),e.upgrades[t.dataset.upgradeKey]=(e.upgrades[t.dataset.upgradeKey]??0)+1,e.spent=(e.spent??da.types[e.type].baseCost)+n,Hg(),e_(),u_(e)}}),yc.addEventListener(`click`,e=>{let t=e.target.closest(`[data-toggle-research-category]`),n=e.target.closest(`[data-start-research]`),r=e.target.closest(`[data-unlock-slot]`);if(t){let e=t.dataset.toggleResearchCategory;Wd.has(e)?Wd.delete(e):Wd.add(e),df(),xu?.mode===`research-category`&&e===`Player Enhancements`&&Fu(`research-upgrade`,ql.querySelector(`[data-start-research="player-speed-multiplier"]`));return}n&&ff(n.dataset.startResearch)&&xu?.mode===`research-upgrade`&&n.dataset.startResearch===`player-speed-multiplier`&&Iu(),r&&pf(Number.parseInt(r.dataset.unlockSlot,10))}),Jl.addEventListener(`input`,()=>{Vd=Jl.value,df()}),Yl.addEventListener(`change`,()=>{Hd=Yl.checked,df()}),Xl.addEventListener(`change`,()=>{Ud=Xl.checked,df()}),nu.addEventListener(`click`,()=>{fv(),lv(!1),bh=!0,xh=!0,$=!1,Q=!1,tu.classList.add(`hidden`)}),ru.addEventListener(`click`,()=>{zd&&l_(),fv(),Cd=null,Td=null,lv(!0),bh=!1,xh=!1,$=!1,Q=!1,yh=!1,tu.classList.add(`hidden`),Zc.classList.add(`hidden`),Rs.textContent=`ASTEROID BELT`,Rs.classList.remove(`death-title`),Rg(),Vs.textContent=N(`message.run_surrendered`),Hs.hidden=!0,Iv(),Fs.classList.remove(`hidden`)}),iu.addEventListener(`click`,()=>{$=!1,tu.classList.add(`hidden`)}),au.addEventListener(`click`,gv),Ps.addEventListener(`click`,()=>{vu?.isActiveStep(`quick-start`)||Q&&($=!$,tu.classList.toggle(`hidden`,!$))}),document.addEventListener(`click`,e=>{if(tu.classList.contains(`hidden`))return;let t=e.composedPath();t.includes(tu)||t.includes(Ps)||($=!1,tu.classList.add(`hidden`))}),eu.addEventListener(`click`,()=>mf(!1)),Ql.addEventListener(`keydown`,e=>{e.key===`Enter`&&(e.preventDefault(),Pf(Ql.value),Ql.value=``),e.key===`Escape`&&(e.preventDefault(),mf(!1)),e.stopPropagation()}),window.addEventListener(`keydown`,e=>{if(Zl.classList.contains(`hidden`)&&!(ic?.isOpen()&&e.key!==ta.hotkey)){if(e.key===`Escape`&&Q&&!vu?.isActiveStep(`quick-start`)){e.preventDefault(),$=!$,tu.classList.toggle(`hidden`,!$);return}if(ta.enabled&&e.key===ta.hotkey){e.preventDefault(),mf();return}if(jv(),Q&&!$&&e.code===`ArrowUp`){e.preventDefault(),W.selected=(W.selected-1+Math.max(W.loadout.length,1))%Math.max(W.loadout.length,1),Hp();return}if(Q&&!$&&e.code===`ArrowDown`){e.preventDefault(),W.selected=(W.selected+1)%Math.max(W.loadout.length,1),Hp();return}if(Q&&!$&&e.code===`Space`){e.preventDefault(),Xp();return}[`ArrowUp`,`ArrowDown`,`ArrowLeft`,`ArrowRight`].includes(e.code)&&e.preventDefault(),Rm.add(e.code)}}),window.addEventListener(`keyup`,e=>Rm.delete(e.code));function Rv(){return window.matchMedia(`(max-width: 580px), (hover: none) and (pointer: coarse)`).matches}function zv(){let[e,t]=qm.values();return Math.hypot(e.x-t.x,e.y-t.y)}function Bv(e){return!zd||!Rv()||e.button!==0?!1:(e.preventDefault(),qm.set(e.pointerId,{x:e.clientX,y:e.clientY}),qm.size===2&&(Jm={distance:zv(),height:Km}),!0)}function Vv(e){let t=qm.get(e.pointerId);if(!t||!zd)return;e.preventDefault();let n={x:e.clientX,y:e.clientY};if(qm.set(e.pointerId,n),qm.size===1){let e=n.x-t.x,r=n.y-t.y;if(Math.hypot(e,r)<.5)return;let i=2*Km*Math.tan(C.degToRad(Fi.fov/2));Gm.x-=e/window.innerWidth*i*tm.aspect,Gm.y-=r/window.innerHeight*i,Ym=!0}else if(qm.size===2&&Jm){let e=zv();e>0&&(Km=C.clamp(Jm.height*Jm.distance/e,Um,Wm)),Ym=!0}}function Hv(e){qm.delete(e.pointerId)&&(qm.size<2&&(Jm=null),Ym&&window.setTimeout(()=>{Ym=!1},250))}function Uv(){return window.matchMedia(`(orientation: portrait)`).matches?Fi.portraitDistance:Fi.landscapeDistance}function Wv(){return Uv()*Math.tan(C.degToRad(Fi.angle))}function Gv(e){if(!Vm)return;let t=e.clientX-Vm.x,n=e.clientY-Vm.y,r=Math.hypot(t,n),i=Math.min(r,Hm),a=r?i/r:0,o=t*a,s=n*a,c=r<8?0:i/Hm;zm.set(o/Hm*c,s/Hm*c),gu.querySelector(`.virtual-joystick-knob`).style.transform=`translate(${o}px, ${s}px)`}function Kv(e){e&&e.pointerId!==Bm||(Bm=null,Vm=null,zm.set(0,0),gu.classList.remove(`active`),gu.querySelector(`.virtual-joystick-knob`).style.transform=``)}Ds.addEventListener(`pointerdown`,e=>{if(zd){Bv(e);return}e.button===0&&jv(),!(!Rv()||!Q||$||e.button!==0||Bm!==null)&&(e.preventDefault(),Bm=e.pointerId,Vm={x:e.clientX,y:e.clientY},gu.style.left=`${e.clientX}px`,gu.style.top=`${e.clientY}px`,gu.classList.add(`active`),Ds.setPointerCapture(e.pointerId),Gv(e))}),Ds.addEventListener(`pointermove`,e=>{e.pointerId===Bm&&(e.preventDefault(),Gv(e))}),Ds.addEventListener(`pointerup`,Kv),Ds.addEventListener(`pointercancel`,Kv),Ds.addEventListener(`lostpointercapture`,Kv),Il.addEventListener(`pointerdown`,Bv),window.addEventListener(`pointermove`,Vv,{passive:!1}),window.addEventListener(`pointerup`,Hv),window.addEventListener(`pointercancel`,Hv),window.addEventListener(`blur`,()=>{Rm.clear(),Kv()}),document.addEventListener(`visibilitychange`,()=>{!document.hidden||!K.gameplay.autoPause||!Q||$||($=!0,tu.classList.remove(`hidden`))}),window.addEventListener(`resize`,()=>{Ef(),tm.aspect=window.innerWidth/window.innerHeight,tm.updateProjectionMatrix(),gp.setSize(window.innerWidth,window.innerHeight),_p.setSize(window.innerWidth,window.innerHeight),zd&&i_()}),Ls?.addEventListener(`click`,e=>{let t=Number(e.target.closest(`[data-save-slot]`)?.dataset.saveSlot);!Number.isInteger(t)||t<1||t>Vu||(localStorage.setItem(zu,String(t)),sessionStorage.setItem(Bu,String(t)),window.location.reload())});async function qv(){}Xo({storage:localStorage,currencyKeys:{cash:Ku,chronoshards:qu,aetherium:Ju},artifactsKey:id,artifacts:Za.artifacts,scope:`slot-${Hu}`,onCommit(e){yd=e.balances.cash,bd=e.balances.chronoshards,xd=e.balances.aetherium,_d=e.artifacts,Rf(),zf(),Bf(),sp(),Up(),fm(),e_(),ec.classList.contains(`hidden`)||nc.render()}}),fm(),e_(),lf(),Lf(),Rf(),zf(),Bf(),mp(),df(),Ov(),tp(),sp(),ip(),mv(),Fv(),lv(),rc=us({repository:ls({storage:localStorage,stateKey:ad,aetheriumKey:Ju,chronoshardsKey:qu,onReward(){xd=Aa(Ju),bd=Aa(qu),Bf(),zf(),Up(),ec.classList.contains(`hidden`)||nc.render()}}),getMaxTier:()=>pd()+1}),ic=ps({service:rc,overlay:document.querySelector(`#daily-missions-overlay`),button:document.querySelector(`#open-daily-missions`),getBalances:()=>({aetherium:xd,chronoshards:bd}),onOpen(){oc=$,$=!0,Rm.clear()},onClose(){$=oc}}),setInterval(()=>{rc.refresh(),ic.render()},1e3);var Jv;function Yv(){clearTimeout(Jv);let e=Math.max(1,rc.getState().calendar.nextDayAt-Date.now());Jv=setTimeout(()=>{rc.refresh(),Yv()},e)}Yv(),document.addEventListener(`visibilitychange`,()=>{document.hidden||(rc.refresh(),ic.render())}),Is&&(Is.hidden=!0),qv(),wv(),vu=ys({isSteamBuild:bs,startTutorialRun:()=>Mv(),startFirstLossGuidance:Au,startSecondSectorGuidance:Mu,startFirstResearchGuidance:Pu,onStepStarted:e=>{e.id===`quick-start`&&Cu(),e.id===`first-loss-guidance`&&(Hs.hidden=!0)},onStepCompleted:e=>{e.id===`quick-start`&&wu()}}),vu.start(),setInterval(()=>{(lf()||!yc.classList.contains(`hidden`))&&df()},1e3);export{Si as n,_o as t};